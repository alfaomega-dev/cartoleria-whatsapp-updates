@echo off
title WhatsApp Print Service 🖨️
color 0A
echo ============================================
echo      AVVIO SERVIZIO STAMPA WHATSAPP
echo ============================================
echo.
echo [1/2] Verifica connessione internet...
ping -n 1 google.com >nul
if errorlevel 1 (
    echo [ERRORE] Nessuna connessione internet. Verificare il cavo o il Wi-Fi.
    pause
    exit
)

echo [2/3] Pulizia vecchi processi in sospeso...
taskkill /F /T /IM PrintZap.exe >nul 2>&1
echo.
echo [3/3] Avvio Server e Dashboard...
echo.
echo [INFO] Dashboard accessibile su: http://localhost:3000
echo [INFO] Scansiona il QR code che apparirà tra poco per connetterti.
echo.
:: Avvia il server usando PrintZap.exe se esiste, altrimenti fallback su node.exe
if exist "%~dp0PrintZap.exe" (
    "%~dp0PrintZap.exe" "%~dp0whatsapp.js"
) else (
    "%~dp0node.exe" "%~dp0whatsapp.js"
)


if errorlevel 1 (
    echo.
    echo [ERRORE] Impossibile avviare il server. Assicurati che non ci siano altre istanze attive.
    pause
)
