// Modulo per l'applicazione delle patch di compatibilità nel browser (Puppeteer)
// Estratto da whatsappClient.js (Fase 6A del piano di modularizzazione).
// Spostamento 1:1 identico per garantire stabilità e prevenire regressioni.

async function applyBrowserCompatibilityPatches(page) {
    if (!page || page.isClosed()) return;
    try {
        await page.evaluate(() => {
            // 1. String.prototype.isBot - fondamentale quando remote è una stringa serializzata
            if (typeof String.prototype.isBot !== 'function') {
                String.prototype.isBot = function () {
                    return (this.includes && (this.includes('@bot') || this.includes('bot@'))) ? true : false;
                };
            }

            // 2. Wid.prototype.isBot
            try {
                const Wid = window.require && window.require('WAWebWid');
                if (Wid && Wid.prototype && typeof Wid.prototype.isBot !== 'function') {
                    Wid.prototype.isBot = function () {
                        return (this && this.server && this.server.includes('bot')) ? true : false;
                    };
                }
                const WidFactory = window.require && window.require('WAWebWidFactory');
                if (WidFactory) {
                    const sample = WidFactory.createWid('393330000000@c.us');
                    if (sample && sample.constructor && sample.constructor.prototype && typeof sample.constructor.prototype.isBot !== 'function') {
                        sample.constructor.prototype.isBot = function () {
                            return (this && this.server && this.server.includes('bot')) ? true : false;
                        };
                    }
                }
            } catch (e) {}

            // 3. WAWebWamMsgUtils.getWamAgentEngagementType wrapper protetto
            try {
                const WamUtils = window.require && window.require('WAWebWamMsgUtils');
                if (WamUtils && WamUtils.getWamAgentEngagementType && !WamUtils.getWamAgentEngagementType._patched) {
                    const orig = WamUtils.getWamAgentEngagementType;
                    WamUtils.getWamAgentEngagementType = function (e) {
                        try {
                            if (e && e.id && e.id.remote && typeof e.id.remote.isBot !== 'function') {
                                e.id.remote.isBot = () => false;
                            }
                            return orig.apply(this, arguments);
                        } catch (err) {
                            return null;
                        }
                    };
                    WamUtils.getWamAgentEngagementType._patched = true;
                }
            } catch (e) {}

            // 4. Object.prototype.equals & String.prototype.equals - previene crash c.equals is not a function
            const getComparable = (x) => {
                if (x == null) return '';
                if (typeof x === 'string') return x;
                if (x._serialized) return String(x._serialized);
                if (x.user && x.server) return x.user + '@' + x.server;
                if (x.user) return String(x.user);
                if (x.id) {
                    if (typeof x.id === 'string') return x.id;
                    if (x.id._serialized) return String(x.id._serialized);
                    if (x.id.user) return String(x.id.user);
                }
                if (typeof x.toString === 'function' && x.toString !== Object.prototype.toString) {
                    try { return x.toString(); } catch (e) { return ''; }
                }
                return '';
            };

            const safeEquals = function (other) {
                if (this === other) return true;
                if (other == null) return false;
                const a = getComparable(this);
                const b = getComparable(other);
                if (a && b) {
                    if (a === b) return true;
                    const userA = a.split('@')[0];
                    const userB = b.split('@')[0];
                    if (userA && userB && userA === userB) return true;
                }
                return false;
            };

            if (typeof Object.prototype.equals !== 'function') {
                Object.defineProperty(Object.prototype, 'equals', {
                    value: safeEquals,
                    writable: true,
                    configurable: true,
                    enumerable: false
                });
            }

            if (typeof String.prototype.equals !== 'function') {
                Object.defineProperty(String.prototype, 'equals', {
                    value: safeEquals,
                    writable: true,
                    configurable: true,
                    enumerable: false
                });
            }
        });
    } catch (err) {
        // Silenzioso se la pagina non è ancora pronta
    }
}

module.exports = {
    applyBrowserCompatibilityPatches
};
