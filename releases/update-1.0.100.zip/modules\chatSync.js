// Modulo dedicato alla sincronizzazione chat, risoluzione contatti e riconciliazione all'avvio.
// Estratto da whatsappClient.js (Fase 5 del piano di modularizzazione).
// Mantiene inalterata la logica di business e la consistenza con SQLite e file system.

const fs = require('fs');
const path = require('path');
const { promiseTimeout } = require('./session');
const { repairMismatchedFolders: defaultRepairFolders, deleteFilesWithCleanup: defaultDeleteFiles, deleteFileWithCleanup: defaultDeleteFile } = require('./helpers');
const { getMessageId: defaultGetMessageId } = require('./whatsappUtils');

let isSyncingContacts = false;
let lastSyncContactTime = 0;
const SYNC_COOLDOWN_MS = 5 * 60 * 1000; // Cooldown 5 minuti

let isReconcilingStartup = false;

/**
 * Sposta la cartella di un contatto su disco se rinominata o associata a un nuovo nome cliente.
 */
function moveContactFolderOnDisk(phone, newFolder, printFolder, logger = console) {
    try {
        if (!phone || !newFolder || !printFolder) return;
        const targetDir = path.join(printFolder, newFolder);
        
        const possibleOldFolders = [
            path.join(printFolder, phone.trim()),
            path.join(printFolder, phone.replace(/[^a-z0-9]/gi, '_'))
        ];

        for (const oldDir of possibleOldFolders) {
            if (fs.existsSync(oldDir) && oldDir !== targetDir) {
                if (!fs.existsSync(targetDir)) {
                    fs.mkdirSync(targetDir, { recursive: true });
                }
                const files = fs.readdirSync(oldDir);
                for (const file of files) {
                    const src = path.join(oldDir, file);
                    const dest = path.join(targetDir, file);
                    try {
                        if (!fs.existsSync(dest)) {
                            fs.renameSync(src, dest);
                        }
                    } catch (e) {
                        if (logger && typeof logger.warn === 'function') {
                            logger.warn(`⚠️ Errore spostamento file ${file}:`, e.message);
                        }
                    }
                }
                try {
                    if (fs.readdirSync(oldDir).length === 0) {
                        fs.rmdirSync(oldDir);
                    }
                } catch (e) {}
            }
        }
    } catch (err) {
        if (logger && typeof logger.warn === 'function') {
            logger.warn(`⚠️ Errore moveContactFolderOnDisk per ${phone}:`, err.message);
        }
    }
}

/**
 * Gestisce l'eliminazione di una chat rimossa o cancellata su WhatsApp.
 */
async function handleChatRemoved(chatId, contactName = null, phone = null, {
    clientInstance,
    getClient,
    dbInstance,
    deleteFilesFn = defaultDeleteFiles,
    notifyDashboardFn,
    logger = console
} = {}) {
    if (!chatId && !contactName && !phone) return;
    if (chatId && String(chatId).includes('@g.us')) return;
    if (logger && typeof logger.info === 'function') {
        logger.info(`🗑️ [handleChatRemoved] Richiesta rimozione chat: ID "${chatId || ''}", Nome: "${contactName || ''}", Tel: "${phone || ''}"`);
    }

    const client = typeof getClient === 'function' ? getClient() : clientInstance;

    try {
        const candidates = new Set();
        if (chatId) {
            candidates.add(chatId);
            const rawId = String(chatId).replace(/@c\.us|@lid/g, '');
            candidates.add(rawId);
            candidates.add(rawId.replace(/\D/g, ''));
        }
        if (phone) {
            candidates.add(phone);
            candidates.add(String(phone).replace(/\D/g, ''));
        }

        // Se è un account LID, prova a recuperare il numero di telefono reale
        if (client && chatId && String(chatId).endsWith('@lid')) {
            try {
                if (typeof client.getContactLidAndPhone === 'function') {
                    const res = await client.getContactLidAndPhone(chatId).catch(() => null);
                    if (res && res[0] && res[0].pn) {
                        const cleanPn = res[0].pn;
                        candidates.add(cleanPn);
                        candidates.add(cleanPn.replace(/[^0-9]/g, ''));
                    }
                }
            } catch (e) {}
        }

        const candidateList = Array.from(candidates).filter(Boolean);
        const resolvedContactName = (contactName && typeof contactName === 'string' && contactName.trim()) ? contactName.trim() : null;

        if (logger && typeof logger.info === 'function') {
            logger.info(`🔍 [handleChatRemoved] Ricerca ordini per candidati (${candidateList.join(', ')}), nome cliente: "${resolvedContactName || ''}"`);
        }

        if (!dbInstance) return;

        // 1. Recupera gli ordini associati al contatto
        const orders = await dbInstance.getOrdersByContact(candidateList, resolvedContactName);

        if (orders && orders.length > 0) {
            if (logger && typeof logger.info === 'function') {
                logger.info(`🗑️ [handleChatRemoved] Trovati ${orders.length} ordini per "${resolvedContactName || chatId}"`);
            }

            // 2. Raccoglie i file fisici da inviare al Cestino di Windows
            const filesToDelete = orders.map(o => o.file).filter(Boolean);
            if (filesToDelete.length > 0 && typeof deleteFilesFn === 'function') {
                deleteFilesFn(filesToDelete);
                if (logger && typeof logger.info === 'function') {
                    logger.info(`🗑️ [handleChatRemoved] Spostati nel Cestino ${filesToDelete.length} file di stampa.`);
                }
            }

            // 3. Elimina gli ordini dal database SQLite
            await dbInstance.deleteOrdersByContact(candidateList, resolvedContactName);
            if (logger && typeof logger.info === 'function') {
                logger.info(`✅ [handleChatRemoved] Eliminati ${orders.length} ordini dal database per "${resolvedContactName || chatId}".`);
            }
        } else {
            // Elimina comunque eventuali record orfani
            await dbInstance.deleteOrdersByContact(candidateList, resolvedContactName);
            if (logger && typeof logger.info === 'function') {
                logger.info(`ℹ️ [handleChatRemoved] Pulizia completata nel database per "${resolvedContactName || chatId}".`);
            }
        }

        // 4. Notifica immediata alla Dashboard
        if (typeof notifyDashboardFn === 'function') {
            notifyDashboardFn({ type: 'ORDERS_UPDATED' });
        }
    } catch (err) {
        if (logger && typeof logger.error === 'function') {
            logger.error(`❌ Errore in handleChatRemoved per "${contactName || chatId}":`, err);
        }
    }
}

/**
 * Risolve e sincronizza i nomi dei contatti numerici con la rubrica/chat WhatsApp.
 */
async function syncContactNames(force = false, {
    clientInstance,
    getClient,
    wpStatus,
    getWpStatus,
    dbInstance,
    printFolder,
    repairMismatchedFoldersFn = defaultRepairFolders,
    moveContactFolderFn = moveContactFolderOnDisk,
    logger = console
} = {}) {
    const client = typeof getClient === 'function' ? getClient() : clientInstance;
    const currentWpStatus = typeof getWpStatus === 'function' ? getWpStatus() : wpStatus;
    if (!client || currentWpStatus !== 'CONNECTED') return;
    if (isSyncingContacts) {
        if (logger && typeof logger.info === 'function') {
            logger.info('ℹ️ syncContactNames già in corso, richiesta ignorata.');
        }
        return;
    }
    const now = Date.now();
    if (!force && (now - lastSyncContactTime < SYNC_COOLDOWN_MS)) {
        return;
    }

    isSyncingContacts = true;
    lastSyncContactTime = now;

    try {
        if (typeof repairMismatchedFoldersFn === 'function') {
            await repairMismatchedFoldersFn();
        }

        if (!dbInstance) return;

        const orders = await dbInstance.getOrders(9999);
        const numericContacts = new Map();
        orders.forEach(o => {
            if (!o.telefono || o.telefono.startsWith('tg_') || o.telefono.includes('@')) return;
            const clientTrimmed = o.cliente ? o.cliente.trim() : '';
            if (o.telefono && clientTrimmed && (clientTrimmed === o.telefono.trim() || /^[\d\s+\-()]+$/.test(clientTrimmed))) {
                numericContacts.set(o.telefono, clientTrimmed);
            }
        });

        if (numericContacts.size === 0) return;

        if (logger && typeof logger.info === 'function') {
            logger.info(`🔄 syncContactNames: trovati ${numericContacts.size} contatti con nome numerico da risolvere...`);
        }

        let chatNameMap = new Map();
        try {
            const allChats = await promiseTimeout(client.getChats(), 10000, 'getChats() for syncContactNames');
            allChats.forEach(chat => {
                if (!chat.isGroup && chat.id && chat.id.user && chat.name && !/^[\d\s+\-()]+$/.test(chat.name.trim())) {
                    chatNameMap.set(chat.id.user, chat.name);
                }
            });
            if (logger && typeof logger.info === 'function') {
                logger.info(`📋 syncContactNames: ${chatNameMap.size} chat caricate come mappa di fallback.`);
            }
        } catch (chatErr) {
            if (logger && typeof logger.warn === 'function') {
                logger.warn('⚠️ syncContactNames: impossibile caricare le chat per fallback:', chatErr.message);
            }
        }

        for (const [phone, currentName] of numericContacts.entries()) {
            try {
                let resolvedName = null;

                if (chatNameMap.has(phone)) {
                    resolvedName = chatNameMap.get(phone);
                    if (logger && typeof logger.info === 'function') {
                        logger.info(`✅ Nome risolto via chatMap: ${phone} -> ${resolvedName}`);
                    }
                }

                if (!resolvedName) {
                    const candidateJids = phone.includes('@')
                        ? [phone]
                        : [`${phone}@c.us`, `${phone}@lid`];

                    for (const jid of candidateJids) {
                        try {
                            const contact = await promiseTimeout(client.getContactById(jid), 4000, `getContactById(${jid})`);
                            if (contact && (contact.name || contact.pushname)) {
                                const nameCandidate = contact.name || contact.pushname;
                                if (nameCandidate && !/^[\d\s+\-()]+$/.test(nameCandidate.trim())) {
                                    resolvedName = nameCandidate;
                                    break;
                                }
                            }
                        } catch (e) {
                            if (logger && typeof logger.info === 'function') {
                                logger.info(`ℹ️ getContactById(${jid}) fallito: ${e.message}`);
                            }
                        }

                        if (resolvedName) break;

                        try {
                            const chat = await promiseTimeout(client.getChatById(jid), 4000, `getChatById(${jid})`);
                            if (chat && chat.name && !/^[\d\s+\-()]+$/.test(chat.name.trim())) {
                                resolvedName = chat.name;
                                break;
                            }
                        } catch (e) {
                            if (logger && typeof logger.info === 'function') {
                                logger.info(`ℹ️ getChatById(${jid}) fallito: ${e.message}`);
                            }
                        }
                    }
                }

                if (resolvedName && !/^[\d\s+\-()]+$/.test(resolvedName.trim())) {
                    const safeName = resolvedName.replace(/[^a-z0-9]/gi, '_');
                    if (typeof moveContactFolderFn === 'function') {
                        moveContactFolderFn(phone, safeName, printFolder, logger);
                    }
                    await dbInstance.updateContactOrdersFolder(phone, resolvedName, safeName);
                    if (logger && typeof logger.info === 'function') {
                        logger.info(`✅ Nome contatto aggiornato: ${phone} (${currentName}) -> ${resolvedName}`);
                    }
                } else {
                    if (logger && typeof logger.info === 'function') {
                        logger.info(`ℹ️ Nome NON risolto per: ${phone} (${currentName}) — contatto non trovato in rubrica.`);
                    }
                }
            } catch (err) {
                if (logger && typeof logger.warn === 'function') {
                    logger.warn(`⚠️ Errore risoluzione nome per ${phone}:`, err.message);
                }
            }
        }
    } catch (err) {
        if (logger && typeof logger.error === 'function') {
            logger.error('Errore durante la risoluzione dei nomi contatti:', err);
        }
    } finally {
        isSyncingContacts = false;
    }
}

/**
 * Verifica e riconciliazione contatti all'avvio: rimuove ordini di chat eliminate
 * e riconcilia lo stato "Stampa Pronta" se inviato antecedentemente.
 */
async function reconcileStartupContacts(clientOrGetClient, {
    isReadyFn,
    dbInstance,
    handleChatRemovedFn,
    isReadyResponseFn,
    handleMerchantReadyMessageFn,
    logger = console
} = {}) {
    const client = typeof clientOrGetClient === 'function' ? clientOrGetClient() : clientOrGetClient;
    if (isReconcilingStartup || !client) return;
    if (typeof isReadyFn === 'function' && !isReadyFn()) return;

    isReconcilingStartup = true;
    if (logger && typeof logger.info === 'function') {
        logger.info('🔄 [Controllo Avvio] Avvio verifica e riconciliazione contatti all\'avvio...');
    }

    try {
        const allChats = await promiseTimeout(client.getChats(), 15000, 'client.getChats() for startup reconciliation');
        if (!allChats || !Array.isArray(allChats) || allChats.length < 5) {
            if (logger && typeof logger.info === 'function') {
                logger.info('ℹ️ [Controllo Avvio] Riconciliazione rinviata: lista chat WhatsApp non ancora pronta o incompleta.');
            }
            return;
        }

        // 1. Mappa rapida di tutte le chat WhatsApp attualmente esistenti
        const waChatMap = new Map();
        const waNamesSet = new Set();

        for (const chat of allChats) {
            if (chat.isGroup) continue;
            const cid = chat.id?._serialized || chat.id;
            const user = chat.id?.user;
            if (cid) waChatMap.set(cid, chat);
            if (user) waChatMap.set(user, chat);
            if (chat.contact?.number) waChatMap.set(chat.contact.number, chat);

            const name = (chat.name || chat.formattedTitle || '').trim().toLowerCase();
            if (name) waNamesSet.add(name);
        }

        // 2. Recupera tutti gli ordini attivi dal database SQLite
        if (!dbInstance) return;
        const orders = await dbInstance.getOrders(500);
        const activeContacts = new Map();

        for (const o of orders) {
            if (o.stato === 'archiviato') continue;
            // Filtra solo contatti WhatsApp (esclude Email, Telegram, Web Bancone)
            if (!o.telefono || o.telefono.includes('@') || o.telefono.startsWith('tg_') || o.telefono.startsWith('web_')) continue;

            const key = o.telefono;
            if (!activeContacts.has(key)) {
                activeContacts.set(key, {
                    phone: o.telefono,
                    cliente: o.cliente,
                    unprintedCount: 0,
                    orders: []
                });
            }
            const c = activeContacts.get(key);
            c.orders.push(o);
            if (o.stato !== 'stampato') {
                c.unprintedCount++;
            }
        }

        if (logger && typeof logger.info === 'function') {
            logger.info(`🔍 [Controllo Avvio] Analizzo ${activeContacts.size} contatti attivi nel database...`);
        }

        for (const [phone, contactData] of activeContacts.entries()) {
            const clientNameLower = (contactData.cliente || '').trim().toLowerCase();

            // Cerca la chat corrispondente su WhatsApp
            let chat = waChatMap.get(phone) ||
                       waChatMap.get(`${phone}@c.us`) ||
                       waChatMap.get(`${phone}@lid`) ||
                       null;

            // Se non trovata per ID/numero, cerca per nome del contatto se testuale
            if (!chat && clientNameLower && !/^[\d\s+\-()]+$/.test(clientNameLower)) {
                for (const c of allChats) {
                    if (c.isGroup) continue;
                    const cName = (c.name || c.formattedTitle || '').trim().toLowerCase();
                    if (cName === clientNameLower) {
                        chat = c;
                        break;
                    }
                }
            }

            // CASO A: La chat NON esiste su WhatsApp (eliminata mentre PrintZap era chiuso o in precedenza)
            if (!chat) {
                if (logger && typeof logger.info === 'function') {
                    logger.info(`🗑️ [Controllo Avvio] La chat per "${contactData.cliente || phone}" (${phone}) non esiste su WhatsApp. Eliminazione automatica...`);
                }
                if (typeof handleChatRemovedFn === 'function') {
                    await handleChatRemovedFn(phone, contactData.cliente, phone);
                }
                continue;
            }

            // CASO B: La chat esiste su WhatsApp ed ha ordini non ancora marcati "stampato"
            // Verifichiamo se tra i messaggi inviati dal negoziante c'è "Stampa Pronta"
            if (chat && contactData.unprintedCount > 0) {
                try {
                    const messages = await promiseTimeout(chat.fetchMessages({ limit: 20 }), 6000, `fetchMessages(${contactData.cliente})`);
                    if (messages && Array.isArray(messages)) {
                        const recentOut = messages.filter(m => m.fromMe);
                        recentOut.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
                        for (const outMsg of recentOut) {
                            const isReady = typeof isReadyResponseFn === 'function' ? isReadyResponseFn(outMsg.body) : false;
                            if (isReady) {
                                const cid = chat.id?._serialized || chat.id;
                                if (typeof handleMerchantReadyMessageFn === 'function') {
                                    const handled = await handleMerchantReadyMessageFn(cid, outMsg.body, chat.name, outMsg.timestamp);
                                    if (handled) {
                                        if (logger && typeof logger.info === 'function') {
                                            logger.info(`🟣 [Controllo Avvio] Riconosciuta "Stampa Pronta" su WhatsApp per "${contactData.cliente || phone}": impostato a STAMPATO (badge viola).`);
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                } catch (msgErr) {}
            }
        }

        if (logger && typeof logger.info === 'function') {
            logger.info('✅ [Controllo Avvio] Riconciliazione automatica contatti completata.');
        }
    } catch (err) {
        if (logger && typeof logger.warn === 'function') {
            logger.warn(`⚠️ [Controllo Avvio] Avviso durante riconciliazione contatti: ${err.message}`);
        }
    } finally {
        isReconcilingStartup = false;
    }
}

/**
 * Gestisce l'annullamento/revoca di un messaggio su WhatsApp, eliminando l'ordine
 * e i file fisici corrispondenti se presenti nel database.
 */
async function handleRevokedMessage(after, before, {
    dbInstance,
    deleteFileFn = defaultDeleteFile,
    getMessageIdFn = defaultGetMessageId,
    logger = console
} = {}) {
    if (logger && typeof logger.info === 'function') {
        logger.info(`🗑️ Evento revoca messaggio avviato...`);
    }
    try {
        const candidates = new Set();

        if (after?.protocolMessageKey) {
            if (after.protocolMessageKey.id) candidates.add(after.protocolMessageKey.id);
            if (after.protocolMessageKey._serialized) candidates.add(after.protocolMessageKey._serialized);
            const remote = after.protocolMessageKey.remoteJid || after.protocolMessageKey.remote || after.from || after.to;
            if (remote && after.protocolMessageKey.id) {
                candidates.add(`false_${remote}_${after.protocolMessageKey.id}`);
                candidates.add(`true_${remote}_${after.protocolMessageKey.id}`);
            }
        }

        if (before) {
            const bId = typeof getMessageIdFn === 'function' ? getMessageIdFn(before) : null;
            if (bId) candidates.add(bId);
            if (before.id?._serialized) candidates.add(before.id._serialized);
            if (before.id?.id) candidates.add(before.id.id);
            if (before.id?.$1) candidates.add(before.id.$1);
            if (before.protocolMessageKey?.id) candidates.add(before.protocolMessageKey.id);
        }

        if (after) {
            const aId = typeof getMessageIdFn === 'function' ? getMessageIdFn(after) : null;
            if (aId) candidates.add(aId);
            if (after.id?._serialized) candidates.add(after.id._serialized);
            if (after.id?.id) candidates.add(after.id.id);
            if (after.id?.$1) candidates.add(after.id.$1);
        }

        const candidateList = Array.from(candidates).filter(Boolean);
        if (logger && typeof logger.info === 'function') {
            logger.info(`🔍 Candidati ID revoca (${candidateList.length}): ${candidateList.join(', ')}`);
        }

        if (candidateList.length > 0 && dbInstance) {
            const order = await dbInstance.getOrderByMsgId(candidateList);
            if (order) {
                if (logger && typeof logger.info === 'function') {
                    logger.info(`🗑️ Trovato ordine da eliminare per messaggio revocato su WhatsApp: ID ${order.id} | File: ${order.file || 'Nessuno'}`);
                }
                if (order.file && typeof deleteFileFn === 'function') {
                    deleteFileFn(order.file);
                }
                await dbInstance.deleteOrderById(order.id);
                if (logger && typeof logger.info === 'function') {
                    logger.info(`✅ Ordine ID ${order.id} e file associato eliminati con successo in seguito all'annullamento del cliente.`);
                }
            } else {
                if (logger && typeof logger.info === 'function') {
                    logger.info(`ℹ️ Nessun ordine associato ai candidati di revoca trovato nel database.`);
                }
            }
        }
    } catch (error) {
        if (logger && typeof logger.error === 'function') {
            logger.error('❌ Errore durante il processamento del messaggio revocato:', error);
        }
    }
}

/**
 * Recupera l'elenco dei contatti esportabili combinando lo storico ordini SQLite
 * e la rubrica/chat attive di WhatsApp se connesso.
 */
async function getExportableContacts({
    dbInstance,
    getClient,
    clientInstance,
    getWpStatus,
    wpStatus,
    logger = console
} = {}) {
    if (!dbInstance) return [];
    const orders = await dbInstance.getOrders(999999);
    const contactsMap = new Map();

    orders.forEach(o => {
        const phone = o.telefono || '';
        if (!phone) return;
        if (!contactsMap.has(phone)) {
            contactsMap.set(phone, {
                name: o.cliente || phone,
                phone: phone,
                orderCount: 1,
                lastOrder: o.data || ''
            });
        } else {
            const existing = contactsMap.get(phone);
            existing.orderCount += 1;
            if (o.data && (!existing.lastOrder || new Date(o.data) > new Date(existing.lastOrder))) {
                existing.lastOrder = o.data;
            }
            if (o.cliente && !/^\d+$/.test(o.cliente) && /^\d+$/.test(existing.name)) {
                existing.name = o.cliente;
            }
        }
    });

    const client = typeof getClient === 'function' ? getClient() : clientInstance;
    const currentWpStatus = typeof getWpStatus === 'function' ? getWpStatus() : wpStatus;

    if (client && currentWpStatus === 'CONNECTED') {
        try {
            const waContacts = await promiseTimeout(client.getContacts(), 8000, 'client.getContacts()');
            if (waContacts && Array.isArray(waContacts)) {
                waContacts.forEach(c => {
                    const number = c.number || (c.id ? c.id.user : null);
                    if (!number || c.isGroup) return;
                    const name = c.name || c.pushname || number;
                    if (!contactsMap.has(number)) {
                        contactsMap.set(number, {
                            name: name,
                            phone: number,
                            orderCount: 0,
                            lastOrder: ''
                        });
                    } else {
                        const existing = contactsMap.get(number);
                        if (name && !/^\d+$/.test(name) && /^\d+$/.test(existing.name)) {
                            existing.name = name;
                        }
                    }
                });
            }
        } catch (err) {
            if (logger && typeof logger.warn === 'function') {
                logger.warn('⚠️ Impossibile recuperare contatti extra da WhatsApp per export:', err.message);
            }
        }
    }

    return Array.from(contactsMap.values());
}

module.exports = {
    moveContactFolderOnDisk,
    handleChatRemoved,
    syncContactNames,
    reconcileStartupContacts,
    handleRevokedMessage,
    getExportableContacts
};
