const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { ROOT_DIR, DATA_DIR } = require('./paths');

const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
const LICENSE_SALT = 'CartoleriaWhatsAppSecretSalt2026';

let _logger = console;

function init({ logger } = {}) {
    if (logger) _logger = logger;
}

let config = {
    notifyMessage: "✅ *Stampa Pronta!* 🖨️\nIl tuo documento è pronto per il ritiro.",
    autoCleanupDays: 7,
    updatesUrl: "https://raw.githubusercontent.com/alfaomega-dev/cartoleria-whatsapp-updates/main",
    emailEnabled: false,
    emailHost: "",
    emailPort: 993,
    emailSecure: true,
    emailUser: "",
    emailPassword: "",
    smtpHost: "",
    smtpPort: 465,
    smtpSecure: true,
    emailCheckIntervalMinutes: 2,
    autoStartEnabled: true
};

let licenseInfo = {
    installDate: null,
    active: false,
    key: ""
};

function loadLicense() {
    if (fs.existsSync(LICENSE_FILE)) {
        try {
            licenseInfo = JSON.parse(fs.readFileSync(LICENSE_FILE, 'utf8'));
        } catch (err) {
            _logger.info('❌ Errore caricamento licenza.');
        }
    } else {
        licenseInfo.installDate = new Date().toISOString();
        fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
    }
    return licenseInfo;
}

function checkLicense() {
    loadLicense();

    // Se c'è una licenza firmata
    if (licenseInfo.customer && licenseInfo.key) {
        // Ricalcola il codice hash di verifica
        const payload = `${licenseInfo.customer}|${licenseInfo.expiryDate || 'never'}|${LICENSE_SALT}`;
        const expectedKey = crypto.createHash('sha256').update(payload).digest('hex');

        if (licenseInfo.key === expectedKey) {
            // Controlla data di scadenza
            if (licenseInfo.expiryDate && licenseInfo.expiryDate !== 'never') {
                const expiry = new Date(licenseInfo.expiryDate);
                const now = new Date();
                if (now > expiry) {
                    return { valid: false, message: `Licenza scaduta il ${expiry.toLocaleDateString()}` };
                }
                const diffDays = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));
                return { valid: true, isTrial: false, active: true, message: `Licenza valida per ${licenseInfo.customer}. Scadenza: ${expiry.toLocaleDateString()} (Rimangono ${diffDays} giorni).` };
            }
            return { valid: true, isTrial: false, active: true, message: `Licenza attiva a vita per: ${licenseInfo.customer}` };
        } else {
            _logger.error('🛑 Tentativo di manomissione licenza rilevato!');
        }
    }

    // Se non c'è licenza attiva o è manomessa, controlla il periodo di prova (Trial)
    const installDate = new Date(licenseInfo.installDate || new Date());
    const now = new Date();
    const diffTime = Math.abs(now - installDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    const TRIAL_DAYS = 30; // 30 giorni di prova

    if (diffDays <= TRIAL_DAYS) {
        return {
            valid: true,
            isTrial: true,
            daysLeft: TRIAL_DAYS - diffDays,
            message: `Periodo di prova attivo: rimangono ${TRIAL_DAYS - diffDays} giorni.`
        };
    }

    return {
        valid: false,
        message: "Periodo di prova scaduto. Contatta l'amministratore per attivare la licenza."
    };
}

function sanitizeClientFolder(name, fallbackId) {
    const raw = (name || fallbackId || 'Cliente').toString().trim();
    let safe = raw.replace(/[/\\?%*:|"<>]/g, '_').replace(/\s+/g, ' ');
    if (!safe || safe.trim() === '_') {
        safe = (fallbackId || 'Cliente').toString().replace(/[/\\?%*:|"<>]/g, '_');
    }
    return safe;
}

function loadConfig(updateAutoStartCallback) {
    let existingUserConfig = null;

    if (fs.existsSync(CONFIG_FILE)) {
        try {
            existingUserConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
            Object.assign(config, existingUserConfig);
        } catch (err) {
            _logger.error('❌ Errore caricamento config.json, uso default.');
        }
    } else {
        const templateConfigPath = path.join(ROOT_DIR, 'config.json');
        if (DATA_DIR !== ROOT_DIR && fs.existsSync(templateConfigPath)) {
            try {
                const templateConfig = JSON.parse(fs.readFileSync(templateConfigPath, 'utf8'));
                if (templateConfig.updatesUrl) config.updatesUrl = templateConfig.updatesUrl;
                if (templateConfig.notifyMessage) config.notifyMessage = templateConfig.notifyMessage;
                _logger.info('📂 Caricato config.json predefinito da ROOT_DIR.');
            } catch (err) {
                _logger.error('❌ Errore caricamento template config.json da ROOT_DIR.');
            }
        }
    }

    if (!config.updatesUrl || !config.updatesUrl.trim()) {
        config.updatesUrl = "https://raw.githubusercontent.com/alfaomega-dev/cartoleria-whatsapp-updates/main";
    }

    if (!config.clientId) {
        config.clientId = 'session_' + Date.now();
    }

    if (config.emailEnabled === undefined) config.emailEnabled = false;
    if (config.emailCheckIntervalMinutes === undefined) config.emailCheckIntervalMinutes = 2;
    if (config.telegramEnabled === undefined) config.telegramEnabled = false;
    if (config.telegramBotToken === undefined) config.telegramBotToken = "";
    if (config.telegramMode === undefined) config.telegramMode = "polling";
    if (config.telegramWebhookUrl === undefined) config.telegramWebhookUrl = "";
    if (config.webBanconeEnabled === undefined) config.webBanconeEnabled = true;
    if (config.language === undefined) config.language = 'it';
    if (config.autoStartEnabled === undefined) config.autoStartEnabled = true;

    if (!config.emailAccounts) {
        config.emailAccounts = [];
        if (config.emailUser && config.emailUser.trim()) {
            config.emailAccounts.push({
                id: 'acc_' + Date.now(),
                emailUser: config.emailUser,
                emailPassword: config.emailPassword || '',
                emailHost: config.emailHost || '',
                emailPort: parseInt(config.emailPort) || 993,
                emailSecure: config.emailSecure !== undefined ? config.emailSecure : true,
                smtpHost: config.smtpHost || '',
                smtpPort: parseInt(config.smtpPort) || 465,
                smtpSecure: config.smtpSecure !== undefined ? config.smtpSecure : true
            });
        }
    }

    const oldFields = ['emailUser', 'emailPassword', 'emailHost', 'emailPort', 'emailSecure', 'smtpHost', 'smtpPort', 'smtpSecure'];
    oldFields.forEach(field => {
        if (config[field] !== undefined) {
            delete config[field];
        }
    });

    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
    _logger.info(`📋 Config caricato: telegramEnabled=${config.telegramEnabled}, clientId=${config.clientId}`);

    if (typeof updateAutoStartCallback === 'function') {
        updateAutoStartCallback(config.autoStartEnabled !== false);
    }

    return config;
}

function getConfig() {
    return config;
}

function saveConfig(newValues) {
    if (newValues && typeof newValues === 'object') {
        Object.assign(config, newValues);
    }
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
    return config;
}

function getLicenseInfo() {
    return licenseInfo;
}

function saveLicense(info) {
    if (info && typeof info === 'object') {
        Object.assign(licenseInfo, info);
    }
    fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
    return licenseInfo;
}

module.exports = {
    init,
    CONFIG_FILE,
    LICENSE_FILE,
    LICENSE_SALT,
    loadConfig,
    getConfig,
    saveConfig,
    loadLicense,
    checkLicense,
    getLicenseInfo,
    saveLicense,
    sanitizeClientFolder
};
