const fs = require('fs');
const path = require('path');
const imaps = require('imap-simple');
const { simpleParser } = require('mailparser');
const nodemailer = require('nodemailer');
const db = require('../db');
const { PRINT_FOLDER } = require('./paths');
const { getConfig } = require('./config');

let _logger = console;
let emailIntervalId = null;

function init({ logger } = {}) {
    if (logger) _logger = logger;
}

function parseThunderbirdFilters(fileContent) {
    const rules = [];
    const lines = fileContent.split(/\r?\n/);
    let currentRule = null;

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('name=')) {
            if (currentRule && currentRule.conditions && currentRule.conditions.length > 0) {
                rules.push(currentRule);
            }
            const nameMatch = trimmed.match(/name="([^"]+)"/);
            currentRule = {
                id: 'tb_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
                name: nameMatch ? nameMatch[1] : 'Filtro Thunderbird',
                enabled: true,
                conditions: []
            };
        } else if (currentRule && trimmed.startsWith('enabled=')) {
            const val = trimmed.match(/enabled="([^"]+)"/);
            if (val && val[1] === 'no') {
                currentRule.enabled = false;
            }
        } else if (currentRule && trimmed.startsWith('condition=')) {
            const valMatch = trimmed.match(/condition="([^"]+)"/);
            if (valMatch) {
                const condString = valMatch[1];
                const regex = /\((subject|from|body|to|message),(contains|is|begins w|ends w),([^)]+)\)/gi;
                let match;
                while ((match = regex.exec(condString)) !== null) {
                    let field = match[1].toLowerCase();
                    if (field === 'message' || field === 'body') field = 'body';
                    let op = match[2].toLowerCase();
                    let operator = 'contains';
                    if (op === 'is') operator = 'is';
                    if (op === 'begins w') operator = 'startsWith';
                    if (op === 'ends w') operator = 'endsWith';

                    currentRule.conditions.push({
                        field,
                        operator,
                        value: match[3].trim()
                    });
                }
            }
        }
    }
    if (currentRule && currentRule.conditions && currentRule.conditions.length > 0) {
        rules.push(currentRule);
    }

    const flatRules = [];
    for (const r of rules) {
        for (const cond of r.conditions) {
            flatRules.push({
                id: 'tb_' + Date.now() + '_' + Math.random().toString(36).substr(2, 7),
                name: r.name,
                field: cond.field,
                operator: cond.operator,
                value: cond.value,
                action: 'skip',
                enabled: r.enabled
            });
        }
    }
    return flatRules;
}

function shouldFilterEmail(emailData, rules) {
    if (!rules || rules.length === 0) return false;

    for (const rule of rules) {
        if (!rule.enabled) continue;

        let textToTest = '';
        if (rule.field === 'from') {
            textToTest = emailData.from || '';
        } else if (rule.field === 'subject') {
            textToTest = emailData.subject || '';
        } else if (rule.field === 'body') {
            textToTest = emailData.body || '';
        }

        textToTest = textToTest.toLowerCase();
        const val = (rule.value || '').toLowerCase();

        let match = false;
        if (rule.operator === 'contains') {
            match = textToTest.includes(val);
        } else if (rule.operator === 'is') {
            match = textToTest === val;
        } else if (rule.operator === 'startsWith') {
            match = textToTest.startsWith(val);
        } else if (rule.operator === 'endsWith') {
            match = textToTest.endsWith(val);
        }

        if (match && rule.action === 'skip') {
            return true;
        }
    }
    return false;
}

async function checkNewEmails() {
    const config = getConfig();
    if (!config.emailEnabled) {
        _logger.info('📧 Servizio e-mail disabilitato.');
        return { success: true, processed: 0, checkedAccounts: 0 };
    }

    if (!config.emailAccounts || config.emailAccounts.length === 0) {
        _logger.warn('📧 Nessun account e-mail configurato nelle impostazioni.');
        return { success: true, processed: 0, checkedAccounts: 0 };
    }

    let totalProcessed = 0;
    let checkedAccounts = 0;

    for (const account of config.emailAccounts) {
        if (!account.emailHost || !account.emailUser || !account.emailPassword) {
            _logger.warn(`📧 Credenziali incomplete per l'account: ${account.emailUser || 'sconosciuto'}, salto.`);
            continue;
        }

        checkedAccounts++;
        _logger.info(`📧 Avvio controllo e-mail per: ${account.emailUser}...`);

        const imapConfig = {
            imap: {
                user: account.emailUser,
                password: account.emailPassword,
                host: account.emailHost,
                port: parseInt(account.emailPort) || 993,
                tls: account.emailSecure,
                tlsOptions: { rejectUnauthorized: false },
                authTimeout: 10000
            }
        };

        let connection;
        try {
            connection = await imaps.connect(imapConfig);
            await connection.openBox('INBOX');

            const sinceDate = new Date();
            sinceDate.setDate(sinceDate.getDate() - 3);
            sinceDate.setHours(0, 0, 0, 0);

            const uidsToProcess = new Set();

            try {
                const unseenResults = await connection.search(['UNSEEN']);
                for (const m of unseenResults) {
                    if (m?.attributes?.uid) uidsToProcess.add(m.attributes.uid);
                }
            } catch (e) {
                _logger.warn(`📧 [${account.emailUser}] Errore ricerca UNSEEN: ${e.message}`);
            }

            try {
                const recentResults = await connection.search([['SINCE', sinceDate]]);
                for (const m of recentResults) {
                    if (m?.attributes?.uid) uidsToProcess.add(m.attributes.uid);
                }
            } catch (e) {
                _logger.warn(`📧 [${account.emailUser}] Errore ricerca SINCE: ${e.message}`);
            }

            if (uidsToProcess.size === 0) {
                _logger.info(`📧 [${account.emailUser}] Nessuna e-mail recente o non letta trovata nella casella.`);
                continue;
            }

            const sortedUids = Array.from(uidsToProcess).sort((a, b) => b - a);
            const uidsToFetch = [];

            for (const uid of sortedUids) {
                const emailOrderId = `email_${account.emailUser}_${uid}`;
                const existsNew = await db.orderExists(emailOrderId);
                const existsOld = await db.orderExists(`email_${uid}`);
                if (!existsNew && !existsOld) {
                    uidsToFetch.push(uid);
                }
                if (uidsToFetch.length >= 25) break;
            }

            if (uidsToFetch.length === 0) {
                _logger.info(`📧 [${account.emailUser}] Tutte le ${sortedUids.length} e-mail recenti sono già state elaborate nel database.`);
                continue;
            }

            _logger.info(`📧 [${account.emailUser}] Trovate ${uidsToFetch.length} nuove e-mail da importare. Avvio download dettagli...`);

            const fetchOptions = {
                bodies: ['HEADER', 'TEXT', ''],
                struct: true
            };

            for (const uid of uidsToFetch) {
                try {
                    const emailOrderId = `email_${account.emailUser}_${uid}`;
                    const messages = await connection.search([['UID', uid]], fetchOptions);
                    if (!messages || messages.length === 0) continue;
                    const message = messages[0];

                    const all = message.parts.find(part => part.which === '');
                    if (!all) {
                        await connection.addFlags(uid, '\\Seen');
                        continue;
                    }

                    const parsed = await simpleParser(all.body);
                    const senderEmail = parsed.from && parsed.from.value && parsed.from.value[0] ? parsed.from.value[0].address : 'sconosciuto@esempio.com';
                    const senderName = parsed.from && parsed.from.value && parsed.from.value[0] ? (parsed.from.value[0].name || senderEmail.split('@')[0]) : 'Cliente E-mail';
                    const subject = parsed.subject || 'Nessun Oggetto';
                    const bodyText = parsed.text || '';

                    const emailDataToTest = {
                        from: senderEmail,
                        subject: subject,
                        body: bodyText
                    };

                    if (shouldFilterEmail(emailDataToTest, config.emailFilters)) {
                        _logger.info(`📧 [${account.emailUser}] Email UID ${uid} saltata per filtri anti-spam.`);
                        await connection.addFlags(uid, '\\Seen');
                        continue;
                    }

                    _logger.info(`📧 [${account.emailUser}] Elaborazione e-mail da: ${senderEmail} - Oggetto: ${subject}`);

                    const attachments = parsed.attachments || [];
                    if (attachments.length === 0) {
                        _logger.info(`📧 [${account.emailUser}] L'e-mail da ${senderEmail} non ha allegati. La salvo come nota.`);
                        
                        const orderData = {
                            id: `email_${account.emailUser.replace(/[^a-zA-Z0-9]/g, '_')}_${uid}_text`,
                            cliente: `${senderName} (Email)`,
                            telefono: senderEmail,
                            file: "",
                            data: parsed.date ? parsed.date.toISOString() : new Date().toISOString(),
                            stato: 'ricevuto',
                            tipo: 'nota',
                            messaggio: `Oggetto: ${subject}\n\n${parsed.text || ''}`,
                            msgId: emailOrderId
                        };
                        
                        await db.saveOrder(orderData);
                        await connection.addFlags(uid, '\\Seen');
                        totalProcessed++;
                        continue;
                    }

                    const safeSenderName = senderEmail.replace(/[^a-zA-Z0-9]/g, '_');
                    const userFolder = path.join(PRINT_FOLDER, `Email_${safeSenderName}`);
                    if (!fs.existsSync(userFolder)) {
                        fs.mkdirSync(userFolder, { recursive: true });
                    }

                    let hasValidPrintFile = false;
                    let attIndex = 0;
                    for (const att of attachments) {
                        attIndex++;
                        const filename = att.filename || `allegato_${Date.now()}_${attIndex}`;
                        const extension = path.extname(filename).toLowerCase();

                        const isPrintable = ['.pdf', '.jpg', '.jpeg', '.png', '.tiff', '.bmp', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.docm'].includes(extension);
                        if (!isPrintable) {
                            _logger.info(`📧 [${account.emailUser}] Allegato ${filename} non stampabile, salto.`);
                            continue;
                        }

                        let targetFilename = filename;
                        let localPath = path.join(userFolder, targetFilename);
                        if (fs.existsSync(localPath)) {
                            const ext = path.extname(filename);
                            const nameWithoutExt = path.basename(filename, ext);
                            targetFilename = `${nameWithoutExt}_${attIndex}${ext}`;
                            localPath = path.join(userFolder, targetFilename);
                        }

                        fs.writeFileSync(localPath, att.content);
                        hasValidPrintFile = true;

                        const relativePath = path.join(`Email_${safeSenderName}`, targetFilename);
                        const cleanFilename = targetFilename.replace(/[^a-zA-Z0-9]/g, '_');
                        const attMsgId = `${emailOrderId}_att${attIndex}_${cleanFilename}`;

                        const orderData = {
                            id: attMsgId,
                            cliente: `${senderName} (Email)`,
                            telefono: senderEmail,
                            file: relativePath.replace(/\\/g, '/'),
                            data: parsed.date ? parsed.date.toISOString() : new Date().toISOString(),
                            stato: 'ricevuto',
                            tipo: extension === '.pdf' ? 'pdf' : (['.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx'].includes(extension) ? 'documento' : 'immagine'),
                            messaggio: `Oggetto: ${subject}`,
                            msgId: attMsgId
                        };

                        await db.saveOrder(orderData);
                        _logger.info(`📧 [${account.emailUser}] Allegato ${targetFilename} salvato come ordine SQLite.`);
                        totalProcessed++;
                    }

                    await connection.addFlags(uid, '\\Seen');

                } catch (msgErr) {
                    _logger.error(`❌ Errore processamento e-mail singola su ${account.emailUser}: ${msgErr.message}`);
                }
            }

        } catch (imapErr) {
            _logger.error(`❌ Errore durante il poller IMAP per ${account.emailUser}: ${imapErr.message}`);
        } finally {
            if (connection) {
                try { await connection.end(); } catch (e) {}
            }
        }
    }

    return { success: true, processed: totalProcessed, checkedAccounts };
}

function startEmailPoller() {
    stopEmailPoller();

    const config = getConfig();
    if (config.emailEnabled) {
        setTimeout(checkNewEmails, 2000);
        const intervalMs = (config.emailCheckIntervalMinutes || 2) * 60 * 1000;
        emailIntervalId = setInterval(checkNewEmails, intervalMs);
        _logger.info(`📧 Poller E-mail impostato ogni ${config.emailCheckIntervalMinutes} minuti.`);
    } else {
        _logger.info('📧 Poller E-mail disattivato.');
    }
}

function stopEmailPoller() {
    if (emailIntervalId) {
        clearInterval(emailIntervalId);
        emailIntervalId = null;
    }
}

async function shutdown() {
    stopEmailPoller();
    _logger.info('📧 Servizio email terminato.');
}

async function testEmailConnection({ emailHost, emailPort, emailSecure, emailUser, emailPassword, smtpHost, smtpPort, smtpSecure }) {
    const testResults = { imap: 'Da testare', smtp: 'Da testare' };

    try {
        const connection = await imaps.connect({
            imap: {
                user: emailUser,
                password: emailPassword,
                host: emailHost,
                port: parseInt(emailPort) || 993,
                tls: emailSecure,
                tlsOptions: { rejectUnauthorized: false },
                authTimeout: 6000
            }
        });
        await connection.end();
        testResults.imap = 'OK';
    } catch (imapErr) {
        testResults.imap = 'ERRORE: ' + imapErr.message;
    }

    try {
        const transporter = nodemailer.createTransport({
            host: smtpHost,
            port: parseInt(smtpPort) || 465,
            secure: smtpSecure,
            auth: {
                user: emailUser,
                pass: emailPassword
            },
            tls: {
                rejectUnauthorized: false
            }
        });
        await transporter.verify();
        testResults.smtp = 'OK';
    } catch (smtpErr) {
        testResults.smtp = 'ERRORE: ' + smtpErr.message;
    }

    return testResults;
}

async function sendEmailNotification({ to, message, activeAccount }) {
    if (!activeAccount || !activeAccount.smtpHost || !activeAccount.emailUser || !activeAccount.emailPassword) {
        throw new Error('Configurazione SMTP non abilitata o incompleta per questo account.');
    }

    _logger.info(`📧 Invio risposta email a: ${to} tramite account ${activeAccount.emailUser}`);
    const transporter = nodemailer.createTransport({
        host: activeAccount.smtpHost,
        port: activeAccount.smtpPort,
        secure: activeAccount.smtpSecure,
        auth: {
            user: activeAccount.emailUser,
            pass: activeAccount.emailPassword
        },
        tls: {
            rejectUnauthorized: false
        }
    });

    await transporter.sendMail({
        from: `"${activeAccount.emailUser.split('@')[0]}" <${activeAccount.emailUser}>`,
        to,
        subject: 'STAMPA PRONTA',
        text: message
    });

    _logger.info(`📧 E-mail inviata con successo a: ${to}`);
}

module.exports = {
    init,
    parseThunderbirdFilters,
    shouldFilterEmail,
    checkNewEmails,
    startEmailPoller,
    stopEmailPoller,
    shutdown,
    testEmailConnection,
    sendEmailNotification
};
