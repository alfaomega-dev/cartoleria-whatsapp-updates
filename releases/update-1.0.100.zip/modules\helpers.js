const fs = require('fs');
const path = require('path');
const db = require('../db');
const { DATA_DIR, PRINT_FOLDER } = require('./paths');

let _logger = console;

function init({ logger } = {}) {
    if (logger) _logger = logger;
}

async function saveOrderInfo(orderData) {
    try {
        await db.saveOrder(orderData);
    } catch (err) {
        _logger.error('❌ Errore salvataggio ordine su SQLite:', err);
    }
}

function saveNote(cliente, nota) {
    const notesFile = path.join(DATA_DIR, 'note.txt');
    const line = `[${new Date().toLocaleString()}] ${cliente}: ${nota}\n`;
    fs.appendFileSync(notesFile, line);
}

const { spawnSync } = require('child_process');

/**
 * Sposta uno o più percorsi (file o cartelle) nel Cestino di Windows.
 * Se PowerShell fallisce o non è disponibile, esegue il fallback su rimozione standard.
 * @param {string|string[]} paths - Percorso assoluto o array di percorsi da cestinare.
 */
function sendToRecycleBin(paths) {
    if (!paths) return;
    const pathList = (Array.isArray(paths) ? paths : [paths]).filter(p => typeof p === 'string' && p.trim().length > 0);
    if (pathList.length === 0) return;

    const existingPaths = pathList.filter(p => fs.existsSync(p));
    if (existingPaths.length === 0) return;

    let success = false;
    try {
        const psScript = `
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName Microsoft.VisualBasic
$input | ForEach-Object {
    $target = $_.Trim()
    if ($target -and (Test-Path -LiteralPath $target)) {
        if (Test-Path -LiteralPath $target -PathType Leaf) {
            [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($target, 'SuppressDialogs', 'SendToRecycleBin')
        } elseif (Test-Path -LiteralPath $target -PathType Container) {
            [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($target, 'SuppressDialogs', 'SendToRecycleBin')
        }
    }
}
`;
        const ps = spawnSync('powershell', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', psScript], {
            input: existingPaths.join('\n'),
            encoding: 'utf8',
            windowsHide: true,
            timeout: 5000
        });

        if (ps && ps.status === 0) {
            const stillExist = existingPaths.filter(p => fs.existsSync(p));
            if (stillExist.length === 0) {
                success = true;
                _logger.info(`🗑️ Spostati nel Cestino di Windows (${existingPaths.length} elementi)`);
            }
        }
    } catch (e) {
        _logger.warn(`Avviso: Cestino Windows non raggiungibile, uso eliminazione diretta: ${e.message}`);
    }

    // Fallback: se qualche percorso esiste ancora, eliminalo direttamente
    if (!success) {
        for (const p of existingPaths) {
            try {
                if (fs.existsSync(p)) {
                    const stat = fs.statSync(p);
                    if (stat.isDirectory()) {
                        fs.rmSync ? fs.rmSync(p, { recursive: true, force: true }) : fs.rmdirSync(p);
                    } else {
                        fs.unlinkSync(p);
                    }
                }
            } catch (fallbackErr) {
                _logger.error(`Errore fallback eliminazione diretta per ${p}:`, fallbackErr);
            }
        }
    }
}

function deleteFileWithCleanup(relativePath) {
    if (!relativePath) return; // Ignora se non c'è file (es. note)
    const filePath = path.join(PRINT_FOLDER, relativePath);
    if (fs.existsSync(filePath)) {
        try {
            sendToRecycleBin(filePath);

            // Se la cartella del cliente è rimasta vuota, spostiamo anch'essa nel Cestino
            const folderPath = path.dirname(filePath);
            if (folderPath.startsWith(PRINT_FOLDER) && folderPath !== PRINT_FOLDER) {
                if (fs.existsSync(folderPath)) {
                    const files = fs.readdirSync(folderPath);
                    if (files.length === 0) {
                        sendToRecycleBin(folderPath);
                        _logger.info(`🗑️ Cartella cliente vuota spostata nel Cestino: ${folderPath}`);
                    }
                }
            }
        } catch (err) {
            _logger.error(`Errore durante lo spostamento nel Cestino del file ${relativePath}:`, err);
        }
    }
}

/**
 * Gestisce l'eliminazione multipla di file inviandoli in un unico batch al Cestino
 * e ripulendo nel Cestino anche le eventuali cartelle clienti rimaste vuote.
 */
function deleteFilesWithCleanup(relativePaths) {
    if (!relativePaths || !Array.isArray(relativePaths) || relativePaths.length === 0) return;

    const filePaths = [];
    const parentFolders = new Set();

    for (const rel of relativePaths) {
        if (!rel) continue;
        const fullPath = path.join(PRINT_FOLDER, rel);
        if (fs.existsSync(fullPath)) {
            filePaths.push(fullPath);
            const folderPath = path.dirname(fullPath);
            if (folderPath.startsWith(PRINT_FOLDER) && folderPath !== PRINT_FOLDER) {
                parentFolders.add(folderPath);
            }
        }
    }

    if (filePaths.length === 0) return;

    // 1. Sposta tutti i file nel Cestino in batch
    sendToRecycleBin(filePaths);

    // 2. Controlla cartelle clienti rimaste vuote e spostale nel Cestino
    const emptyFolders = [];
    for (const f of parentFolders) {
        try {
            if (fs.existsSync(f)) {
                const files = fs.readdirSync(f);
                if (files.length === 0) {
                    emptyFolders.push(f);
                }
            }
        } catch (e) {}
    }

    if (emptyFolders.length > 0) {
        sendToRecycleBin(emptyFolders);
        _logger.info(`🗑️ Cartelle clienti vuote spostate nel Cestino (${emptyFolders.length})`);
    }
}

async function repairMismatchedFolders() {
    try {
        const orders = await db.getOrders(9999);
        let repairedCount = 0;

        for (const order of orders) {
            if (!order.file) continue;
            const expectedPath = path.join(PRINT_FOLDER, order.file);
            
            if (!fs.existsSync(expectedPath)) {
                const fileName = path.basename(order.file);
                const targetDir = path.join(PRINT_FOLDER, path.dirname(order.file));
                
                // 1. Controlla cartella numerica basata su telefono
                if (order.telefono) {
                    const numDir = path.join(PRINT_FOLDER, order.telefono.trim());
                    const numFilePath = path.join(numDir, fileName);

                    if (fs.existsSync(numFilePath)) {
                        if (!fs.existsSync(targetDir)) {
                            fs.mkdirSync(targetDir, { recursive: true });
                        }
                        const targetFilePath = path.join(targetDir, fileName);
                        fs.renameSync(numFilePath, targetFilePath);
                        repairedCount++;
                        _logger.info(`🛠 Riparazione cartella: ${numFilePath} -> ${targetFilePath}`);
                        
                        try {
                            if (fs.readdirSync(numDir).length === 0) {
                                fs.rmdirSync(numDir);
                            }
                        } catch(e){}
                        continue;
                    }
                }

                // 2. Se non ancora trovato, cerca il file in qualsiasi cartella di PRINT_FOLDER
                if (fs.existsSync(PRINT_FOLDER)) {
                    const subdirs = fs.readdirSync(PRINT_FOLDER);
                    for (const subdir of subdirs) {
                        const subdirPath = path.join(PRINT_FOLDER, subdir);
                        if (fs.statSync(subdirPath).isDirectory()) {
                            const candidateFile = path.join(subdirPath, fileName);
                            if (fs.existsSync(candidateFile)) {
                                if (!fs.existsSync(targetDir)) {
                                    fs.mkdirSync(targetDir, { recursive: true });
                                }
                                const targetFilePath = path.join(targetDir, fileName);
                                fs.renameSync(candidateFile, targetFilePath);
                                repairedCount++;
                                _logger.info(`🛠 Riparazione cartella (cerca globale): ${candidateFile} -> ${targetFilePath}`);
                                try {
                                    if (fs.readdirSync(subdirPath).length === 0) {
                                        fs.rmdirSync(subdirPath);
                                    }
                                } catch(e){}
                                break;
                            }
                        }
                    }
                }
            }
        }
        if (repairedCount > 0) {
            _logger.info(`✅ Riparazione completata: ${repairedCount} file riallineati nelle cartelle con nome contatto.`);
        }
    } catch (err) {
        _logger.error('❌ Errore durante la riparazione delle cartelle:', err);
    }
}

module.exports = {
    init,
    saveOrderInfo,
    saveNote,
    sendToRecycleBin,
    deleteFileWithCleanup,
    deleteFilesWithCleanup,
    repairMismatchedFolders
};
