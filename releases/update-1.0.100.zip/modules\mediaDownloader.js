// Modulo dedicato al download e salvataggio multimediale WhatsApp.
// Estratto da whatsappClient.js (Fase 4 del piano di modularizzazione).
// Mantiene il codice in-page Puppeteer identico al 100%.

const fs = require('fs');
const path = require('path');
const { promiseTimeout } = require('./session');
const { getMessageId, getExtensionFromMime } = require('./whatsappUtils');

/**
 * Salva i media su disco gestendo l'estensione e l'anti-collisione progressiva dei file.
 */
function saveMediaToDisk({ media, contactName, msgType, printFolder, generateOrderId, logger = console }) {
    if (!media || !media.data) {
        throw new Error('Oggetto media o dati binari assenti');
    }

    const safeContactName = (contactName || 'Sconosciuto').replace(/[^a-z0-9]/gi, '_');
    const contactFolder = path.join(printFolder, safeContactName);
    if (!fs.existsSync(contactFolder)) {
        fs.mkdirSync(contactFolder, { recursive: true });
    }

    let ext = getExtensionFromMime(media.mimetype);
    let orderType = media.mimetype;
    if (msgType === 'ptt' || msgType === 'audio') {
        orderType = 'audio';
        if (!ext || ext === 'bin') ext = 'ogg';
    } else if (media.mimetype && media.mimetype.startsWith('image/')) {
        orderType = 'immagine';
    } else if (media.mimetype === 'application/pdf') {
        orderType = 'pdf';
    }

    const orderId = typeof generateOrderId === 'function' ? generateOrderId() : Date.now();
    let fileName;

    if (media.filename) {
        const originalName = media.filename;
        const originalExt = path.extname(originalName).replace('.', '');
        const safeOriginalName = originalName.replace(/[^a-z0-9\.\-_]/gi, '_');
        
        if (originalExt) {
            ext = originalExt;
            fileName = `${orderId}_${safeOriginalName}`;
        } else {
            fileName = `${orderId}_${safeOriginalName}.${ext}`;
        }
    } else {
        const randomSuffix = Math.random().toString(36).substring(2, 6);
        fileName = `${orderId}_${randomSuffix}.${ext}`;
    }

    let filePath = path.join(contactFolder, fileName);
    let collisionCounter = 1;
    while (fs.existsSync(filePath)) {
        if (media.filename) {
            const safeOriginalName = media.filename.replace(/[^a-z0-9\.\-_]/gi, '_');
            fileName = `${orderId}_${collisionCounter}_${safeOriginalName}`;
        } else {
            const randomSuffix = Math.random().toString(36).substring(2, 6);
            fileName = `${orderId}_${randomSuffix}_${collisionCounter}.${ext}`;
        }
        filePath = path.join(contactFolder, fileName);
        collisionCounter++;
    }

    const buffer = Buffer.from(media.data, 'base64');
    fs.writeFileSync(filePath, buffer);

    const relativePath = `${safeContactName}/${fileName}`;
    if (logger && typeof logger.info === 'function') {
        logger.info(`✅ File salvato: ${relativePath} (Tipo: ${orderType})`);
    }

    return {
        orderId,
        fileName,
        filePath,
        relativePath,
        orderType
    };
}

/**
 * Download resiliente dei media tramite Puppeteer / WhatsApp Web interno
 */
async function downloadMediaResilient(msg, clientInstance, logger = console) {
    if (!msg || msg.type === 'album') return null;
    const msgId = getMessageId(msg);

    try {
        if (typeof msg.downloadMedia === 'function') {
            const media = await promiseTimeout(msg.downloadMedia(), 8000, `msg.downloadMedia(${msgId})`);
            if (media && media.data) {
                return media;
            }
        }
    } catch (err) {
        if (logger && typeof logger.info === 'function') {
            logger.info(`ℹ️ Download nativo non immediato per ${msgId} (${err.message}), avvio fallback resiliente...`);
        }
    }

    if (!clientInstance || !clientInstance.pupPage) {
        return null;
    }

    try {
        const rawId = msg.id;
        const targetId = msgId;
        const remoteStr = msg.from || (msg.id && typeof msg.id.remote === 'string' ? msg.id.remote : (msg.id?.remote?._serialized || msg.id?.remote?.$1));

        const result = await clientInstance.pupPage.evaluate(async (targetId, rawId, remoteStr) => {
            const sleep = ms => new Promise(r => setTimeout(r, ms));
            const { Msg, Chat } = window.require('WAWebCollections') || {};
            const { Cmd } = window.require('WAWebCmd') || {};
            const widFactory = window.require('WAWebWidFactory');

            const rawPart = (rawId && rawId.id) || (targetId && targetId.split('_').pop());

            async function findMsg() {
                try {
                    if (!Msg) return null;

                    if (targetId) {
                        let m = Msg.get(targetId);
                        if (m) return m;
                    }

                    if (rawId) {
                        const s = rawId._serialized || rawId.$1;
                        if (s) {
                            let m = Msg.get(s);
                            if (m) return m;
                        }
                    }

                    if (targetId && typeof Msg.getMessagesById === 'function') {
                        try {
                            const res = await Msg.getMessagesById([targetId]);
                            const m = res?.messages?.[0] || (Array.isArray(res) ? res[0] : null);
                            if (m) return m;
                        } catch (e) {}
                    }
                    if (rawId && typeof Msg.getMessagesById === 'function') {
                        const s = rawId._serialized || rawId.$1;
                        if (s) {
                            try {
                                const res = await Msg.getMessagesById([s]);
                                const m = res?.messages?.[0] || (Array.isArray(res) ? res[0] : null);
                                if (m) return m;
                            } catch (e) {}
                        }
                    }

                    if (Msg.models && Msg.models.length > 0) {
                        const targetIdStr = targetId || (rawId && (rawId._serialized || rawId.$1));
                        for (let i = Msg.models.length - 1; i >= 0; i--) {
                            const mod = Msg.models[i];
                            if (!mod || !mod.id) continue;
                            const modSerialized = mod.id._serialized || mod.id.$1 || (typeof mod.id.toString === 'function' ? mod.id.toString() : '');
                            if (targetIdStr && (modSerialized === targetIdStr || modSerialized.includes(targetIdStr))) return mod;
                            if (rawPart && mod.id.id === rawPart) return mod;
                        }
                    }

                    if (Chat && remoteStr) {
                        let chat = Chat.get(remoteStr);
                        if (!chat && widFactory) {
                            try { chat = Chat.get(widFactory.createWid(remoteStr)); } catch (e) {}
                        }
                        if (chat) {
                            if (chat.msgs) {
                                const m = (targetId && chat.msgs.get(targetId)) ||
                                    (rawPart && chat.msgs.models && chat.msgs.models.find(mod => mod?.id?.id === rawPart));
                                if (m) return m;
                            }
                            if (typeof chat.fetchMessages === 'function') {
                                try {
                                    const msgs = await chat.fetchMessages({ limit: 30 });
                                    if (msgs && Array.isArray(msgs)) {
                                        const m = msgs.find(mod => {
                                            if (!mod || !mod.id) return false;
                                            const s = mod.id._serialized || mod.id.$1;
                                            if (s === targetId) return true;
                                            if (rawPart && mod.id.id === rawPart) return true;
                                            return false;
                                        });
                                        if (m) return m;
                                    }
                                } catch (e) {}
                            }
                        }
                    }
                } catch (e) {}
                return null;
            }

            let m = await findMsg();

            for (let i = 0; !m && i < 8; i++) {
                await sleep(250);
                m = await findMsg();
            }

            if (!m) return { error: 'Messaggio non trovato nel database interno di WhatsApp' };

            if (m.mediaData || typeof m.downloadMedia === 'function') {
                try {
                    if (typeof m.downloadMedia === 'function') {
                        m.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
                    } else if (m.mediaData && typeof m.mediaData.downloadMedia === 'function') {
                        m.mediaData.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
                    }
                } catch (e) {}

                for (let i = 0; i < 32; i++) {
                    if (m.mediaData?.mediaStage === 'RESOLVED') break;
                    if (m.mediaObject?.mediaBlob || m.mediaData?.renderableUrl) break;
                    if (m.mediaData?.mediaStage && m.mediaData?.mediaStage.includes('ERROR')) break;
                    await sleep(250);
                }
            }

            let blob = null;

            try {
                const cache = window.require('WAWebMediaInMemoryBlobCache')?.InMemoryMediaBlobCache;
                if (cache) {
                    const hash = m.mediaObject?.filehash || m.filehash || m.mediaData?.filehash || m._data?.filehash;
                    if (hash) blob = cache.get(hash);
                }
            } catch (e) {}

            if (!blob && m.mediaObject?.mediaBlob) {
                try {
                    blob = typeof m.mediaObject.mediaBlob.forceToBlob === 'function'
                        ? m.mediaObject.mediaBlob.forceToBlob()
                        : m.mediaObject.mediaBlob;
                } catch (e) {}
            }

            if (!blob && m.mediaData?.renderableUrl) {
                try {
                    const resp = await window.fetch(m.mediaData.renderableUrl);
                    if (resp.ok) blob = await resp.blob();
                } catch (e) {}
            }

            if (!blob) {
                try {
                    const downloadManager = window.require('WAWebDownloadManager')?.downloadManager;
                    if (downloadManager && typeof downloadManager.downloadAndMaybeDecrypt === 'function') {
                        const mockQpl = { addAnnotations: () => mockQpl, addPoint: () => mockQpl };
                        const rawType = m.type || m.mediaData?.type || m._data?.type || 'image';
                        const safeType = rawType === 'album' ? 'image' : rawType;
                        const decrypted = await downloadManager.downloadAndMaybeDecrypt({
                            directPath: m.directPath || m.mediaData?.directPath || m._data?.directPath,
                            encFilehash: m.encFilehash || m.mediaData?.encFilehash || m._data?.encFilehash,
                            filehash: m.filehash || m.mediaData?.filehash || m._data?.filehash,
                            mediaKey: m.mediaKey || m.mediaData?.mediaKey || m._data?.mediaKey,
                            mediaKeyTimestamp: m.mediaKeyTimestamp || m.mediaData?.mediaKeyTimestamp || m._data?.mediaKeyTimestamp,
                            type: safeType,
                            signal: new AbortController().signal,
                            downloadQpl: mockQpl
                        });
                        if (decrypted) {
                            blob = new Blob([decrypted], { type: m.mimetype || m.mediaData?.mimetype || m._data?.mimetype || 'application/octet-stream' });
                        }
                    }
                } catch (e) {}
            }

            if (!blob) {
                try {
                    let img = null;
                    if (rawPart) {
                        img = document.querySelector(`div[data-id*="${rawPart}"] img[src^="blob:"]`) ||
                              document.querySelector(`div[data-id*="${rawPart}"] img`) ||
                              document.querySelector(`img[src*="${rawPart}"]`);
                    }
                    if (!img) {
                        const allImgs = Array.from(document.querySelectorAll('#main img[src^="blob:"]'));
                        if (allImgs.length > 0) {
                            img = allImgs[allImgs.length - 1];
                        }
                    }
                    if (img && img.src && img.src.startsWith('blob:')) {
                        const resp = await window.fetch(img.src);
                        if (resp.ok) blob = await resp.blob();
                    }
                } catch (e) {}
            }

            if (!blob) {
                return { error: `Impossibile estrarre blob multimediale (mediaStage: ${m.mediaData?.mediaStage || 'sconosciuto'})` };
            }

            const base64 = await new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onloadend = () => {
                    if (typeof reader.result === 'string') {
                        const commaIdx = reader.result.indexOf(',');
                        resolve(commaIdx !== -1 ? reader.result.substring(commaIdx + 1) : reader.result);
                    } else {
                        resolve('');
                    }
                };
                reader.onerror = () => reject(new Error('Errore FileReader durante lettura Blob'));
                reader.readAsDataURL(blob);
            });

            return {
                data: base64,
                mimetype: m.mimetype || (m.mediaData && m.mediaData.mimetype) || (m._data && m._data.mimetype) || blob.type || 'application/octet-stream',
                filename: m.filename || (m.mediaData && m.mediaData.filename) || (m._data && m._data.filename) || null,
                filesize: blob.size
            };
        }, targetId, rawId, remoteStr);

        if (result && result.data) {
            if (logger && typeof logger.info === 'function') {
                logger.info(`✨ Recupero multimediale resiliente riuscito per ${targetId} (${result.mimetype}, ${Math.round((result.filesize || 0) / 1024)} KB)`);
            }
            return result;
        } else if (result && result.error) {
            if (logger && typeof logger.warn === 'function') {
                logger.warn(`⚠️ Dettaglio tentativo recupero resiliente per ${targetId}: ${result.error}`);
            }
        }
    } catch (evalErr) {
        if (logger && typeof logger.error === 'function') {
            logger.error(`❌ Errore in downloadMediaResilient per ${msgId}: ${evalErr.message}`);
        }
    }

    return null;
}

/**
 * Recupero manuale di un allegato da parte del negoziante tramite pulsante in dashboard
 */
async function redownloadOrderMedia(order, clientInstance, dbInstance, printFolder, logger = console) {
    if (!order || !order.id) throw new Error('Dati ordine non validi per il recupero');
    if (!clientInstance || !clientInstance.pupPage) throw new Error('Client WhatsApp non pronto');

    if (logger && typeof logger.info === 'function') {
        logger.info(`🔄 Tentativo recupero download allegato per ordine ${order.id} (msgId: ${order.msgId}, contatto: ${order.cliente || order.telefono})...`);
    }

    const result = await clientInstance.pupPage.evaluate(async (targetMsgId, userPhone, contactName) => {
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        const { Msg, Chat } = window.require('WAWebCollections') || {};
        const { Cmd } = window.require('WAWebCmd') || {};
        const widFactory = window.require('WAWebWidFactory');

        let chat = null;
        if (userPhone && widFactory && Chat) {
            try {
                chat = Chat.get(widFactory.createWid(userPhone.includes('@') ? userPhone : `${userPhone}@c.us`));
            } catch (e) {}
            if (!chat) {
                try {
                    chat = Chat.get(widFactory.createWid(`${userPhone}@lid`));
                } catch (e) {}
            }
            if (!chat && contactName && Chat.models) {
                chat = Chat.models.find(c => {
                    const title = c.name || c.formattedTitle || (c.contact && (c.contact.name || c.contact.pushname));
                    return title && title.toLowerCase() === String(contactName).toLowerCase();
                });
            }
        }

        if (chat && Cmd && typeof Cmd.openChatBottom === 'function') {
            try {
                await Cmd.openChatBottom({ chat });
                await sleep(800);
            } catch (e) {}
        }

        let m = null;
        const rawPart = targetMsgId && targetMsgId.includes('_') ? targetMsgId.split('_').pop() : targetMsgId;

        if (targetMsgId && Msg) {
            try { m = Msg.get(targetMsgId); } catch (e) {}
        }

        if (!m && targetMsgId && Msg && typeof Msg.getMessagesById === 'function') {
            try {
                const res = await Msg.getMessagesById([targetMsgId]);
                m = res?.messages?.[0] || (Array.isArray(res) ? res[0] : null);
            } catch (e) {}
        }

        if (!m && chat && typeof chat.fetchMessages === 'function') {
            try {
                const msgs = await chat.fetchMessages({ limit: 30 });
                if (msgs && Array.isArray(msgs)) {
                    m = msgs.find(mod => {
                        if (!mod || !mod.id) return false;
                        const s = mod.id._serialized || mod.id.$1;
                        if (s === targetMsgId) return true;
                        if (rawPart && mod.id.id === rawPart) return true;
                        return false;
                    });
                }
            } catch (e) {}
        }

        if (!m && Msg && Msg.models) {
            m = Msg.models.find(mod => {
                if (!mod || !mod.id) return false;
                const s = mod.id._serialized || mod.id.$1;
                if (s === targetMsgId) return true;
                if (rawPart && mod.id.id === rawPart) return true;
                return false;
            });
        }

        if (!m && chat && chat.msgs && chat.msgs.models) {
            for (let i = chat.msgs.models.length - 1; i >= 0; i--) {
                const candidate = chat.msgs.models[i];
                if (candidate && !candidate.id?.fromMe && candidate.type !== 'album' && (candidate.hasMedia || candidate.mediaData || candidate.type === 'image' || candidate.type === 'document')) {
                    m = candidate;
                    break;
                }
            }
        }

        if (m && (m.mediaData || typeof m.downloadMedia === 'function')) {
            try {
                if (typeof m.downloadMedia === 'function') {
                    m.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
                } else if (m.mediaData && typeof m.mediaData.downloadMedia === 'function') {
                    m.mediaData.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
                }
            } catch (e) {}

            for (let i = 0; i < 20; i++) {
                if (m.mediaData?.mediaStage === 'RESOLVED') break;
                if (m.mediaObject?.mediaBlob || m.mediaData?.renderableUrl) break;
                if (m.mediaData?.mediaStage && m.mediaData?.mediaStage.includes('ERROR')) break;
                await sleep(200);
            }
        }

        let blob = null;

        try {
            const cache = window.require('WAWebMediaInMemoryBlobCache')?.InMemoryMediaBlobCache;
            if (cache) {
                const hash = m?.mediaObject?.filehash || m?.filehash || m?.mediaData?.filehash || m?._data?.filehash;
                if (hash) blob = cache.get(hash);
            }
        } catch (e) {}

        if (!blob && m?.mediaObject?.mediaBlob) {
            try {
                blob = typeof m.mediaObject.mediaBlob.forceToBlob === 'function'
                    ? m.mediaObject.mediaBlob.forceToBlob()
                    : m.mediaObject.mediaBlob;
            } catch (e) {}
        }

        if (!blob && m?.mediaData?.renderableUrl) {
            try {
                const resp = await window.fetch(m.mediaData.renderableUrl);
                if (resp.ok) blob = await resp.blob();
            } catch (e) {}
        }

        if (!blob && m) {
            try {
                const downloadManager = window.require('WAWebDownloadManager')?.downloadManager;
                if (downloadManager && typeof downloadManager.downloadAndMaybeDecrypt === 'function') {
                    const mockQpl = { addAnnotations: () => mockQpl, addPoint: () => mockQpl };
                    const rawType = m.type || m.mediaData?.type || m._data?.type || 'image';
                    const safeType = rawType === 'album' ? 'image' : rawType;
                    const decrypted = await downloadManager.downloadAndMaybeDecrypt({
                        directPath: m.directPath || m.mediaData?.directPath || m._data?.directPath,
                        encFilehash: m.encFilehash || m.mediaData?.encFilehash || m._data?.encFilehash,
                        filehash: m.filehash || m.mediaData?.filehash || m._data?.filehash,
                        mediaKey: m.mediaKey || m.mediaData?.mediaKey || m._data?.mediaKey,
                        mediaKeyTimestamp: m.mediaKeyTimestamp || m.mediaData?.mediaKeyTimestamp || m._data?.mediaKeyTimestamp,
                        type: safeType,
                        signal: new AbortController().signal,
                        downloadQpl: mockQpl
                    });
                    if (decrypted) {
                        blob = new Blob([decrypted], { type: m.mimetype || m.mediaData?.mimetype || m._data?.mimetype || 'image/jpeg' });
                    }
                }
            } catch (e) {}
        }

        if (!blob) {
            try {
                let img = null;
                if (rawPart) {
                    img = document.querySelector(`div[data-id*="${rawPart}"] img[src^="blob:"]`) ||
                          document.querySelector(`div[data-id*="${rawPart}"] img`);
                }
                if (!img) {
                    const allImgs = Array.from(document.querySelectorAll('#main img[src^="blob:"]'));
                    if (allImgs.length > 0) {
                        img = allImgs[allImgs.length - 1];
                    }
                }
                if (img && img.src && img.src.startsWith('blob:')) {
                    const resp = await window.fetch(img.src);
                    if (resp.ok) blob = await resp.blob();
                }
            } catch (e) {}
        }

        if (!blob) {
            return { error: 'Impossibile estrarre il file multimediale da WhatsApp Web.' };
        }

        const base64 = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                if (typeof reader.result === 'string') {
                    const commaIdx = reader.result.indexOf(',');
                    resolve(commaIdx !== -1 ? reader.result.substring(commaIdx + 1) : reader.result);
                } else {
                    resolve('');
                }
            };
            reader.onerror = () => reject(new Error('Errore FileReader durante lettura Blob'));
            reader.readAsDataURL(blob);
        });

        return {
            data: base64,
            mimetype: (m && (m.mimetype || m.mediaData?.mimetype || m._data?.mimetype)) || blob.type || 'image/jpeg',
            filename: (m && (m.filename || m.mediaData?.filename || m._data?.filename)) || null
        };
    }, order.msgId, order.telefono, order.cliente);

    if (!result || !result.data) {
        throw new Error((result && result.error) || 'Download non riuscito da WhatsApp Web');
    }

    const extMap = {
        'image/jpeg': 'jpg',
        'image/png': 'png',
        'image/webp': 'webp',
        'application/pdf': 'pdf'
    };
    const ext = extMap[result.mimetype] || result.mimetype?.split('/')[1]?.split(';')[0] || 'jpg';
    const contactName = order.cliente || order.telefono || 'Cliente';
    const safeContactName = contactName.replace(/[^a-z0-9]/gi, '_');
    const contactFolder = path.join(printFolder, safeContactName);
    if (!fs.existsSync(contactFolder)) {
        fs.mkdirSync(contactFolder, { recursive: true });
    }

    const timestamp = Date.now();
    const fileName = `${timestamp}_recuperato.${ext}`;
    const filePath = path.join(contactFolder, fileName);
    fs.writeFileSync(filePath, Buffer.from(result.data, 'base64'));

    const relativePath = `${safeContactName}/${fileName}`;
    const cleanMsg = (order.messaggio || '')
        .replace(/\n\n⚠️ \(Errore: Impossibile scaricare l'allegato\)/g, '')
        .replace(/⚠️ \(Errore: Impossibile scaricare l'allegato\)/g, '')
        .trim();

    order.file = relativePath;
    order.tipo = (result.mimetype && result.mimetype.startsWith('image/')) ? 'immagine' : (result.mimetype === 'application/pdf' ? 'pdf' : 'documento');
    order.messaggio = cleanMsg;
    order.stato = 'nuovo';

    if (dbInstance && typeof dbInstance.saveOrder === 'function') {
        await dbInstance.saveOrder(order);
    }
    if (logger && typeof logger.info === 'function') {
        logger.info(`🎉 Recupero download completato con successo per ordine ${order.id}: salvato in ${relativePath}`);
    }
    return { success: true, order };
}

module.exports = {
    saveMediaToDisk,
    downloadMediaResilient,
    redownloadOrderMedia
};
