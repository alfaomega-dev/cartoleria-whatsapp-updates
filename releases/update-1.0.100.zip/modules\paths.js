const path = require('path');
const fs = require('fs');

const isPkg = !!process.pkg;
const ROOT_DIR = isPkg ? path.dirname(process.execPath) : path.join(__dirname, '..');

const isInstalled = isPkg
    || ROOT_DIR.toLowerCase().includes('program files')
    || ROOT_DIR.toLowerCase().includes('appdata\\local');

const appDataPath = process.env.APPDATA
    || path.join(process.env.USERPROFILE, 'AppData', 'Roaming');

const DATA_DIR = isInstalled ? path.join(appDataPath, 'PrintZap') : ROOT_DIR;
const AUTH_DIR = path.join(DATA_DIR, '.wwebjs_auth');
const PRINT_FOLDER = path.join(DATA_DIR, 'file_da_stampare');

// Auto-migrazione dei dati utente da CartoleriaWhatsApp a PrintZap (preserva sessione e database)
if (isInstalled && !fs.existsSync(DATA_DIR)) {
    const oldDataDir = path.join(appDataPath, 'CartoleriaWhatsApp');
    if (fs.existsSync(oldDataDir)) {
        try {
            fs.renameSync(oldDataDir, DATA_DIR);
        } catch (migrateErr) {
            // Fallback se bloccato: procederà a ricrearla vuota
        }
    }
}

// Assicura l'esistenza delle cartelle principali
[DATA_DIR, AUTH_DIR, PRINT_FOLDER].forEach(d => {
    if (!fs.existsSync(d)) {
        fs.mkdirSync(d, { recursive: true });
    }
});

module.exports = {
    isPkg,
    isInstalled,
    ROOT_DIR,
    DATA_DIR,
    AUTH_DIR,
    PRINT_FOLDER
};
