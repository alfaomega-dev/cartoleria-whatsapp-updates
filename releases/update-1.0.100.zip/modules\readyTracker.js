// Modulo per la gestione e il tracciamento dello stato "Stampa Pronta" (Merchant Ready Tracker).
// Estratto da whatsappClient.js (Fase 6D del piano di modularizzazione).
// Isola la memoria in-process delle notifiche del negoziante e la persistenza SQLite dello stato stampato.

const lastReadyTimestampByContact = new Map();

function isReadyResponse(bodyText) {
    const bodyLower = (bodyText || '').toLowerCase();
    return bodyLower.includes('stampa pronta') ||
           bodyLower.includes('pronto') ||
           bodyLower.includes('pronte') ||
           bodyLower.includes('pronti') ||
           bodyLower.includes('ritirare');
}

function recordReadyTimestamp(keys, timestampSec) {
    if (!timestampSec) return;
    const sec = typeof timestampSec === 'number'
        ? (timestampSec > 1e11 ? Math.floor(timestampSec / 1000) : timestampSec)
        : Math.floor(new Date(timestampSec).getTime() / 1000);
    if (!sec || isNaN(sec)) return;
    const list = (Array.isArray(keys) ? keys : [keys]).filter(Boolean);
    for (const k of list) {
        const cleanK = String(k).trim().toLowerCase();
        const prev = lastReadyTimestampByContact.get(cleanK) || 0;
        if (sec > prev) {
            lastReadyTimestampByContact.set(cleanK, sec);
        }
        const numericOnly = cleanK.replace(/[^0-9]/g, '');
        if (numericOnly && numericOnly.length >= 7) {
            const prevNum = lastReadyTimestampByContact.get(numericOnly) || 0;
            if (sec > prevNum) {
                lastReadyTimestampByContact.set(numericOnly, sec);
            }
        }
    }
}

function isMessageCoveredByReady(keys, msgTimestampSec) {
    if (!msgTimestampSec) return false;
    const sec = typeof msgTimestampSec === 'number'
        ? (msgTimestampSec > 1e11 ? Math.floor(msgTimestampSec / 1000) : msgTimestampSec)
        : Math.floor(new Date(msgTimestampSec).getTime() / 1000);
    if (!sec || isNaN(sec)) return false;
    const list = (Array.isArray(keys) ? keys : [keys]).filter(Boolean);
    for (const k of list) {
        const cleanK = String(k).trim().toLowerCase();
        const readySec = lastReadyTimestampByContact.get(cleanK) || 0;
        if (readySec > 0 && sec <= readySec) {
            return true;
        }
        const numericOnly = cleanK.replace(/[^0-9]/g, '');
        if (numericOnly && numericOnly.length >= 7) {
            const readySecNum = lastReadyTimestampByContact.get(numericOnly) || 0;
            if (readySecNum > 0 && sec <= readySecNum) {
                return true;
            }
        }
    }
    return false;
}

async function handleMerchantReadyMessage(targetId, bodyText, chatTitle = null, msgTimestamp = null, {
    getClient,
    clientInstance,
    dbInstance,
    notifyDashboardFn,
    logger = console
} = {}) {
    if (!targetId || targetId.includes('@g.us') || targetId.includes('@broadcast') || targetId.includes('@newsletter')) return false;

    if (!isReadyResponse(bodyText)) return false;

    // Calcola il timestamp ISO massimo: il messaggio del negoziante può marcare
    // SOLAMENTE ordini arrivati PRIMA o nello stesso momento del messaggio!
    let maxDateIso = null;
    let maxTimestampSec = null;
    if (msgTimestamp) {
        if (typeof msgTimestamp === 'number') {
            maxTimestampSec = msgTimestamp > 1e11 ? Math.floor(msgTimestamp / 1000) : msgTimestamp;
            maxDateIso = new Date(maxTimestampSec * 1000).toISOString();
        } else if (typeof msgTimestamp === 'string') {
            const parsed = new Date(msgTimestamp);
            maxTimestampSec = Math.floor(parsed.getTime() / 1000);
            maxDateIso = msgTimestamp.includes('T') ? msgTimestamp : parsed.toISOString();
        } else if (msgTimestamp instanceof Date) {
            maxTimestampSec = Math.floor(msgTimestamp.getTime() / 1000);
            maxDateIso = msgTimestamp.toISOString();
        }
    } else {
        // Se non specificato (es. evento real-time immediato), usa l'orario corrente
        const now = new Date();
        maxTimestampSec = Math.floor(now.getTime() / 1000);
        maxDateIso = now.toISOString();
    }

    if (logger && typeof logger.info === 'function') {
        logger.info(`⚡ Rilevato messaggio notifica/risposta negoziante per ${targetId}: "${bodyText}" (fino a ${maxDateIso})`);
    }
    const candidates = [targetId, String(targetId).replace(/@c\.us|@lid/g, '')];
    let contactName = chatTitle || null;

    const client = typeof getClient === 'function' ? getClient() : clientInstance;

    try {
        if (client) {
            const contact = await client.getContactById(targetId).catch(() => null);
            if (contact && contact.number) candidates.push(contact.number);
            if (contact && (contact.name || contact.pushname)) contactName = contactName || contact.name || contact.pushname;

            if (String(targetId).endsWith('@lid') && typeof client.getContactLidAndPhone === 'function') {
                const res = await client.getContactLidAndPhone(targetId).catch(() => null);
                if (res && res[0] && res[0].pn) {
                    const cleanPn = res[0].pn;
                    candidates.push(cleanPn);
                    candidates.push(cleanPn.replace(/[^0-9]/g, ''));
                }
            }
        }
    } catch (e) {}

    // Registra il timestamp di Stampa Pronta in memoria per tutti gli alias del contatto
    if (maxTimestampSec) {
        recordReadyTimestamp([...candidates, contactName], maxTimestampSec);
    }

    if (!dbInstance) return false;

    const updated = await dbInstance.markContactOrdersPrinted(candidates, contactName, maxDateIso);
    if (updated) {
        if (logger && typeof logger.info === 'function') {
            logger.info(`✅ Ordini per ${candidates.join(', ')} (${contactName || 'Nome n/d'}) contrassegnati come STAMPATI in seguito a risposta (<= ${maxDateIso}).`);
        }
        if (typeof notifyDashboardFn === 'function') {
            notifyDashboardFn({ type: 'ORDERS_UPDATED' });
        }
        return true;
    }
    return false;
}

function clearReadyTrackerMap() {
    lastReadyTimestampByContact.clear();
}

module.exports = {
    isReadyResponse,
    recordReadyTimestamp,
    isMessageCoveredByReady,
    handleMerchantReadyMessage,
    clearReadyTrackerMap
};
