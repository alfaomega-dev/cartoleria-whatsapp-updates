const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const { ROOT_DIR, DATA_DIR } = require('./paths');
const { getConfig } = require('./config');

let _logger = console;

function init({ logger } = {}) {
    if (logger) _logger = logger;
}

function applyLocalHotPatchCache(localPatchPath) {
    if (fs.existsSync(localPatchPath)) {
        try {
            _logger.info(`🔄 Hot-Patch: Caricamento patch in memoria da: ${localPatchPath}`);
            const utilsModulePath = require.resolve('whatsapp-web.js/src/util/Injected/Utils');
            const patchedModule = require(localPatchPath);
            require.cache[utilsModulePath] = {
                id: utilsModulePath,
                filename: utilsModulePath,
                loaded: true,
                exports: patchedModule
            };
            _logger.info('✅ Hot-Patch: Applicata con successo la patch in require.cache!');
        } catch (cacheErr) {
            _logger.error(`⚠️ Hot-Patch: Errore nell'override di require.cache (${cacheErr.message})`);
        }
    } else {
        _logger.info('ℹ️ Hot-Patch: Nessuna patch personalizzata da caricare. Verrà usata la versione predefinita.');
    }
}

async function checkAndApplyHotPatch() {
    const config = getConfig();
    const patchDir = path.join(DATA_DIR, 'patch');
    const localPatchPath = path.join(patchDir, 'Utils.js');
    const originalPatchPath = path.join(ROOT_DIR, 'node_modules', 'whatsapp-web.js', 'src', 'util', 'Injected', 'Utils.js');

    if (!config.updatesUrl) {
        _logger.info('ℹ️ Hot-Patch: updatesUrl non impostato, salto il controllo.');
        applyLocalHotPatchCache(localPatchPath);
        return;
    }

    const baseUrl = config.updatesUrl.replace(/\/+$/, '');
    const patchUrl = `${baseUrl}/patch/Utils.js`;

    _logger.info(`🔍 Hot-Patch: Controllo aggiornamenti critici su: ${patchUrl}...`);

    try {
        const response = await axios.get(patchUrl, { timeout: 8000 });
        if (response.status === 200 && typeof response.data === 'string') {
            const remoteContent = response.data;

            let currentContent = '';
            if (fs.existsSync(localPatchPath)) {
                currentContent = fs.readFileSync(localPatchPath, 'utf8');
            } else if (fs.existsSync(originalPatchPath)) {
                currentContent = fs.readFileSync(originalPatchPath, 'utf8');
            }

            const remoteHash = crypto.createHash('md5').update(remoteContent).digest('hex');
            const currentHash = crypto.createHash('md5').update(currentContent).digest('hex');

            if (remoteHash !== currentHash) {
                _logger.info('🔄 Hot-Patch: Trovata una nuova versione di Utils.js. Salvataggio in corso...');
                fs.mkdirSync(patchDir, { recursive: true });
                fs.writeFileSync(localPatchPath, remoteContent, 'utf8');
                _logger.info('✅ Hot-Patch: Salvata patch di compatibilità WhatsApp Web con successo in DATA_DIR.');
            } else {
                _logger.info('✅ Hot-Patch: Utils.js locale è già allineato alla versione remota.');
            }
        }
    } catch (err) {
        _logger.error(`⚠️ Hot-Patch: Impossibile scaricare la patch remota (${err.message}). Verrà utilizzata la patch locale più recente.`);
    }

    applyLocalHotPatchCache(localPatchPath);
}

// Verifica e attende che la connessione di rete e i server WhatsApp siano pronti (fondamentale al boot del PC)
async function waitForNetwork(timeoutSec = 15) {
    _logger.info('🌐 Verifica connettività Internet per WhatsApp...');
    const startTime = Date.now();
    let attempts = 0;
    while (Date.now() - startTime < timeoutSec * 1000) {
        attempts++;
        try {
            await axios.get('https://web.whatsapp.com', { timeout: 3500 });
            _logger.info(`✅ Connessione Internet e web.whatsapp.com verificati (tentativo #${attempts}).`);
            return true;
        } catch (err) {
            // Se otteniamo una qualsiasi risposta HTTP (es. 200, 302, 403, 429), la connessione TCP/IP è attiva!
            if (err.response) {
                _logger.info(`✅ Rete Internet verificata (risposta HTTP ${err.response.status}).`);
                return true;
            }
            _logger.info(`⏳ In attesa della connessione di rete (tentativo #${attempts})...`);
            await new Promise(r => setTimeout(r, 2000));
        }
    }
    _logger.info('⚠️ Timeout verifica rete: procedo con l\'avvio di WhatsApp.');
    return false;
}

function isPuppeteerContextError(err) {
    const msg = err && (err.message || err.toString());
    return (
        msg === 'r' ||
        (msg && msg.includes('Execution context was destroyed')) ||
        (msg && msg.includes('Cannot read properties of null')) ||
        (msg && msg.includes('Session closed'))
    );
}

// Helper: applica un timeout a una Promise
function promiseTimeout(promise, ms, name = 'Promise') {
    let timeout = new Promise((_, reject) => {
        let id = setTimeout(() => {
            clearTimeout(id);
            reject(new Error(`Timeout superato (${ms}ms) per: ${name}`));
        }, ms);
    });
    return Promise.race([promise, timeout]);
}

module.exports = {
    init,
    applyLocalHotPatchCache,
    checkAndApplyHotPatch,
    waitForNetwork,
    isPuppeteerContextError,
    promiseTimeout
};
