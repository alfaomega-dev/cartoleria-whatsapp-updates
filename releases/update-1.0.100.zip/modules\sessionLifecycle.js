// Modulo per la gestione del ciclo di vita della sessione WhatsApp (logout, reset, shutdown).
// Estratto da whatsappClient.js (Fase 7 del piano di modularizzazione).
// Utilizza getter e setter espliciti per evitare variabili globali condivise.

const fs = require('fs');
const path = require('path');
const { execSync: defaultExecSync } = require('child_process');
const { DATA_DIR: defaultDataDir } = require('./paths');
const { getConfig: defaultGetConfig, saveConfig: defaultSaveConfig } = require('./config');

async function logout({
    getClient,
    setClient,
    setWpStatus,
    setLatestQR,
    setInitializing,
    restart,
    getConfigFn = defaultGetConfig,
    saveConfigFn = defaultSaveConfig,
    execSyncFn = defaultExecSync,
    dataDir = defaultDataDir,
    logger = console
} = {}) {
    if (logger && typeof logger.info === 'function') {
        logger.info('🔄 Richiesta Logout Ricevuta...');
    }
    const client = typeof getClient === 'function' ? getClient() : null;
    if (client) {
        let pid = null;
        try {
            if (client.pupBrowser && client.pupBrowser.process()) {
                pid = client.pupBrowser.process().pid;
            }
        } catch (e) { }

        try {
            await client.logout();
            if (logger && typeof logger.info === 'function') {
                logger.info('✅ Logout effettuato.');
            }
        } catch (err) {
            if (logger && typeof logger.info === 'function') {
                logger.info('ℹ️ Client già disconnesso o logout non necessario.');
            }
        }
        try {
            const destroyPromise = client.destroy();
            const timeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Timeout distruzione client')), 5000)
            );
            await Promise.race([destroyPromise, timeoutPromise]);
            await new Promise(r => setTimeout(r, 1000));
            if (typeof setClient === 'function') setClient(null);
            if (logger && typeof logger.info === 'function') {
                logger.info('✅ Client distrutto.');
            }
        } catch (err) {
            if (logger && typeof logger.info === 'function') {
                logger.info('❌ Errore o Timeout durante la distruzione del client:', err.message);
            }
            if (typeof setClient === 'function') setClient(null);
        }

        if (pid && typeof execSyncFn === 'function') {
            try { execSyncFn(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
            await new Promise(r => setTimeout(r, 1000));
        }
    }

    const config = typeof getConfigFn === 'function' ? getConfigFn() : {};
    config.clientId = 'session_' + Date.now();
    if (typeof saveConfigFn === 'function') saveConfigFn(config);
    if (logger && typeof logger.info === 'function') {
        logger.info(`🔄 Generata nuova cartella sessione per scavalcare i file in uso: ${config.clientId}`);
    }

    const cachePath = path.join(dataDir, '.wwebjs_cache');
    if (fs.existsSync(cachePath)) {
        try {
            fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 });
            if (logger && typeof logger.info === 'function') {
                logger.info('🗑️ Cache rimossa.');
            }
        } catch (err) {
            if (logger && typeof logger.error === 'function') {
                logger.error('⚠️ Errore rimozione cache:', err.message);
            }
        }
    }

    if (typeof setWpStatus === 'function') setWpStatus('DISCONNECTED');
    if (typeof setLatestQR === 'function') setLatestQR(null);
    if (typeof setInitializing === 'function') setInitializing(false);

    if (typeof restart === 'function') {
        setTimeout(restart, 2000);
    }
    return { success: true, message: 'Disconnesso. Il client si sta riavviando.' };
}

async function reset({
    getClient,
    setClient,
    setWpStatus,
    setLatestQR,
    setInitializing,
    restart,
    getConfigFn = defaultGetConfig,
    saveConfigFn = defaultSaveConfig,
    execSyncFn = defaultExecSync,
    dataDir = defaultDataDir,
    logger = console
} = {}) {
    if (logger && typeof logger.info === 'function') {
        logger.info('🔄 Richiesta RESET Sessione Ricevuta...');
    }
    const client = typeof getClient === 'function' ? getClient() : null;
    if (client) {
        let pid = null;
        try {
            if (client.pupBrowser && client.pupBrowser.process()) {
                pid = client.pupBrowser.process().pid;
            }
        } catch (e) { }

        try {
            const destroyPromise = client.destroy();
            const timeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Timeout distruzione client durante reset')), 5000)
            );
            await Promise.race([destroyPromise, timeoutPromise]);
            await new Promise(r => setTimeout(r, 1000));
            if (logger && typeof logger.info === 'function') {
                logger.info('✅ Client distrutto durante reset.');
            }
        } catch (err) {
            if (logger && typeof logger.info === 'function') {
                logger.info('ℹ️ Errore/Timeout distruzione client durante reset:', err.message);
            }
        }
        if (typeof setClient === 'function') setClient(null);

        if (pid && typeof execSyncFn === 'function') {
            if (logger && typeof logger.info === 'function') {
                logger.info(`🧹 Forzo sicurezza kill su PID noto del browser: ${pid}`);
            }
            try { execSyncFn(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
            await new Promise(r => setTimeout(r, 1500));
        }
    }

    const config = typeof getConfigFn === 'function' ? getConfigFn() : {};
    config.clientId = 'session_' + Date.now();
    if (typeof saveConfigFn === 'function') saveConfigFn(config);
    if (logger && typeof logger.info === 'function') {
        logger.info(`🗑️ Nuova sessione assegnata: ${config.clientId}. Vecchia folder ignorata se bloccata.`);
    }

    const cachePath = path.join(dataDir, '.wwebjs_cache');
    if (fs.existsSync(cachePath)) {
        try {
            fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 });
            if (logger && typeof logger.info === 'function') {
                logger.info('🗑️ Cache rimossa durante reset.');
            }
        } catch (err) {
            if (logger && typeof logger.error === 'function') {
                logger.error('⚠️ Errore rimozione cache durante reset:', err.message);
            }
        }
    }

    if (typeof setWpStatus === 'function') setWpStatus('DISCONNECTED');
    if (typeof setLatestQR === 'function') setLatestQR(null);
    if (typeof setInitializing === 'function') setInitializing(false);

    if (typeof restart === 'function') {
        setTimeout(restart, 2000);
    }
    return { success: true, message: 'Reset completato. Il client si sta riavviando.' };
}

async function shutdown({
    getClient,
    setClient,
    clearWatchdog,
    logger = console
} = {}) {
    if (typeof clearWatchdog === 'function') {
        clearWatchdog();
    }
    const client = typeof getClient === 'function' ? getClient() : null;
    if (client) {
        try {
            const destroyPromise = client.destroy();
            const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout destroy')), 4000));
            await Promise.race([destroyPromise, timeoutPromise]).catch(err => {
                if (logger && typeof logger.error === 'function') {
                    logger.error('Errore durante client.destroy in shutdown:', err.message);
                }
            });
        } catch (err) { }
        if (typeof setClient === 'function') setClient(null);
    }
}

module.exports = {
    logout,
    reset,
    shutdown
};
