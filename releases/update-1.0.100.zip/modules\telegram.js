const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { spawn, execSync } = require('child_process');
const localtunnel = require('localtunnel');
const db = require('../db');
const { ROOT_DIR, DATA_DIR, PRINT_FOLDER } = require('./paths');
const { getConfig, saveConfig } = require('./config');

let _logger = console;
let _PORT = 3000;
let _notifyDashboard = () => {};

// Telegram state
let telegramPollingTimer = null;
let lastTelegramUpdateId = 0;
let isTelegramPolling = false;
let telegramStatus = 'DISCONNECTED'; // 'DISCONNECTED'|'CONNECTING'|'ONLINE'|'ERROR_TOKEN'|'ERROR_NET'|'DISABLED'
let telegramBotName = '';
let telegramBotUsername = '';
let telegramReconnectDelay = 1000;
let cloudflaredProcess = null;
let cloudflareTimeoutTimer = null;
let localtunnelInstance = null;
let currentTunnelUrl = '';

function init({ logger, PORT, notifyDashboard } = {}) {
    if (logger) _logger = logger;
    if (PORT) _PORT = PORT;
    if (notifyDashboard) _notifyDashboard = notifyDashboard;
}

function sanitizeClientFolderTelegram(name, key) {
    const safeName = (name || 'Cliente').replace(/[^a-zA-Z0-9_]/g, '_');
    const safeKey = (key || 'key').replace(/[^a-zA-Z0-9_]/g, '_');
    return `Tg_${safeName}_${safeKey}`;
}

function findCloudflaredBinary() {
    const candidates = [
        path.join(ROOT_DIR, 'cloudflared.exe'),
        path.join(DATA_DIR, 'cloudflared.exe'),
        path.join(process.cwd(), 'cloudflared.exe'),
        'cloudflared.exe'
    ];
    for (const c of candidates) {
        if (c && fs.existsSync(c)) {
            return c;
        }
    }
    return null;
}

function stopCloudflareProcess() {
    if (cloudflareTimeoutTimer) {
        clearTimeout(cloudflareTimeoutTimer);
        cloudflareTimeoutTimer = null;
    }
    if (cloudflaredProcess) {
        try { cloudflaredProcess.kill('SIGKILL'); } catch (e) {}
        cloudflaredProcess = null;
    }
    if (process.platform === 'win32') {
        try { execSync('taskkill /F /IM cloudflared.exe', { stdio: 'ignore' }); } catch (e) {}
    }
}

async function startCloudflareTunnel(token) {
    stopCloudflareProcess();

    const binPath = findCloudflaredBinary();
    if (!binPath) {
        _logger.error('❌ Executable cloudflared.exe non trovato nelle cartelle di gioco o di installazione.');
        telegramStatus = 'ERROR_NET';
        return false;
    }

    _logger.info(`🚀 [CLOUDFLARE] Avvio Cloudflare Tunnel con: ${binPath}...`);

    return new Promise((resolve) => {
        let isResolved = false;
        if (cloudflareTimeoutTimer) clearTimeout(cloudflareTimeoutTimer);
        cloudflareTimeoutTimer = setTimeout(() => {
            if (!isResolved) {
                isResolved = true;
                cloudflareTimeoutTimer = null;
                _logger.error('❌ [CLOUDFLARE] Timeout avvio tunnel (35s).');
                telegramStatus = 'ERROR_NET';
                resolve(false);
            }
        }, 35000);

        try {
            cloudflaredProcess = spawn(binPath, ['tunnel', '--url', `http://localhost:${_PORT}`], {
                windowsHide: true
            });

            const onData = async (data) => {
                const text = data.toString();
                const match = text.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/i);
                if (match && !isResolved) {
                    isResolved = true;
                    if (cloudflareTimeoutTimer) {
                        clearTimeout(cloudflareTimeoutTimer);
                        cloudflareTimeoutTimer = null;
                    }
                    currentTunnelUrl = match[0];
                    _logger.info(`✅ [CLOUDFLARE] Tunnel generato con successo: ${currentTunnelUrl}`);
                    _logger.info('⏳ [CLOUDFLARE] Attesa propagazione DNS (3.5s)...');

                    // Attendi 3.5s per consentire a Cloudflare di propagare il record DNS globale a Telegram
                    await new Promise(r => setTimeout(r, 3500));

                    const webhookEndpoint = `${currentTunnelUrl}/api/telegram/webhook`;
                    let success = false;

                    for (let attempt = 1; attempt <= 3; attempt++) {
                        try {
                            const setRes = await axios.get(`https://api.telegram.org/bot${token}/setWebhook`, {
                                params: {
                                    url: webhookEndpoint,
                                    allowed_updates: JSON.stringify(["message", "edited_message"])
                                },
                                timeout: 10000
                            });
                            if (setRes.data && setRes.data.ok) {
                                telegramStatus = 'ONLINE';
                                _logger.info(`✅ Webhook Telegram registrato su Cloudflare Tunnel: ${webhookEndpoint}`);
                                success = true;
                                break;
                            } else {
                                _logger.error(`❌ Errore registrazione Webhook (tentativo ${attempt}): ${JSON.stringify(setRes.data)}`);
                            }
                        } catch (err) {
                            const errDesc = err.response?.data?.description || err.message;
                            _logger.warn(`⚠️ Tentativo ${attempt}/3 setWebhook fallito (${errDesc}). Riprovo tra 2s...`);
                            await new Promise(r => setTimeout(r, 2000));
                        }
                    }

                    if (success) {
                        resolve(true);
                    } else {
                        telegramStatus = 'ERROR_NET';
                        _logger.error('❌ Impossibile registrare Webhook su Telegram dopo 3 tentativi.');
                        resolve(false);
                    }
                }
            };

            if (cloudflaredProcess.stdout) cloudflaredProcess.stdout.on('data', onData);
            if (cloudflaredProcess.stderr) cloudflaredProcess.stderr.on('data', onData);

            cloudflaredProcess.on('error', (err) => {
                _logger.error(`❌ [CLOUDFLARE] Errore processo: ${err.message}`);
                if (!isResolved) {
                    isResolved = true;
                    clearTimeout(timeoutTimer);
                    telegramStatus = 'ERROR_NET';
                    resolve(false);
                }
            });

            cloudflaredProcess.on('close', (code) => {
                _logger.info(`🚀 [CLOUDFLARE] Processo terminato (code ${code}).`);
                cloudflaredProcess = null;
            });
        } catch (e) {
            clearTimeout(timeoutTimer);
            _logger.error(`❌ Errore spawn cloudflared: ${e.message}`);
            telegramStatus = 'ERROR_NET';
            resolve(false);
        }
    });
}

async function initTelegramService() {
    await stopTelegramBot();

    const config = getConfig();

    if (config.telegramEnabled === false) {
        telegramStatus = 'DISABLED';
        _logger.info('ℹ️ Servizio Telegram: Disattivato dall\'utente (flag telegramEnabled: false).');
        return;
    }

    const mode = config.telegramMode || 'cloudflare';
    const token = config.telegramBotToken ? config.telegramBotToken.trim() : '';

    if (mode === 'off') {
        telegramStatus = 'DISABLED';
        _logger.info('ℹ️ Servizio Telegram: Disabilitato dall\'utente.');
        return;
    }

    if (!token) {
        telegramStatus = 'DISABLED';
        _logger.info('ℹ️ Servizio Telegram: Nessun token configurato.');
        return;
    }

    telegramStatus = 'CONNECTING';
    _logger.info(`✈️ Servizio Telegram: avvio in modalità '${mode}'...`);

    try {
        const meRes = await axios.get(`https://api.telegram.org/bot${token}/getMe`, { timeout: 8000 });
        if (meRes.data && meRes.data.ok && meRes.data.result) {
            telegramBotName = meRes.data.result.first_name || '';
            telegramBotUsername = meRes.data.result.username || '';
            _logger.info(`✅ Token Telegram valido. Bot: ${telegramBotName} (@${telegramBotUsername})`);
        } else {
            telegramStatus = 'ERROR_TOKEN';
            _logger.error('❌ Token Telegram non valido (getMe fallito).');
            return;
        }
    } catch (err) {
        if (err.response && err.response.status === 401) {
            telegramStatus = 'ERROR_TOKEN';
            _logger.error('❌ Token Telegram non valido (401).');
        } else {
            telegramStatus = 'ERROR_NET';
            _logger.error(`⚠️ Impossibile verificare token Telegram (errore rete): ${err.message}`);
        }
        return;
    }

    if (mode === 'cloudflare' || (mode === 'tunnel' && findCloudflaredBinary() !== null)) {
        _logger.info('🚀 Modalità Cloudflare Tunnel attivata.');
        await startCloudflareTunnel(token);
    } else if (mode === 'tunnel') {
        try {
            if (localtunnelInstance) {
                try { localtunnelInstance.close(); } catch(e){}
                localtunnelInstance = null;
            }
            localtunnelInstance = await localtunnel({ port: _PORT });
            currentTunnelUrl = localtunnelInstance.url;
            _logger.info(`🚀 Tunnel HTTPS localtunnel avviato: ${currentTunnelUrl}`);

            const webhookEndpoint = `${currentTunnelUrl}/api/telegram/webhook`;
            const setRes = await axios.get(`https://api.telegram.org/bot${token}/setWebhook`, {
                params: {
                    url: webhookEndpoint,
                    allowed_updates: JSON.stringify(["message", "edited_message"])
                },
                timeout: 10000
            });
            if (setRes.data && setRes.data.ok) {
                telegramStatus = 'ONLINE';
                _logger.info(`✅ Webhook Telegram registrato con successo su: ${webhookEndpoint}`);
            } else {
                telegramStatus = 'ERROR_NET';
                _logger.error(`❌ Errore registrazione Webhook Telegram: ${JSON.stringify(setRes.data)}`);
            }

            localtunnelInstance.on('close', () => {
                _logger.info('🚀 Tunnel HTTPS localtunnel chiuso.');
            });
        } catch (tErr) {
            telegramStatus = 'ERROR_NET';
            _logger.error(`❌ Errore avvio Tunnel HTTPS Telegram: ${tErr.message}`);
        }
    } else if (mode === 'webhook_custom') {
        const customUrl = (config.telegramWebhookUrl || '').trim();
        if (!customUrl) {
            telegramStatus = 'ERROR_NET';
            _logger.error('❌ URL Webhook personalizzato non specificato nelle Impostazioni.');
            return;
        }
        try {
            const webhookEndpoint = customUrl.endsWith('/') ? `${customUrl}api/telegram/webhook` : `${customUrl}/api/telegram/webhook`;
            const setRes = await axios.get(`https://api.telegram.org/bot${token}/setWebhook`, {
                params: {
                    url: webhookEndpoint,
                    allowed_updates: JSON.stringify(["message", "edited_message"])
                },
                timeout: 10000
            });
            if (setRes.data && setRes.data.ok) {
                telegramStatus = 'ONLINE';
                _logger.info(`✅ Webhook Telegram Personalizzato registrato su: ${webhookEndpoint}`);
            } else {
                telegramStatus = 'ERROR_NET';
                _logger.error(`❌ Errore registrazione Webhook Personalizzato: ${JSON.stringify(setRes.data)}`);
            }
        } catch (wErr) {
            telegramStatus = 'ERROR_NET';
            _logger.error(`❌ Errore impostazione Webhook Personalizzato: ${wErr.message}`);
        }
    } else if (mode === 'qr_account' || mode === 'polling') {
        try {
            await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=true`, { timeout: 8000 });
            _logger.info('✅ Webhook Telegram rimosso per modalità polling/QR.');
        } catch (delErr) {
            _logger.warn(`⚠️ Warning rimozione webhook: ${delErr.message}`);
        }

        isTelegramPolling = true;
        telegramReconnectDelay = 1000;
        telegramStatus = 'ONLINE';
        pollTelegramUpdates();
    }
}

async function stopTelegramBot() {
    isTelegramPolling = false;
    stopCloudflareProcess();
    if (telegramPollingTimer) {
        clearTimeout(telegramPollingTimer);
        telegramPollingTimer = null;
    }
    if (localtunnelInstance) {
        try { localtunnelInstance.close(); } catch(e){}
        localtunnelInstance = null;
    }
    currentTunnelUrl = '';
    const config = getConfig();
    const token = config.telegramBotToken ? config.telegramBotToken.trim() : '';
    if (token) {
        try {
            await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=true`, { timeout: 8000 });
            _logger.info('✅ Webhook Telegram rimosso con successo.');
        } catch (e) {
            _logger.warn(`⚠️ Rimozione webhook Telegram: ${e.message}`);
        }
    }
    lastTelegramUpdateId = 0;
    telegramReconnectDelay = 1000;
    if (telegramStatus !== 'ERROR_TOKEN') {
        telegramStatus = 'DISCONNECTED';
    }
}

async function pollTelegramUpdates() {
    const config = getConfig();
    if (!isTelegramPolling || !config.telegramBotToken) return;

    if (telegramPollingTimer) {
        clearTimeout(telegramPollingTimer);
        telegramPollingTimer = null;
    }

    let nextDelay = 500;
    const token = config.telegramBotToken ? config.telegramBotToken.trim() : '';

    try {
        if (!token) {
            isTelegramPolling = false;
            telegramStatus = 'DISABLED';
            return;
        }

        const url = `https://api.telegram.org/bot${token}/getUpdates?offset=${lastTelegramUpdateId + 1}&timeout=20`;
        const res = await axios.get(url, { timeout: 35000 });

        if (res.data && res.data.ok && Array.isArray(res.data.result)) {
            telegramStatus = 'ONLINE';
            telegramReconnectDelay = 1000;
            if (res.data.result.length > 0) {
                _logger.info(`📩 Telegram: ricevuti ${res.data.result.length} aggiornamento/i`);
            }
            for (const update of res.data.result) {
                lastTelegramUpdateId = Math.max(lastTelegramUpdateId, update.update_id);
                if (update.message) {
                    await handleIncomingTelegramMessage(update.message);
                }
            }
            nextDelay = res.data.result.length > 0 ? 100 : 500;
        } else if (res.data && !res.data.ok) {
            _logger.error(`❌ Telegram API error: ${res.data.description || JSON.stringify(res.data)}`);
            if (res.data.error_code === 401) {
                telegramStatus = 'ERROR_TOKEN';
                isTelegramPolling = false;
                _logger.error('❌ Token Telegram non valido (401). Polling interrotto.');
                return;
            } else if (res.data.error_code === 409) {
                telegramStatus = 'ERROR_NET';
                _logger.info('⚠️ Telegram: conflitto (409) — riprovo tra 5s...');
                nextDelay = 5000;
            }
        }
    } catch (err) {
        if (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT') {
            nextDelay = 100;
        } else if (err.response && err.response.status === 409) {
            _logger.info('⚠️ Telegram: conflitto HTTP 409 (Webhook residuo). Forzo la rimozione del Webhook...');
            try {
                await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=false`, { timeout: 6000 });
                _logger.info('✅ Webhook residuo rimosso con successo dopo 409.');
            } catch (del409Err) {}
            nextDelay = 1000;
        } else {
            telegramStatus = 'ERROR_NET';
            telegramReconnectDelay = Math.min(telegramReconnectDelay * 2, 30000);
            _logger.info(`⚠️ Polling Telegram: ${err.message}. Riprovo tra ${telegramReconnectDelay / 1000}s...`);
            nextDelay = telegramReconnectDelay;
        }
    }

    if (isTelegramPolling) {
        telegramPollingTimer = setTimeout(pollTelegramUpdates, nextDelay);
    }
}

async function handleIncomingTelegramMessage(msg) {
    if (!msg || !msg.chat) return;
    const chatId = msg.chat.id;
    const phoneKey = `tg_${chatId}`;

    let clientName = [msg.from?.first_name, msg.from?.last_name].filter(Boolean).join(' ');
    if (msg.from?.username) {
        clientName = clientName ? `${clientName} (@${msg.from.username})` : `@${msg.from.username}`;
    }
    if (!clientName) clientName = `Telegram User ${chatId}`;

    const config = getConfig();
    const token = config.telegramBotToken ? config.telegramBotToken.trim() : '';

    // 1. Gestione comando /start
    if (msg.text && msg.text.trim().startsWith('/start')) {
        _logger.info(`✈️ Ricevuto /start da Telegram: ${clientName} (${phoneKey})`);
        if (token) {
            try {
                await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
                    chat_id: chatId,
                    text: `👋 Benvenuto su PrintZap!\n\nInviami pure i documenti o le foto che desideri stampare (PDF, Word, Excel, Foto, ecc.) e li riceveremo subito in cartoleria.`
                });
            } catch (replyErr) {
                _logger.error('⚠️ Errore invio riscontro /start Telegram:', replyErr.message);
            }
        }
        return;
    }

    // 2. Rilevamento file (Documenti, Foto, Audio, Vocali, Video)
    let fileObj = msg.document || (msg.photo ? msg.photo[msg.photo.length - 1] : null) || msg.audio || msg.voice || msg.video;

    if (fileObj) {
        try {
            if (!token) return;
            const fileId = fileObj.file_id;

            const fileRes = await axios.get(`https://api.telegram.org/bot${token}/getFile?file_id=${fileId}`);
            if (fileRes.data && fileRes.data.ok && fileRes.data.result.file_path) {
                const filePathOnTelegram = fileRes.data.result.file_path;
                const fileDownloadUrl = `https://api.telegram.org/file/bot${token}/${filePathOnTelegram}`;

                let originalFileName = msg.document?.file_name || msg.audio?.file_name || msg.video?.file_name;
                if (!originalFileName) {
                    if (msg.photo) {
                        originalFileName = `foto_${Date.now()}.jpg`;
                    } else if (msg.voice) {
                        originalFileName = `vocale_${Date.now()}.ogg`;
                    } else {
                        originalFileName = path.basename(filePathOnTelegram) || `file_${Date.now()}`;
                    }
                }

                const safeName = originalFileName.replace(/[^a-zA-Z0-9_.-]/g, '_');
                const localFileName = `tg_${Date.now()}_${safeName}`;

                const clientFolder = sanitizeClientFolderTelegram(clientName, phoneKey);
                const absoluteClientFolder = path.join(PRINT_FOLDER, clientFolder);

                if (!fs.existsSync(absoluteClientFolder)) {
                    fs.mkdirSync(absoluteClientFolder, { recursive: true });
                }

                const relativeFilePath = path.join(clientFolder, localFileName);
                const savePath = path.join(PRINT_FOLDER, relativeFilePath);

                const fileStreamRes = await axios.get(fileDownloadUrl, { responseType: 'stream' });
                const writer = fs.createWriteStream(savePath);
                fileStreamRes.data.pipe(writer);

                await new Promise((resolve, reject) => {
                    writer.on('finish', resolve);
                    writer.on('error', reject);
                });

                _logger.info(`📥 File Telegram scaricato (${originalFileName}): ${relativeFilePath} per ${clientName}`);

                const isAudio = !!(msg.voice || msg.audio);
                const newOrder = {
                    id: 'tg_ord_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
                    cliente: clientName,
                    telefono: phoneKey,
                    file: relativeFilePath,
                    tipo: isAudio ? 'audio' : 'file',
                    messaggio: msg.caption || `File Telegram: ${originalFileName}`,
                    stato: 'nuovo',
                    data: new Date().toISOString(),
                    orarioStampa: null,
                    msgId: `tg_msg_${msg.message_id}`
                };

                await db.saveOrder(newOrder);

                // Invia conferma automatica di ricezione al cliente su Telegram
                try {
                    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
                        chat_id: chatId,
                        text: `📥 File "${originalFileName}" ricevuto con successo! È pronto per la stampa in cartoleria.`
                    });
                } catch (confErr) {
                    _logger.error('⚠️ Errore invio conferma ricezione file Telegram:', confErr.message);
                }
            }
        } catch (err) {
            _logger.error('❌ Errore durante il download del file Telegram:', err);
        }
    } else if (msg.text) {
        const newOrder = {
            id: 'tg_note_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
            cliente: clientName,
            telefono: phoneKey,
            file: '',
            tipo: 'nota',
            messaggio: msg.text,
            stato: 'nuovo',
            data: new Date().toISOString(),
            orarioStampa: null,
            msgId: `tg_msg_${msg.message_id}`
        };

        await db.saveOrder(newOrder);
    }
}

function getTelegramStatus() {
    const config = getConfig();
    const currentMode = config.telegramMode || 'cloudflare';
    const isOnline = telegramStatus === 'ONLINE';
    return {
        polling: isOnline,
        enabled: config.telegramEnabled !== false && currentMode !== 'off',
        hasToken: !!(config.telegramBotToken && config.telegramBotToken.trim()),
        lastUpdateId: lastTelegramUpdateId,
        status: telegramStatus,
        botName: telegramBotName,
        botUsername: telegramBotUsername,
        mode: currentMode,
        webhookUrl: config.telegramWebhookUrl || '',
        currentTunnelUrl: currentTunnelUrl,
        qrCodeUrl: telegramBotUsername ? `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent('https://t.me/' + telegramBotUsername)}` : null,
        botLink: telegramBotUsername ? `https://t.me/${telegramBotUsername}` : null
    };
}

async function testTelegramToken(token) {
    if (!token || !token.trim()) {
        throw new Error('Token non inserito');
    }
    const cleanToken = token.trim();
    const response = await axios.get(`https://api.telegram.org/bot${cleanToken}/getMe`, { timeout: 8000 });
    if (response.data && response.data.ok) {
        const botInfo = response.data.result;
        return {
            success: true,
            botName: botInfo.first_name,
            username: botInfo.username
        };
    }
    throw new Error('Token non valido');
}

async function startService({ mode, telegramBotToken, telegramWebhookUrl } = {}) {
    const config = getConfig();
    if (mode) config.telegramMode = mode;
    if (telegramBotToken !== undefined) config.telegramBotToken = telegramBotToken;
    if (telegramWebhookUrl !== undefined) config.telegramWebhookUrl = telegramWebhookUrl;
    config.telegramEnabled = config.telegramMode !== 'off';

    saveConfig(config);

    await initTelegramService();
    _logger.info(`▶️ Servizio Telegram aggiornato dalla dashboard (Modalità: ${config.telegramMode}).`);
    return {
        success: true,
        message: telegramStatus === 'ERROR_TOKEN' ? 'Token non valido.' : 'Servizio Telegram avviato.',
        status: telegramStatus,
        mode: config.telegramMode,
        currentTunnelUrl,
        botName: telegramBotName,
        botUsername: telegramBotUsername
    };
}

async function stopService() {
    const config = getConfig();
    config.telegramMode = 'off';
    config.telegramEnabled = false;
    saveConfig(config);

    await stopTelegramBot();
    telegramStatus = 'DISABLED';
    _logger.info('⏹️ Servizio Telegram fermato dalla dashboard.');
    return {
        success: true,
        message: 'Servizio Telegram fermato.',
        status: telegramStatus,
        mode: 'off'
    };
}

async function sendTelegramNotification({ chatId, message }) {
    const config = getConfig();
    const token = config.telegramBotToken ? config.telegramBotToken.trim() : '';
    if (!token) {
        throw new Error('Token Bot Telegram non configurato nelle Impostazioni.');
    }
    _logger.info(`✈️ Invio risposta Telegram a Chat ID: ${chatId}`);
    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
        chat_id: chatId,
        text: message
    });
    _logger.info(`✈️ Messaggio Telegram inviato con successo a: tg_${chatId}`);
}

async function handleWebhook(reqBody) {
    if (!reqBody) return;
    const msg = reqBody.message || reqBody.edited_message;
    if (msg) {
        await handleIncomingTelegramMessage(msg);
    }
}

async function shutdown() {
    await stopTelegramBot();
}

module.exports = {
    init,
    initTelegramService,
    stopTelegramBot,
    pollTelegramUpdates,
    handleIncomingTelegramMessage,
    getTelegramStatus,
    testTelegramToken,
    startService,
    stopService,
    sendTelegramNotification,
    handleWebhook,
    shutdown,
    findCloudflaredBinary,
    stopCloudflareProcess,
    startCloudflareTunnel,
    sanitizeClientFolderTelegram
};
