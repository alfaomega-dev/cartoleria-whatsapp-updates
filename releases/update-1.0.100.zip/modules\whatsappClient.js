const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const qrcode = require('qrcode-terminal');
const db = require('../db');
const linkDownloader = require('../link-downloader');

const { ROOT_DIR, DATA_DIR, AUTH_DIR, PRINT_FOLDER } = require('./paths');
const { getConfig, saveConfig, checkLicense } = require('./config');
const { cleanupOldSessions, clearSessionLocks, killOrphanedChrome } = require('./startup');
const { waitForNetwork, checkAndApplyHotPatch, isPuppeteerContextError, promiseTimeout } = require('./session');
const { saveOrderInfo, saveNote, deleteFileWithCleanup, deleteFilesWithCleanup, repairMismatchedFolders } = require('./helpers');
const { getMessageId, getExtensionFromMime } = require('./whatsappUtils');
const { saveMediaToDisk, downloadMediaResilient: downloadMediaResilientImpl, redownloadOrderMedia: redownloadOrderMediaImpl } = require('./mediaDownloader');
const {
    moveContactFolderOnDisk: moveContactFolderOnDiskImpl,
    handleChatRemoved: handleChatRemovedImpl,
    syncContactNames: syncContactNamesImpl,
    reconcileStartupContacts: reconcileStartupContactsImpl,
    handleRevokedMessage: handleRevokedMessageImpl,
    getExportableContacts: getExportableContactsImpl
} = require('./chatSync');
const { applyBrowserCompatibilityPatches } = require('./browserPatches');
const { sendWhatsAppNotification: sendWhatsAppNotificationImpl } = require('./whatsappSender');
const {
    isReadyResponse,
    recordReadyTimestamp,
    isMessageCoveredByReady,
    handleMerchantReadyMessage: handleMerchantReadyMessageImpl
} = require('./readyTracker');
const { logout: logoutImpl, reset: resetImpl, shutdown: shutdownImpl } = require('./sessionLifecycle');

let Client, LocalAuth;
let _logger = console;
let _notifyDashboard = () => {};

// WhatsApp State
let client = null;
let wpStatus = 'DISCONNECTED'; // 'DISCONNECTED'|'INITIALIZING'|'WAITING_FOR_QR'|'AUTHENTICATING'|'CONNECTED'|'EXPIRED'
let latestQR = null;
let isSyncing = false;       // Flag: blocca eventi message durante la sync iniziale
let pendingMessages = [];    // Coda messaggi ricevuti durante la sync
let isInitializing = false;  // Flag: previene inizializzazioni parallele concorrenti
let reconnectAttempts = 0;
const RECONNECT_BASE_DELAY = 5000;   // 5 secondi base
const RECONNECT_MAX_DELAY  = 300000; // massimo 5 minuti

let messageQueueChain = Promise.resolve();
let lastUniqueOrderTimestamp = 0;
let syncWatchdogInterval = null;
const processedMsgIdsCache = new Set();

function markProcessed(id) {
    if (!id) return;
    processedMsgIdsCache.add(id);
    if (processedMsgIdsCache.size > 3000) {
        const first = processedMsgIdsCache.values().next().value;
        processedMsgIdsCache.delete(first);
    }
}

function init({ logger, notifyDashboard } = {}) {
    if (logger) _logger = logger;
    if (notifyDashboard) _notifyDashboard = notifyDashboard;
}

function getStatus() {
    return {
        status: wpStatus,
        qr: latestQR,
        isSyncing,
        pendingMessages: pendingMessages.length
    };
}

function getWpStatus() {
    return wpStatus;
}

function setWpStatus(status) {
    wpStatus = status;
}

function getLatestQR() {
    return latestQR;
}

function getClient() {
    return client;
}

function isReady() {
    return wpStatus === 'CONNECTED' && !!client;
}

function generateUniqueOrderId() {
    let now = Date.now();
    if (now <= lastUniqueOrderTimestamp) {
        now = lastUniqueOrderTimestamp + 1;
    }
    lastUniqueOrderTimestamp = now;
    return now;
}

function enqueueIncomingMessage(msg) {
    const task = async () => {
        try {
            await processMessageSafe(msg);
            await new Promise(r => setTimeout(r, 200));
        } catch (err) {
            _logger.error('❌ Errore in coda elaborazione messaggio:', err);
        }
    };
    messageQueueChain = messageQueueChain.then(task, task);
    return messageQueueChain;
}

async function handleRevokedMessage(after, before) {
    return handleRevokedMessageImpl(after, before, {
        dbInstance: db,
        deleteFileFn: deleteFileWithCleanup,
        getMessageIdFn: getMessageId,
        logger: _logger
    });
}

async function initializeClient() {
    if (isInitializing) {
        _logger.info('⚠️ initializeClient è già in corso. Ignoro chiamata parallela.');
        return;
    }
    isInitializing = true;
    _logger.info('🎬 Avvio initializeClient...');
    await checkAndApplyHotPatch();

    await waitForNetwork(15);

    if (!Client || !LocalAuth) {
        try {
            _logger.info('📦 Caricamento di whatsapp-web.js...');
            const wweb = require('whatsapp-web.js');
            Client = wweb.Client;
            LocalAuth = wweb.LocalAuth;
            _logger.info('📦 Libreria whatsapp-web.js caricata correttamente.');
        } catch (wwebErr) {
            _logger.error(`❌ Errore critico nel caricamento di whatsapp-web.js: ${wwebErr.message}`);
            isInitializing = false;
            return;
        }
    }
    cleanupOldSessions();
    killOrphanedChrome();

    const cachePathStartup = path.join(DATA_DIR, '.wwebjs_cache');
    if (fs.existsSync(cachePathStartup)) {
        try {
            fs.rmSync(cachePathStartup, { recursive: true, force: true });
            _logger.info('🗑️ Cache WhatsApp Web rimossa per avvio pulito.');
        } catch (e) {
            _logger.info('ℹ️ Impossibile rimuovere cache: ' + e.message);
        }
    }

    wpStatus = 'INITIALIZING';
    const lic = checkLicense();
    if (!lic.valid) {
        _logger.error(`🛑 ${lic.message}`);
        _logger.info(`🛑 LICENSE EXPIRED: ${lic.message}`);
        wpStatus = 'EXPIRED';
        isInitializing = false;
        return;
    }

    if (lic.isTrial) {
        _logger.info(`💡 ${lic.message}`);
    }

    let executablePath = undefined;
    const localChrome = path.join(ROOT_DIR, 'chrome-win64', 'chrome.exe');
    const systemChromePaths = [
        localChrome,
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
        path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'),
        'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
        'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Microsoft\\Edge\\Application\\msedge.exe')
    ];

    for (const p of systemChromePaths) {
        if (p && fs.existsSync(p)) {
            executablePath = p;
            _logger.info(`🌐 Browser trovato in: ${p}`);
            break;
        }
    }

    if (!executablePath) {
        _logger.info("⚠️ ATTENZIONE: Chrome non trovato nel sistema. WhatsApp potrebbe non avviarsi.");
        _logger.error("❌ Chrome non trovato! Installalo o aggiungi 'chrome-win64' nella cartella root.");
    }

    if (executablePath) _logger.info('Chromium locale trovato:', executablePath);

    const config = getConfig();
    const activeSessionDir = path.join(AUTH_DIR, `session-${config.clientId}`);
    clearSessionLocks(activeSessionDir);

    client = new Client({
        authStrategy: new LocalAuth({ clientId: config.clientId, dataPath: AUTH_DIR }),
        authTimeoutMs: 60000,
        qrMaxRetries: 5,
        puppeteer: {
            headless: true,
            executablePath: executablePath,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--disable-gpu',
                '--disable-session-crashed-bubble',
                '--disable-features=Translate,OptimizationHints',
                '--disable-blink-features=AutomationControlled',
                '--disable-infobars',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--mute-audio'
            ]
        },
        webVersionCache: {
            type: 'none'
        }
    });

    client.on('qr', (qr) => {
        isInitializing = false;
        _logger.info('Scansiona questo QR con WhatsApp:');
        _logger.info('📷 QR Code generato. In attesa di scansione...');
        qrcode.generate(qr, { small: true });
        wpStatus = 'WAITING_FOR_QR';
        latestQR = qr;
    });

    client.on('ready', async () => {
        isInitializing = false;
        _logger.info('✅ WhatsApp connesso e pronto!');
        _logger.info('✅ EVENTO READY: WhatsApp connesso e pronto!');
        wpStatus = 'CONNECTED';
        reconnectAttempts = 0;
        latestQR = null;

        if (client.pupPage) {
            await applyBrowserCompatibilityPatches(client.pupPage);
            await setupInPageMessageListener();
        }

        await new Promise(r => setTimeout(r, 2000));
        isSyncing = true;
        pendingMessages = [];
        try {
            await syncUnreadMessages(client);
        } finally {
            isSyncing = false;
            if (pendingMessages.length > 0) {
                _logger.info(`📬 Processo ${pendingMessages.length} messaggi ricevuti durante la sync...`);
                const queue = [...pendingMessages];
                pendingMessages = [];
                for (const m of queue) {
                    await enqueueIncomingMessage(m);
                }
            }
            _logger.info('✅ Sync completata. Ascolto nuovi messaggi attivo.');

            // Controllo all'avvio: riconciliazione automatica chat eliminate e badge "Stampa Pronta"
            setTimeout(() => {
                reconcileStartupContacts(client).catch(() => {});
            }, 1000);
        }

        // Watchdog di background ogni 10 secondi per catturare eventuali messaggi persi
        if (syncWatchdogInterval) clearInterval(syncWatchdogInterval);
        syncWatchdogInterval = setInterval(() => {
            if (client && wpStatus === 'CONNECTED' && !isSyncing && !isSyncRunning) {
                syncUnreadMessages(client).catch(() => {});
            }
        }, 10000);
    });

    client.on('authenticated', () => {
        _logger.info('🔑 Autenticato con successo!');
        _logger.info('🔑 EVENTO AUTHENTICATED: Sessione ripristinata o nuova sessione creata.');
        wpStatus = 'AUTHENTICATING';
        latestQR = null;

        // Watchdog per sessioni ripristinate da disco: se Socket.hasSynced è già true, sblocca la transizione a READY
        setTimeout(async () => {
            if (wpStatus !== 'CONNECTED' && client && client.pupPage && !client.pupPage.isClosed()) {
                try {
                    await client.pupPage.evaluate(() => {
                        const socket = window.require && window.require('WAWebSocketModel')?.Socket;
                        if (socket && socket.hasSynced && typeof window.onAppStateHasSyncedEvent === 'function') {
                            window.onAppStateHasSyncedEvent();
                        }
                    });
                } catch (e) {}
            }
        }, 3000);
    });

    client.on('auth_failure', msg => {
        isInitializing = false;
        _logger.error('⛔ Errore di autenticazione:', msg);
        _logger.info(`⛔ EVENTO AUTH_FAILURE: ${msg}`);
        wpStatus = 'DISCONNECTED';
    });

    client.on('message', async msg => {
        if (!msg || msg.from === 'status@broadcast' || msg.to === 'status@broadcast' || msg.isStatus || msg.from?.endsWith('@newsletter')) return;
        const msgId = getMessageId(msg);
        if (msgId && processedMsgIdsCache.has(msgId)) return;
        markProcessed(msgId);
        _logger.info(`📥 Evento 'message' intercettato da: ${msg?.from || 'Mittente sconosciuto'} | ID: ${msgId || 'Nessuno'} | Tipo: ${msg?.type || 'Sconosciuto'}`);
        
        if (msg?.type === 'revoked') {
            await handleRevokedMessage(msg, null);
            return;
        }

        // I messaggi di tipo 'album' sono meri contenitori di raggruppamento per l'interfaccia WhatsApp;
        // i file veri e propri arrivano come singoli messaggi 'image'/'video'. Se non c'è testo/didascalia, ignoralo.
        if (msg?.type === 'album' && (!msg.body || !msg.body.trim())) {
            _logger.info(`ℹ️ Ignorato contenitore 'album' senza testo da: ${msg?.from || 'sconosciuto'} (le singole foto arrivano separatamente)`);
            return;
        }

        if (isSyncing) {
            pendingMessages.push(msg);
            _logger.info(`⏸ Messaggio in coda (sync in corso): ${msgId || 'ID sconosciuto'}`);
            return;
        }
        enqueueIncomingMessage(msg);
    });

    client.on('message_create', async msg => {
        if (!msg || msg.from === 'status@broadcast' || msg.to === 'status@broadcast' || msg.isStatus || msg.from?.endsWith('@newsletter')) return;
        // 1. Fallback messaggi in arrivo: se WhatsApp Desktop è aperto e marca come letto, 'message' potrebbe non scattare ma 'message_create' sì
        if (!msg.fromMe) {
            const msgId = getMessageId(msg);
            if (msgId && processedMsgIdsCache.has(msgId)) return;
            markProcessed(msgId);
            _logger.info(`📥 Evento 'message_create' (incoming fallback) da: ${msg?.from || 'Mittente sconosciuto'} | ID: ${msgId || 'Nessuno'} | Tipo: ${msg?.type || 'Sconosciuto'}`);
            
            if (msg?.type === 'revoked') {
                await handleRevokedMessage(msg, null);
                return;
            }

            // I messaggi di tipo 'album' sono meri contenitori di raggruppamento per l'interfaccia WhatsApp;
            // i file veri e propri arrivano come singoli messaggi 'image'/'video'. Se non c'è testo/didascalia, ignoralo.
            if (msg?.type === 'album' && (!msg.body || !msg.body.trim())) {
                _logger.info(`ℹ️ Ignorato contenitore 'album' senza testo da: ${msg?.from || 'sconosciuto'} (le singole foto arrivano separatamente)`);
                return;
            }

            if (isSyncing) {
                pendingMessages.push(msg);
                return;
            }
            enqueueIncomingMessage(msg);
            return;
        }

        // 2. Intercetta messaggi inviati dal negoziante contenenti "stampa pronta"
        try {
            await handleMerchantReadyMessage(msg.to, msg.body, null, msg.timestamp);
        } catch (error) {
            _logger.error('❌ Errore processamento messaggio in uscita negoziante:', error);
        }
    });

    client.on('chat_removed', async chat => {
        if (!chat) return;
        const chatJid = chat.id?._serialized || chat.id || (typeof chat === 'string' ? chat : null);
        if (!chatJid || String(chatJid).includes('@g.us')) return;
        _logger.info(`🗑️ Evento 'chat_removed' intercettato per la chat: ${chatJid}`);
        const contactName = chat.name || chat.formattedTitle || (chat.contact ? (chat.contact.name || chat.contact.pushname) : null);
        const phone = chat.contact?.number || (chat.id?.user ? chat.id.user.replace(/\D/g, '') : null);
        await handleChatRemoved(chatJid, contactName, phone);
    });

    client.on('message_revoke_everyone', async (after, before) => {
        _logger.info(`🗑️ Evento 'message_revoke_everyone' intercettato!`);
        await handleRevokedMessage(after, before);
    });

    client.on('disconnected', async (reason) => {
        _logger.info('❌ WhatsApp disconnesso:', reason);
        _logger.info(`❌ WhatsApp disconnesso: ${reason}. Inizializzo reset automatico sessione...`);
        wpStatus = 'DISCONNECTED';
        latestQR = null;
        isInitializing = false;

        if (client) {
            try {
                const destroyPromise = client.destroy();
                const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 5000));
                await Promise.race([destroyPromise, timeoutPromise]).catch(() => { });
                await new Promise(r => setTimeout(r, 1000));
            } catch (err) { }
            client = null;
        }

        const currentConfig = getConfig();
        _logger.info(`🔄 Riavvio con la sessione esistente (${currentConfig.clientId}) per preservare il login WhatsApp.`);

        const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
        if (fs.existsSync(cachePath)) {
            try { fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 }); } catch (e) { _logger.info('Errore delete dir cache: ' + e.message); }
        }

        reconnectAttempts++;
        const delay = Math.min(RECONNECT_BASE_DELAY * Math.pow(2, reconnectAttempts - 1), RECONNECT_MAX_DELAY);
        _logger.info(`🔄 Tentativo di riconnessione #${reconnectAttempts} tra ${Math.round(delay / 1000)}s...`);
        setTimeout(initializeClient, delay);
    });

    try {
        _logger.info(`🛠️ Inizializzazione client con browser: ${executablePath || 'Default'}`);
        client.initialize().catch(err => {
            _logger.info(`❌ Errore in client.initialize(): ${err.message}`);
            _logger.error('Errore inizializzazione:', err);
            wpStatus = 'DISCONNECTED';
            isInitializing = false;
        });
    } catch (err) {
        _logger.info(`❌ Eccezione durante inizializzazione: ${err.message}`);
        wpStatus = 'DISCONNECTED';
        isInitializing = false;
    }
}

async function handleChatRemoved(chatId, contactName = null, phone = null) {
    return handleChatRemovedImpl(chatId, contactName, phone, {
        getClient: () => client,
        clientInstance: client,
        dbInstance: db,
        deleteFilesFn: deleteFilesWithCleanup,
        notifyDashboardFn: _notifyDashboard,
        logger: _logger
    });
}

async function handleMerchantReadyMessage(targetId, bodyText, chatTitle = null, msgTimestamp = null) {
    return handleMerchantReadyMessageImpl(targetId, bodyText, chatTitle, msgTimestamp, {
        getClient: () => client,
        dbInstance: db,
        notifyDashboardFn: _notifyDashboard,
        logger: _logger
    });
}

const isSyncSingleChatRunning = new Set();

async function syncSingleChat(chatOrId) {
    if (!client || !isReady()) return;
    const chatId = typeof chatOrId === 'string' ? chatOrId : (chatOrId?.id?._serialized || chatOrId?.id);
    if (!chatId || isSyncSingleChatRunning.has(chatId)) return;
    isSyncSingleChatRunning.add(chatId);

    try {
        let chat = typeof chatOrId === 'object' && typeof chatOrId.fetchMessages === 'function' ? chatOrId : null;
        if (!chat) {
            chat = await promiseTimeout(client.getChatById(chatId), 5000, `getChatById(${chatId})`);
        }
        if (!chat || typeof chat.fetchMessages !== 'function') return;

        const fetchLimit = chat.unreadCount > 0 ? Math.max(chat.unreadCount, 20) : 10;
        const messages = await promiseTimeout(chat.fetchMessages({ limit: fetchLimit }), 5000, `fetchMessages(${chat.name || chatId})`);
        if (!messages || !Array.isArray(messages)) return;

        // 1. Controlla prima se tra i messaggi del negoziante è presente "stampa pronta"
        let latestReadySec = 0;
        let latestReadyMsg = null;
        const recentOut = messages.filter(m => m.fromMe);
        for (const outMsg of recentOut) {
            if (isReadyResponse(outMsg.body)) {
                const ts = outMsg.timestamp || 0;
                if (ts >= latestReadySec) {
                    latestReadySec = ts;
                    latestReadyMsg = outMsg;
                }
            }
        }

        // Se è presente "Stampa Pronta", aggiorna subito gli ordini già registrati nel database
        if (latestReadyMsg) {
            await handleMerchantReadyMessage(chatId, latestReadyMsg.body, chat.name, latestReadyMsg.timestamp);
        }

        const startOfTodaySec = Math.floor(new Date().setHours(0, 0, 0, 0) / 1000);
        const processedMsgIds = await db.getProcessedMessageIds();
        const candidateIncoming = messages.filter(m =>
            !m.fromMe &&
            m.id &&
            m.id._serialized &&
            (!m.timestamp || m.timestamp >= startOfTodaySec) && // SOLO messaggi di OGGI
            !processedMsgIds.has(m.id._serialized) &&
            !processedMsgIdsCache.has(m.id._serialized)
        );

        const toDownload = [];
        for (const m of candidateIncoming) {
            if (latestReadySec > 0 && m.timestamp && m.timestamp <= latestReadySec) {
                // Antecedente o coevo a Stampa Pronta: già evaso dal negoziante, non scaricare!
                markProcessed(m.id._serialized);
                processedMsgIds.add(m.id._serialized);
                _logger.info(`⏭️ [Realtime] Chat "${chat.name || chatId}": messaggio ${m.id._serialized} antecedente a "Stampa Pronta" (${m.timestamp} <= ${latestReadySec}), ignorato download.`);
            } else {
                toDownload.push(m);
            }
        }

        if (toDownload.length > 0) {
            _logger.info(`⚡ [Realtime] Chat "${chat.name || chatId}": trovati ${toDownload.length} nuovi messaggi da elaborare`);
            for (const m of toDownload) {
                markProcessed(m.id._serialized);
                await enqueueIncomingMessage(m);
                processedMsgIds.add(m.id._serialized);
            }
        }
    } catch (e) {
        if (!isPuppeteerContextError(e)) {
            _logger.info(`ℹ️ syncSingleChat info: ${e.message}`);
        }
    } finally {
        isSyncSingleChatRunning.delete(chatId);
    }
}

async function reconcileStartupContacts(clientInstance = null) {
    return reconcileStartupContactsImpl(clientInstance || (() => client), {
        isReadyFn: isReady,
        dbInstance: db,
        handleChatRemovedFn: handleChatRemoved,
        isReadyResponseFn: isReadyResponse,
        handleMerchantReadyMessageFn: handleMerchantReadyMessage,
        logger: _logger
    });
}

async function setupInPageMessageListener() {
    if (!client || !client.pupPage || client.pupPage.isClosed()) return;
    try {
        await client.pupPage.exposeFunction('onInPageMessageAdd', async (rawMsg) => {
            if (!rawMsg) return;
            if (rawMsg.fromMe) {
                await handleMerchantReadyMessage(rawMsg.to, rawMsg.body, rawMsg.chatTitle, rawMsg.t || rawMsg.timestamp);
            } else {
                if (rawMsg.chatId && !rawMsg.isStatus) {
                    syncSingleChat(rawMsg.chatId).catch(() => {});
                }
            }
        }).catch(() => {});

        await client.pupPage.exposeFunction('onInPageChatRemoved', async (data) => {
            if (!data) return;
            _logger.info(`🗑️ [In-Page] Chat rimossa intercettata da WhatsApp: ${data.chatId} ("${data.contactName || ''}")`);
            await handleChatRemoved(data.chatId, data.contactName, data.phone);
        }).catch(() => {});

        await client.pupPage.evaluate(() => {
            if (window._inPageMessageListenerAttached) return;
            window._inPageMessageListenerAttached = true;
            const { Msg, Chat } = window.require('WAWebCollections') || {};
            if (Msg) {
                Msg.on('add', (msg) => {
                    try {
                        if (!msg || !msg.id) return;
                        const fromMe = Boolean(msg.id.fromMe);
                        const remote = msg.id.remote ? (msg.id.remote._serialized || msg.id.remote) : '';
                        const isStatus = remote === 'status@broadcast' || msg.isStatus;
                        const body = msg.body || '';
                        let chatTitle = null;
                        if (msg.chat) chatTitle = msg.chat.name || msg.chat.formattedTitle;
                        if (typeof window.onInPageMessageAdd === 'function') {
                            window.onInPageMessageAdd({
                                id: msg.id._serialized,
                                fromMe,
                                to: remote,
                                chatId: remote,
                                body,
                                isStatus,
                                chatTitle,
                                t: msg.t || msg.timestamp
                            });
                        }
                    } catch (e) {}
                });
            }
            if (Chat) {
                Chat.on('remove', (chat) => {
                    try {
                        if (!chat) return;
                        const chatId = chat.id ? (chat.id._serialized || chat.id) : '';
                        let contactName = chat.name || chat.formattedTitle || null;
                        if (!contactName && chat.contact) {
                            contactName = chat.contact.name || chat.contact.pushname || null;
                        }
                        let phone = null;
                        if (chat.contact && chat.contact.number) {
                            phone = chat.contact.number;
                        } else if (chat.id && chat.id.user && !chat.id.user.includes('@')) {
                            phone = chat.id.user;
                        }
                        if (typeof window.onInPageChatRemoved === 'function') {
                            window.onInPageChatRemoved({
                                chatId,
                                contactName,
                                phone
                            });
                        }
                    } catch (e) {}
                });
            }
        });
        _logger.info('⚡ In-page listener WhatsApp Web attivo per messaggi e cancellazione chat.');
    } catch (err) {
        _logger.info(`ℹ️ Setup listener in-page: ${err.message}`);
    }
}

let isSyncRunning = false;

async function syncUnreadMessages(clientInstance = client, retryCount = 0) {
    if (isSyncRunning) return;
    isSyncRunning = true;
    try {
        if (!clientInstance || !isReady()) {
            return;
        }
        const processedMsgIds = await db.getProcessedMessageIds();
        const chats = await promiseTimeout(clientInstance.getChats(), 15000, 'client.getChats()');
        if (!chats || !Array.isArray(chats)) return;

        // Cerca chat candidate:
        // 1. Chat non-gruppo con messaggi non letti (unreadCount > 0)
        // 2. Fino a 5 chat con attività recente negli ultimi 15 minuti
        const candidateChats = [];
        const seenChatIds = new Set();

        for (const chat of chats) {
            if (chat.isGroup) continue;
            const cid = chat.id?._serialized || chat.id;
            if (chat.unreadCount > 0) {
                candidateChats.push(chat);
                seenChatIds.add(cid);
            }
        }

        const nowSec = Math.floor(Date.now() / 1000);
        let recentAdded = 0;
        for (const chat of chats) {
            if (chat.isGroup) continue;
            const cid = chat.id?._serialized || chat.id;
            if (!seenChatIds.has(cid) && chat.timestamp && (nowSec - chat.timestamp < 900)) {
                candidateChats.push(chat);
                seenChatIds.add(cid);
                recentAdded++;
                if (recentAdded >= 5) break;
            }
        }

        if (candidateChats.length > 0) {
            for (const chat of candidateChats) {
                try {
                    const fetchLimit = chat.unreadCount > 0 ? Math.max(chat.unreadCount, 20) : 10;
                    const messages = await promiseTimeout(chat.fetchMessages({ limit: fetchLimit }), 8000, `chat.fetchMessages(${chat.name || chat.id?.user})`);
                    if (!messages || !Array.isArray(messages)) continue;

                    const cid = chat.id?._serialized || chat.id;

                    // 1. Controlla prima se tra i messaggi del negoziante è presente "stampa pronta"
                    let latestReadySec = 0;
                    let latestReadyMsg = null;
                    const recentOut = messages.filter(m => m.fromMe);
                    for (const outMsg of recentOut) {
                        if (isReadyResponse(outMsg.body)) {
                            const ts = outMsg.timestamp || 0;
                            if (ts >= latestReadySec) {
                                latestReadySec = ts;
                                latestReadyMsg = outMsg;
                            }
                        }
                    }

                    if (latestReadyMsg) {
                        await handleMerchantReadyMessage(cid, latestReadyMsg.body, chat.name, latestReadyMsg.timestamp);
                    }

                    const startOfTodaySec = Math.floor(new Date().setHours(0, 0, 0, 0) / 1000);
                    const candidateIncoming = messages.filter(m =>
                        !m.fromMe &&
                        m.id &&
                        m.id._serialized &&
                        (!m.timestamp || m.timestamp >= startOfTodaySec) && // SOLO messaggi di OGGI
                        !processedMsgIds.has(m.id._serialized) &&
                        !processedMsgIdsCache.has(m.id._serialized)
                    );

                    const toDownload = [];
                    for (const m of candidateIncoming) {
                        if (latestReadySec > 0 && m.timestamp && m.timestamp <= latestReadySec) {
                            markProcessed(m.id._serialized);
                            processedMsgIds.add(m.id._serialized);
                            _logger.info(`⏭️ Chat "${chat.name || chat.id?.user}": messaggio ${m.id._serialized} antecedente a "Stampa Pronta" (${m.timestamp} <= ${latestReadySec}), ignorato download.`);
                        } else {
                            toDownload.push(m);
                        }
                    }

                    if (toDownload.length > 0) {
                        _logger.info(`📩 Chat "${chat.name || chat.id?.user}": trovati ${toDownload.length} nuovi messaggi da elaborare...`);
                        for (const m of toDownload) {
                            markProcessed(m.id._serialized);
                            await enqueueIncomingMessage(m);
                            processedMsgIds.add(m.id._serialized);
                        }
                    }

                    // NOTA CRITICA: Non chiamare mai chat.sendSeen() qui!
                    // In questo modo i messaggi e il badge verde (conteggio non letti)
                    // rimangono intatti e visibili sia su WhatsApp Web sia su WhatsApp Desktop.
                } catch (chatErr) {
                    if (!isPuppeteerContextError(chatErr)) {
                        _logger.info(`ℹ️ Info sync chat "${chat.name || 'sconosciuta'}": ${chatErr.message}`);
                    }
                }
            }
        }
    } catch (error) {
        if (isPuppeteerContextError(error)) {
            if (retryCount < 2) {
                const delay = (retryCount + 1) * 3000;
                await new Promise(r => setTimeout(r, delay));
                return syncUnreadMessages(clientInstance, retryCount + 1);
            }
        } else {
            _logger.warn(`⚠️ Warning durante syncUnreadMessages: ${error.message}`);
        }
    } finally {
        isSyncRunning = false;
    }
}

async function downloadMediaResilient(msg, clientInstance = client) {
    return downloadMediaResilientImpl(msg, clientInstance, _logger);
}

async function processMessage(msg, retryCount = 0) {
    const msgId = getMessageId(msg);
    if (!msgId) {
        _logger.info('⏭ Messaggio di sistema senza ID valido ignorato.');
        return;
    }

    try {
        if (msg.isStatus) return;

        const chat = await promiseTimeout(msg.getChat(), 8000, 'msg.getChat()');
        if (chat.isGroup) return;

        const exists = await db.orderExists(msgId);
        if (exists) return;

        const contact = await promiseTimeout(msg.getContact(), 8000, 'msg.getContact()');
        let contactName = (contact && (contact.name || contact.pushname)) ? (contact.name || contact.pushname) : null;
        if (!contactName || /^[\d\s+\-()]+$/.test(contactName.trim())) {
            try {
                if (chat && chat.name && !/^[\d\s+\-()]+$/.test(chat.name.trim())) {
                    contactName = chat.name;
                }
            } catch (e) {}
        }
        if (!contactName) {
            contactName = contact ? contact.number : 'Cliente';
        }

        const safeContactName = contactName.replace(/[^a-z0-9]/gi, '_');
        if (!/^[a-z0-9_]+$/i.test(safeContactName)) {
            throw new Error('Nome contatto non valido');
        }
        const contactFolder = path.join(PRINT_FOLDER, safeContactName);

        const candidateKeys = [contact.number, contactName, safeContactName, msg.from, msg.to, msg.author].filter(Boolean);
        const isAlreadyPrinted = isMessageCoveredByReady(candidateKeys, msg.timestamp);
        const initialOrderState = isAlreadyPrinted ? 'stampato' : 'nuovo';
        if (isAlreadyPrinted) {
            _logger.info(`🟣 Ordine ${msgId} per "${contactName}" identificato come già evaso da "Stampa Pronta" (stato: STAMPATO)`);
        }

        const existingOrders = await db.getOrdersByPhoneAndHasFile(contact.number);
        const hasExistingFiles = existingOrders.length > 0;
        const allExistingFilesPrinted = hasExistingFiles && existingOrders.every(o => o.stato === 'stampato' || o.stato === 'archiviato');

        if (existingOrders.length > 0) {
            const oldRelativeFolder = path.dirname(existingOrders[0].file);

            if (oldRelativeFolder !== safeContactName) {
                const oldFullPath = path.join(PRINT_FOLDER, oldRelativeFolder);
                if (fs.existsSync(oldFullPath)) {
                    _logger.info(`🔄 Sincronizzazione: Rinomino/Sposto cartella da ${oldRelativeFolder} a ${safeContactName}`);
                    try {
                        if (!fs.existsSync(contactFolder)) {
                            fs.renameSync(oldFullPath, contactFolder);
                        } else {
                            const files = fs.readdirSync(oldFullPath);
                            for (const f of files) {
                                const src = path.join(oldFullPath, f);
                                const dest = path.join(contactFolder, f);
                                if (!fs.existsSync(dest)) fs.renameSync(src, dest);
                            }
                            try { if (fs.readdirSync(oldFullPath).length === 0) fs.rmdirSync(oldFullPath); } catch(e){}
                        }

                        await db.updateContactOrdersFolder(contact.number, contactName, safeContactName);
                    } catch (err) {
                        _logger.error('❌ Errore sincronizzazione nomi:', err);
                    }
                }
            }
        }

        const body = msg.body || "";
        const detectedService = linkDownloader.detectService(body);

        if (detectedService) {
            _logger.info(`🔗 Rilevato link ${detectedService} da: ${contactName}`);

            if (!fs.existsSync(contactFolder)) {
                fs.mkdirSync(contactFolder, { recursive: true });
            }

            const timestamp = generateUniqueOrderId();
            const prefix = `${timestamp}_link`;
            const result = await linkDownloader.download(body, contactFolder, prefix);

            if (result.success) {
                const relativePath = `${safeContactName}/${path.basename(result.filepath)}`;
                _logger.info(`✅ Link scaricato: ${relativePath}`);

                const ext = path.extname(result.filename).toLowerCase().replace('.', '');
                let orderType = 'documento';
                if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) orderType = 'immagine';
                if (['pdf'].includes(ext)) orderType = 'pdf';

                await saveOrderInfo({
                    id: timestamp,
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: relativePath,
                    tipo: orderType,
                    messaggio: `Link ${detectedService}: ${body}`,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: initialOrderState
                });

                return;
            } else {
                _logger.error(`❌ Errore download link: ${result.error}`);
            }
        }

        // I messaggi di tipo 'album' sono meri contenitori di raggruppamento per l'interfaccia WhatsApp:
        // non hanno payload multimediale binario proprio (le singole foto/video arrivano come messaggi separati).
        if (msg.type === 'album') {
            _logger.info(`ℹ️ Messaggio contenitore 'album' da: ${contactName}. I singoli allegati vengono elaborati separatamente.`);
            if (msg.body && msg.body.trim()) {
                saveNote(contactName, msg.body);
                await saveOrderInfo({
                    id: generateUniqueOrderId(),
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: null,
                    tipo: 'nota',
                    messaggio: msg.body,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: initialOrderState
                });
            }
            return;
        }

        if (msg.hasMedia) {
            _logger.info(`📩 Messaggio con media da: ${contactName} | Tipo: ${msg.type || 'sconosciuto'}`);
            let media = null;

            try {
                media = await msg.downloadMedia();
            } catch (mediaErr) {
                _logger.warn(`⚠️ msg.downloadMedia() per ${msgId} non immediato: ${mediaErr.message}`);
            }

            if (!media || !media.data) {
                try {
                    media = await downloadMediaResilient(msg, client);
                } catch (resilientErr) {
                    _logger.warn(`⚠️ downloadMediaResilient per ${msgId} fallito: ${resilientErr.message}`);
                }
            }

            if (media) {
                const saved = saveMediaToDisk({
                    media,
                    contactName,
                    msgType: msg.type,
                    printFolder: PRINT_FOLDER,
                    generateOrderId: generateUniqueOrderId,
                    logger: _logger
                });

                await saveOrderInfo({
                    id: saved.orderId,
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: saved.relativePath,
                    tipo: saved.orderType,
                    messaggio: msg.body,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: initialOrderState
                });
            } else {
                _logger.warn(`⚠️ Impossibile scaricare i media per il messaggio ${msgId}. Salvo come nota.`);
                const warningMessage = msg.body
                    ? `${msg.body}\n\n⚠️ (Errore: Impossibile scaricare l'allegato)`
                    : `⚠️ (Errore: Impossibile scaricare l'allegato)`;

                await saveOrderInfo({
                    id: generateUniqueOrderId(),
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: null,
                    tipo: 'nota',
                    messaggio: warningMessage,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: initialOrderState
                });
            }

        } else if (msg.body && !msg.fromMe) {
            _logger.info(`💬 Testo da ${contactName}: ${msg.body}`);
            saveNote(contactName, msg.body);

            // Se per questo cliente tutti i file precedenti sono già stati stampati ed evasi,
            // un semplice messaggio di cortesia o testo successivo ("Grazie", "Arrivo tra poco")
            // non deve riaprire la chat né creare un ordine con stato "nuovo".
            const noteState = allExistingFilesPrinted ? 'stampato' : initialOrderState;

            await saveOrderInfo({
                id: generateUniqueOrderId(),
                msgId: msgId,
                cliente: contactName,
                telefono: contact.number,
                file: null,
                tipo: 'nota',
                messaggio: msg.body,
                data: new Date(msg.timestamp * 1000).toISOString(),
                stato: noteState
            });
        }

    } catch (error) {
        _logger.info(`🔍 Dettaglio errore per msg ${msgId || '?'}: ${error.message}\n${error.stack}`);
        if (isPuppeteerContextError(error)) {
            if (retryCount < 3) {
                const delay = (retryCount + 1) * 3000;
                _logger.info(`⚠️ Retry msg ${msgId || '?'} tra ${delay / 1000}s (tentativo ${retryCount + 1}/3)...`);
                await new Promise(r => setTimeout(r, delay));
                return processMessage(msg, retryCount + 1);
            } else {
                _logger.info(`⚠️ Messaggio ${msgId || 'ID sconosciuto'} non processabile dopo 3 tentativi (pagina instabile).`);
            }
        } else {
            _logger.error('❌ Errore processamento messaggio:', error);
        }
    }
}

async function processMessageSafe(msg) {
    const msgId = getMessageId(msg);
    if (!msgId) {
        _logger.info('⏭ Messaggio di sistema senza ID valido ignorato.');
        return;
    }
    return processMessage(msg, 0);
}

function moveContactFolderOnDisk(phone, newFolder) {
    return moveContactFolderOnDiskImpl(phone, newFolder, PRINT_FOLDER, _logger);
}

async function syncContactNames(force = false) {
    return syncContactNamesImpl(force, {
        getClient: () => client,
        clientInstance: client,
        getWpStatus: () => wpStatus,
        wpStatus,
        dbInstance: db,
        printFolder: PRINT_FOLDER,
        repairMismatchedFoldersFn: repairMismatchedFolders,
        moveContactFolderFn: moveContactFolderOnDisk,
        logger: _logger
    });
}

async function getExportableContacts() {
    return getExportableContactsImpl({
        dbInstance: db,
        getClient: () => client,
        getWpStatus: () => wpStatus,
        logger: _logger
    });
}

async function redownloadOrderMedia(order) {
    return redownloadOrderMediaImpl(order, client, db, PRINT_FOLDER, _logger);
}

async function sendWhatsAppNotification({ order, message }) {
    return sendWhatsAppNotificationImpl({ order, message }, {
        getClient: () => client,
        getWpStatus: () => wpStatus,
        isReady,
        applyBrowserCompatibilityPatches,
        logger: _logger
    });
}

async function logout() {
    return logoutImpl({
        getClient: () => client,
        setClient: (c) => { client = c; },
        setWpStatus: (s) => { wpStatus = s; },
        setLatestQR: (q) => { latestQR = q; },
        setInitializing: (i) => { isInitializing = i; },
        restart: initializeClient,
        logger: _logger
    });
}

async function reset() {
    return resetImpl({
        getClient: () => client,
        setClient: (c) => { client = c; },
        setWpStatus: (s) => { wpStatus = s; },
        setLatestQR: (q) => { latestQR = q; },
        setInitializing: (i) => { isInitializing = i; },
        restart: initializeClient,
        logger: _logger
    });
}

async function shutdown() {
    return shutdownImpl({
        getClient: () => client,
        setClient: (c) => { client = c; },
        clearWatchdog: () => {
            if (syncWatchdogInterval) {
                clearInterval(syncWatchdogInterval);
                syncWatchdogInterval = null;
            }
        },
        logger: _logger
    });
}

module.exports = {
    init,
    initializeClient,
    getStatus,
    getWpStatus,
    setWpStatus,
    getLatestQR,
    getClient,
    isReady,
    generateUniqueOrderId,
    enqueueIncomingMessage,
    getMessageId,
    syncUnreadMessages,
    downloadMediaResilient,
    processMessage,
    processMessageSafe,
    handleRevokedMessage,
    moveContactFolderOnDisk,
    syncContactNames,
    getExportableContacts,
    redownloadOrderMedia,
    sendWhatsAppNotification,
    handleChatRemoved,
    reconcileStartupContacts,
    logout,
    reset,
    shutdown
};
