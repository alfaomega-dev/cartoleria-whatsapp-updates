// Modulo per l'invio delle notifiche WhatsApp (in-page e fallback)
// Estratto da whatsappClient.js (Fase 6C del piano di modularizzazione).
// Spostamento 1:1 identico con supporto pattern a getter (getClient, getWpStatus, isReady).

const { applyBrowserCompatibilityPatches: defaultApplyPatches } = require('./browserPatches');

async function sendWhatsAppNotification({ order, message }, {
    getClient,
    clientInstance,
    getWpStatus,
    wpStatus,
    isReady: isReadyFn,
    applyBrowserCompatibilityPatches: applyPatchesFn,
    maxWaitReadyMs = 15000,
    logger = console
} = {}) {
    const client = typeof getClient === 'function' ? getClient() : clientInstance;
    if (!client) throw new Error('Client WhatsApp non connesso');

    const checkReady = () => {
        if (typeof isReadyFn === 'function') return isReadyFn();
        return false;
    };

    const getStatus = () => {
        if (typeof getWpStatus === 'function') return getWpStatus();
        return wpStatus || 'DISCONNECTED';
    };

    // 0. Assicura che WhatsApp sia completamente pronto prima di procedere all'invio
    if (!checkReady()) {
        if (logger && typeof logger.info === 'function') {
            logger.info(`⏳ WhatsApp non ancora pronto (stato attuale: ${getStatus()}). Attesa completamento inizializzazione fino a 15s...`);
        }
        const maxWaitMs = maxWaitReadyMs;
        const startWait = Date.now();
        while (Date.now() - startWait < maxWaitMs) {
            if (checkReady()) break;
            await new Promise(r => setTimeout(r, 500));
        }
    }

    if (!checkReady()) {
        if (getStatus() === 'WAITING_FOR_QR') {
            throw new Error('WhatsApp non connesso: scansiona prima il codice QR nelle impostazioni.');
        }
        throw new Error('WhatsApp si sta ancora connettendo, attendi qualche secondo che sia pronto e riprova.');
    }

    // Assicura che l'oggetto WWebJS sia presente nella pagina di WhatsApp Web
    if (client.pupPage && !client.pupPage.isClosed()) {
        const hasWWebJS = await client.pupPage.evaluate(() => typeof window.WWebJS !== 'undefined' && typeof window.WWebJS.sendMessage === 'function').catch(() => false);
        if (!hasWWebJS) {
            if (logger && typeof logger.info === 'function') {
                logger.info('⚠️ window.WWebJS non pronto nella pagina, re-iniezione in corso...');
            }
            try {
                const { LoadUtils } = require('whatsapp-web.js/src/util/Injected/Utils');
                await client.pupPage.evaluate(LoadUtils);
                await new Promise(r => setTimeout(r, 600));
            } catch (injectErr) {
                if (logger && typeof logger.warn === 'function') {
                    logger.warn(`Tentativo iniezione LoadUtils: ${injectErr.message}`);
                }
            }
        }
    }

    // Estrazione e normalizzazione di tutti i possibili identificatori (JID) del destinatario
    const jidCandidates = [];
    const addJid = (j) => {
        if (j && typeof j === 'string') {
            const clean = j.trim();
            if (clean && !jidCandidates.includes(clean)) jidCandidates.push(clean);
        }
    };

    // 1. Dal msgId originale salvato (il JID esatto da cui il cliente ha scritto: @lid o @c.us)
    let originalJid = null;
    if (order.msgId && typeof order.msgId === 'string') {
        const parts = order.msgId.split('_');
        if (parts.length >= 2 && parts[1] && (parts[1].includes('@c.us') || parts[1].includes('@lid') || parts[1].includes('@g.us'))) {
            originalJid = parts[1].trim();
            addJid(originalJid);
        }
    }

    // 2. Dal campo telefono memorizzato per il contatto
    if (order.telefono) {
        const cleanTel = String(order.telefono).trim();
        if (cleanTel.includes('@')) {
            addJid(cleanTel);
        } else {
            const digits = cleanTel.replace(/[^0-9]/g, '');
            if (digits) {
                if (digits.length >= 13) {
                    addJid(`${digits}@lid`);
                } else {
                    addJid(`${digits}@c.us`);
                    if (digits.length === 10 && digits.startsWith('3')) {
                        addJid(`39${digits}@c.us`);
                    } else if (digits.length === 12 && digits.startsWith('39')) {
                        addJid(`${digits.substring(2)}@c.us`);
                    }
                }
            }
        }
    }

    // 3. Se presente identificatore @lid, prova la risoluzione bidirezionale LID <-> Telefono reale
    const lidCandidate = jidCandidates.find(j => j.endsWith('@lid'));
    if (lidCandidate && typeof client.getContactLidAndPhone === 'function') {
        try {
            const resolved = await client.getContactLidAndPhone(lidCandidate);
            if (resolved && resolved[0] && resolved[0].pn) {
                const pn = resolved[0].pn;
                const cleanPn = pn.includes('@') ? pn : `${pn}@c.us`;
                addJid(cleanPn);
                if (logger && typeof logger.info === 'function') {
                    logger.info(`🔍 Risolto numero reale per LID ${lidCandidate} -> ${cleanPn}`);
                }
            }
        } catch (e) {
            if (logger && typeof logger.info === 'function') {
                logger.info(`ℹ️ Risoluzione LID->PN non disponibile: ${e.message}`);
            }
        }
    }

    // Ordina i candidati:
    // Se abbiamo il JID originario del messaggio (es. il canale @lid da cui il cliente ha inviato i file),
    // questo DEVE avere la priorità massima poiché rappresenta la conversazione reale e attiva.
    // In assenza di msgId, i numeri telefonici reali @c.us hanno priorità.
    jidCandidates.sort((a, b) => {
        if (originalJid) {
            if (a === originalJid && b !== originalJid) return -1;
            if (a !== originalJid && b === originalJid) return 1;
        }
        const aIsCus = a.endsWith('@c.us');
        const bIsCus = b.endsWith('@c.us');
        if (aIsCus && !bIsCus) return -1;
        if (!aIsCus && bIsCus) return 1;
        return 0;
    });

    if (jidCandidates.length === 0) {
        throw new Error('Nessun destinatario WhatsApp valido trovato per questo ordine');
    }

    if (logger && typeof logger.info === 'function') {
        logger.info(`🚀 Invio notifica WhatsApp per "${order.cliente || order.telefono}" verso candidati: ${jidCandidates.join(', ')}`);
    }

    let lastError = null;

    // Metodo 1 (Primario e Resiliente): Invio diretto in-page via Puppeteer
    if (client.pupPage && !client.pupPage.isClosed()) {
        try {
            const applyPatches = typeof applyPatchesFn === 'function' ? applyPatchesFn : defaultApplyPatches;
            await applyPatches(client.pupPage);
            if (logger && typeof logger.info === 'function') {
                logger.info(`🔄 Invio notifica in-page per ${order.cliente || order.telefono}...`);
            }
            const pageResult = await client.pupPage.evaluate(async (targetJids, orderMsgId, contactName, text) => {
                // Polyfill difensivo immediato in-page per Object.prototype.equals e String.prototype.equals
                const getComparable = (x) => {
                    if (x == null) return '';
                    if (typeof x === 'string') return x;
                    if (x._serialized) return String(x._serialized);
                    if (x.user && x.server) return x.user + '@' + x.server;
                    if (x.user) return String(x.user);
                    if (x.id) {
                        if (typeof x.id === 'string') return x.id;
                        if (x.id._serialized) return String(x.id._serialized);
                        if (x.id.user) return String(x.id.user);
                    }
                    if (typeof x.toString === 'function' && x.toString !== Object.prototype.toString) {
                        try { return x.toString(); } catch (e) { return ''; }
                    }
                    return '';
                };

                const safeEquals = function (other) {
                    if (this === other) return true;
                    if (other == null) return false;
                    const a = getComparable(this);
                    const b = getComparable(other);
                    if (a && b) {
                        if (a === b) return true;
                        const userA = a.split('@')[0];
                        const userB = b.split('@')[0];
                        if (userA && userB && userA === userB) return true;
                    }
                    return false;
                };

                if (typeof Object.prototype.equals !== 'function') {
                    Object.defineProperty(Object.prototype, 'equals', {
                        value: safeEquals,
                        writable: true,
                        configurable: true,
                        enumerable: false
                    });
                }

                if (typeof String.prototype.equals !== 'function') {
                    Object.defineProperty(String.prototype, 'equals', {
                        value: safeEquals,
                        writable: true,
                        configurable: true,
                        enumerable: false
                    });
                }

                const { Chat, Msg } = window.require('WAWebCollections') || {};
                const widFactory = window.require('WAWebWidFactory');

                if (!Chat) return { success: false, error: 'Collezione Chat non disponibile in WhatsApp Web' };

                let targetChat = null;

                // A. Dal messaggio originale da cui è scaturito l'ordine (chat attiva garantita)
                if (orderMsgId) {
                    try {
                        if (Msg) {
                            let m = Msg.get(orderMsgId);
                            if (!m && typeof Msg.getMessagesById === 'function') {
                                const res = await Msg.getMessagesById([orderMsgId]);
                                m = res?.messages?.[0] || (Array.isArray(res) ? res[0] : null);
                            }
                            if (m) {
                                if (m.chat) targetChat = m.chat;
                                else if (m.id && m.id.remote) {
                                    targetChat = Chat.get(m.id.remote);
                                    if (!targetChat && widFactory) {
                                        try { targetChat = Chat.get(widFactory.createWid(m.id.remote)); } catch (e) {}
                                    }
                                }
                            }
                        }
                        if (!targetChat) {
                            const origJid = orderMsgId.split('_')[1];
                            if (origJid) {
                                if (widFactory) {
                                    try { targetChat = Chat.get(widFactory.createWid(origJid)); } catch (e) {}
                                }
                                if (!targetChat) targetChat = Chat.get(origJid);
                            }
                        }
                    } catch (e) {}
                }

                // B. Cerca nei modelli attivi Chat.models per ciascun candidato JID (chat già aperta/sincronizzata)
                if (!targetChat && Chat.models && Chat.models.length > 0) {
                    for (const jid of targetJids) {
                        const jidClean = String(jid).trim();
                        const jidUser = jidClean.split('@')[0];
                        try {
                            if (widFactory) targetChat = Chat.get(widFactory.createWid(jidClean));
                            if (!targetChat) targetChat = Chat.get(jidClean);
                        } catch (e) {}
                        if (!targetChat) {
                            targetChat = Chat.models.find(c => {
                                if (!c || !c.id) return false;
                                const cSerialized = c.id._serialized || c.id.$1 || (typeof c.id.toString === 'function' ? c.id.toString() : '');
                                if (cSerialized === jidClean) return true;
                                if (c.id.user === jidUser) return true;
                                if (c.contact) {
                                    const contactSerialized = c.contact.id?._serialized || c.contact.id?.$1 || '';
                                    if (contactSerialized === jidClean) return true;
                                    if (c.contact.number === jidUser) return true;
                                }
                                return false;
                            });
                        }
                        if (targetChat) break;
                    }
                }

                // C. Fallback per nome contatto se presente nella rubrica / chat
                if (!targetChat && contactName && Chat.models) {
                    const cleanTarget = String(contactName).toLowerCase().replace(/[^a-z0-9]/gi, ' ').trim();
                    const targetWords = cleanTarget.split(/\s+/).filter(w => w.length >= 2);
                    targetChat = Chat.models.find(c => {
                        const rawTitle = c.formattedTitle || c.name || (c.contact && (c.contact.name || c.contact.pushname || c.contact.displayName)) || '';
                        if (!rawTitle) return false;
                        const t = String(rawTitle).toLowerCase().replace(/[^a-z0-9]/gi, ' ').trim();
                        if (t === cleanTarget || t.includes(cleanTarget) || cleanTarget.includes(t)) return true;
                        if (targetWords.length > 0 && targetWords.every(w => t.includes(w))) return true;
                        return false;
                    });
                }

                // D. Solo se nessuna chat esiste in memoria, prova apertura/creazione con findOrCreateLatestChat
                if (!targetChat && widFactory) {
                    const findChatAction = window.require('WAWebFindChatAction');
                    if (findChatAction && typeof findChatAction.findOrCreateLatestChat === 'function') {
                        for (const jid of targetJids) {
                            try {
                                const wid = widFactory.createWid(jid);
                                const res = await findChatAction.findOrCreateLatestChat(wid);
                                if (res && res.chat) {
                                    targetChat = res.chat;
                                    break;
                                }
                            } catch (e) {}
                        }
                    }
                }

                if (!targetChat) {
                    return { success: false, error: 'Chat non trovata né per ID messaggio, né per JID, né per nome' };
                }

                // Invio effettivo del messaggio alla chat individuata con sendSeen: false e waitUntilMsgSent: true
                let sendSuccess = false;
                let sentMsgId = null;

                // Tentativo A: tramite window.WWebJS.sendMessage
                if (window.WWebJS && typeof window.WWebJS.sendMessage === 'function') {
                    try {
                        const sent = await window.WWebJS.sendMessage(targetChat, text, { sendSeen: false, waitUntilMsgSent: true });
                        sendSuccess = true;
                        if (sent && sent.id) {
                            sentMsgId = sent.id._serialized || sent.id.id || String(sent.id);
                        }
                    } catch (wwebErr) {
                        console.warn('Errore window.WWebJS.sendMessage:', wwebErr);
                    }
                }

                // Tentativo B (se A ha lanciato eccezione): invio diretto tramite WAWebSendMsgChatAction
                if (!sendSuccess && window.require) {
                    try {
                        const sendMsgAction = window.require('WAWebSendMsgChatAction');
                        const UserPrefs = window.require('WAWebUserPrefsMeUser');
                        const MsgKey = window.require('WAWebMsgKey');
                        if (sendMsgAction && UserPrefs && MsgKey) {
                            const lidUser = typeof UserPrefs.getMaybeMeLidUser === 'function' ? UserPrefs.getMaybeMeLidUser() : null;
                            const meUser = typeof UserPrefs.getMaybeMePnUser === 'function' ? UserPrefs.getMaybeMePnUser() : null;
                            const newId = await MsgKey.newId();
                            const isLid = targetChat.id && typeof targetChat.id.isLid === 'function' && targetChat.id.isLid();
                            const from = isLid ? (lidUser || meUser) : (meUser || lidUser);
                            const newMsgKey = new MsgKey({
                                from: from,
                                to: targetChat.id,
                                id: newId,
                                selfDir: 'out'
                            });
                            const msgObj = {
                                id: newMsgKey,
                                ack: 0,
                                body: text,
                                from: from,
                                to: targetChat.id,
                                local: true,
                                self: 'out',
                                t: Math.floor(Date.now() / 1000),
                                isNewMsg: true,
                                type: 'chat'
                            };
                            const [msgPromise, sendMsgResultPromise] = sendMsgAction.addAndSendMsgToChat(targetChat, msgObj);
                            await msgPromise;
                            if (sendMsgResultPromise) await sendMsgResultPromise;
                            sendSuccess = true;
                            sentMsgId = newMsgKey._serialized || newId;
                        }
                    } catch (directErr) {
                        console.warn('Errore invio diretto WAWebSendMsgChatAction:', directErr);
                    }
                }

                // Se l'invio è avvenuto con successo, recupera l'ID del messaggio se non già presente
                if (sendSuccess) {
                    if (!sentMsgId && targetChat.msgs) {
                        try {
                            const lastMsg = typeof targetChat.msgs.last === 'function' ? targetChat.msgs.last() : null;
                            if (lastMsg && lastMsg.id) {
                                sentMsgId = lastMsg.id._serialized || lastMsg.id.id || String(lastMsg.id);
                            }
                        } catch (e) {}
                    }
                    return {
                        success: true,
                        msgId: sentMsgId || ('out_' + Date.now()),
                        chat: targetChat.id?._serialized || targetChat.id?.user || 'unknown'
                    };
                }

                return { success: false, error: 'Invio fallito tramite i metodi interni della chat' };
            }, jidCandidates, order.msgId, order.cliente, message);

            if (pageResult && pageResult.success) {
                if (logger && typeof logger.info === 'function') {
                    logger.info(`✅ Notifica WhatsApp inviata con successo in-page a: ${pageResult.chat} (MsgID: ${pageResult.msgId})`);
                }
                return pageResult;
            } else {
                if (logger && typeof logger.warn === 'function') {
                    logger.warn(`⚠️ Tentativo in-page fallito: ${pageResult?.error || 'nessun errore specificato'}`);
                }
                lastError = new Error(pageResult?.error || 'Invio in-page fallito');
            }
        } catch (pageErr) {
            if (logger && typeof logger.warn === 'function') {
                logger.warn(`⚠️ Eccezione durante invio in-page: ${pageErr.message}`);
            }
            lastError = pageErr;
        }
    }

    // Metodo 2 (Fallback secondario): client.sendMessage(...) per ciascun JID candidato
    if (logger && typeof logger.info === 'function') {
        logger.info('🔄 Tentativo fallback tramite client.sendMessage...');
    }
    for (const jid of jidCandidates) {
        try {
            if (logger && typeof logger.info === 'function') {
                logger.info(`Tentativo sendMessage verso: ${jid}`);
            }
            const res = await client.sendMessage(jid, message, { sendSeen: false, waitUntilMsgSent: true });
            if (res && (res.id || typeof res === 'object')) {
                if (logger && typeof logger.info === 'function') {
                    logger.info(`✅ Messaggio WhatsApp inviato con successo a: ${jid}`);
                }
                return res;
            }
        } catch (err) {
            if (logger && typeof logger.warn === 'function') {
                logger.warn(`⚠️ sendMessage verso ${jid} fallito: ${err.message}`);
            }
            lastError = err;
        }
    }

    throw new Error(`Impossibile inviare la notifica WhatsApp a "${order.cliente || order.telefono}": ${lastError ? lastError.message : 'Nessuna chat raggiungibile'}`);
}

module.exports = {
    sendWhatsAppNotification
};
