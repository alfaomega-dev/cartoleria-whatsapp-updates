// Utility pure (senza stato) per il client WhatsApp.
// Estratte da whatsappClient.js senza modifiche alla logica.

const MIME_EXTENSION_MAP = {
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'application/msword': 'doc',
    'application/pdf': 'pdf',
    'application/vnd.ms-excel': 'xls',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
    'application/vnd.ms-powerpoint': 'ppt',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
    'text/plain': 'txt',
    'text/csv': 'csv',
    'image/jpeg': 'jpg',
    'image/png': 'png',
    'image/gif': 'gif',
    'image/webp': 'webp',
    'image/bmp': 'bmp',
    'image/tiff': 'tiff',
    'video/mp4': 'mp4',
    'application/zip': 'zip',
    'audio/ogg; codecs=opus': 'ogg',
    'audio/ogg': 'ogg',
    'audio/mpeg': 'mp3',
    'audio/mp4': 'm4a'
};

// Ricava l'estensione file da un mimetype (default 'bin').
function getExtensionFromMime(mimetype) {
    let ext = MIME_EXTENSION_MAP[mimetype] || mimetype?.split('/')[1]?.split(';')[0] || 'bin';
    if (ext.includes('wordprocessingml')) ext = 'docx';
    if (ext.includes('spreadsheetml')) ext = 'xlsx';
    if (ext.includes('presentationml')) ext = 'pptx';
    return ext;
}

function getMessageId(msg) {
    if (!msg) return null;
    if (msg.id) {
        if (typeof msg.id === 'string' && msg.id !== '[object Object]') return msg.id;
        if (msg.id._serialized && msg.id._serialized !== '[object Object]' && typeof msg.id._serialized === 'string' && !msg.id._serialized.includes('[object Object]')) {
            return msg.id._serialized;
        }
        if (msg.id.$1 && msg.id.$1 !== '[object Object]' && typeof msg.id.$1 === 'string' && !msg.id.$1.includes('[object Object]')) {
            return msg.id.$1;
        }
        if (msg.id.id) {
            const remote = msg.id.remote || msg.from || 'unknown';
            const remoteStr = typeof remote === 'object' && remote !== null
                ? ((remote._serialized && remote._serialized !== '[object Object]') ? remote._serialized : (remote.$1 || (remote.user && remote.server ? `${remote.user}@${remote.server}` : 'unknown')))
                : remote;
            const fromMe = msg.id.fromMe ? 'true' : 'false';
            if (remoteStr && remoteStr !== 'unknown') {
                return `${fromMe}_${remoteStr}_${msg.id.id}`;
            }
            return `${fromMe}_${msg.from || 'unknown'}_${msg.id.id}`;
        }
    }
    if (msg.from && msg.timestamp) {
        const extraKey = msg.mediaKey || (msg.mediaData && msg.mediaData.filehash) || (msg._data && (msg._data.filehash || msg._data.id)) || Math.random().toString(36).substring(2, 6);
        return `fallback_${msg.from}_${msg.timestamp}_${msg.type || 'text'}_${extraKey}`;
    }
    return null;
}

module.exports = { MIME_EXTENSION_MAP, getExtensionFromMime, getMessageId };
