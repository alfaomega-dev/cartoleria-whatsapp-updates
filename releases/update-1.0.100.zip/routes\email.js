const express = require('express');
const router = express.Router();
const fs = require('fs');

const { CONFIG_FILE, getConfig, saveConfig } = require('../modules/config');
const {
    testEmailConnection,
    parseThunderbirdFilters,
    checkNewEmails
} = require('../modules/email');

function init({ logger } = {}) {
    const _logger = logger || console;

    // POST /api/email/test - Test connessione IMAP / SMTP
    router.post('/api/email/test', async (req, res) => {
        const { emailHost, emailUser, emailPassword, smtpHost } = req.body;
        if (!emailHost || !emailUser || !emailPassword || !smtpHost) {
            return res.status(400).json({ error: 'Dati incompleti per eseguire il test.' });
        }
        try {
            const testResults = await testEmailConnection(req.body);
            res.json(testResults);
        } catch (err) {
            _logger.error('Errore test connessione email:', err);
            res.status(500).json({ error: 'Errore durante il test di connessione: ' + err.message });
        }
    });

    // GET /api/email/filters - Lista dei filtri e-mail configurati
    router.get('/api/email/filters', (req, res) => {
        const config = getConfig();
        res.json(config.emailFilters || []);
    });

    // POST /api/email/filters - Aggiunta manuale di una regola filtro e-mail
    router.post('/api/email/filters', (req, res) => {
        const { name, field, operator, value, action } = req.body;
        if (!field || !operator || !value) {
            return res.status(400).json({ error: 'Campi obbligatori mancanti.' });
        }

        const config = getConfig();
        const newRule = {
            id: 'rule_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            name: name || 'Nuova Regola',
            field: field,
            operator: operator,
            value: value,
            action: action || 'skip',
            enabled: true
        };

        if (!config.emailFilters) config.emailFilters = [];
        config.emailFilters.push(newRule);

        try {
            saveConfig({ emailFilters: config.emailFilters });
            res.json({ success: true, filters: config.emailFilters });
        } catch (err) {
            _logger.error('Impossibile salvare il filtro email:', err);
            res.status(500).json({ error: 'Impossibile salvare la configurazione.' });
        }
    });

    // DELETE /api/email/filters/:id - Rimozione di un filtro e-mail
    router.delete('/api/email/filters/:id', (req, res) => {
        const { id } = req.params;
        const config = getConfig();
        if (!config.emailFilters) config.emailFilters = [];

        config.emailFilters = config.emailFilters.filter(rule => rule.id !== id);

        try {
            saveConfig({ emailFilters: config.emailFilters });
            res.json({ success: true, filters: config.emailFilters });
        } catch (err) {
            _logger.error('Impossibile rimuovere il filtro email:', err);
            res.status(500).json({ error: 'Impossibile salvare la configurazione.' });
        }
    });

    // POST /api/email/filters/import - Importazione filtri da Thunderbird (.dat)
    router.post('/api/email/filters/import', (req, res) => {
        const { fileContent } = req.body;
        if (!fileContent) {
            return res.status(400).json({ error: 'Nessun contenuto del file ricevuto.' });
        }

        try {
            const importedRules = parseThunderbirdFilters(fileContent);
            const config = getConfig();
            if (!config.emailFilters) config.emailFilters = [];

            let addedCount = 0;
            for (const imp of importedRules) {
                const exists = config.emailFilters.some(
                    existing => existing.field === imp.field &&
                                existing.operator === imp.operator &&
                                existing.value.toLowerCase() === imp.value.toLowerCase()
                );
                if (!exists) {
                    config.emailFilters.push(imp);
                    addedCount++;
                }
            }

            saveConfig({ emailFilters: config.emailFilters });
            res.json({ success: true, importedCount: addedCount, totalCount: config.emailFilters.length, filters: config.emailFilters });
        } catch (err) {
            _logger.error('Errore importazione filtri Thunderbird:', err);
            res.status(500).json({ error: 'Errore durante la lettura del file dei filtri.' });
        }
    });

    // POST /api/email/check - Forzatura manuale del controllo nuove e-mail
    router.post('/api/email/check', async (req, res) => {
        try {
            const result = await checkNewEmails();
            res.json(result);
        } catch (err) {
            _logger.error('❌ Errore durante il controllo e-mail manuale:', err);
            res.status(500).json({ error: 'Errore durante il controllo e-mail: ' + err.message });
        }
    });

    return router;
}

module.exports = { init };
