const express = require('express');
const router = express.Router();

const db = require('../db');
const { getExportableContacts } = require('../modules/whatsappClient');

function init({ logger } = {}) {
    const _logger = logger || console;

    // GET /api/contacts/export/csv - Esportazione contatti in formato CSV
    router.get('/api/contacts/export/csv', async (req, res) => {
        try {
            const contacts = await getExportableContacts();
            let csvContent = '\uFEFF'; // UTF-8 BOM per Excel
            csvContent += 'Nome;Telefono;Totale Ordini;Ultimo Ordine\n';

            contacts.forEach(c => {
                const safeName = (c.name || '').replace(/;/g, ',');
                const phone = (c.phone || '').replace(/;/g, '');
                const count = c.orderCount || 0;
                const lastDate = c.lastOrder ? new Date(c.lastOrder).toLocaleString('it-IT') : 'N/D';
                csvContent += `"${safeName}";"${phone}";${count};"${lastDate}"\n`;
            });

            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', 'attachment; filename="rubrica_printzap.csv"');
            res.status(200).send(csvContent);
        } catch (err) {
            _logger.error('Errore export CSV:', err);
            res.status(500).json({ error: 'Errore durante la generazione del file CSV' });
        }
    });

    // GET /api/contacts/export/vcf - Esportazione contatti in formato VCF (vCard)
    router.get('/api/contacts/export/vcf', async (req, res) => {
        try {
            const contacts = await getExportableContacts();
            let vcfContent = '';

            contacts.forEach(c => {
                let phone = (c.phone || '').replace(/[^0-9+]/g, '');
                if (!phone) return;
                if (!phone.startsWith('+') && !phone.startsWith('00')) {
                    if (phone.startsWith('39') && phone.length >= 10) {
                        phone = '+' + phone;
                    } else if (phone.length === 10) {
                        phone = '+39' + phone;
                    }
                }

                const name = c.name || phone;

                vcfContent += 'BEGIN:VCARD\r\n';
                vcfContent += 'VERSION:3.0\r\n';
                vcfContent += `FN:${name}\r\n`;
                vcfContent += `TEL;TYPE=CELL:${phone}\r\n`;
                vcfContent += 'END:VCARD\r\n';
            });

            res.setHeader('Content-Type', 'text/vcard; charset=utf-8');
            res.setHeader('Content-Disposition', 'attachment; filename="rubrica_printzap.vcf"');
            res.status(200).send(vcfContent);
        } catch (err) {
            _logger.error('Errore export VCF:', err);
            res.status(500).json({ error: 'Errore durante la generazione del file VCF' });
        }
    });

    // GET /api/reports/export - Generazione Report CSV degli ordini
    router.get('/api/reports/export', async (req, res) => {
        try {
            const orders = await db.getOrders();
            let csv = '\uFEFF'; // UTF-8 BOM per Excel
            csv += 'ID Ordine;Data;Ora;Cliente;Canale / Telefono;Tipo Documento;File;Stato;Dettagli / Messaggio\n';

            for (const ord of orders) {
                const dateObj = new Date(ord.data);
                const dataFormatted = !isNaN(dateObj) ? dateObj.toLocaleDateString('it-IT') : '';
                const oraFormatted = !isNaN(dateObj) ? dateObj.toLocaleTimeString('it-IT') : '';
                const channel = (ord.telefono || '').startsWith('tg_') ? 'Telegram' :
                                (ord.telefono || '').startsWith('web_') ? 'Web Bancone' :
                                (ord.id || '').startsWith('email_') ? 'Email' : 'WhatsApp';

                const cleanMessage = (ord.messaggio || '').replace(/[\r\n]+/g, ' | ').replace(/;/g, ',');
                csv += `"${ord.id}";"${dataFormatted}";"${oraFormatted}";"${ord.cliente}";"${channel} (${ord.telefono})";"${ord.tipo}";"${ord.file}";"${ord.stato}";"${cleanMessage}"\n`;
            }

            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="report_ordini_printzap_${Date.now()}.csv"`);
            res.send(csv);
        } catch (err) {
            _logger.error('❌ Errore durante esportazione report CSV:', err);
            res.status(500).json({ error: 'Impossibile esportare il report: ' + err.message });
        }
    });

    return router;
}

module.exports = { init };
