const express = require('express');
const router = express.Router();

const db = require('../db');

function init({ logger } = {}) {
    const _logger = logger || console;

    // GET /api/stats - Statistiche complessive (con supporto filtri periodo)
    router.get('/api/stats', async (req, res) => {
        try {
            const { period, from, to } = req.query;
            const stats = await db.getStatistics({ period, from, to });
            res.json(stats);
        } catch (err) {
            _logger.error('Errore recupero statistiche:', err);
            res.status(500).json({ error: 'Impossibile caricare le statistiche.' });
        }
    });

    // POST /api/stats/reset-today - Reset statistiche della giornata odierna
    router.post('/api/stats/reset-today', async (req, res) => {
        try {
            const result = await db.resetTodayStatistics();
            _logger.info(`🧹 Statistiche della giornata azzerate: ${result.updatedRows} ordini spostati in archivio.`);
            res.json({ success: true, message: 'Statistiche della giornata azzerate con successo.', updatedOrders: result.updatedRows });
        } catch (err) {
            _logger.error('Errore azzeramento statistiche giornata:', err);
            res.status(500).json({ error: 'Impossibile azzerare le statistiche di oggi.' });
        }
    });

    // POST /api/stats/reset-all - Reset totale dell'archivio ordini
    router.post('/api/stats/reset-all', async (req, res) => {
        try {
            const result = await db.resetAllStatistics();
            _logger.info(`🧹 Reset totale statistiche completato: ${result.updatedRows} ordini spostati in archivio.`);
            res.json({ success: true, message: 'Tutti gli ordini sono stati archiviati con successo.', updatedOrders: result.updatedRows });
        } catch (err) {
            _logger.error('Errore azzeramento totale statistiche:', err);
            res.status(500).json({ error: 'Impossibile azzerare lo storico ordini.' });
        }
    });

    // GET /api/stats/export/excel - Esportazione statistiche in formato Excel (CSV)
    router.get('/api/stats/export/excel', async (req, res) => {
        try {
            const { period, from, to } = req.query;
            const stats = await db.getStatistics({ period, from, to });
            const now = new Date();
            const dateStr = now.toLocaleDateString('it-IT');
            const timeStr = now.toLocaleTimeString('it-IT');

            const periodLabels = {
                all: 'Tutto lo Storico',
                today: 'Oggi',
                yesterday: 'Ieri',
                week: 'Ultimi 7 Giorni',
                month: 'Questo Mese',
                custom: `Personalizzato (${from || ''} - ${to || ''})`
            };
            const currentPeriodLabel = periodLabels[period] || periodLabels.all;

            let csvContent = '\uFEFF'; // BOM UTF-8 per apertura diretta in Excel
            csvContent += `REPORT STATISTICHE PRINTZAP;Data: ${dateStr} ${timeStr};Periodo: ${currentPeriodLabel}\n\n`;
            csvContent += `INDICATORE;VALORE;NOTE\n`;
            csvContent += `Totale Ordini Periodo;${stats.totalOrders};Ordini nel periodo selezionato\n`;
            csvContent += `Totale Storico Assoluto;${stats.allTimeOrders || stats.totalOrders};Tutti gli ordini registrati nel DB\n`;
            csvContent += `Ordini di Oggi;${stats.todayOrders};Ordini ricevuti nella giornata odierna\n`;
            csvContent += `Ordini Mese Corrente;${stats.thisMonthOrders};Ordini ricevuti nel mese corrente\n`;
            csvContent += `Ordini Stampati;${stats.printedOrders};${stats.totalOrders > 0 ? Math.round((stats.printedOrders / stats.totalOrders) * 100) : 0}% del periodo\n`;
            csvContent += `Ordini In Coda;${stats.pendingOrders};In attesa di stampa\n`;
            csvContent += `Ordini Archiviati;${stats.archivedOrders};Completati e archiviati\n`;
            csvContent += `Clienti Unici;${stats.uniqueContacts};Contatti distinti nel periodo\n`;
            csvContent += `Volume Dati Ricevuto;${stats.totalSizeFormatted || '0 B'};Peso totale allegati su disco\n`;
            csvContent += `File / Allegati;${stats.filesCount};Totale file ricevuti\n`;
            csvContent += `Documenti PDF;${stats.pdfCount || 0};File PDF\n`;
            csvContent += `Immagini / Foto;${stats.imagesCount || 0};JPG, PNG, WebP\n`;
            csvContent += `Documenti Office / Altro;${stats.docsCount || 0};Word, Excel, PPT, Zip\n`;
            csvContent += `Note di Testo;${stats.notesCount};Messaggi scritti\n`;
            csvContent += `Messaggi Vocali;${stats.audioCount};File audio ricevuti\n`;
            csvContent += `Ora di Punta;"${stats.peakHour}";Fascia oraria max affluenza\n`;
            csvContent += `Giorno di Maggior Affluenza;"${stats.peakDay}";Giorno settimana max ordini\n\n`;

            csvContent += `CANALE DI RICEZIONE;CONTEGGIO;PERCENTUALE\n`;
            csvContent += `WhatsApp Web;${stats.whatsappOrders};${stats.totalOrders > 0 ? Math.round((stats.whatsappOrders / stats.totalOrders) * 100) : 0}%\n`;
            csvContent += `Telegram Bot;${stats.telegramOrders};${stats.totalOrders > 0 ? Math.round((stats.telegramOrders / stats.totalOrders) * 100) : 0}%\n`;
            csvContent += `E-mail (IMAP);${stats.emailOrders};${stats.totalOrders > 0 ? Math.round((stats.emailOrders / stats.totalOrders) * 100) : 0}%\n`;
            csvContent += `Web Bancone (Self-Service);${stats.webOrders || 0};${stats.totalOrders > 0 ? Math.round(((stats.webOrders || 0) / stats.totalOrders) * 100) : 0}%\n\n`;

            if (stats.topClients && stats.topClients.length > 0) {
                csvContent += `TOP 5 CLIENTI PIU' ATTIVI;ORDINI TOTALI;STAMPATI;FILE;CANALE PRINCIPALE\n`;
                stats.topClients.forEach((c, idx) => {
                    csvContent += `#${idx + 1} ${c.cliente} (${c.telefono});${c.count};${c.printed};${c.files};${c.channel}\n`;
                });
                csvContent += `\n`;
            }

            csvContent += `TENDENZA ULTIME 7 GIORNATE;ORDINI TOTALI;ORDINI STAMPATI\n`;
            if (stats.recentDailyTrend) {
                stats.recentDailyTrend.forEach(d => {
                    csvContent += `${d.label};${d.total};${d.printed}\n`;
                });
            }

            const fileName = `statistiche_printzap_${now.toISOString().split('T')[0]}.csv`;
            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
            res.status(200).send(csvContent);
        } catch (err) {
            _logger.error('Errore export Excel statistiche:', err);
            res.status(500).json({ error: 'Errore durante la generazione del file Excel.' });
        }
    });

    // GET /api/stats/export/pdf - Anteprima stampabile PDF delle statistiche
    router.get('/api/stats/export/pdf', async (req, res) => {
        try {
            const { period, from, to } = req.query;
            const stats = await db.getStatistics({ period, from, to });
            const now = new Date();
            const dateStr = now.toLocaleDateString('it-IT', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

            const periodLabels = {
                all: 'Tutto lo Storico',
                today: 'Oggi',
                yesterday: 'Ieri',
                week: 'Ultimi 7 Giorni',
                month: 'Questo Mese',
                custom: `Personalizzato (${from || ''} - ${to || ''})`
            };
            const currentPeriodLabel = periodLabels[period] || periodLabels.all;

            const html = `<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Report Statistiche Stampa - PrintZap (${dateStr})</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; color: #1e293b; margin: 30px; background-color: #ffffff; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0284c7; padding-bottom: 15px; margin-bottom: 25px; }
        .title { font-size: 22px; font-weight: bold; color: #0f172a; }
        .subtitle { font-size: 13px; color: #64748b; margin-top: 4px; }
        .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px; }
        .card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; background: #f8fafc; text-align: center; }
        .card-val { font-size: 24px; font-weight: bold; color: #0284c7; }
        .card-lbl { font-size: 12px; color: #64748b; margin-top: 4px; text-transform: uppercase; }
        .section-title { font-size: 16px; font-weight: bold; border-bottom: 1px solid #cbd5e1; padding-bottom: 6px; margin-top: 25px; margin-bottom: 12px; color: #334155; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13px; }
        th, td { border: 1px solid #e2e8f0; padding: 8px 12px; text-align: left; }
        th { background-color: #f1f5f9; color: #334155; }
        tr:nth-child(even) { background-color: #f8fafc; }
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 20px; text-align: right;">
        <button onclick="window.print()" style="padding: 8px 16px; background-color: #0284c7; color: white; border: none; border-radius: 4px; font-size: 14px; cursor: pointer;">🖨️ Stampa / Salva come PDF</button>
    </div>

    <div class="header">
        <div>
            <div class="title">📊 Report Statistiche Stampa & Affluenza</div>
            <div class="subtitle">Generato da PrintZap Cartoleria il ${dateStr} | <strong>Filtro: ${currentPeriodLabel}</strong></div>
        </div>
        <div style="text-align: right; font-size: 12px; color: #64748b;">
            PrintZap Service
        </div>
    </div>

    <div class="grid">
        <div class="card"><div class="card-val">${stats.totalOrders}</div><div class="card-lbl">Ordini Periodo</div></div>
        <div class="card"><div class="card-val" style="color: #25d366;">${stats.printedOrders}</div><div class="card-lbl">Stampati (${stats.totalOrders > 0 ? Math.round((stats.printedOrders/stats.totalOrders)*100) : 0}%)</div></div>
        <div class="card"><div class="card-val" style="color: #f97316;">${stats.pendingOrders}</div><div class="card-lbl">In Coda</div></div>
        <div class="card"><div class="card-val" style="color: #0284c7;">${stats.totalSizeFormatted || '0 B'}</div><div class="card-lbl">Volume Dati Ricevuto</div></div>
        <div class="card"><div class="card-val" style="color: #ec4899;">${stats.uniqueContacts}</div><div class="card-lbl">Clienti Unici</div></div>
        <div class="card"><div class="card-val" style="color: #a855f7;">${stats.allTimeOrders || stats.totalOrders}</div><div class="card-lbl">Totale Storico Assoluto</div></div>
    </div>

    <div class="section-title">⏱️ Affluenza e Orari di Punta</div>
    <table>
        <tr><th>Indicatore</th><th>Valore / Dettaglio</th></tr>
        <tr><td><strong>Ora di Punta (Peak Hour)</strong></td><td>${stats.peakHour}</td></tr>
        <tr><td><strong>Giorno di Maggior Affluenza (Peak Day)</strong></td><td>${stats.peakDay}</td></tr>
    </table>

    <div class="section-title">💬 Canali di Ricezione e Tipologie Contenuti</div>
    <table>
        <thead>
            <tr><th>Canale / Tipologia</th><th>Quantità Ordini</th><th>Percentuale</th></tr>
        </thead>
        <tbody>
            <tr><td>💬 WhatsApp Web</td><td>${stats.whatsappOrders}</td><td>${stats.totalOrders > 0 ? Math.round((stats.whatsappOrders/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>✈️ Telegram Bot</td><td>${stats.telegramOrders}</td><td>${stats.totalOrders > 0 ? Math.round((stats.telegramOrders/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>✉️ E-mail (IMAP)</td><td>${stats.emailOrders}</td><td>${stats.totalOrders > 0 ? Math.round((stats.emailOrders/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>🌐 Web Bancone (Self-Service)</td><td>${stats.webOrders || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.webOrders || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>📕 Documenti PDF</td><td>${stats.pdfCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.pdfCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>🖼️ Immagini / Foto (JPG, PNG)</td><td>${stats.imagesCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.imagesCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>📘 Office / Word / Excel / Altro</td><td>${stats.docsCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.docsCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>🎙️ Messaggi Vocali</td><td>${stats.audioCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.audioCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>💬 Note di Testo</td><td>${stats.notesCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.notesCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
        </tbody>
    </table>

    ${stats.topClients && stats.topClients.length > 0 ? `
    <div class="section-title">🏆 Top 5 Clienti del Periodo</div>
    <table>
        <thead>
            <tr><th>#</th><th>Cliente</th><th>Telefono</th><th>Ordini</th><th>Stampati</th><th>File</th><th>Canale</th></tr>
        </thead>
        <tbody>
            ${stats.topClients.map((c, i) => `
                <tr>
                    <td><strong>#${i + 1}</strong></td>
                    <td>${c.cliente}</td>
                    <td>${c.telefono}</td>
                    <td><strong>${c.count}</strong></td>
                    <td>${c.printed}</td>
                    <td>${c.files}</td>
                    <td>${c.channel}</td>
                </tr>
            `).join('')}
        </tbody>
    </table>
    ` : ''}

    <div class="section-title">📈 Tendenza degli Ultime 7 Giorni</div>
    <table>
        <thead>
            <tr><th>Data</th><th>Ordini Ricevuti</th><th>Ordini Stampati</th></tr>
        </thead>
        <tbody>
            ${(stats.recentDailyTrend || []).map(d => `<tr><td>${d.label}</td><td>${d.total}</td><td>${d.printed}</td></tr>`).join('')}
        </tbody>
    </table>

    <script>
        window.onload = function() {
            setTimeout(function() { window.print(); }, 500);
        };
    </script>
</body>
</html>`;
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            res.status(200).send(html);
        } catch (err) {
            _logger.error('Errore export PDF statistiche:', err);
            res.status(500).send('Errore durante la generazione del report PDF.');
        }
    });

    return router;
}

module.exports = { init };
