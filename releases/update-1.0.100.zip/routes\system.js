const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const { exec, spawn } = require('child_process');

const { ROOT_DIR, DATA_DIR } = require('../modules/paths');
const {
    CONFIG_FILE,
    LICENSE_SALT,
    getConfig,
    saveConfig,
    loadLicense,
    checkLicense,
    getLicenseInfo
} = require('../modules/config');
const { updateAutoStart } = require('../modules/startup');
const emailService = require('../modules/email');
const telegramService = require('../modules/telegram');
const whatsappClient = require('../modules/whatsappClient');

function init({ logger, APP_VERSION, handleGracefulShutdown, activeConnections, getServer } = {}) {
    const _logger = logger || console;

    // GET /api/status - Stato WhatsApp e QR Code
    router.get('/api/status', (req, res) => {
        res.json({ status: whatsappClient.getWpStatus(), qr: whatsappClient.getLatestQR() });
    });

    // POST /api/logout - Disconnessione sessione WhatsApp
    router.post('/api/logout', async (req, res) => {
        try {
            const result = await whatsappClient.logout();
            res.json(result);
        } catch (error) {
            _logger.error('❌ Errore durante il logout:', error);
            fs.writeFileSync(path.join(DATA_DIR, 'logout_error.txt'), error.toString() + '\n' + (error.stack || ''));
            res.status(500).json({ error: 'Errore durante il logout: ' + error.message });
        }
    });

    // POST /api/reset - Reset forzato sessione WhatsApp
    router.post('/api/reset', async (req, res) => {
        try {
            const result = await whatsappClient.reset();
            res.json(result);
        } catch (error) {
            _logger.error('❌ Errore durante il reset:', error);
            res.status(500).json({ error: 'Errore durante il reset: ' + error.message });
        }
    });

    // POST /api/system/close - Chiusura controllata dell'applicazione
    router.post('/api/system/close', async (req, res) => {
        _logger.info('🔌 Richiesta chiusura servizio ricevuta...');
        res.json({ success: true, message: 'Servizio in chiusura...' });
        if (typeof handleGracefulShutdown === 'function') {
            setTimeout(() => handleGracefulShutdown('API_CLOSE'), 1000);
        } else {
            setTimeout(() => process.exit(0), 1000);
        }
    });

    // GET /api/system/logs - Ultimi 150 log di debug dell'applicazione
    router.get('/api/system/logs', (req, res) => {
        const logPath = path.join(DATA_DIR, 'app_debug.log');
        if (!fs.existsSync(logPath)) {
            return res.json({ logs: 'Nessun log di sistema trovato.' });
        }
        try {
            const content = fs.readFileSync(logPath, 'utf8');
            const lines = content.split('\n');
            const lastLines = lines.slice(-150).join('\n');
            res.json({ logs: lastLines });
        } catch (err) {
            res.status(500).json({ error: 'Impossibile leggere i log: ' + err.message });
        }
    });

    // POST /api/system/shutdown - Arresto sicuro di WhatsApp e spegnimento PC
    router.post('/api/system/shutdown', async (req, res) => {
        _logger.info('🔌 Richiesta arresto PC ricevuta...');
        res.json({ success: true, message: 'Chiusura sicura di WhatsApp in corso... Il computer si spegnerà a breve.' });

        setTimeout(async () => {
            // 1. Chiusura pulita di WhatsApp
            try {
                await whatsappClient.shutdown();
            } catch (e) { }

            // 2. Lancia arresto Windows
            exec('shutdown /s /t 0 /f', (err) => {
                if (err) _logger.error('Errore esecuzione shutdown:', err);
                process.exit(0);
            });
        }, 1000);
    });

    // GET /api/config - Configurazione corrente
    router.get('/api/config', (req, res) => {
        res.json(getConfig());
    });

    // POST /api/config - Salvataggio configurazione e aggiornamento servizi
    router.post('/api/config', (req, res) => {
        try {
            const config = getConfig();
            const prevAutoStart = config.autoStartEnabled;
            saveConfig(req.body);
            // Aggiorna il Registro di Windows se il flag avvio automatico è cambiato
            if (config.autoStartEnabled !== prevAutoStart || req.body.autoStartEnabled !== undefined) {
                updateAutoStart(config.autoStartEnabled);
            }
            emailService.startEmailPoller();
            telegramService.initTelegramService();
            res.json({ success: true, config: getConfig() });
        } catch (error) {
            res.status(500).json({ error: 'Impossibile salvare la configurazione' });
        }
    });

    // GET /api/update/check - Controllo versione remota e verifica validità licenza
    router.get('/api/update/check', async (req, res) => {
        const config = getConfig();
        const licenseInfo = getLicenseInfo();

        // Controllo revoca licenza in background se configurato
        if (licenseInfo.activationKey && config.updatesUrl) {
            const baseUrl = config.updatesUrl.replace(/\/+$/, '');
            const licenseUrl = `${baseUrl}/licenses/${licenseInfo.activationKey}.json`;
            axios.get(licenseUrl, { timeout: 4000 }).then(async (response) => {
                if (response.status === 200 && response.data) {
                    const remoteLicense = response.data;
                    const payload = `${remoteLicense.customer}|${remoteLicense.expiryDate || 'never'}|${LICENSE_SALT}`;
                    const expectedKey = crypto.createHash('sha256').update(payload).digest('hex');

                    // Se la licenza online ha una firma diversa o è stata disattivata, invalidala localmente
                    if (remoteLicense.key !== expectedKey || remoteLicense.active === false) {
                        _logger.info('⚠️ Rilevata licenza online non più valida o disattivata. Blocco del servizio.');
                        licenseInfo.active = false;
                        const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
                        fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
                        whatsappClient.setWpStatus('EXPIRED');
                        try { await whatsappClient.shutdown(); } catch (e) { }
                    }
                }
            }).catch(async (err) => {
                // Se il server risponde con 404, significa che la licenza è stata eliminata (revocata)
                if (err.response && err.response.status === 404) {
                    _logger.info('⚠️ Licenza revocata dall\'amministratore (file non trovato online). Blocco del servizio.');
                    licenseInfo.active = false;
                    const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
                    fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
                    whatsappClient.setWpStatus('EXPIRED');
                    try { await whatsappClient.shutdown(); } catch (e) { }
                }
            });
        }

        if (!config.updatesUrl) {
            return res.json({ updateAvailable: false, message: 'URL aggiornamenti non configurato.' });
        }
        try {
            const baseUrl = config.updatesUrl.replace(/\/+$/, '');
            const resRemote = await axios.get(`${baseUrl}/version.json?t=${Date.now()}`, { timeout: 5000 });
            if (resRemote.status === 200 && resRemote.data) {
                const remoteInfo = resRemote.data;
                const remoteVersion = remoteInfo.version;

                const parseVersion = (v) => {
                    if (typeof v !== 'string') return [0];
                    return v.split('.').map(val => parseInt(val, 10) || 0);
                };
                const localParts = parseVersion(APP_VERSION || '1.0.0');
                const remoteParts = parseVersion(remoteVersion);

                let updateAvailable = false;
                for (let i = 0; i < Math.max(localParts.length, remoteParts.length); i++) {
                    const lp = localParts[i] || 0;
                    const rp = remoteParts[i] || 0;
                    if (rp > lp) {
                        updateAvailable = true;
                        break;
                    } else if (lp > rp) {
                        break;
                    }
                }
                res.json({
                    updateAvailable,
                    currentVersion: APP_VERSION || '1.0.0',
                    latestVersion: remoteVersion,
                    zipUrl: remoteInfo.zipUrl,
                    notes: remoteInfo.notes || 'Nessuna nota di rilascio fornita.'
                });
            } else {
                res.status(500).json({ error: 'Impossibile leggere le informazioni di versione dal server remoto.' });
            }
        } catch (error) {
            _logger.error('Errore durante il controllo versione:', error);
            res.status(500).json({ error: 'Errore durante la connessione al server di aggiornamento.' });
        }
    });

    // POST /api/update/download - Download file ZIP aggiornamento e applicazione via aggiorna.bat
    router.post('/api/update/download', async (req, res) => {
        const { zipUrl } = req.body;
        if (!zipUrl) {
            return res.status(400).json({ error: 'URL dello ZIP non fornito.' });
        }

        try {
            const tmpDir = path.join(DATA_DIR, 'tmp');
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true });
            }

            const zipPath = path.join(tmpDir, 'update.zip');
            _logger.info(`📥 Avvio download aggiornamento da: ${zipUrl}`);

            const response = await axios({
                method: 'get',
                url: zipUrl,
                responseType: 'stream',
                timeout: 30000
            });

            const writer = fs.createWriteStream(zipPath);
            response.data.pipe(writer);

            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });

            _logger.info('✅ Download completato. Avvio aggiornamento diretto (senza UAC)...');

            res.json({ success: true, message: 'Download completato. Avvio installazione...' });

            const updatedFlagPath = path.join(DATA_DIR, 'updated.flag');
            try { fs.writeFileSync(updatedFlagPath, '1'); } catch (e) {}

            const batPath = path.join(ROOT_DIR, 'aggiorna.bat');
            const vbsPath = path.join(ROOT_DIR, 'PrintZap.vbs');

            const configBackupPath = path.join(DATA_DIR, 'tmp', 'config_user_backup.json');
            const configSourcePath = CONFIG_FILE;

            const batContent = `@echo off
echo Preparazione dell'aggiornamento in corso...
timeout /t 3 /nobreak > nul

echo Chiusura dei servizi attivi...
taskkill /F /IM mshta.exe > nul 2>&1
taskkill /F /IM PrintZap.exe > nul 2>&1
taskkill /F /IM node.exe > nul 2>&1
timeout /t 3 /nobreak > nul

echo Terminazione residui browser per sblocco sessione...
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \\"Name='chrome.exe' OR Name='msedge.exe'\\" | Where-Object { $_.CommandLine -match 'PrintZap' } | Stop-Process -Force" > nul 2>&1

echo Backup impostazioni utente...
if exist "${configSourcePath.replace(/\\/g, '\\\\')}" copy /Y "${configSourcePath.replace(/\\/g, '\\\\')}" "${configBackupPath.replace(/\\/g, '\\\\')}"

echo Estrazione dei nuovi file di aggiornamento...
powershell -NoProfile -Command "try { Expand-Archive -Path '${zipPath.replace(/\\/g, '\\\\')}' -DestinationPath '${ROOT_DIR.replace(/\\/g, '\\\\')}' -Force } catch { Write-Host $_.Exception.Message }"

echo Ripristino impostazioni utente (protezione sovrascrittura config)...
if exist "${configBackupPath.replace(/\\/g, '\\\\')}" copy /Y "${configBackupPath.replace(/\\/g, '\\\\')}" "${configSourcePath.replace(/\\/g, '\\\\')}"
if exist "${configBackupPath.replace(/\\/g, '\\\\')}" del /f /q "${configBackupPath.replace(/\\/g, '\\\\')}"

echo Pulizia file temporanei...
if exist "${zipPath}" del /f /q "${zipPath}"

echo Riavvio di PrintZap...
start "" "wscript.exe" "${vbsPath}"

echo Aggiornamento completato con successo!
del "%~f0"
`;

            try {
                fs.writeFileSync(batPath, batContent, 'utf8');
            } catch (writeErr) {
                _logger.error('❌ Impossibile scrivere il file aggiorna.bat:', writeErr);
            }

            setTimeout(async () => {
                try {
                    // 1. Chiudi WhatsApp/Puppeteer
                    try {
                        await whatsappClient.shutdown();
                        _logger.info('✅ Client WhatsApp chiuso.');
                    } catch (e) {
                        _logger.warn('⚠️ Errore chiusura client:', e.message);
                    }

                    // 2. Chiudi il server HTTP
                    if (activeConnections) {
                        for (const socket of activeConnections) {
                            socket.destroy();
                        }
                    }
                    const srv = typeof getServer === 'function' ? getServer() : null;
                    if (srv && typeof srv.close === 'function') {
                        srv.close();
                    }

                    // 3. Esegui il file batch in background staccato
                    spawn('cmd.exe', ['/c', batPath], {
                        detached: true,
                        stdio: 'ignore',
                        cwd: ROOT_DIR
                    }).unref();

                    setTimeout(() => process.exit(0), 500);

                } catch (updateErr) {
                    _logger.error('❌ Errore durante l\'esecuzione del file batch:', updateErr);
                    process.exit(1);
                }
            }, 1500);

        } catch (error) {
            _logger.error('Errore durante il download o la preparazione dell\'aggiornamento:', error);
            res.status(500).json({ error: 'Errore durante il download dell\'aggiornamento: ' + error.message });
        }
    });

    // GET /api/license - Stato licenza corrente
    router.get('/api/license', (req, res) => {
        const licenseInfo = getLicenseInfo();
        const status = checkLicense();
        res.json({
            ...status,
            customer: licenseInfo.customer || null,
            expiryDate: licenseInfo.expiryDate || null,
            activationKey: licenseInfo.activationKey || null
        });
    });

    // POST /api/license/activate - Attivazione licenza online tramite chiave
    router.post('/api/license/activate', async (req, res) => {
        const { key } = req.body;
        if (!key || !key.trim()) {
            return res.status(400).json({ error: 'La chiave di licenza non può essere vuota.' });
        }

        const config = getConfig();
        if (!config.updatesUrl) {
            return res.status(400).json({ error: 'Impossibile scaricare la licenza: URL degli aggiornamenti (updatesUrl) non configurato nelle Impostazioni.' });
        }

        const baseUrl = config.updatesUrl.replace(/\/+$/, '');
        const cleanKey = key.trim().replace(/\.json$/i, '');
        const url = `${baseUrl}/licenses/${cleanKey}.json`;

        _logger.info(`📥 Tentativo di attivazione online con chiave: ${cleanKey} da ${url}...`);

        try {
            const response = await axios.get(url, { timeout: 10000 });
            if (response.status !== 200 || typeof response.data !== 'object') {
                throw new Error('Risposta del server non valida.');
            }

            const remoteLicense = response.data;

            if (!remoteLicense.customer || !remoteLicense.key) {
                return res.status(400).json({ error: 'Il file di licenza scaricato è invalido o non firmato.' });
            }

            const payload = `${remoteLicense.customer}|${remoteLicense.expiryDate || 'never'}|${LICENSE_SALT}`;
            const expectedKey = crypto.createHash('sha256').update(payload).digest('hex');

            if (remoteLicense.key !== expectedKey) {
                return res.status(400).json({ error: 'Firma di licenza non valida. Possibile file corrotto o contraffatto.' });
            }

            remoteLicense.activationKey = cleanKey;

            const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
            fs.writeFileSync(LICENSE_FILE, JSON.stringify(remoteLicense, null, 2));

            loadLicense();
            const status = checkLicense();

            _logger.info(`✅ Licenza attivata con successo per: ${remoteLicense.customer}`);

            if (whatsappClient.getWpStatus() === 'EXPIRED') {
                whatsappClient.setWpStatus('DISCONNECTED');
                setTimeout(whatsappClient.initializeClient, 1000);
            }

            res.json({
                success: true,
                message: 'Attivazione completata con successo!',
                license: remoteLicense,
                status: status.message
            });
        } catch (err) {
            _logger.error(`❌ Errore durante l'attivazione della chiave ${cleanKey}:`, err.message);
            res.status(500).json({ error: `Impossibile scaricare o convalidare la chiave di licenza. Verifica che la chiave sia corretta e che il computer sia connesso a internet.` });
        }
    });

    return router;
}

module.exports = { init };
