const express = require('express');
const router = express.Router();

const {
    testTelegramToken,
    getTelegramStatus,
    startService: startTelegramService,
    stopService: stopTelegramService,
    handleWebhook: handleTelegramWebhook
} = require('../modules/telegram');

function init({ logger } = {}) {
    const _logger = logger || console;

    // POST /api/telegram/test - Verifica del Token di un Bot Telegram
    router.post('/api/telegram/test', async (req, res) => {
        const { token } = req.body;
        try {
            const result = await testTelegramToken(token);
            res.json(result);
        } catch (err) {
            const detail = err.response?.data?.description || err.message;
            _logger.error(`❌ Errore test Telegram Token: ${detail}`);
            res.status(400).json({ error: `Errore Telegram: ${detail}` });
        }
    });

    // GET /api/telegram/status - Stato attuale del Servizio Telegram
    router.get('/api/telegram/status', (req, res) => {
        res.json(getTelegramStatus());
    });

    // POST /api/telegram/start - Avvio o riconfigurazione Servizio Telegram
    router.post('/api/telegram/start', async (req, res) => {
        try {
            const result = await startTelegramService(req.body);
            res.json(result);
        } catch (err) {
            _logger.error('❌ Errore avvio servizio Telegram:', err);
            res.status(500).json({ error: 'Errore avvio Telegram: ' + err.message });
        }
    });

    // POST /api/telegram/stop - Arresto Servizio Telegram
    router.post('/api/telegram/stop', async (req, res) => {
        try {
            const result = await stopTelegramService();
            res.json(result);
        } catch (err) {
            _logger.error('❌ Errore stop servizio Telegram:', err);
            res.status(500).json({ error: 'Errore stop Telegram: ' + err.message });
        }
    });

    // POST /api/telegram/webhook - Endpoint ricezione Webhook Telegram
    router.post('/api/telegram/webhook', async (req, res) => {
        res.status(200).send('OK');
        try {
            await handleTelegramWebhook(req.body);
        } catch (err) {
            _logger.error('⚠️ Errore durante elaborazione Webhook Telegram:', err.message);
        }
    });

    return router;
}

module.exports = { init };
