const express = require('express');
const router = express.Router();

const { getConfig } = require('../modules/config');
const {
    generateUploadPage,
    uploadWebMulter,
    handleWebUpload
} = require('../modules/webBancone');

function init({ logger } = {}) {
    const _logger = logger || console;

    // GET /upload - Servizio pagina Web Mobile Bancone (Self-service via QR Code)
    router.get('/upload', (req, res) => {
        const config = getConfig();
        res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        res.send(generateUploadPage(config));
    });

    // POST /api/web/upload - Ricezione allegati e messaggi dal modulo Web Bancone
    router.post('/api/web/upload', uploadWebMulter.array('files', 15), async (req, res) => {
        const config = getConfig();
        if (config.webBanconeEnabled === false) {
            return res.status(403).json({ error: 'Il servizio Web Bancone è momentaneamente disattivato dal gestore.' });
        }
        try {
            const result = await handleWebUpload({ body: req.body, files: req.files });
            res.json(result);
        } catch (err) {
            _logger.error('❌ Errore durante elaborazione upload web:', err);
            res.status(500).json({ error: 'Errore durante il salvataggio dei file: ' + err.message });
        }
    });

    return router;
}

module.exports = { init };
