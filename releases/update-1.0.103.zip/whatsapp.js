const fs = require('fs');
const path = require('path');
const express = require('express');
const cors = require('cors');
const { exec, execSync } = require('child_process');
const crypto = require('crypto');
const db = require('./db');

const { ROOT_DIR, DATA_DIR, AUTH_DIR, PRINT_FOLDER } = require('./modules/paths');

const APP_VERSION = '1.0.103';

const app = express();
const PORT = process.env.PORT || 3000;

// --- STRUCTURED LOGGING (Scrive sia in Console che su File) ---
const pino = require('pino');
const streams = [
    { stream: process.stdout },
    { stream: fs.createWriteStream(path.join(DATA_DIR, 'app_debug.log'), { flags: 'a' }) }
];
const logger = pino({}, pino.multistream(streams));

logger.info('🚀 Avvio applicazione professionale...');
logger.info(`📂 DATA_DIR: ${DATA_DIR}`);
logger.info(`📂 AUTH_DIR: ${AUTH_DIR}`);

function notifyDashboard(data) {
    try {
        if (data && data.order) {
            logger.info(`📢 Notifica ordine dashboard (${data.channel || 'generico'}): ${data.order.id} per ${data.order.cliente}`);
        }
    } catch (e) {}
}


// --- PULIZIA PORTA ---
function killPort(port) {
    if (process.platform !== 'win32') return;
    try {
        const stdout = execSync(`netstat -ano | findstr :${port}`).toString();
        const lines = stdout.trim().split('\n');
        lines.forEach(line => {
            const parts = line.trim().split(/\s+/);
            const pid = parts[parts.length - 1];
            if (pid && pid !== '0' && pid !== process.pid.toString()) {
                logger.info(`🧹 Pulizia: Trovato processo ${pid} sulla porta ${port}. Terminazione...`);
                execSync(`taskkill /F /PID ${pid}`);
            }
        });
    } catch (e) {
        logger.info(`ℹ️ Info pulizia porta: ${e.message}`);
    }
}

killPort(PORT);

process.on('uncaughtException', (err) => {
    logger.info(`❌ CRASH (Uncaught Exception): ${err.message}\n${err.stack}`);
    logger.error('CRASH:', err);
    // Tieni aperto il processo per leggere l'errore se avviato da terminale
    setTimeout(() => process.exit(1), 30000);
});

process.on('unhandledRejection', (reason, promise) => {
    logger.info(`⚠️ UNHANDLED REJECTION: ${reason}`);
});

app.use(cors());
app.use(express.json());

// Add correlationId to all requests
app.use((req, res, next) => {
    req.correlationId = req.headers['x-correlation-id'] || crypto.randomUUID();
    logger.info({ correlationId: req.correlationId, path: req.path }, 'Request started');
    next();
});

// Track server and active connections
let server;
const activeConnections = new Set();

// Configurazione e Licenze (Modulo modules/config.js - DEGOD Fase 2.1)
const configModule = require('./modules/config');
configModule.init({ logger });

// Servizi di Avvio e Gestione Sessioni (Modulo modules/startup.js - DEGOD Fase 2.2)
const startupModule = require('./modules/startup');
startupModule.init({ logger });
const { updateAutoStart, migrateLegacySessionFolder } = startupModule;

function loadConfig() {
    return configModule.loadConfig(updateAutoStart);
}

loadConfig();
migrateLegacySessionFolder();

// Gestione Sessioni e Hot-Patch (Modulo modules/session.js - DEGOD Fase 2.3)
const sessionModule = require('./modules/session');
sessionModule.init({ logger });


// Funzioni Helper Condivise (Modulo modules/helpers.js - DEGOD Helpers)
const helpersModule = require('./modules/helpers');
helpersModule.init({ logger });
const { repairMismatchedFolders } = helpersModule;

// Servizio E-mail IMAP/SMTP (Modulo modules/email.js - DEGOD Fase 2.4)
const emailService = require('./modules/email');
emailService.init({ logger });
const { startEmailPoller } = emailService;

// Servizio Telegram Bot (Modulo modules/telegram.js - DEGOD Fase 2.5)
const telegramService = require('./modules/telegram');
telegramService.init({ logger, PORT, notifyDashboard });
const { initTelegramService } = telegramService;

// Servizio Web Bancone (Modulo modules/webBancone.js - DEGOD Fase 2.6)
const webBanconeService = require('./modules/webBancone');
webBanconeService.init({ logger, notifyDashboard });

// Servizio WhatsApp Client (Modulo modules/whatsappClient.js - DEGOD Fase 2.7)
const whatsappClientService = require('./modules/whatsappClient');
whatsappClientService.init({ logger, notifyDashboard });
const {
    initializeClient,
    shutdown: shutdownWhatsApp
} = whatsappClientService;

// ===== ROUTER EXPRESS MODULARI (DEGOD Fase 3) =====
const systemRouter = require('./routes/system').init({
    logger,
    APP_VERSION,
    handleGracefulShutdown,
    activeConnections,
    getServer: () => server
});
const ordersRouter = require('./routes/orders').init({ logger });
const statsRouter = require('./routes/stats').init({ logger });
const exportsRouter = require('./routes/exports').init({ logger });
const emailRouter = require('./routes/email').init({ logger });
const telegramRouter = require('./routes/telegram').init({ logger });
const webBanconeRouter = require('./routes/webBancone').init({ logger });

app.use(systemRouter);
app.use(ordersRouter);
app.use(statsRouter);
app.use(exportsRouter);
app.use(emailRouter);
app.use(telegramRouter);
app.use(webBanconeRouter);

// Serve il frontend Dashboard (dopo il build)
const dashboardPath = path.join(ROOT_DIR, 'dashboard', 'dist');
if (fs.existsSync(dashboardPath)) {
    app.use(express.static(dashboardPath, {
        setHeaders: (res, filePath) => {
            res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        }
    }));

    // SPA Fallback: deve rimanere in fondo a tutte le rotte API per non intercettare le chiamate /api/*
    app.get('*', (req, res) => {
        res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        res.sendFile(path.join(dashboardPath, 'index.html'));
    });
}


server = app.listen(PORT, async () => {
    logger.info(`🚀 Server in ascolto su http://localhost:${PORT}`);
    logger.info(`✅ Server avviato correttamente sulla porta ${PORT}`);

    try {
        const dbPath = path.join(DATA_DIR, 'ordini.db');
        logger.info(`📦 Inizializzazione database SQLite in ${dbPath}...`);
        await db.initDb(dbPath);
        logger.info('✅ Database SQLite pronto.');

        // Pulizia avvio: auto-archiviazione ordini già stampati delle giornate precedenti (GIACENZA)
        try {
            const archivedCount = await db.archivePastPrintedOrders();
            if (archivedCount > 0) {
                logger.info(`🧹 Pulizia avvio: archiviati ${archivedCount} ordini stampati delle giornate precedenti.`);
            }
        } catch (archErr) {
            logger.warn(`⚠️ Errore pulizia giacenze: ${archErr.message}`);
        }

        // Sincronizzazione / Riparazione cartelle numeriche con nomi contatto
        await repairMismatchedFolders();

        // Migrazione automatica da ordini.json se presente
        const ordersFile = path.join(DATA_DIR, 'ordini.json');
        if (fs.existsSync(ordersFile)) {
            try {
                logger.info("📦 Trovato file ordini.json. Avvio migrazione su SQLite...");
                const jsonOrders = JSON.parse(fs.readFileSync(ordersFile, 'utf8'));
                let count = 0;
                for (const order of jsonOrders) {
                    await db.saveOrder(order);
                    count++;
                }
                fs.renameSync(ordersFile, ordersFile + '.bak');
                logger.info(`✅ Migrazione completata con successo! Importati ${count} ordini. Creato backup ordini.json.bak`);
            } catch (err) {
                logger.error("❌ Errore durante la migrazione dei dati:", err);
            }
        }
    } catch (dbErr) {
        logger.error('❌ Errore critico inizializzazione database:', dbErr);
        setTimeout(() => process.exit(1), 5000);
        return;
    }

    // Avvia WhatsApp solo se il server è partito
    initializeClient();

    // Avvia il poller e-mail all'avvio
    startEmailPoller();

    // Avvia il servizio Telegram all'avvio (gestisce la modalità configurata)
    initTelegramService();

    // Chiudi lo splash screen ed apri il browser sulla dashboard dinamicamente a server pronto
    if (process.platform === 'win32') {
        exec('taskkill /F /IM mshta.exe >nul 2>&1');
        const flagPath = path.join(DATA_DIR, 'updated.flag');
        if (fs.existsSync(flagPath)) {
            try { fs.unlinkSync(flagPath); } catch (e) {}
        }
        // Apri sempre il browser sulla Dashboard ad ogni avvio del server
        exec(`start http://localhost:${PORT}`);
    }
}).on('connection', (socket) => {
    activeConnections.add(socket);
    socket.on('close', () => activeConnections.delete(socket));
}).on('error', (err) => {
    logger.info(`❌ ERRORE SERVER: ${err.message}`);
    if (err.code === 'EADDRINUSE') {
        logger.info(`⚠️ La porta ${PORT} è già occupata da un altro programma (forse hai già aperto il servizio?). Chiudi la versione precedente.`);
    }
    // Mostra errore all'utente prima di uscire
    logger.error('ERRORE CRITICO:', err.message);
    setTimeout(() => process.exit(1), 30000);
});

// initializeClient(); // Spostato dentro app.listen


async function handleGracefulShutdown(signal) {
    logger.info(`⏹️ Ricevuto segnale ${signal}. Chiusura pulita in corso...`);
    try {
        emailService.shutdown();
    } catch (e) { }
    try {
        await telegramService.shutdown();
    } catch (e) { }
    try {
        await shutdownWhatsApp();
    } catch (e) { }

    // Chiudi tutte le connessioni attive
    activeConnections.forEach(socket => socket.destroy());

    // Chiudi il server ed esci
    server.close(() => {
        logger.info('Server chiuso correttamente');
        process.exit(0);
    });

    // Uscita forzata dopo 5 secondi
    setTimeout(() => {
        logger.error('Forzata chiusura dopo timeout di sicurezza');
        process.exit(1);
    }, 5000);
}

process.on('SIGINT', () => handleGracefulShutdown('SIGINT'));
process.on('SIGTERM', () => handleGracefulShutdown('SIGTERM'));
process.on('SIGHUP', () => handleGracefulShutdown('SIGHUP'));
