const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const { PRINT_FOLDER } = require('./modules/paths');

let db = null;

/**
 * Inizializza il database SQLite e crea le tabelle necessarie.
 * @param {string} dbPath - Il percorso assoluto del file database SQLite.
 */
function initDb(dbPath) {
    return new Promise((resolve, reject) => {
        db = new sqlite3.Database(dbPath, (err) => {
            if (err) {
                return reject(new Error(`Impossibile connettersi a SQLite: ${err.message}`));
            }

            // Ottimizzazioni per concorrenza e resilienza multi-processo/lettura
            db.run("PRAGMA journal_mode = WAL;");
            db.run("PRAGMA busy_timeout = 5000;");
            
            // Controlla lo schema esistente della tabella orders
            db.all("PRAGMA table_info(orders)", [], (err, rows) => {
                if (err) return reject(err);
                
                const tableExists = rows && rows.length > 0;
                const needsMigration = tableExists && rows.find(r => r.name === 'id' && r.type.toUpperCase() === 'INTEGER');
                
                if (needsMigration) {
                    // Esegui migrazione da INTEGER a TEXT per il campo id per consentire gli ordini email
                    db.serialize(() => {
                        db.run("ALTER TABLE orders RENAME TO orders_old", (err) => {
                            if (err) return reject(err);
                            
                            db.run(`
                                CREATE TABLE orders (
                                    id TEXT PRIMARY KEY,
                                    msgId TEXT UNIQUE,
                                    cliente TEXT,
                                    telefono TEXT,
                                    file TEXT,
                                    tipo TEXT,
                                    messaggio TEXT,
                                    data TEXT,
                                    stato TEXT
                                )
                            `, (err) => {
                                if (err) return reject(err);
                                
                                db.run("INSERT INTO orders SELECT CAST(id AS TEXT), msgId, cliente, telefono, file, tipo, messaggio, data, stato FROM orders_old", (err) => {
                                    if (err) return reject(err);
                                    
                                    db.run("DROP TABLE orders_old", (err) => {
                                        if (err) return reject(err);
                                        createIndexes().then(resolve).catch(reject);
                                    });
                                });
                            });
                        });
                    });
                } else if (!tableExists) {
                    // Crea la tabella da zero con il tipo id TEXT
                    db.run(`
                        CREATE TABLE IF NOT EXISTS orders (
                            id TEXT PRIMARY KEY,
                            msgId TEXT UNIQUE,
                            cliente TEXT,
                            telefono TEXT,
                            file TEXT,
                            tipo TEXT,
                            messaggio TEXT,
                            data TEXT,
                            stato TEXT
                        )
                    `, (err) => {
                        if (err) return reject(err);
                        createIndexes().then(resolve).catch(reject);
                    });
                } else {
                    // La tabella esiste già ed è già migrata a TEXT (o non ha bisogno di modifiche)
                    createIndexes().then(resolve).catch(reject);
                }
            });
        });
    });
}

function createIndexes() {
    return new Promise((resolve, reject) => {
        db.run('CREATE INDEX IF NOT EXISTS idx_orders_telefono ON orders(telefono)', (err) => {
            if (err) return reject(err);
            db.run('CREATE INDEX IF NOT EXISTS idx_orders_msgid ON orders(msgId)', (err) => {
                if (err) return reject(err);
                resolve();
            });
        });
    });
}

/**
 * Ottiene una lista degli ordini ordinati per ID decrescente.
 * @param {number} [limit=200] - Numero massimo di ordini da restituire.
 */
function getOrders(limit = 200) {
    return new Promise((resolve, reject) => {
        db.all('SELECT * FROM orders ORDER BY id DESC LIMIT ?', [limit], (err, rows) => {
            if (err) return reject(err);
            resolve(rows || []);
        });
    });
}

/**
 * Ottiene un ordine tramite ID.
 */
function getOrderById(id) {
    if (id === undefined || id === null) return Promise.resolve(null);
    return new Promise((resolve, reject) => {
        const strId = String(id);
        const cleanId = strId.replace(/\.0$/, '');
        const numId = Number(cleanId);
        db.get('SELECT * FROM orders WHERE id = ? OR id = ? OR id = ?', [strId, cleanId, isNaN(numId) ? cleanId : numId], (err, row) => {
            if (err) return reject(err);
            resolve(row || null);
        });
    });
}

/**
 * Helper per generare tutte le varianti di formato di un ID (stringa pura, con .0, senza .0, e numerica).
 * Risolve la discrepanza in SQLite tra '12345.0' e 12345.
 */
function prepareCandidateIds(ids) {
    if (!ids || !Array.isArray(ids)) return [];
    const set = new Set();
    for (const raw of ids) {
        if (raw === undefined || raw === null) continue;
        const str = String(raw).trim();
        if (!str) continue;
        set.add(str);
        if (str.endsWith('.0')) {
            set.add(str.slice(0, -2));
        } else {
            set.add(str + '.0');
        }
        const clean = str.replace(/\.0$/, '');
        const num = Number(clean);
        if (!isNaN(num)) {
            set.add(num);
        }
    }
    return Array.from(set);
}

/**
 * Ottiene più ordini tramite un array di ID (supporta tutte le varianti numeriche e stringa).
 */
function getOrdersByIds(ids) {
    if (!ids || ids.length === 0) return Promise.resolve([]);
    const candidateIds = prepareCandidateIds(ids);
    if (candidateIds.length === 0) return Promise.resolve([]);
    return new Promise((resolve, reject) => {
        const placeholders = candidateIds.map(() => '?').join(',');
        db.all(`SELECT * FROM orders WHERE id IN (${placeholders})`, candidateIds, (err, rows) => {
            if (err) return reject(err);
            resolve(rows || []);
        });
    });
}

/**
 * Salva o aggiorna un ordine nel database.
 */
function saveOrder(order) {
    return new Promise((resolve, reject) => {
        db.run(`
            INSERT OR REPLACE INTO orders (id, msgId, cliente, telefono, file, tipo, messaggio, data, stato)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            order.id,
            order.msgId || null,
            order.cliente,
            order.telefono,
            order.file || null,
            order.tipo,
            order.messaggio || null,
            order.data,
            order.stato
        ], function(err) {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Verifica se un ordine con un determinato msgId esiste già.
 */
function orderExists(msgId) {
    if (!msgId) return Promise.resolve(false);
    return new Promise((resolve, reject) => {
        db.get('SELECT COUNT(*) as count FROM orders WHERE msgId = ? OR msgId LIKE ?', [msgId, `${msgId}_%`], (err, row) => {
            if (err) return reject(err);
            resolve(row ? row.count > 0 : false);
        });
    });
}

/**
 * Ritorna un Set con tutti i msgId già processati (per la sincronizzazione iniziale).
 */
function getProcessedMessageIds() {
    return new Promise((resolve, reject) => {
        db.all('SELECT msgId FROM orders WHERE msgId IS NOT NULL', (err, rows) => {
            if (err) return reject(err);
            const set = new Set(rows.map(r => r.msgId));
            resolve(set);
        });
    });
}

/**
 * Ritorna tutti gli ordini per un determinato contatto che hanno un file associato.
 */
function getOrdersByPhoneAndHasFile(phone) {
    return new Promise((resolve, reject) => {
        db.all('SELECT * FROM orders WHERE telefono = ? AND file IS NOT NULL', [phone], (err, rows) => {
            if (err) return reject(err);
            resolve(rows || []);
        });
    });
}

/**
 * Aggiorna il nome del cliente e il percorso della cartella file per tutti gli ordini legati a un numero.
 */
function updateContactOrdersFolder(phone, newClientName, newFolder) {
    return new Promise((resolve, reject) => {
        db.all('SELECT id, file FROM orders WHERE telefono = ? AND file IS NOT NULL', [phone], (err, rows) => {
            if (err) return reject(err);
            
            db.serialize(() => {
                db.run('BEGIN TRANSACTION', (beginErr) => {
                    if (beginErr) return reject(beginErr);

                    // 1. Aggiorna nome cliente per tutti gli ordini del contatto (con o senza file)
                    db.run('UPDATE orders SET cliente = ? WHERE telefono = ?', [newClientName, phone], (updateErr) => {
                        if (updateErr) {
                            db.run('ROLLBACK');
                            return reject(updateErr);
                        }

                        // 2. Aggiorna i percorsi relativi dei file
                        if (rows && rows.length > 0) {
                            const stmt = db.prepare('UPDATE orders SET file = ? WHERE id = ?', (prepErr) => {
                                if (prepErr) {
                                    db.run('ROLLBACK');
                                    return reject(prepErr);
                                }

                                let completed = 0;
                                let failed = false;

                                for (const row of rows) {
                                    const fileName = path.basename(row.file);
                                    const newPath = `${newFolder}/${fileName}`;
                                    
                                    stmt.run(newPath, row.id, (runErr) => {
                                        if (failed) return;
                                        if (runErr) {
                                            failed = true;
                                            stmt.finalize();
                                            db.run('ROLLBACK');
                                            return reject(runErr);
                                        }

                                        completed++;
                                        if (completed === rows.length) {
                                            stmt.finalize((finErr) => {
                                                if (finErr) {
                                                    db.run('ROLLBACK');
                                                    return reject(finErr);
                                                }
                                                db.run('COMMIT', (commitErr) => {
                                                    if (commitErr) {
                                                        db.run('ROLLBACK');
                                                        return reject(commitErr);
                                                    }
                                                    resolve();
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        } else {
                            db.run('COMMIT', (commitErr) => {
                                if (commitErr) {
                                    db.run('ROLLBACK');
                                    return reject(commitErr);
                                }
                                resolve();
                            });
                        }
                    });
                });
            });
        });
    });
}

/**
 * Segna come stampato un singolo ordine.
 */
function markOrderPrinted(id) {
    return new Promise((resolve, reject) => {
        db.run("UPDATE orders SET stato = 'stampato' WHERE id = ? AND stato != 'archiviato'", [id], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Segna come stampati tutti gli ordini non stampati per un certo numero di telefono o nome contatto.
 * NOTA CRITICA: Non tocca mai gli ordini con stato = 'archiviato' per evitare di riesumare ordini cancellati dall'utente.
 */
function markContactOrdersPrinted(phone, contactName = null, maxDateIso = null) {
    return new Promise((resolve, reject) => {
        const phones = (Array.isArray(phone) ? phone : [phone]).filter(Boolean).map(String);
        if (phones.length === 0 && !contactName) return resolve(false);

        const clauses = [];
        const params = [];

        if (phones.length > 0) {
            const placeholders = phones.map(() => '?').join(',');
            clauses.push(`telefono IN (${placeholders})`);
            params.push(...phones);
        }

        if (contactName && typeof contactName === 'string' && contactName.trim()) {
            clauses.push(`cliente = ?`);
            params.push(contactName.trim());
        }

        let dateClause = '';
        if (maxDateIso) {
            dateClause = ' AND data <= ?';
            params.push(maxDateIso);
        }

        const query = `UPDATE orders SET stato = 'stampato' WHERE stato NOT IN ('stampato', 'archiviato') AND (${clauses.join(' OR ')})${dateClause}`;
        db.run(query, params, function(err) {
            if (err) return reject(err);
            resolve(this.changes > 0); // Ritorna true se ci sono state modifiche
        });
    });
}

/**
 * Elimina un ordine tramite ID.
 */
function deleteOrderById(id) {
    return new Promise((resolve, reject) => {
        db.run('DELETE FROM orders WHERE id = ?', [id], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Elimina più ordini tramite i loro ID (gestisce sia stringhe che numeri).
 */
function deleteOrdersByIds(ids) {
    if (!ids || ids.length === 0) return Promise.resolve();
    const candidateIds = prepareCandidateIds(ids);
    if (candidateIds.length === 0) return Promise.resolve();
    return new Promise((resolve, reject) => {
        const placeholders = candidateIds.map(() => '?').join(',');
        db.run(`DELETE FROM orders WHERE id IN (${placeholders})`, candidateIds, (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Svuota completamente la tabella degli ordini.
 */
function deleteAllOrders() {
    return new Promise((resolve, reject) => {
        db.run('DELETE FROM orders', (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Ritorna tutti gli ordini per un determinato contatto (telefono o nome).
 */
function getOrdersByContact(phone, contactName = null) {
    return new Promise((resolve, reject) => {
        const phones = (Array.isArray(phone) ? phone : [phone]).filter(Boolean).map(String);
        if (phones.length === 0 && !contactName) return resolve([]);
        const clauses = [];
        const params = [];
        if (phones.length > 0) {
            const placeholders = phones.map(() => '?').join(',');
            clauses.push(`telefono IN (${placeholders})`);
            params.push(...phones);
        }
        if (contactName && typeof contactName === 'string' && contactName.trim()) {
            clauses.push(`cliente = ?`);
            params.push(contactName.trim());
        }
        db.all(`SELECT * FROM orders WHERE ${clauses.join(' OR ')}`, params, (err, rows) => {
            if (err) return reject(err);
            resolve(rows || []);
        });
    });
}

function getOrdersByPhone(phone) {
    return getOrdersByContact(phone);
}

/**
 * Elimina tutti gli ordini per un determinato contatto (telefono o nome).
 */
function deleteOrdersByContact(phone, contactName = null) {
    return new Promise((resolve, reject) => {
        const phones = (Array.isArray(phone) ? phone : [phone]).filter(Boolean).map(String);
        if (phones.length === 0 && !contactName) return resolve();
        const clauses = [];
        const params = [];
        if (phones.length > 0) {
            const placeholders = phones.map(() => '?').join(',');
            clauses.push(`telefono IN (${placeholders})`);
            params.push(...phones);
        }
        if (contactName && typeof contactName === 'string' && contactName.trim()) {
            clauses.push(`cliente = ?`);
            params.push(contactName.trim());
        }
        db.run(`DELETE FROM orders WHERE ${clauses.join(' OR ')}`, params, (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

function deleteOrdersByPhone(phone) {
    return deleteOrdersByContact(phone);
}

/**
 * Imposta lo stato di un ordine a 'archiviato'.
 */
function archiveOrder(id) {
    return new Promise((resolve, reject) => {
        db.run("UPDATE orders SET stato = 'archiviato' WHERE id = ?", [id], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Imposta lo stato di più ordini a 'archiviato' (gestisce sia stringhe che numeri).
 */
function archiveOrders(ids) {
    if (!ids || ids.length === 0) return Promise.resolve(0);
    const candidateIds = prepareCandidateIds(ids);
    if (candidateIds.length === 0) return Promise.resolve(0);
    return new Promise((resolve, reject) => {
        const placeholders = candidateIds.map(() => '?').join(',');
        db.run(`UPDATE orders SET stato = 'archiviato' WHERE id IN (${placeholders})`, candidateIds, function(err) {
            if (err) return reject(err);
            resolve(this.changes || 0);
        });
    });
}

/**
 * Ottiene un ordine tramite il msgId di WhatsApp.
 * Supporta un singolo ID o un array di candidati, eseguendo sia il match esatto
 * sia il fallback tramite stanzaId (essenziale per chat con identificatori LID).
 */
function getOrderByMsgId(msgId) {
    if (!msgId) return Promise.resolve(null);
    const candidates = (Array.isArray(msgId) ? msgId : [msgId]).filter(Boolean);
    if (candidates.length === 0) return Promise.resolve(null);

    return new Promise((resolve, reject) => {
        // 1. Prova prima il match esatto per tutti i candidati
        const placeholders = candidates.map(() => '?').join(',');
        db.get(`SELECT * FROM orders WHERE msgId IN (${placeholders})`, candidates, (err, row) => {
            if (err) return reject(err);
            if (row) return resolve(row);

            // 2. Fallback: estrazione stanzaId univoco per chat @lid / @c.us
            const stanzaIds = new Set();
            for (const cand of candidates) {
                if (typeof cand !== 'string') continue;
                const parts = cand.split('_');
                for (const part of parts) {
                    if (part.length >= 8 && !part.includes('@') && !['true', 'false', 'fallback'].includes(part.toLowerCase())) {
                        stanzaIds.add(part);
                    }
                }
            }

            const stanzaList = Array.from(stanzaIds);
            if (stanzaList.length === 0) {
                return resolve(null);
            }

            const likeClauses = stanzaList.map(() => 'msgId LIKE ?').join(' OR ');
            const likeParams = stanzaList.map(s => `%${s}%`);

            db.get(`SELECT * FROM orders WHERE ${likeClauses}`, likeParams, (likeErr, likeRow) => {
                if (likeErr) return reject(likeErr);
                resolve(likeRow || null);
            });
        });
    });
}


/**
 * Elimina un ordine tramite il msgId di WhatsApp.
 */
function deleteOrderByMsgId(msgId) {
    if (!msgId) return Promise.resolve();
    return new Promise((resolve, reject) => {
        db.run('DELETE FROM orders WHERE msgId = ?', [msgId], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

function formatBytes(bytes) {
    if (!bytes || bytes <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

/**
 * Calcola le statistiche generali e avanzate degli ordini memorizzati nel database.
 * Supporta filtri per periodo (all, today, yesterday, week, month, custom) e intervallo date.
 */
function getStatistics(filters = {}) {
    return new Promise((resolve, reject) => {
        db.all('SELECT stato, cliente, telefono, data, file, tipo FROM orders', [], (err, rows) => {
            if (err) return reject(err);
            rows = rows || [];
            
            const now = new Date();
            const todayStr = now.toISOString().split('T')[0];
            const yesterdayDate = new Date(now);
            yesterdayDate.setDate(yesterdayDate.getDate() - 1);
            const yesterdayStr = yesterdayDate.toISOString().split('T')[0];
            const thisMonthPrefix = todayStr.substring(0, 7); // YYYY-MM
            
            const weekStartDate = new Date(now);
            weekStartDate.setDate(weekStartDate.getDate() - 6);
            weekStartDate.setHours(0, 0, 0, 0);
            
            const period = filters.period || 'all';
            const customFrom = filters.from ? String(filters.from).trim() : null;
            const customTo = filters.to ? String(filters.to).trim() : null;

            // Filtro righe per periodo
            const filteredRows = rows.filter(r => {
                if (!r.data) return period === 'all';
                const orderDate = new Date(r.data);
                if (isNaN(orderDate.getTime())) return period === 'all';
                const isoDate = orderDate.toISOString().split('T')[0];

                if (period === 'today') {
                    return isoDate === todayStr;
                } else if (period === 'yesterday') {
                    return isoDate === yesterdayStr;
                } else if (period === 'week') {
                    return orderDate >= weekStartDate;
                } else if (period === 'month') {
                    return isoDate.startsWith(thisMonthPrefix);
                } else if (period === 'custom') {
                    if (customFrom && customTo) {
                        return isoDate >= customFrom && isoDate <= customTo;
                    } else if (customFrom) {
                        return isoDate >= customFrom;
                    } else if (customTo) {
                        return isoDate <= customTo;
                    }
                    return true;
                }
                return true;
            });

            const uniquePhones = new Set();
            const clientStatsMap = new Map();
            let totalBytes = 0;

            const stats = {
                filterPeriod: period,
                filterFrom: customFrom,
                filterTo: customTo,
                totalOrders: filteredRows.length,
                allTimeOrders: rows.length,
                printedOrders: 0,
                pendingOrders: 0,
                archivedOrders: 0,
                whatsappOrders: 0,
                telegramOrders: 0,
                emailOrders: 0,
                webOrders: 0,
                todayOrders: 0,
                thisMonthOrders: 0,
                uniqueContacts: 0,
                filesCount: 0,
                pdfCount: 0,
                imagesCount: 0,
                docsCount: 0,
                notesCount: 0,
                audioCount: 0,
                totalBytes: 0,
                totalSizeFormatted: '0 B',
                peakHour: 'N/D',
                peakDay: 'N/D',
                hourlyDistribution: new Array(24).fill(0),
                dailyDistribution: { 'Lun': 0, 'Mar': 0, 'Mer': 0, 'Gio': 0, 'Ven': 0, 'Sab': 0, 'Dom': 0 },
                recentDailyTrend: [],
                topClients: []
            };

            // Ordini di oggi e mese corrente globali (per confronto)
            rows.forEach(r => {
                if (r.data) {
                    const isoDate = String(r.data).split('T')[0];
                    if (isoDate === todayStr) stats.todayOrders++;
                    if (isoDate.startsWith(thisMonthPrefix)) stats.thisMonthOrders++;
                }
            });

            // Mappa trend ultimi 7 giorni
            const last7DaysMap = {};
            for (let i = 6; i >= 0; i--) {
                const d = new Date(now);
                d.setDate(d.getDate() - i);
                const isoKey = d.toISOString().split('T')[0];
                const dayLabel = `${d.getDate().toString().padStart(2, '0')}/${(d.getMonth() + 1).toString().padStart(2, '0')}`;
                last7DaysMap[isoKey] = { dateIso: isoKey, label: dayLabel, total: 0, printed: 0 };
            }

            const dayNamesIt = ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'];

            filteredRows.forEach(r => {
                const phone = r.telefono || 'unknown';
                uniquePhones.add(phone);

                if (r.stato === 'stampato') stats.printedOrders++;
                else if (r.stato === 'archiviato') stats.archivedOrders++;
                else stats.pendingOrders++;

                // Tipologia contenuto dettagliata (Inbound)
                let isFile = false;
                if (r.file && r.file.trim().length > 0) {
                    stats.filesCount++;
                    isFile = true;
                    const ext = path.extname(r.file).toLowerCase().replace('.', '');
                    if (['pdf'].includes(ext)) {
                        stats.pdfCount++;
                    } else if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'tiff'].includes(ext)) {
                        stats.imagesCount++;
                    } else if (['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'txt', 'rtf', 'zip', 'rar', '7z'].includes(ext)) {
                        stats.docsCount++;
                    } else if (['ogg', 'mp3', 'wav', 'm4a', 'aac', 'opus'].includes(ext) || r.tipo === 'audio') {
                        stats.audioCount++;
                    } else {
                        stats.docsCount++;
                    }

                    // Calcolo dimensione fisica su disco
                    try {
                        const fullPath = path.join(PRINT_FOLDER, r.file);
                        if (fs.existsSync(fullPath)) {
                            const stat = fs.statSync(fullPath);
                            totalBytes += stat.size;
                        }
                    } catch (e) {}
                } else if (r.tipo === 'audio') {
                    stats.audioCount++;
                } else {
                    stats.notesCount++;
                }

                // Canali di ricezione (incluso Web Bancone)
                let channelName = 'WhatsApp';
                if ((r.telefono && r.telefono.startsWith('web_')) || r.tipo === 'web') {
                    stats.webOrders++;
                    channelName = 'Web Bancone';
                } else if (r.telefono && r.telefono.includes('@')) {
                    stats.emailOrders++;
                    channelName = 'Email';
                } else if (r.telefono && r.telefono.startsWith('tg_')) {
                    stats.telegramOrders++;
                    channelName = 'Telegram';
                } else {
                    stats.whatsappOrders++;
                    channelName = 'WhatsApp';
                }

                // Aggregazione per Top Clienti
                const clientKey = phone;
                if (!clientStatsMap.has(clientKey)) {
                    clientStatsMap.set(clientKey, {
                        cliente: r.cliente || phone,
                        telefono: phone,
                        name: r.cliente || phone,
                        phone: phone,
                        count: 0,
                        ordersCount: 0,
                        printed: 0,
                        files: 0,
                        channel: channelName
                    });
                }
                const cStat = clientStatsMap.get(clientKey);
                cStat.count++;
                cStat.ordersCount = cStat.count;
                if (r.stato === 'stampato') cStat.printed++;
                if (isFile) cStat.files++;
                if (r.cliente && (cStat.cliente === phone || !cStat.cliente)) {
                    cStat.cliente = r.cliente;
                    cStat.name = r.cliente;
                }

                // Data e orari
                if (r.data) {
                    const orderDate = new Date(r.data);
                    if (!isNaN(orderDate.getTime())) {
                        const isoDate = orderDate.toISOString().split('T')[0];

                        const hour = orderDate.getHours();
                        if (hour >= 0 && hour < 24) {
                            stats.hourlyDistribution[hour]++;
                        }

                        const dayIdx = orderDate.getDay();
                        const dayName = dayNamesIt[dayIdx];
                        if (stats.dailyDistribution[dayName] !== undefined) {
                            stats.dailyDistribution[dayName]++;
                        }

                        if (last7DaysMap[isoDate]) {
                            last7DaysMap[isoDate].total++;
                            if (r.stato === 'stampato') {
                                last7DaysMap[isoDate].printed++;
                            }
                        }
                    }
                }
            });

            stats.uniqueContacts = uniquePhones.size;
            stats.totalBytes = totalBytes;
            stats.totalSizeFormatted = formatBytes(totalBytes);
            stats.recentDailyTrend = Object.values(last7DaysMap);

            // Calcola Ora di Punta
            let maxHourCount = -1;
            let peakHourIdx = -1;
            stats.hourlyDistribution.forEach((cnt, h) => {
                if (cnt > maxHourCount && cnt > 0) {
                    maxHourCount = cnt;
                    peakHourIdx = h;
                }
            });
            if (peakHourIdx !== -1) {
                const nextH = (peakHourIdx + 1) % 24;
                const formatH = (h) => h.toString().padStart(2, '0') + ':00';
                stats.peakHour = `${formatH(peakHourIdx)} - ${formatH(nextH)} (${maxHourCount} ordini)`;
            }

            // Calcola Giorno di Maggior Affluenza
            const dayFullNames = {
                'Lun': 'Lunedì',
                'Mar': 'Martedì',
                'Mer': 'Mercoledì',
                'Gio': 'Giovedì',
                'Ven': 'Venerdì',
                'Sab': 'Sabato',
                'Dom': 'Domenica'
            };
            let maxDayCount = -1;
            let peakDayKey = '';
            Object.entries(stats.dailyDistribution).forEach(([dKey, cnt]) => {
                if (cnt > maxDayCount && cnt > 0) {
                    maxDayCount = cnt;
                    peakDayKey = dKey;
                }
            });
            if (peakDayKey) {
                stats.peakDay = `${dayFullNames[peakDayKey]} (${maxDayCount} ordini)`;
            }

            // Top 5 Clienti del periodo
            stats.topClients = Array.from(clientStatsMap.values())
                .filter(c => (c.count || c.ordersCount) > 0)
                .sort((a, b) => (b.count || b.ordersCount) - (a.count || a.ordersCount))
                .slice(0, 5);

            resolve(stats);
        });
    });
}

/**
 * Azzera le statistiche della giornata archiviando tutti gli ordini ricevuti oggi.
 */
function resetTodayStatistics() {
    return new Promise((resolve, reject) => {
        const todayStr = new Date().toISOString().split('T')[0];
        db.run(`
            UPDATE orders 
            SET stato = 'archiviato' 
            WHERE data LIKE ? AND stato != 'archiviato'
        `, [`${todayStr}%`], function(err) {
            if (err) return reject(err);
            resolve({ updatedRows: this.changes });
        });
    });
}

/**
 * Azzera l'intero storico ordini archiviando tutti gli ordini non ancora archiviati.
 */
function resetAllStatistics() {
    return new Promise((resolve, reject) => {
        db.run(`
            UPDATE orders 
            SET stato = 'archiviato' 
            WHERE stato != 'archiviato'
        `, [], function(err) {
            if (err) return reject(err);
            resolve({ updatedRows: this.changes });
        });
    });
}

/**
 * Auto-archivia gli ordini già stampati/evasi delle giornate precedenti,
 * mantenendo la lista della dashboard pulita all'avvio.
 */
function archivePastPrintedOrders() {
    return new Promise((resolve, reject) => {
        const startOfTodayIso = new Date(new Date().setHours(0, 0, 0, 0)).toISOString();
        db.run(
            "UPDATE orders SET stato = 'archiviato' WHERE stato = 'stampato' AND data < ?",
            [startOfTodayIso],
            function(err) {
                if (err) return reject(err);
                resolve(this.changes || 0);
            }
        );
    });
}

module.exports = {
    initDb,
    getOrders,
    getOrderById,
    getOrdersByIds,
    getOrderByMsgId,
    saveOrder,
    orderExists,
    getProcessedMessageIds,
    getOrdersByPhoneAndHasFile,
    updateContactOrdersFolder,
    markOrderPrinted,
    markContactOrdersPrinted,
    deleteOrderById,
    deleteOrdersByIds,
    deleteOrderByMsgId,
    deleteAllOrders,
    getOrdersByPhone,
    deleteOrdersByPhone,
    getOrdersByContact,
    deleteOrdersByContact,
    archiveOrder,
    archiveOrders,
    archivePastPrintedOrders,
    getStatistics,
    resetTodayStatistics,
    resetAllStatistics
};


