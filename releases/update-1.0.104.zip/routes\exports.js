const express = require('express');
const router = express.Router();

const db = require('../db');
const { getExportableContacts } = require('../modules/whatsappClient');

function init({ logger } = {}) {
    const _logger = logger || console;

    // GET /api/contacts/export/csv - Esportazione contatti in formato CSV
    router.get('/api/contacts/export/csv', async (req, res) => {
        try {
            const contacts = await getExportableContacts();
            let csvContent = '\uFEFF'; // UTF-8 BOM per Excel
            csvContent += 'Nome;Canale;Telefono;Email;Totale Ordini;Ultimo Ordine\n';

            contacts.forEach(c => {
                let rawName = (c.name || '').replace(/;/g, ',').trim();
                let rawPhone = (c.phone || '').trim();
                let channel = 'WhatsApp';
                let email = '';
                let phone = '';

                // Riconoscimento intelligente del canale e separazione Telefono/Email
                if (rawPhone.includes('@') || rawName.includes('(Email)')) {
                    channel = 'Email';
                    email = rawPhone.replace(/;/g, '');
                    rawName = rawName.replace(/\s*\(Email\)\s*/gi, '').trim();
                } else if (rawPhone.startsWith('tg_') || rawName.includes('(Telegram)')) {
                    channel = 'Telegram';
                    phone = rawPhone.replace(/^tg_/, '');
                    rawName = rawName.replace(/\s*\(Telegram\)\s*/gi, '').trim();
                } else if (rawPhone.startsWith('web_') || rawName.includes('(Web Bancone)')) {
                    channel = 'Web Bancone';
                    phone = '';
                    rawName = rawName.replace(/\s*\(Web Bancone\)\s*/gi, '').trim();
                } else {
                    channel = 'WhatsApp';
                    phone = rawPhone.replace(/@c\.us|@lid/g, '');
                }

                // Protezione contro la notazione scientifica di Excel (es. 1,20E+14)
                // Usando la sintassi formula ="VALORE", Excel tratta la cella come testo esatto senza alterare le cifre
                let excelPhone = '""';
                if (phone) {
                    const digits = phone.replace(/[^0-9]/g, '');
                    if (digits.startsWith('39') && digits.length >= 12 && digits.length <= 13) {
                        // Numero italiano con prefisso 39: visualizzazione leggibile
                        excelPhone = `="+39 ${digits.slice(2)}"`;
                    } else if (digits.length >= 8) {
                        // Numero lungo o identificativo LID: forza formato testo esatto
                        excelPhone = `="${phone}"`;
                    } else {
                        excelPhone = `="${phone}"`;
                    }
                }

                const excelEmail = email ? `"${email}"` : '""';
                const safeName = rawName || phone || email || 'Cliente';
                const count = c.orderCount || 0;
                const lastDate = c.lastOrder ? new Date(c.lastOrder).toLocaleString('it-IT') : 'N/D';

                csvContent += `"${safeName}";"${channel}";${excelPhone};${excelEmail};${count};"${lastDate}"\n`;
            });

            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', 'attachment; filename="rubrica_printzap.csv"');
            res.status(200).send(csvContent);
        } catch (err) {
            _logger.error('Errore export CSV:', err);
            res.status(500).json({ error: 'Errore durante la generazione del file CSV' });
        }
    });

    // GET /api/contacts/export/vcf - Esportazione contatti in formato VCF (vCard)
    router.get('/api/contacts/export/vcf', async (req, res) => {
        try {
            const contacts = await getExportableContacts();
            let vcfContent = '';

            contacts.forEach(c => {
                let phone = (c.phone || '').replace(/[^0-9+]/g, '');
                if (!phone) return;
                if (!phone.startsWith('+') && !phone.startsWith('00')) {
                    if (phone.startsWith('39') && phone.length >= 10) {
                        phone = '+' + phone;
                    } else if (phone.length === 10) {
                        phone = '+39' + phone;
                    }
                }

                const name = c.name || phone;

                vcfContent += 'BEGIN:VCARD\r\n';
                vcfContent += 'VERSION:3.0\r\n';
                vcfContent += `FN:${name}\r\n`;
                vcfContent += `TEL;TYPE=CELL:${phone}\r\n`;
                vcfContent += 'END:VCARD\r\n';
            });

            res.setHeader('Content-Type', 'text/vcard; charset=utf-8');
            res.setHeader('Content-Disposition', 'attachment; filename="rubrica_printzap.vcf"');
            res.status(200).send(vcfContent);
        } catch (err) {
            _logger.error('Errore export VCF:', err);
            res.status(500).json({ error: 'Errore durante la generazione del file VCF' });
        }
    });

    // GET /api/reports/export - Generazione Report CSV degli ordini
    router.get('/api/reports/export', async (req, res) => {
        try {
            const orders = await db.getOrders();
            let csv = '\uFEFF'; // UTF-8 BOM per Excel
            csv += 'ID Ordine;Data;Ora;Cliente;Canale;Telefono / Identificativo;Tipo Documento;File;Stato;Dettagli / Messaggio\n';

            for (const ord of orders) {
                const dateObj = new Date(ord.data);
                const dataFormatted = !isNaN(dateObj) ? dateObj.toLocaleDateString('it-IT') : '';
                const oraFormatted = !isNaN(dateObj) ? dateObj.toLocaleTimeString('it-IT') : '';
                const channel = (ord.telefono || '').startsWith('tg_') ? 'Telegram' :
                                (ord.telefono || '').startsWith('web_') ? 'Web Bancone' :
                                (ord.id || '').startsWith('email_') ? 'Email' : 'WhatsApp';

                const cleanMessage = (ord.messaggio || '').replace(/[\r\n]+/g, ' | ').replace(/;/g, ',');
                const rawTel = (ord.telefono || '').replace(/@c\.us|@lid/g, '');
                let excelTel = `"${rawTel}"`;
                if (/^\d{8,}$/.test(rawTel)) {
                    excelTel = `="${rawTel}"`;
                }

                const excelId = `="${ord.id}"`;
                csv += `${excelId};"${dataFormatted}";"${oraFormatted}";"${ord.cliente}";"${channel}";${excelTel};"${ord.tipo}";"${ord.file}";"${ord.stato}";"${cleanMessage}"\n`;
            }

            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="report_ordini_printzap_${Date.now()}.csv"`);
            res.send(csv);
        } catch (err) {
            _logger.error('❌ Errore durante esportazione report CSV:', err);
            res.status(500).json({ error: 'Impossibile esportare il report: ' + err.message });
        }
    });

    return router;
}

module.exports = { init };
