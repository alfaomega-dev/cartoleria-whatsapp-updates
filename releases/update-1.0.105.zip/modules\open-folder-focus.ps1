param(
    [string]$TargetFolder,
    [switch]$Maximize
)

if (-not $TargetFolder -or -not (Test-Path -LiteralPath $TargetFolder)) { exit }

Add-Type @'
using System;
using System.Runtime.InteropServices;
public class WinApi {
    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")]
    public static extern void SwitchToThisWindow(IntPtr hWnd, bool fUnknown);
    [DllImport("user32.dll")]
    public static extern bool BringWindowToTop(IntPtr hWnd);
    [DllImport("user32.dll")]
    public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);
}
'@

function BringHwndToFront([IntPtr]$hwnd, [bool]$max) {
    if ($hwnd -ne [IntPtr]::Zero) {
        # Tap tasto ALT virtuale per azzerare il ForegroundLockTimeout di Windows
        [WinApi]::keybd_event(0x12, 0, 0, 0)
        [WinApi]::keybd_event(0x12, 0, 2, 0)
        $nCmd = if ($max) { 3 } else { 9 } # 3 = SW_MAXIMIZE, 9 = SW_RESTORE
        [void][WinApi]::ShowWindow($hwnd, $nCmd)
        [void][WinApi]::BringWindowToTop($hwnd)
        [void][WinApi]::SwitchToThisWindow($hwnd, $true)
        [void][WinApi]::SetForegroundWindow($hwnd)
    }
}

$resolved = (Resolve-Path -LiteralPath $TargetFolder).Path
$targetUrl = ([System.Uri]$resolved).AbsoluteUri.TrimEnd('/').ToLower()
$shell = New-Object -ComObject Shell.Application
$targetHwnd = [IntPtr]::Zero

# 1. Controlla se la finestra di Explorer per questa cartella è già aperta
foreach ($w in $shell.Windows()) {
    try {
        if ($w.LocationURL) {
            $wUrl = ([System.Uri]$w.LocationURL).AbsoluteUri.TrimEnd('/').ToLower()
            if ($wUrl -eq $targetUrl) {
                $targetHwnd = [IntPtr]$w.HWND
                break
            }
        }
    } catch {}
}

if ($targetHwnd -ne [IntPtr]::Zero) {
    # Già aperta: sblocca e porta immediatamente in primo piano e massimizzata
    BringHwndToFront $targetHwnd $Maximize.IsPresent
    exit
}

# 2. Non è ancora aperta: avvia explorer
Start-Process explorer.exe -ArgumentList "`"$resolved`""

# 3. Attendi la comparsa della nuova finestra e portala subito in primo piano
for ($i = 0; $i -lt 15; $i++) {
    Start-Sleep -Milliseconds 100
    foreach ($w in $shell.Windows()) {
        try {
            if ($w.LocationURL) {
                $wUrl = ([System.Uri]$w.LocationURL).AbsoluteUri.TrimEnd('/').ToLower()
                if ($wUrl -eq $targetUrl) {
                    $targetHwnd = [IntPtr]$w.HWND
                    BringHwndToFront $targetHwnd $Maximize.IsPresent
                    exit
                }
            }
        } catch {}
    }
}
