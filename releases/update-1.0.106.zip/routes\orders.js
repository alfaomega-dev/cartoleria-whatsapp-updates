const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { exec, spawn } = require('child_process');

const db = require('../db');
const { ROOT_DIR, DATA_DIR, PRINT_FOLDER } = require('../modules/paths');
const { getConfig, sanitizeClientFolder } = require('../modules/config');
const { deleteFileWithCleanup, deleteFilesWithCleanup, repairMismatchedFolders } = require('../modules/helpers');
const { sendEmailNotification } = require('../modules/email');
const { sendTelegramNotification } = require('../modules/telegram');
const {
    syncContactNames,
    redownloadOrderMedia,
    sendWhatsAppNotification,
    syncUnreadMessages
} = require('../modules/whatsappClient');

function init({ logger } = {}) {
    const _logger = logger || console;

    // GET /api/orders - Recupero lista ordini (con sync opzionale)
    router.get('/api/orders', async (req, res) => {
        try {
            if (req.query.sync === 'true') {
                await Promise.allSettled([
                    syncContactNames(true),
                    syncUnreadMessages()
                ]);
            }
            const orders = await db.getOrders(200);
            res.json(orders);
        } catch (error) {
            _logger.error('Errore recupero ordini:', error);
            res.status(500).json({ error: 'Errore interno del database' });
        }
    });

    // POST /api/orders/sync - Forzatura immediata sincronizzazione messaggi WhatsApp
    router.post('/api/orders/sync', async (req, res) => {
        try {
            await syncUnreadMessages();
            const orders = await db.getOrders(200);
            res.json({ success: true, count: orders.length });
        } catch (error) {
            _logger.error('Errore forzatura sync:', error);
            res.status(500).json({ error: 'Errore durante sincronizzazione: ' + error.message });
        }
    });

    // POST /api/orders/:id/print - Contrassegna singolo ordine come stampato
    router.post('/api/orders/:id/print', async (req, res) => {
        const { id } = req.params;
        try {
            await db.markOrderPrinted(id);
            res.json({ success: true });
        } catch (error) {
            _logger.error(`Errore print ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno del database' });
        }
    });

    // POST /api/orders/bulk/print - Contrassegna più ordini come stampati
    router.post('/api/orders/bulk/print', async (req, res) => {
        const { ids } = req.body;
        if (!Array.isArray(ids)) return res.status(400).json({ error: 'IDs must be an array' });
        try {
            for (const id of ids) {
                await db.markOrderPrinted(id);
            }
            res.json({ success: true });
        } catch (error) {
            _logger.error('Errore print bulk:', error);
            res.status(500).json({ error: 'Errore interno del database' });
        }
    });

    // POST /api/notes - Creazione rapida nota manuale
    router.post('/api/notes', async (req, res) => {
        const { cliente, telefono, messaggio } = req.body;
        if (!cliente || !messaggio) return res.status(400).json({ error: 'Missing client or message' });
        try {
            const orderData = {
                id: 'note_' + Date.now(),
                cliente: cliente.trim(),
                telefono: telefono || '',
                file: '',
                data: new Date().toISOString(),
                stato: 'ricevuto',
                tipo: 'nota',
                messaggio: messaggio.trim()
            };
            await db.saveOrder(orderData);
            res.json({ success: true, order: orderData });
        } catch (error) {
            _logger.error('Errore creazione nota manuale:', error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // POST /api/orders/:id/retry-download - Nuovo tentativo di download allegato
    router.post('/api/orders/:id/retry-download', async (req, res) => {
        const { id } = req.params;
        try {
            const order = await db.getOrderById(id);
            if (!order) {
                return res.status(404).json({ error: 'Ordine non trovato' });
            }

            if (order.file && fs.existsSync(path.join(PRINT_FOLDER, order.file))) {
                return res.json({ success: true, order, message: 'File già presente' });
            }

            const result = await redownloadOrderMedia(order);
            return res.json(result);
        } catch (error) {
            _logger.error(`❌ Errore in retry-download per ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno durante il recupero: ' + error.message });
        }
    });

    // Helper garantito per aprire qualsiasi cartella in Esplora Risorse in primo piano e massimizzata
    const openFolderInForeground = (folderPath, maximize = true) => {
        try {
            const resolvedPath = path.resolve(folderPath);

            // Garantisce che la cartella esista fisicamente su disco prima di aprirla
            if (!fs.existsSync(resolvedPath)) {
                fs.mkdirSync(resolvedPath, { recursive: true });
            }

            // 1. Apertura immediata e nativa con comando Win32 start /max explorer
            const maxFlag = maximize ? '/max ' : '';
            exec(`start "" ${maxFlag}explorer.exe "${resolvedPath}"`, (err) => {
                if (err) {
                    exec(`explorer "${resolvedPath}"`);
                }
            });

            // 2. Forza il primo piano bypassando il focus lock di Windows
            const folderLeaf = path.basename(resolvedPath);
            const focusCmd = `powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; Start-Sleep -Milliseconds 300; $ws.SendKeys('%'); $ws.AppActivate('${folderLeaf.replace(/'/g, "''")}');"`;
            exec(focusCmd);
        } catch (err) {
            _logger.error('Errore durante apertura cartella:', err);
            // Fallback estremo di emergenza
            try { exec(`explorer "${path.resolve(folderPath)}"`); } catch (_) {}
        }
    };

    // POST /api/orders/open-print-folder - Apertura cartella principale file_da_stampare in primo piano
    router.post('/api/orders/open-print-folder', (req, res) => {
        try {
            _logger.info(`📂 Apertura cartella principale stampe in primo piano: ${PRINT_FOLDER}`);
            openFolderInForeground(PRINT_FOLDER, true);
            res.json({ success: true, folder: PRINT_FOLDER });
        } catch (error) {
            _logger.error('Errore apertura cartella principale file_da_stampare:', error);
            res.status(500).json({ error: 'Errore apertura cartella principale' });
        }
    });

    // POST /api/orders/:id/open-folder - Apertura cartella ordine in Esplora Risorse in primo piano
    router.post('/api/orders/:id/open-folder', async (req, res) => {
        const { id } = req.params;
        const { telefono, cliente } = req.body || {};
        try {
            let targetFolder = PRINT_FOLDER;
            if (id && id !== 'contact' && id !== 'root') {
                const order = await db.getOrderById(id);
                if (order && order.file) {
                    const possibleFolder = path.join(PRINT_FOLDER, path.dirname(order.file));
                    if (fs.existsSync(possibleFolder)) {
                        targetFolder = possibleFolder;
                    } else if (order.telefono && fs.existsSync(path.join(PRINT_FOLDER, order.telefono))) {
                        targetFolder = path.join(PRINT_FOLDER, order.telefono);
                    }
                }
            }

            if (targetFolder === PRINT_FOLDER && (cliente || telefono)) {
                const clientFolder = sanitizeClientFolder(cliente || telefono, telefono || cliente);
                const possibleClientFolder = path.join(PRINT_FOLDER, clientFolder);
                if (fs.existsSync(possibleClientFolder)) {
                    targetFolder = possibleClientFolder;
                } else if (telefono && fs.existsSync(path.join(PRINT_FOLDER, telefono))) {
                    targetFolder = path.join(PRINT_FOLDER, telefono);
                }
            }

            const resolvedPath = path.resolve(targetFolder);
            _logger.info(`📂 Apertura cartella Explorer in primo piano: ${resolvedPath} (ID: ${id})`);

            openFolderInForeground(resolvedPath, true);
            res.json({ success: true, folder: resolvedPath });
        } catch (error) {
            _logger.error(`Errore open-folder ID ${id}:`, error);
            res.status(500).json({ error: 'Errore durante l\'apertura della cartella' });
        }
    });

    // POST /api/orders/:id/open-file - Apertura file associato all'ordine
    router.post('/api/orders/:id/open-file', async (req, res) => {
        const { id } = req.params;
        try {
            const order = await db.getOrderById(id);
            if (order && order.file) {
                let filePath = path.join(PRINT_FOLDER, order.file);

                if (!fs.existsSync(filePath)) {
                    await repairMismatchedFolders();
                    filePath = path.join(PRINT_FOLDER, order.file);
                }

                if (!fs.existsSync(filePath) && order.telefono) {
                    const altPath = path.join(PRINT_FOLDER, order.telefono, path.basename(order.file));
                    if (fs.existsSync(altPath)) {
                        filePath = altPath;
                    }
                }

                if (fs.existsSync(filePath)) {
                    const resolvedPath = path.resolve(filePath);
                    _logger.info(`📄 Apertura file: ${resolvedPath} (Ordine ID: ${id})`);

                    exec(`start "" "${resolvedPath}"`, (err) => {
                        if (err) {
                            exec(`explorer /select,"${resolvedPath}"`);
                        }
                    });
                    return res.json({ success: true });
                } else {
                    _logger.warn(`⚠️ File non trovato sul disco per ordine ${id}: ${filePath}`);
                    return res.status(404).json({ error: 'File non trovato sul disco' });
                }
            } else {
                _logger.warn(`⚠️ Ordine non trovato o privo di file per ID ${id}`);
                return res.status(404).json({ error: 'Ordine non trovato' });
            }
        } catch (error) {
            _logger.error(`Errore open-file ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // POST /api/orders/:id/notify - Invia notifica di pronto al cliente (WhatsApp, Telegram o Email)
    router.post('/api/orders/:id/notify', async (req, res) => {
        const { id } = req.params;
        const { message: customMessage } = req.body;
        const config = getConfig();

        try {
            const order = await db.getOrderById(id);
            if (order) {
                const message = customMessage || config.notifyMessage || `✅ *Stampa Pronta!* 🖨️\nIl tuo documento è pronto per il ritiro.`;

                // Se è un ordine Telegram
                if (order.telefono && order.telefono.startsWith('tg_')) {
                    try {
                        const chatId = order.telefono.replace('tg_', '');
                        await sendTelegramNotification({ chatId, message });
                        await db.markContactOrdersPrinted(order.telefono);
                        return res.json({ success: true });
                    } catch (tgError) {
                        _logger.error('❌ Errore durante l\'invio del messaggio Telegram:', tgError);
                        return res.status(500).json({ error: 'Impossibile inviare la notifica Telegram: ' + (tgError.response?.data?.description || tgError.message) });
                    }
                }

                // Se è un ordine Email
                if (order.telefono && order.telefono.includes('@')) {
                    if (!config.emailEnabled) {
                        return res.status(400).json({ error: 'Configurazione E-mail non abilitata.' });
                    }

                    // Trova l'account e-mail corretto che ha ricevuto l'ordine
                    let activeAccount = null;
                    if (order.msgId && order.msgId.startsWith('email_')) {
                        const parts = order.msgId.split('_');
                        if (parts.length >= 3) {
                            const accountUser = parts[1];
                            activeAccount = config.emailAccounts.find(acc => acc.emailUser === accountUser);
                        }
                    }

                    // Fallback al primo account e-mail disponibile
                    if (!activeAccount && config.emailAccounts && config.emailAccounts.length > 0) {
                        activeAccount = config.emailAccounts[0];
                    }

                    try {
                        await sendEmailNotification({ to: order.telefono, message, activeAccount });
                        await db.markContactOrdersPrinted(order.telefono);
                        return res.json({ success: true });
                    } catch (emailError) {
                        _logger.error('❌ Errore durante l\'invio dell\'email:', emailError);
                        return res.status(500).json({ error: 'Impossibile inviare la notifica e-mail: ' + emailError.message });
                    }
                }

                // Se è un ordine Web Bancone
                if ((order.telefono && order.telefono.startsWith('web_')) || order.tipo === 'web') {
                    await db.markContactOrdersPrinted(order.telefono);
                    return res.json({ success: true, message: 'Notifica completata: ordine Web Bancone segnato come stampato' });
                }

                // Invio classico via WhatsApp
                try {
                    await sendWhatsAppNotification({ order, message });
                    const phoneCandidates = [order.telefono];
                    if (order.telefono) {
                        const digits = String(order.telefono).replace(/[^0-9]/g, '');
                        if (digits && !phoneCandidates.includes(digits)) phoneCandidates.push(digits);
                    }
                    await db.markOrderPrinted(order.id);
                    await db.markContactOrdersPrinted(phoneCandidates);
                    res.json({ success: true });
                } catch (error) {
                    _logger.error('Errore invio notifica WhatsApp:', error);
                    res.status(500).json({ error: 'Impossibile inviare il messaggio WhatsApp: ' + error.message });
                }
            } else {
                res.status(404).json({ error: 'Ordine non trovato' });
            }
        } catch (error) {
            _logger.error(`Errore notify ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // DELETE /api/orders/bulk - Archiviazione ordini multipli
    router.delete('/api/orders/bulk', async (req, res) => {
        const { ids } = req.body;
        if (!Array.isArray(ids)) return res.status(400).json({ error: 'IDs must be an array' });

        try {
            const orders = await db.getOrdersByIds(ids);
            const filesToDelete = orders.map(o => o.file).filter(Boolean);
            try {
                deleteFilesWithCleanup(filesToDelete);
            } catch (fileErr) {
                _logger.warn('Avviso rimozione file durante bulk delete:', fileErr.message);
            }
            await db.archiveOrders(ids);
            res.json({ success: true, archived: ids.length });
        } catch (error) {
            _logger.error('Errore archiviazione bulk:', error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // DELETE /api/orders - Svuotamento ordini (con filtro opzionale canale)
    router.delete('/api/orders', async (req, res) => {
        try {
            const channel = req.query.channel;
            let orders = await db.getOrders(999999);

            if (channel === 'email') {
                orders = orders.filter(o => o.telefono && o.telefono.includes('@'));
            } else if (channel === 'telegram') {
                orders = orders.filter(o => o.telefono && o.telefono.startsWith('tg_'));
            } else if (channel === 'whatsapp') {
                orders = orders.filter(o => o.telefono && !o.telefono.includes('@') && !o.telefono.startsWith('tg_'));
            }

            const filesToDelete = orders.map(o => o.file).filter(Boolean);
            try {
                deleteFilesWithCleanup(filesToDelete);
            } catch (fileErr) {
                _logger.warn('Avviso rimozione file durante deleteAll:', fileErr.message);
            }

            if (channel) {
                const ids = orders.map(o => o.id);
                await db.archiveOrders(ids);
            } else {
                await db.deleteAllOrders();
            }

            res.json({ success: true, deleted: orders.length });
        } catch (error) {
            _logger.error('Errore svuotamento ordini:', error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // DELETE /api/orders/:id - Archiviazione singolo ordine
    router.delete('/api/orders/:id', async (req, res) => {
        const { id } = req.params;
        try {
            const orderToDelete = await db.getOrderById(id);

            if (orderToDelete) {
                if (orderToDelete.file) {
                    try {
                        deleteFileWithCleanup(orderToDelete.file);
                    } catch (fileErr) {
                        _logger.warn(`Avviso rimozione file ordine ${id}:`, fileErr.message);
                    }
                }
                await db.archiveOrder(id);
                res.json({ success: true });
            } else {
                res.status(404).json({ error: 'Ordine non trovato' });
            }
        } catch (error) {
            _logger.error(`Errore archiviazione ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // Static files handler per /api/file
    router.use('/api/file', express.static(PRINT_FOLDER));

    return router;
}

module.exports = { init };
