const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

let db = null;

/**
 * Inizializza il database SQLite e crea le tabelle necessarie.
 * @param {string} dbPath - Il percorso assoluto del file database SQLite.
 */
function initDb(dbPath) {
    return new Promise((resolve, reject) => {
        db = new sqlite3.Database(dbPath, (err) => {
            if (err) {
                return reject(new Error(`Impossibile connettersi a SQLite: ${err.message}`));
            }
            
            // Controlla lo schema esistente della tabella orders
            db.all("PRAGMA table_info(orders)", [], (err, rows) => {
                if (err) return reject(err);
                
                const tableExists = rows && rows.length > 0;
                const needsMigration = tableExists && rows.find(r => r.name === 'id' && r.type.toUpperCase() === 'INTEGER');
                
                if (needsMigration) {
                    // Esegui migrazione da INTEGER a TEXT per il campo id per consentire gli ordini email
                    db.serialize(() => {
                        db.run("ALTER TABLE orders RENAME TO orders_old", (err) => {
                            if (err) return reject(err);
                            
                            db.run(`
                                CREATE TABLE orders (
                                    id TEXT PRIMARY KEY,
                                    msgId TEXT UNIQUE,
                                    cliente TEXT,
                                    telefono TEXT,
                                    file TEXT,
                                    tipo TEXT,
                                    messaggio TEXT,
                                    data TEXT,
                                    stato TEXT
                                )
                            `, (err) => {
                                if (err) return reject(err);
                                
                                db.run("INSERT INTO orders SELECT CAST(id AS TEXT), msgId, cliente, telefono, file, tipo, messaggio, data, stato FROM orders_old", (err) => {
                                    if (err) return reject(err);
                                    
                                    db.run("DROP TABLE orders_old", (err) => {
                                        if (err) return reject(err);
                                        createIndexes().then(resolve).catch(reject);
                                    });
                                });
                            });
                        });
                    });
                } else if (!tableExists) {
                    // Crea la tabella da zero con il tipo id TEXT
                    db.run(`
                        CREATE TABLE IF NOT EXISTS orders (
                            id TEXT PRIMARY KEY,
                            msgId TEXT UNIQUE,
                            cliente TEXT,
                            telefono TEXT,
                            file TEXT,
                            tipo TEXT,
                            messaggio TEXT,
                            data TEXT,
                            stato TEXT
                        )
                    `, (err) => {
                        if (err) return reject(err);
                        createIndexes().then(resolve).catch(reject);
                    });
                } else {
                    // La tabella esiste già ed è già migrata a TEXT (o non ha bisogno di modifiche)
                    createIndexes().then(resolve).catch(reject);
                }
            });
        });
    });
}

function createIndexes() {
    return new Promise((resolve, reject) => {
        db.run('CREATE INDEX IF NOT EXISTS idx_orders_telefono ON orders(telefono)', (err) => {
            if (err) return reject(err);
            db.run('CREATE INDEX IF NOT EXISTS idx_orders_msgid ON orders(msgId)', (err) => {
                if (err) return reject(err);
                resolve();
            });
        });
    });
}

/**
 * Ottiene una lista degli ordini ordinati per ID decrescente.
 * @param {number} [limit=200] - Numero massimo di ordini da restituire.
 */
function getOrders(limit = 200) {
    return new Promise((resolve, reject) => {
        db.all('SELECT * FROM orders ORDER BY id DESC LIMIT ?', [limit], (err, rows) => {
            if (err) return reject(err);
            resolve(rows || []);
        });
    });
}

/**
 * Ottiene un ordine tramite ID.
 */
function getOrderById(id) {
    return new Promise((resolve, reject) => {
        db.get('SELECT * FROM orders WHERE id = ?', [id], (err, row) => {
            if (err) return reject(err);
            resolve(row || null);
        });
    });
}

/**
 * Ottiene più ordini tramite un array di ID.
 */
function getOrdersByIds(ids) {
    if (!ids || ids.length === 0) return Promise.resolve([]);
    return new Promise((resolve, reject) => {
        const placeholders = ids.map(() => '?').join(',');
        db.all(`SELECT * FROM orders WHERE id IN (${placeholders})`, ids, (err, rows) => {
            if (err) return reject(err);
            resolve(rows || []);
        });
    });
}

/**
 * Salva o aggiorna un ordine nel database.
 */
function saveOrder(order) {
    return new Promise((resolve, reject) => {
        db.run(`
            INSERT OR REPLACE INTO orders (id, msgId, cliente, telefono, file, tipo, messaggio, data, stato)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            order.id,
            order.msgId || null,
            order.cliente,
            order.telefono,
            order.file || null,
            order.tipo,
            order.messaggio || null,
            order.data,
            order.stato
        ], function(err) {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Verifica se un ordine con un determinato msgId esiste già.
 */
function orderExists(msgId) {
    if (!msgId) return Promise.resolve(false);
    return new Promise((resolve, reject) => {
        db.get('SELECT COUNT(*) as count FROM orders WHERE msgId = ?', [msgId], (err, row) => {
            if (err) return reject(err);
            resolve(row ? row.count > 0 : false);
        });
    });
}

/**
 * Ritorna un Set con tutti i msgId già processati (per la sincronizzazione iniziale).
 */
function getProcessedMessageIds() {
    return new Promise((resolve, reject) => {
        db.all('SELECT msgId FROM orders WHERE msgId IS NOT NULL', (err, rows) => {
            if (err) return reject(err);
            const set = new Set(rows.map(r => r.msgId));
            resolve(set);
        });
    });
}

/**
 * Ritorna tutti gli ordini per un determinato contatto che hanno un file associato.
 */
function getOrdersByPhoneAndHasFile(phone) {
    return new Promise((resolve, reject) => {
        db.all('SELECT * FROM orders WHERE telefono = ? AND file IS NOT NULL', [phone], (err, rows) => {
            if (err) return reject(err);
            resolve(rows || []);
        });
    });
}

/**
 * Aggiorna il nome del cliente e il percorso della cartella file per tutti gli ordini legati a un numero.
 */
function updateContactOrdersFolder(phone, newClientName, newFolder) {
    return new Promise((resolve, reject) => {
        db.all('SELECT id, file FROM orders WHERE telefono = ? AND file IS NOT NULL', [phone], (err, rows) => {
            if (err) return reject(err);
            
            db.serialize(() => {
                db.run('BEGIN TRANSACTION', (beginErr) => {
                    if (beginErr) return reject(beginErr);

                    // 1. Aggiorna nome cliente per tutti gli ordini del contatto (con o senza file)
                    db.run('UPDATE orders SET cliente = ? WHERE telefono = ?', [newClientName, phone], (updateErr) => {
                        if (updateErr) {
                            db.run('ROLLBACK');
                            return reject(updateErr);
                        }

                        // 2. Aggiorna i percorsi relativi dei file
                        if (rows && rows.length > 0) {
                            const stmt = db.prepare('UPDATE orders SET file = ? WHERE id = ?', (prepErr) => {
                                if (prepErr) {
                                    db.run('ROLLBACK');
                                    return reject(prepErr);
                                }

                                let completed = 0;
                                let failed = false;

                                for (const row of rows) {
                                    const fileName = path.basename(row.file);
                                    const newPath = `${newFolder}/${fileName}`;
                                    
                                    stmt.run(newPath, row.id, (runErr) => {
                                        if (failed) return;
                                        if (runErr) {
                                            failed = true;
                                            stmt.finalize();
                                            db.run('ROLLBACK');
                                            return reject(runErr);
                                        }

                                        completed++;
                                        if (completed === rows.length) {
                                            stmt.finalize((finErr) => {
                                                if (finErr) {
                                                    db.run('ROLLBACK');
                                                    return reject(finErr);
                                                }
                                                db.run('COMMIT', (commitErr) => {
                                                    if (commitErr) {
                                                        db.run('ROLLBACK');
                                                        return reject(commitErr);
                                                    }
                                                    resolve();
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        } else {
                            db.run('COMMIT', (commitErr) => {
                                if (commitErr) {
                                    db.run('ROLLBACK');
                                    return reject(commitErr);
                                }
                                resolve();
                            });
                        }
                    });
                });
            });
        });
    });
}

/**
 * Segna come stampato un singolo ordine.
 */
function markOrderPrinted(id) {
    return new Promise((resolve, reject) => {
        db.run("UPDATE orders SET stato = 'stampato' WHERE id = ?", [id], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Segna come stampati tutti gli ordini non stampati per un certo numero di telefono.
 */
function markContactOrdersPrinted(phone) {
    return new Promise((resolve, reject) => {
        db.run("UPDATE orders SET stato = 'stampato' WHERE telefono = ? AND stato != 'stampato'", [phone], function(err) {
            if (err) return reject(err);
            resolve(this.changes > 0); // Ritorna true se ci sono state modifiche
        });
    });
}

/**
 * Elimina un ordine tramite ID.
 */
function deleteOrderById(id) {
    return new Promise((resolve, reject) => {
        db.run('DELETE FROM orders WHERE id = ?', [id], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Elimina più ordini tramite i loro ID.
 */
function deleteOrdersByIds(ids) {
    if (!ids || ids.length === 0) return Promise.resolve();
    return new Promise((resolve, reject) => {
        const placeholders = ids.map(() => '?').join(',');
        db.run(`DELETE FROM orders WHERE id IN (${placeholders})`, ids, (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Svuota completamente la tabella degli ordini.
 */
function deleteAllOrders() {
    return new Promise((resolve, reject) => {
        db.run('DELETE FROM orders', (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Ritorna tutti gli ordini per un determinato contatto.
 */
function getOrdersByPhone(phone) {
    return new Promise((resolve, reject) => {
        db.all('SELECT * FROM orders WHERE telefono = ?', [phone], (err, rows) => {
            if (err) return reject(err);
            resolve(rows || []);
        });
    });
}

/**
 * Elimina tutti gli ordini per un determinato contatto.
 */
function deleteOrdersByPhone(phone) {
    return new Promise((resolve, reject) => {
        db.run('DELETE FROM orders WHERE telefono = ?', [phone], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Imposta lo stato di un ordine a 'archiviato'.
 */
function archiveOrder(id) {
    return new Promise((resolve, reject) => {
        db.run("UPDATE orders SET stato = 'archiviato' WHERE id = ?", [id], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Imposta lo stato di più ordini a 'archiviato'.
 */
function archiveOrders(ids) {
    if (!ids || ids.length === 0) return Promise.resolve();
    return new Promise((resolve, reject) => {
        const placeholders = ids.map(() => '?').join(',');
        db.run(`UPDATE orders SET stato = 'archiviato' WHERE id IN (${placeholders})`, ids, (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

/**
 * Ottiene un ordine tramite il msgId di WhatsApp.
 */
function getOrderByMsgId(msgId) {
    if (!msgId) return Promise.resolve(null);
    return new Promise((resolve, reject) => {
        db.get('SELECT * FROM orders WHERE msgId = ?', [msgId], (err, row) => {
            if (err) return reject(err);
            resolve(row || null);
        });
    });
}

/**
 * Elimina un ordine tramite il msgId di WhatsApp.
 */
function deleteOrderByMsgId(msgId) {
    if (!msgId) return Promise.resolve();
    return new Promise((resolve, reject) => {
        db.run('DELETE FROM orders WHERE msgId = ?', [msgId], (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
}

module.exports = {
    initDb,
    getOrders,
    getOrderById,
    getOrdersByIds,
    getOrderByMsgId,
    saveOrder,
    orderExists,
    getProcessedMessageIds,
    getOrdersByPhoneAndHasFile,
    updateContactOrdersFolder,
    markOrderPrinted,
    markContactOrdersPrinted,
    deleteOrderById,
    deleteOrdersByIds,
    deleteOrderByMsgId,
    deleteAllOrders,
    getOrdersByPhone,
    deleteOrdersByPhone,
    archiveOrder,
    archiveOrders
};
