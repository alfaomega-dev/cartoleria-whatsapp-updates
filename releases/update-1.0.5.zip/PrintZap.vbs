Set WshShell = CreateObject("WScript.Shell")
' Chiudi eventuali vecchi processi in esecuzione per evitare conflitti
WshShell.Run "taskkill /F /IM mshta.exe", 0, True
WshShell.Run "taskkill /F /IM node.exe /T", 0, True
' Imposta la cartella di lavoro ed esegui con percorsi assoluti
appPath = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = appPath
' Avvia lo splash screen in parallelo
WshShell.Run "mshta.exe """ & appPath & "\splash.hta""", 0, False
' Avvia il node locale
WshShell.Run """" & appPath & "\node.exe"" """ & appPath & "\whatsapp.js""", 0, False
