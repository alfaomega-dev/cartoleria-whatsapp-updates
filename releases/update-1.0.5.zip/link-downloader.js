const axios = require('axios');
const fs = require('fs');
const path = require('path');
const url = require('url');

class LinkDownloader {
    constructor() {
        this.userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    }

    async download(text, outputFolder, fileNamePrefix) {
        try {
            // Estrai URL dal testo
            const extractedUrl = this.extractUrl(text);
            if (!extractedUrl) return { success: false, error: 'Nessun URL trovato nel messaggio' };

            const service = this.detectService(extractedUrl);
            if (!service) return { success: false, error: 'Servizio non supportato' };

            console.log(`🔗 Rilevato link ${service}: ${extractedUrl}`);

            let downloadInfo;

            switch (service) {
                case 'Adobe':
                    downloadInfo = await this.handleAdobe(extractedUrl);
                    break;
                case 'GoogleDrive':
                    downloadInfo = await this.handleGoogleDrive(extractedUrl);
                    break;
                case 'GoogleShare':
                    downloadInfo = await this.handleGoogleShare(extractedUrl);
                    break;
                case 'Dropbox':
                    downloadInfo = await this.handleDropbox(extractedUrl);
                    break;
                case 'Pinterest':
                    downloadInfo = await this.handlePinterest(extractedUrl);
                    break;
                case 'OneDrive':
                    downloadInfo = await this.handleOneDrive(extractedUrl);
                    break;
                case 'Direct':
                    downloadInfo = { url: extractedUrl, filename: null };
                    break;
            }

            if (!downloadInfo || !downloadInfo.url) {
                return { success: false, error: 'Impossibile trovare il file da scaricare' };
            }

            return await this.downloadFile(downloadInfo.url, outputFolder, fileNamePrefix, downloadInfo.filename);

        } catch (error) {
            console.error('❌ Errore LinkDownloader:', error.message);
            return { success: false, error: error.message };
        }
    }

    extractUrl(text) {
        // Regex per trovare URL http/https
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        const matches = text.match(urlRegex);
        // Ritorna il primo URL trovato che corrisponde a un servizio noto, oppure il primo in assoluto
        if (matches) {
            for (const url of matches) {
                if (this.detectService(url)) return url;
            }
            return matches[0];
        }
        return null;
    }

    detectService(linkUrl) {
        const u = linkUrl.toLowerCase();
        if (u.includes('acrobat.adobe.com') || u.includes('documentcloud.adobe.com')) return 'Adobe';
        if (u.includes('drive.google.com') || u.includes('docs.google.com')) return 'GoogleDrive';
        if (u.includes('share.google')) return 'GoogleShare';
        if (u.includes('dropbox.com')) return 'Dropbox';
        if (u.includes('pinterest.') || u.includes('pin.it')) return 'Pinterest';
        if (u.includes('onedrive.live.com') || u.includes('1drv.ms') || u.includes('sharepoint.com')) return 'OneDrive';

        // Generic Direct File Check
        try {
            const parsed = url.parse(linkUrl);
            const path = parsed.pathname || '';
            const ext = path.split('.').pop();
            const validExts = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'rar', 'jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (validExts.includes(ext)) return 'Direct';
        } catch (e) { }

        return null;
    }

    async handleAdobe(linkUrl) {
        const response = await axios.get(linkUrl, {
            headers: { 'User-Agent': this.userAgent }
        });
        const html = response.data;

        // Regex pattern from FileHub
        const patterns = [
            /https:\/\/documentcloud\.adobe\.com\/[^"\'<>\s]+\.pdf[^"\'<>\s]*/,
            /https:\/\/[^"\'<>\s]+\.acrobat\.com\/[^"\'<>\s]+\.pdf[^"\'<>\s]*/,
            /"(https:\/\/[^"]+\.pdf[^"]*)"/,
            /content_url["\s:]+["\'](https:\/\/[^"\']+)/
        ];

        for (const pattern of patterns) {
            const match = html.match(pattern);
            if (match) {
                let pdfUrl = match[1] || match[0];
                return { url: pdfUrl.replace(/["']/g, ''), filename: null }; // Filename will be detected from headers
            }
        }

        // Fallback meta tag
        const metaMatch = html.match(/<meta[^>]+property="og:url"[^>]+content="([^"]+)"/);
        if (metaMatch && metaMatch[1].includes('.pdf')) {
            return { url: metaMatch[1], filename: null };
        }

        throw new Error('PDF non trovato nella pagina Adobe');
    }

    async handleGoogleDrive(linkUrl) {
        // Extract ID
        let fileId = null;
        const idMatch = linkUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);
        if (idMatch) fileId = idMatch[1];
        else {
            const qMatch = linkUrl.match(/[?&]id=([a-zA-Z0-9_-]+)/);
            if (qMatch) fileId = qMatch[1];
        }

        if (!fileId) throw new Error('ID Google Drive non trovato');

        return {
            url: `https://drive.google.com/uc?export=download&id=${fileId}`,
            filename: null
        };
    }

    async handleGoogleShare(linkUrl) {
        const response = await axios.get(linkUrl, {
            headers: { 'User-Agent': this.userAgent }
        });
        const html = response.data;

        // Patterns from FileHub logic
        const patterns = [
            /href="(https:\/\/[^"]+\.(?:pdf|jpg|jpeg|png|gif|zip|doc|docx)[^"]*)"/,
            /"url":"(https:\/\/[^"]+\.(?:pdf|jpg|jpeg|png|gif|zip))"/,
            /src="(https:\/\/[^"]+\.(?:jpg|jpeg|png|gif)[^"]*)"/
        ];

        for (const pattern of patterns) {
            const match = html.match(pattern);
            if (match) {
                return { url: match[1], filename: null };
            }
        }

        // Fallback: use final URL if it ends with extension
        const finalUrl = response.request.res.responseUrl || linkUrl;
        const ext = path.extname(new URL(finalUrl).pathname);
        if (['.pdf', '.jpg', '.png', '.zip', '.docx'].includes(ext)) {
            return { url: finalUrl, filename: null };
        }

        throw new Error('File non trovato su Google Share');
    }

    async handleDropbox(linkUrl) {
        let downloadUrl = linkUrl;
        if (linkUrl.includes('dl=0')) downloadUrl = linkUrl.replace('dl=0', 'dl=1');
        else if (!linkUrl.includes('dl=1')) downloadUrl += (linkUrl.includes('?') ? '&' : '?') + 'dl=1';

        return { url: downloadUrl, filename: null };
    }

    async handleOneDrive(linkUrl) {
        // Resolve redirects
        const response = await axios.head(linkUrl, {
            maxRedirects: 10,
            headers: { 'User-Agent': this.userAgent }
        });
        const finalUrl = response.request.res.responseUrl || linkUrl;

        // Try to construct download URL
        const parsed = url.parse(finalUrl, true);

        // Strategy A: resid + authkey
        if (parsed.query.resid) {
            let dlUrl = `https://onedrive.live.com/download?resid=${parsed.query.resid}`;
            if (parsed.query.authkey) dlUrl += `&authkey=${parsed.query.authkey}`;
            else if (parsed.query.redeem) dlUrl += `&authkey=${parsed.query.redeem}`;
            return { url: dlUrl, filename: null };
        }

        // Strategy B: append download=1
        let dlUrl = finalUrl;
        dlUrl += (finalUrl.includes('?') ? '&' : '?') + 'download=1';
        return { url: dlUrl, filename: null };
    }

    async handlePinterest(linkUrl) {
        const response = await axios.get(linkUrl, {
            headers: { 'User-Agent': this.userAgent }
        });
        const html = response.data;

        // Patterns from FileHub
        const patterns = [
            /"url":"(https:\/\/i\.pinimg\.com\/originals\/[^"]+)"/,
            /<img[^>]+src="(https:\/\/i\.pinimg\.com\/originals\/[^"]+)"/,
            /"images":\{"orig":\{"url":"([^"]+)"/
        ];

        for (const pattern of patterns) {
            const match = html.match(pattern);
            if (match) {
                return { url: match[1].replace(/\\\//g, '/'), filename: null };
            }
        }
        throw new Error('Immagine Pinterest non trovata');
    }

    async downloadFile(fileUrl, outputFolder, fileNamePrefix, forcedFilename) {
        try {
            console.log(`⬇️ Avvio download da: ${fileUrl}`);
            const response = await axios({
                method: 'GET',
                url: fileUrl,
                responseType: 'stream',
                headers: { 'User-Agent': this.userAgent }
            });

            // Detect filename
            let filename = forcedFilename;
            if (!filename) {
                const cd = response.headers['content-disposition'];
                if (cd) {
                    const match = cd.match(/filename[*]?=["']?(?:UTF-8'')?([^"';]+)/);
                    if (match) filename = decodeURIComponent(match[1]);
                }
            }
            if (!filename) {
                const parsed = url.parse(fileUrl);
                filename = path.basename(parsed.pathname);
                filename = decodeURIComponent(filename);
            }

            // Cleanup filename
            if (!filename || filename.length < 3 || filename.includes('download')) {
                const ct = response.headers['content-type'] || '';
                let ext = 'bin';
                if (ct.includes('pdf')) ext = 'pdf';
                else if (ct.includes('jpeg') || ct.includes('jpg')) ext = 'jpg';
                else if (ct.includes('png')) ext = 'png';
                else if (ct.includes('zip')) ext = 'zip';
                else if (ct.includes('spreadsheet') || ct.includes('excel')) ext = 'xlsx';
                else if (ct.includes('word') || ct.includes('document')) ext = 'docx';

                // Genera nome se veramente sconosciuto
                if (!filename || filename.length < 3) {
                    filename = `download.${ext}`;
                } else if (!path.extname(filename)) {
                    filename += `.${ext}`;
                }
            }

            // Add prefix (timestamp) and sanitize filename
            const safeName = path.basename(filename).replace(/[^a-z0-9\.\-_]/gi, '_');
            const finalName = `${fileNamePrefix}_${safeName}`;
            const outputPath = path.join(outputFolder, finalName);

            const writer = fs.createWriteStream(outputPath);
            response.data.pipe(writer);

            return new Promise((resolve, reject) => {
                writer.on('finish', () => {
                    console.log(`✅ Download completato: ${finalName}`);
                    resolve({ success: true, filepath: outputPath, filename: finalName });
                });
                writer.on('error', (err) => {
                    console.error('❌ Errore scrittura file:', err);
                    reject(err);
                });
            });
        } catch (err) {
            console.error('❌ Errore durante il download stream:', err.message);
            throw err;
        }
    }
}

module.exports = new LinkDownloader();
