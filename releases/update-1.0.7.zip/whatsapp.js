// whatsapp-print-service.js
let Client, LocalAuth;
const qrcode = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');
const express = require('express');
const cors = require('cors');
const { exec, execSync, spawn } = require('child_process');
const crypto = require('crypto');
const axios = require('axios');
const db = require('./db');

const APP_VERSION = '1.0.7';

const app = express();
const PORT = process.env.PORT || 3000;

// Determina la cartella radice e la cartella dati (standard Windows)
const isPkg = !!process.pkg;
const ROOT_DIR = isPkg ? path.dirname(process.execPath) : __dirname;

// Usa AppData se installato in Program Files o come pkg (per evitare problemi di permessi)
const isInstalled = isPkg || ROOT_DIR.toLowerCase().includes('program files');
const appDataPath = process.env.APPDATA || path.join(process.env.USERPROFILE, 'AppData', 'Roaming');
const DATA_DIR = isInstalled
    ? path.join(appDataPath, 'PrintZap')
    : ROOT_DIR;

// Auto-migrazione dei dati utente da CartoleriaWhatsApp a PrintZap (preserva sessione e database)
if (isInstalled && !fs.existsSync(DATA_DIR)) {
    const oldDataDir = path.join(appDataPath, 'CartoleriaWhatsApp');
    if (fs.existsSync(oldDataDir)) {
        try {
            fs.renameSync(oldDataDir, DATA_DIR);
        } catch (migrateErr) {
            // Fallback se bloccato: procederà a ricrearla vuota
        }
    }
}

if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// --- STRUCTURED LOGGING (Scrive sia in Console che su File) ---
const pino = require('pino');
const streams = [
    { stream: process.stdout },
    { stream: fs.createWriteStream(path.join(DATA_DIR, 'app_debug.log'), { flags: 'a' }) }
];
const logger = pino({}, pino.multistream(streams));

logger.info('🚀 Avvio applicazione professionale...');
logger.info(`📂 DATA_DIR: ${DATA_DIR}`);

// --- PULIZIA PORTA ---
function killPort(port) {
    if (process.platform !== 'win32') return;
    try {
        const stdout = execSync(`netstat -ano | findstr :${port}`).toString();
        const lines = stdout.trim().split('\n');
        lines.forEach(line => {
            const parts = line.trim().split(/\s+/);
            const pid = parts[parts.length - 1];
            if (pid && pid !== '0' && pid !== process.pid.toString()) {
                logger.info(`🧹 Pulizia: Trovato processo ${pid} sulla porta ${port}. Terminazione...`);
                execSync(`taskkill /F /PID ${pid}`);
            }
        });
    } catch (e) {
        logger.info(`ℹ️ Info pulizia porta: ${e.message}`);
    }
}

killPort(PORT);

process.on('uncaughtException', (err) => {
    logger.info(`❌ CRASH (Uncaught Exception): ${err.message}\n${err.stack}`);
    logger.error('CRASH:', err);
    // Tieni aperto il processo per leggere l'errore se avviato da terminale
    setTimeout(() => process.exit(1), 30000);
});

process.on('unhandledRejection', (reason, promise) => {
    logger.info(`⚠️ UNHANDLED REJECTION: ${reason}`);
});

app.use(cors());
app.use(express.json());

// Add correlationId to all requests
app.use((req, res, next) => {
    req.correlationId = req.headers['x-correlation-id'] || crypto.randomUUID();
    logger.info({ correlationId: req.correlationId, path: req.path }, 'Request started');
    next();
});

// Cartelle
const PRINT_FOLDER = path.join(DATA_DIR, 'file_da_stampare');
if (!fs.existsSync(PRINT_FOLDER)) {
    fs.mkdirSync(PRINT_FOLDER, { recursive: true });
}

// Stato WhatsApp
let wpStatus = 'DISCONNECTED';
let latestQR = null;
let isSyncing = false;       // Flag: blocca eventi message durante la sync iniziale
let pendingMessages = [];    // Coda messaggi ricevuti durante la sync
let isInitializing = false;  // Flag: previene inizializzazioni parallele concorrenti

// Configurazione
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const LICENSE_FILE = path.join(DATA_DIR, 'license.json');

let config = {
    notifyMessage: "✅ *Stampa Pronta!* 🖨️\nIl tuo documento è pronto per il ritiro.",
    autoCleanupDays: 7,
    updatesUrl: "https://raw.githubusercontent.com/alfaomega-dev/cartoleria-whatsapp-updates/main"
};

let licenseInfo = {
    installDate: null,
    active: false,
    key: ""
};

function loadLicense() {
    if (fs.existsSync(LICENSE_FILE)) {
        try {
            licenseInfo = JSON.parse(fs.readFileSync(LICENSE_FILE, 'utf8'));
        } catch (err) {
            logger.info(`❌ Errore caricamento licenza.`);
        }
    } else {
        licenseInfo.installDate = new Date().toISOString();
        fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
    }
}

function checkLicense() {
    loadLicense();

    // Salt segreto per impedire la manomissione delle licenze
    const LICENSE_SALT = 'PrintZapSecretSalt2026';

    // Se c'è una licenza firmata
    if (licenseInfo.customer && licenseInfo.key) {
        // Ricalcola il codice hash di verifica
        const payload = `${licenseInfo.customer}|${licenseInfo.expiryDate || 'never'}|${LICENSE_SALT}`;
        const expectedKey = crypto.createHash('sha256').update(payload).digest('hex');

        if (licenseInfo.key === expectedKey) {
            // Controlla data di scadenza
            if (licenseInfo.expiryDate && licenseInfo.expiryDate !== 'never') {
                const expiry = new Date(licenseInfo.expiryDate);
                const now = new Date();
                if (now > expiry) {
                    return { valid: false, message: `Licenza scaduta il ${expiry.toLocaleDateString()}` };
                }
                const diffDays = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));
                return { valid: true, isTrial: false, active: true, message: `Licenza valida per ${licenseInfo.customer}. Scadenza: ${expiry.toLocaleDateString()} (Rimangono ${diffDays} giorni).` };
            }
            return { valid: true, isTrial: false, active: true, message: `Licenza attiva a vita per: ${licenseInfo.customer}` };
        } else {
            logger.error('🛑 Tentativo di manomissione licenza rilevato!');
        }
    }

    // Se non c'è licenza attiva o è manomessa, controlla il periodo di prova (Trial)
    const installDate = new Date(licenseInfo.installDate || new Date());
    const now = new Date();
    const diffTime = Math.abs(now - installDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    const TRIAL_DAYS = 30; // 30 giorni di prova

    if (diffDays <= TRIAL_DAYS) {
        return {
            valid: true,
            isTrial: true,
            daysLeft: TRIAL_DAYS - diffDays,
            message: `Periodo di prova attivo: rimangono ${TRIAL_DAYS - diffDays} giorni.`
        };
    }

    return {
        valid: false,
        message: "Periodo di prova scaduto. Contatta l'amministratore per attivare la licenza."
    };
}

function loadConfig() {
    if (fs.existsSync(CONFIG_FILE)) {
        try {
            config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
        } catch (err) {
            logger.error('❌ Errore caricamento config.json, uso default.');
        }
    } else {
        // Se non esiste in DATA_DIR, proviamo a caricarlo da ROOT_DIR (modello installato)
        const templateConfigPath = path.join(ROOT_DIR, 'config.json');
        if (fs.existsSync(templateConfigPath)) {
            try {
                config = JSON.parse(fs.readFileSync(templateConfigPath, 'utf8'));
                logger.info('📂 Caricato config.json predefinito da ROOT_DIR.');
            } catch (err) {
                logger.error('❌ Errore caricamento template config.json da ROOT_DIR.');
            }
        }
    }

    // Assicura che l'URL degli aggiornamenti sia impostato (auto-healing per file esistenti vuoti)
    if (!config.updatesUrl || !config.updatesUrl.trim()) {
        config.updatesUrl = "https://raw.githubusercontent.com/alfaomega-dev/cartoleria-whatsapp-updates/main";
    }

    // Assegna un clientId univoco alla prima esecuzione o se assente
    if (!config.clientId) {
        config.clientId = 'session_' + Date.now();
    }

    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}
loadConfig();

async function checkAndApplyHotPatch() {
    const patchDir = path.join(DATA_DIR, 'patch');
    const localPatchPath = path.join(patchDir, 'Utils.js');
    const originalPatchPath = path.join(ROOT_DIR, 'node_modules', 'whatsapp-web.js', 'src', 'util', 'Injected', 'Utils.js');

    if (!config.updatesUrl) {
        logger.info('ℹ️ Hot-Patch: updatesUrl non impostato, salto il controllo.');
        applyLocalHotPatchCache(localPatchPath);
        return;
    }

    const baseUrl = config.updatesUrl.replace(/\/+$/, '');
    const patchUrl = `${baseUrl}/patch/Utils.js`;

    logger.info(`🔍 Hot-Patch: Controllo aggiornamenti critici su: ${patchUrl}...`);

    try {
        const response = await axios.get(patchUrl, { timeout: 8000 });
        if (response.status === 200 && typeof response.data === 'string') {
            const remoteContent = response.data;

            let currentContent = '';
            if (fs.existsSync(localPatchPath)) {
                currentContent = fs.readFileSync(localPatchPath, 'utf8');
            } else if (fs.existsSync(originalPatchPath)) {
                currentContent = fs.readFileSync(originalPatchPath, 'utf8');
            }

            const remoteHash = crypto.createHash('md5').update(remoteContent).digest('hex');
            const currentHash = crypto.createHash('md5').update(currentContent).digest('hex');

            if (remoteHash !== currentHash) {
                logger.info('🔄 Hot-Patch: Trovata una nuova versione di Utils.js. Salvataggio in corso...');
                fs.mkdirSync(patchDir, { recursive: true });
                fs.writeFileSync(localPatchPath, remoteContent, 'utf8');
                logger.info('✅ Hot-Patch: Salvata patch di compatibilità WhatsApp Web con successo in DATA_DIR.');
            } else {
                logger.info('✅ Hot-Patch: Utils.js locale è già allineato alla versione remota.');
            }
        }
    } catch (err) {
        logger.error(`⚠️ Hot-Patch: Impossibile scaricare la patch remota (${err.message}). Verrà utilizzata la patch locale più recente.`);
    }

    applyLocalHotPatchCache(localPatchPath);
}

function applyLocalHotPatchCache(localPatchPath) {
    if (fs.existsSync(localPatchPath)) {
        try {
            logger.info(`🔄 Hot-Patch: Caricamento patch in memoria da: ${localPatchPath}`);
            const utilsModulePath = require.resolve('whatsapp-web.js/src/util/Injected/Utils');
            const patchedModule = require(localPatchPath);
            require.cache[utilsModulePath] = {
                id: utilsModulePath,
                filename: utilsModulePath,
                loaded: true,
                exports: patchedModule
            };
            logger.info('✅ Hot-Patch: Applicata con successo la patch in require.cache!');
        } catch (cacheErr) {
            logger.error(`⚠️ Hot-Patch: Errore nell'override di require.cache (${cacheErr.message})`);
        }
    } else {
        logger.info('ℹ️ Hot-Patch: Nessuna patch personalizzata da caricare. Verrà usata la versione predefinita.');
    }
}

function cleanupOldSessions() {
    if (process.platform !== 'win32') return;
    try {
        logger.info('🧹 Pulizia vecchie cartelle di sessione orfane...');
        logger.info('🧹 Pulizia vecchie cartelle di sessione orfane...');

        const authDir = path.join(DATA_DIR, '.wwebjs_auth');
        if (fs.existsSync(authDir)) {
            const dirs = fs.readdirSync(authDir);
            dirs.forEach(dir => {
                if (dir.startsWith('session-') && dir !== `session-${config.clientId}`) {
                    try {
                        fs.rmSync(path.join(authDir, dir), { recursive: true, force: true });
                        logger.info(`🗑️ Rimossa vecchia sessione: ${dir}`);
                    } catch (e) { }
                }
            });
        }

        const oldSessionDir = path.join(DATA_DIR, 'session');
        if (fs.existsSync(oldSessionDir)) {
            try { fs.rmSync(oldSessionDir, { recursive: true, force: true }); } catch (e) { }
        }
    } catch (e) {
        logger.info(`ℹ️ Output pulizia vecchie sessioni: ${e.message}`);
    }
}

function killOrphanedChrome() {
    if (process.platform !== 'win32') return;
    try {
        logger.info('🧹 Cerco e termino processi Chrome/Edge bloccati (Powershell+Taskkill)...');
        logger.info('🧹 Cerco processi Chrome/Edge bloccati...');

        // Estrai solo i PID numerici dei processi interessati
        const psCmd = `powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \\"Name='chrome.exe' OR Name='msedge.exe'\\" | Where-Object { $_.CommandLine -match 'PrintZap' } | Select-Object -ExpandProperty ProcessId"`;

        try {
            const pidsOutput = execSync(psCmd, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
            if (pidsOutput) {
                const pids = pidsOutput.split('\n');
                pids.forEach(pidStr => {
                    const pid = pidStr.trim();
                    if (pid && !isNaN(pid)) {
                        logger.info(`🔫 Trovato PID orfano: ${pid}. Termino albero processi...`);
                        try { execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
                    }
                });
            }
        } catch (e) {
            logger.info(`ℹ️ powershell non ha trovato processi o ha incontrato un errore`);
        }

        // Attesa bloccante puramente JS (senza comandi esterni che falliscono senza TTY)
        const start = Date.now();
        while (Date.now() - start < 1500) { }
    } catch (e) {
        logger.info(`ℹ️ Output pulizia Chrome fantasma: ${e.message}`);
        logger.info(`ℹ️ Output pulizia Chrome fantasma: ${e.message}`);
    }
}

let client;

async function initializeClient() {
    if (isInitializing) {
        logger.info('⚠️ initializeClient è già in corso. Ignoro chiamata parallela.');
        return;
    }
    isInitializing = true;
    logger.info('🎬 Avvio initializeClient...');
    await checkAndApplyHotPatch();

    // Caricamento differito di whatsapp-web.js per applicare l'Hot-Patch prima del require
    if (!Client || !LocalAuth) {
        try {
            logger.info('📦 Caricamento di whatsapp-web.js...');
            const wweb = require('whatsapp-web.js');
            Client = wweb.Client;
            LocalAuth = wweb.LocalAuth;
            logger.info('📦 Libreria whatsapp-web.js caricata correttamente.');
        } catch (wwebErr) {
            logger.error(`❌ Errore critico nel caricamento di whatsapp-web.js: ${wwebErr.message}`);
            isInitializing = false;
            return;
        }
    }
    cleanupOldSessions(); // Pulisce le cartelle vecchie non più in uso
    killOrphanedChrome(); // Forza sempre la pulizia prima dell'avvio o ravvio di un nuovo client

    // Pulisci la cache di WhatsApp Web per evitare versioni incompatibili
    const cachePathStartup = path.join(DATA_DIR, '.wwebjs_cache');
    if (fs.existsSync(cachePathStartup)) {
        try {
            fs.rmSync(cachePathStartup, { recursive: true, force: true });
            logger.info('🗑️ Cache WhatsApp Web rimossa per avvio pulito.');
        } catch (e) {
            logger.info('ℹ️ Impossibile rimuovere cache: ' + e.message);
        }
    }

    wpStatus = 'INITIALIZING';
    const lic = checkLicense();
    if (!lic.valid) {
        logger.error(`🛑 ${lic.message}`);
        logger.info(`🛑 LICENSE EXPIRED: ${lic.message}`);
        wpStatus = 'EXPIRED';
        isInitializing = false;
        return;
    }

    if (lic.isTrial) {
        logger.info(`💡 ${lic.message}`);
        logger.info(lic.message);
    }

    // --- RILEVAMENTO BROWSER ---
    let executablePath = undefined;

    // 1. Cerca Chrome locale (versione portabile in cartella app) - PRIORITÀ ALTA
    const localChrome = path.join(ROOT_DIR, 'chrome-win64', 'chrome.exe');

    // 2. Percorsi standard Windows per Chrome ed Edge (Chromium based) installati
    const systemChromePaths = [
        localChrome,
        // Google Chrome
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
        path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'),
        // Microsoft Edge (Perfettamente compatibile con Puppeteer)
        'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
        'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Microsoft\\Edge\\Application\\msedge.exe')
    ];

    for (const p of systemChromePaths) {
        if (p && fs.existsSync(p)) {
            executablePath = p;
            logger.info(`🌐 Browser trovato in: ${p}`);
            break;
        }
    }

    if (!executablePath) {
        logger.info("⚠️ ATTENZIONE: Chrome non trovato nel sistema. WhatsApp potrebbe non avviarsi.");
        logger.error("❌ Chrome non trovato! Installalo o aggiungi 'chrome-win64' nella cartella root.");
    }

    if (executablePath) logger.info('Chromium locale trovato:', executablePath);

    client = new Client({
        authStrategy: new LocalAuth({ clientId: config.clientId, dataPath: DATA_DIR }),
        puppeteer: {
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu'
            ],
            executablePath: executablePath
        },
        webVersionCache: {
            type: 'none'
        }
    });

    client.on('qr', (qr) => {
        isInitializing = false; // Il browser è avviato e aspetta lo scan
        logger.info('Scansiona questo QR con WhatsApp:');
        logger.info('📷 QR Code generato. In attesa di scansione...');
        qrcode.generate(qr, { small: true });
        wpStatus = 'WAITING_FOR_QR';
        latestQR = qr;
    });

    client.on('ready', async () => {
        isInitializing = false;
        logger.info('✅ WhatsApp connesso e pronto!');
        logger.info('✅ EVENTO READY: WhatsApp connesso e pronto!');
        wpStatus = 'CONNECTED';
        latestQR = null;

        // Attendi 3s per dare tempo a WhatsApp Web di stabilizzarsi
        // poi sincronizza messaggi non letti all'avvio
        await new Promise(r => setTimeout(r, 3000));
        isSyncing = true;
        pendingMessages = [];
        try {
            await syncUnreadMessages(client);
        } finally {
            isSyncing = false;
            // Processa i messaggi arrivati durante la sync (in ordine di arrivo)
            if (pendingMessages.length > 0) {
                logger.info(`📬 Processo ${pendingMessages.length} messaggi ricevuti durante la sync...`);
                const queue = [...pendingMessages];
                pendingMessages = [];
                for (const m of queue) {
                    await processMessageSafe(m);
                }
            }
            logger.info('✅ Sync completata. Ascolto nuovi messaggi attivo.');
        }
    });

    client.on('authenticated', () => {
        logger.info('🔑 Autenticato con successo!');
        logger.info('🔑 EVENTO AUTHENTICATED: Sessione ripristinata o nuova sessione creata.');
        wpStatus = 'AUTHENTICATING';
        latestQR = null; // Nascondi il QR dalla dashboard
    });

    client.on('auth_failure', msg => {
        isInitializing = false;
        logger.error('⛔ Errore di autenticazione:', msg);
        logger.info(`⛔ EVENTO AUTH_FAILURE: ${msg}`);
        wpStatus = 'DISCONNECTED';
    });

    client.on('message', async msg => {
        const msgId = getMessageId(msg);
        logger.info(`📥 Evento 'message' intercettato da: ${msg?.from || 'Mittente sconosciuto'} | ID: ${msgId || 'Nessuno'} | Tipo: ${msg?.type || 'Sconosciuto'}`);
        if (isSyncing) {
            // Metti in coda: verrà processato subito dopo la sync
            pendingMessages.push(msg);
            logger.info(`⏸ Messaggio in coda (sync in corso): ${msgId || 'ID sconosciuto'}`);
            return;
        }
        await processMessageSafe(msg);
    });

    client.on('message_create', async msg => {
        // Intercetta solo i messaggi inviati DA ME che contengono "stampa pronta"
        if (msg.fromMe && msg.body.toLowerCase().includes('stampa pronta')) {
            logger.info('⚡ Rilevato comando manuale "Stampa Pronta"');
            try {
                const targetId = msg.to;

                // Risolviamo il contatto per ottenere il numero reale (specialmente se è un @lid)
                const contact = await client.getContactById(targetId);
                const recipientNumber = contact.number;

                logger.info(`📩 Outgoing message to: ${targetId} | Real Phone: ${recipientNumber} | Body: ${msg.body}`);

                // Ignora gruppi
                if (!targetId || targetId.includes('@g.us')) return;

                const updated = await db.markContactOrdersPrinted(recipientNumber);
                if (updated) {
                    logger.info(`✅ Ordini per ${recipientNumber} segnati come STAMPATI (Manual Trigger SQLite)`);
                } else {
                    logger.info(`ℹ️ Nessun ordine 'nuovo' trovato per ${recipientNumber} in SQLite`);
                }
            } catch (error) {
                logger.error('❌ Errore processamento comando manuale:', error);
            }
        }
    });

    client.on('chat_removed', async chat => {
        if (chat.isGroup) return;
        const chatJid = chat.id._serialized;
        logger.info(`🗑️ Evento 'chat_removed' intercettato per la chat: ${chatJid}`);
        try {
            // Risolviamo il contatto per ottenere il numero reale (gestendo i @lid)
            const contact = await client.getContactById(chatJid);
            const phone = contact.number;

            if (phone) {
                // Recupera gli ordini associati a questo telefono per cancellare i file
                const orders = await db.getOrdersByPhone(phone);
                if (orders.length > 0) {
                    logger.info(`🗑️ Rimozione di ${orders.length} ordini associati al numero ${phone}`);

                    // Cancella i file fisici
                    orders.forEach(order => {
                        if (order.file) {
                            deleteFileWithCleanup(order.file);
                        }
                    });

                    // Rimuove gli ordini dal database
                    await db.deleteOrdersByPhone(phone);
                    logger.info(`✅ Eliminati con successo tutti gli ordini per ${phone} dal database.`);
                } else {
                    logger.info(`ℹ️ Nessun ordine presente nel database per il numero ${phone}.`);
                }
            }
        } catch (error) {
            logger.error('❌ Errore durante la rimozione automatica degli ordini per chat rimossa:', error);
        }
    });

    client.on('disconnected', async (reason) => {
        logger.info('❌ WhatsApp disconnesso:', reason);
        logger.info(`❌ WhatsApp disconnesso: ${reason}. Inizializzo reset automatico sessione...`);
        wpStatus = 'DISCONNECTED';
        latestQR = null;
        isInitializing = false;

        if (client) {
            try {
                const destroyPromise = client.destroy();
                const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 5000));
                await Promise.race([destroyPromise, timeoutPromise]).catch(() => { });
                await new Promise(r => setTimeout(r, 1000)); // Attendi rilascio file lock
            } catch (err) { }
            client = null;
        }

        // Ruota il session ID SOLO se il motivo è un LOGOUT effettivo.
        // Altrimenti proviamo a riutilizzare la sessione esistente per evitare di dover rifare la scansione del QR.
        if (reason === 'LOGOUT') {
            config.clientId = 'session_' + Date.now();
            fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
            logger.info(`🔄 Generato nuovo clientId al logout: ${config.clientId}`);
        } else {
            logger.info(`🔄 Riavvio con la sessione esistente (${config.clientId}) per cercare di ripristinarla.`);
        }

        const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
        if (fs.existsSync(cachePath)) {
            try { fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 }); } catch (e) { logger.info('Errore delete dir cache: ' + e.message); }
        }

        logger.info('🔄 Riparto per inizializzare il client tra 3 secondi...');
        setTimeout(initializeClient, 3000);
    });

    try {
        logger.info(`🛠️ Inizializzazione client con browser: ${executablePath || 'Default'}`);
        client.initialize().catch(err => {
            logger.info(`❌ Errore in client.initialize(): ${err.message}`);
            logger.error('Errore inizializzazione:', err);
            wpStatus = 'DISCONNECTED';
            isInitializing = false;
        });
    } catch (err) {
        logger.info(`❌ Eccezione durante inizializzazione: ${err.message}`);
        wpStatus = 'DISCONNECTED';
        isInitializing = false;
    }
}

// Helper: rileva se l'errore è un errore transitorio di Puppeteer (pagina in reload)
function isPuppeteerContextError(err) {
    const msg = err && (err.message || err.toString());
    return (
        msg === 'r' ||
        (msg && msg.includes('Execution context was destroyed')) ||
        (msg && msg.includes('Cannot read properties of null')) ||
        (msg && msg.includes('Session closed'))
    );
}

// Helper: applica un timeout a una Promise
function promiseTimeout(promise, ms, name = 'Promise') {
    let timeout = new Promise((_, reject) => {
        let id = setTimeout(() => {
            clearTimeout(id);
            reject(new Error(`Timeout superato (${ms}ms) per: ${name}`));
        }, ms);
    });
    return Promise.race([promise, timeout]);
}

// Helper: estrae o genera un ID univoco per il messaggio in modo resiliente
function getMessageId(msg) {
    if (!msg) return null;
    if (msg.id) {
        if (typeof msg.id === 'string') return msg.id;
        if (msg.id._serialized) return msg.id._serialized;
        if (msg.id.id) {
            const remote = msg.id.remote || msg.from || 'unknown';
            const fromMe = msg.id.fromMe ? 'true' : 'false';
            return `${fromMe}_${remote}_${msg.id.id}`;
        }
    }
    // Fallback in caso di oggetti parziali per non scartare mai i messaggi reali
    if (msg.from && msg.timestamp) {
        return `fallback_${msg.from}_${msg.timestamp}_${msg.type || 'text'}`;
    }
    return null;
}

async function syncUnreadMessages(clientInstance = client, retryCount = 0) {
    logger.info('🔍 Sincronizzazione messaggi non letti (avvio)...');
    try {
        if (!clientInstance) {
            logger.error('❌ Errore sync: clientInstance è nullo.');
            return;
        }
        // Carica gli ID già processati per evitare duplicati
        const processedMsgIds = await db.getProcessedMessageIds();

        const chats = await promiseTimeout(clientInstance.getChats(), 15000, 'client.getChats()');

        // Filtra solo le chat private con messaggi non letti
        const unreadChats = chats.filter(chat => !chat.isGroup && chat.unreadCount > 0);

        if (unreadChats.length > 0) {
            logger.info(`📬 Trovate ${unreadChats.length} chat con messaggi non letti...`);

            for (const chat of unreadChats) {
                try {
                    const messages = await promiseTimeout(chat.fetchMessages({ limit: Math.max(chat.unreadCount, 30) }), 10000, `chat.fetchMessagesUnread(${chat.name})`);

                    const unprocessed = messages.filter(m =>
                        !m.fromMe &&
                        !processedMsgIds.has(m.id._serialized)
                    );

                    if (unprocessed.length > 0) {
                        logger.info(`📩 Chat "${chat.name}": processamento di ${unprocessed.length} nuovi messaggi...`);
                        for (const m of unprocessed) {
                            await processMessageSafe(m);
                            processedMsgIds.add(m.id._serialized);
                        }
                    }

                    // Segna come letta SOLO dopo aver processato tutto
                    await chat.sendSeen();
                } catch (chatErr) {
                    if (!isPuppeteerContextError(chatErr)) {
                        logger.error(`⚠️ Errore sincronizzazione chat "${chat.name}":`, chatErr.message);
                    }
                }
            }
        }

        logger.info('✅ Sincronizzazione all\'avvio completata.');

    } catch (error) {
        logger.info(`🔍 Dettaglio errore sync: ${error.message}\n${error.stack}`);
        if (isPuppeteerContextError(error)) {
            // Errore transitorio: WhatsApp Web stava ricaricando la pagina
            if (retryCount < 2) {
                const delay = (retryCount + 1) * 5000;
                logger.info(`⚠️ Sync interrotta (pagina in reload). Riprovo tra ${delay / 1000}s... (tentativo ${retryCount + 1}/2)`);
                await new Promise(r => setTimeout(r, delay));
                return syncUnreadMessages(clientInstance, retryCount + 1);
            } else {
                logger.info('⚠️ Sync annullata dopo 2 tentativi: pagina non ancora stabile. Riproverà al prossimo messaggio.');
            }
        } else {
            logger.error('❌ Errore durante la sincronizzazione:', error);
        }
    }
}

// Link Downloader
const linkDownloader = require('./link-downloader');

async function processMessage(msg, retryCount = 0) {

    const msgId = getMessageId(msg);
    if (!msgId) {
        logger.info('⏭ Messaggio di sistema senza ID valido ignorato.');
        return;
    }

    try {
        // Filtra storie/stati
        if (msg.isStatus) return;

        // Filtra solo chat private (esclude gruppi) con timeout di 8 secondi
        const chat = await promiseTimeout(msg.getChat(), 8000, 'msg.getChat()');
        if (chat.isGroup) return;

        // Evita di processare messaggi già salvati (controllo ID)
        const exists = await db.orderExists(msgId);
        if (exists) return;

        // Recupera contatto con timeout di 8 secondi
        const contact = await promiseTimeout(msg.getContact(), 8000, 'msg.getContact()');
        const contactName = contact.name || contact.pushname || contact.number;

        // Sanitize contact name with allowlist
        const safeContactName = contactName.replace(/[^a-z0-9]/gi, '_');
        if (!/^[a-z0-9_]+$/i.test(safeContactName)) {
            throw new Error('Nome contatto non valido');
        }
        const contactFolder = path.join(PRINT_FOLDER, safeContactName);

        // --- LOGICA DI SINCRONIZZAZIONE CARTELLE ---
        const existingOrders = await db.getOrdersByPhoneAndHasFile(contact.number);

        if (existingOrders.length > 0) {
            const oldRelativeFolder = path.dirname(existingOrders[0].file);

            if (oldRelativeFolder !== safeContactName) {
                const oldFullPath = path.join(PRINT_FOLDER, oldRelativeFolder);
                if (fs.existsSync(oldFullPath)) {
                    logger.info(`🔄 Sincronizzazione: Rinomino cartella da ${oldRelativeFolder} a ${safeContactName}`);
                    try {
                        if (!fs.existsSync(contactFolder)) {
                            fs.renameSync(oldFullPath, contactFolder);
                        }

                        await db.updateContactOrdersFolder(contact.number, contactName, safeContactName);
                    } catch (err) {
                        logger.error('❌ Errore sincronizzazione nomi:', err);
                    }
                }
            }
        }

        // --- GESTIONE LINK ---
        // Verifica se il messaggio contiene un link supportato
        const body = msg.body || "";
        const detectedService = linkDownloader.detectService(body);

        if (detectedService) {
            logger.info(`🔗 Rilevato link ${detectedService} da: ${contactName}`);

            if (!fs.existsSync(contactFolder)) {
                fs.mkdirSync(contactFolder, { recursive: true });
            }

            const timestamp = Date.now();
            // Aggiungi tag "_link" al prefisso per identificare i file scaricati da link
            const prefix = `${timestamp}_link`;
            const result = await linkDownloader.download(body, contactFolder, prefix);

            if (result.success) {
                const relativePath = `${safeContactName}/${path.basename(result.filepath)}`;
                logger.info(`✅ Link scaricato: ${relativePath}`);

                // Mappa estensione a tipo ordine
                const ext = path.extname(result.filename).toLowerCase().replace('.', '');
                let orderType = 'documento';
                if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) orderType = 'immagine';
                if (['pdf'].includes(ext)) orderType = 'pdf';

                await saveOrderInfo({
                    id: timestamp,
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: relativePath,
                    tipo: orderType,
                    messaggio: `Link ${detectedService}: ${body}`,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: 'nuovo'
                });

                // Opzionale: Rispondi al cliente
                // await msg.reply(`✅ Ho scaricato il tuo file ${detectedService}!`);
                return; // Esci per non salvare anche come nota
            } else {
                logger.error(`❌ Errore download link: ${result.error}`);
                // Se fallisce, lo salviamo comunque come nota con il link
            }
        }


        if (msg.hasMedia) {
            logger.info(`📩 Messaggio con media da: ${contactName}`);
            const media = await msg.downloadMedia();

            if (media) {
                if (!fs.existsSync(contactFolder)) {
                    fs.mkdirSync(contactFolder, { recursive: true });
                }

                const mimeMap = {
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
                    'application/msword': 'doc',
                    'application/pdf': 'pdf',
                    'application/vnd.ms-excel': 'xls',
                    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
                    'application/vnd.ms-powerpoint': 'ppt',
                    'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
                    'text/plain': 'txt',
                    'text/csv': 'csv',
                    'image/jpeg': 'jpg',
                    'image/png': 'png',
                    'image/gif': 'gif',
                    'image/webp': 'webp',
                    'image/bmp': 'bmp',
                    'image/tiff': 'tiff',
                    'video/mp4': 'mp4',
                    'application/zip': 'zip',
                    'audio/ogg; codecs=opus': 'ogg',
                    'audio/ogg': 'ogg',
                    'audio/mpeg': 'mp3',
                    'audio/mp4': 'm4a'
                };

                let ext = mimeMap[media.mimetype] || media.mimetype.split('/')[1]?.split(';')[0] || 'bin';
                if (ext.includes('wordprocessingml')) ext = 'docx';
                if (ext.includes('spreadsheetml')) ext = 'xlsx';
                if (ext.includes('presentationml')) ext = 'pptx';

                // Gestione specifica per audio/vocali
                let orderType = media.mimetype;
                if (msg.type === 'ptt' || msg.type === 'audio') {
                    orderType = 'audio';
                    if (!ext || ext === 'bin') ext = 'ogg'; // Default extension for voice notes
                }

                const timestamp = Date.now();
                let fileName;

                if (media.filename) {
                    // Se c'è un nome file originale, usalo (sanitizzato)
                    const originalName = media.filename;
                    // Ottieni l'estensione originale se disponibile
                    const originalExt = path.extname(originalName).replace('.', '');
                    if (originalExt) {
                        // Usa l'estensione originale ma verifica se coincide con il mime type atteso (opzionale)
                        ext = originalExt;
                    }

                    // Rimuovi caratteri non validi
                    const safeOriginalName = originalName.replace(/[^a-z0-9\.\-_]/gi, '_');
                    fileName = `${timestamp}_${safeOriginalName}`;
                } else {
                    // Fallback: usa timestamp + estensione dedotta
                    fileName = `${timestamp}.${ext}`;
                }

                const filePath = path.join(contactFolder, fileName);

                const buffer = Buffer.from(media.data, 'base64');
                fs.writeFileSync(filePath, buffer);

                const relativePath = `${safeContactName}/${fileName}`;
                logger.info(`✅ File salvato: ${relativePath} (Tipo: ${orderType})`);

                await saveOrderInfo({
                    id: timestamp,
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: relativePath,
                    tipo: orderType, // 'audio' se è un vocale
                    messaggio: msg.body, // Di solito vuoto per audio
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: 'nuovo'
                });
            } else {
                logger.warn(`⚠️ Impossibile scaricare i media per il messaggio ${msgId}. Salvo come nota.`);
                const warningMessage = msg.body
                    ? `${msg.body}\n\n⚠️ (Errore: Impossibile scaricare l'allegato)`
                    : `⚠️ (Errore: Impossibile scaricare l'allegato)`;

                await saveOrderInfo({
                    id: Date.now(),
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: null,
                    tipo: 'nota',
                    messaggio: warningMessage,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: 'nuovo'
                });
            }

        } else if (msg.body && !msg.fromMe) {
            logger.info(`💬 Testo da ${contactName}: ${msg.body}`);
            saveNote(contactName, msg.body);

            // Nuovo: Salva anche come "ordine" di tipo nota per la Dashboard
            await saveOrderInfo({
                id: Date.now(),
                msgId: msgId,
                cliente: contactName,
                telefono: contact.number,
                file: null, // Nessun file
                tipo: 'nota',
                messaggio: msg.body,
                data: new Date(msg.timestamp * 1000).toISOString(),
                stato: 'nuovo'
            });
        }

    } catch (error) {
        logger.info(`🔍 Dettaglio errore per msg ${msgId || '?'}: ${error.message}\n${error.stack}`);
        if (isPuppeteerContextError(error)) {
            // Errore transitorio: WhatsApp Web stava ricaricando la pagina
            if (retryCount < 3) {
                const delay = (retryCount + 1) * 3000; // 3s, 6s, 9s
                logger.info(`⚠️ Retry msg ${msgId || '?'} tra ${delay / 1000}s (tentativo ${retryCount + 1}/3)...`);
                await new Promise(r => setTimeout(r, delay));
                return processMessage(msg, retryCount + 1);
            } else {
                logger.info(`⚠️ Messaggio ${msgId || 'ID sconosciuto'} non processabile dopo 3 tentativi (pagina instabile).`);
            }
        } else {
            logger.error('❌ Errore processamento messaggio:', error);
        }
    }
}

async function processMessageSafe(msg) {
    const msgId = getMessageId(msg);
    if (!msgId) {
        logger.info('⏭ Messaggio di sistema senza ID valido ignorato.');
        return;
    }
    return processMessage(msg, 0);
}

// API Endpoints
app.get('/api/status', (req, res) => {
    res.json({ status: wpStatus, qr: latestQR });
});

app.post('/api/logout', async (req, res) => {
    logger.info('🔄 Richiesta Logout Ricevuta...');
    try {
        if (client) {
            let pid = null;
            try {
                if (client.pupBrowser && client.pupBrowser.process()) {
                    pid = client.pupBrowser.process().pid;
                }
            } catch (e) { }

            try {
                await client.logout();
                logger.info('✅ Logout effettuato.');
            } catch (err) {
                logger.info('ℹ️ Client già disconnesso o logout non necessario.');
            }
            try {
                // Wrap destroy in a race with timeout
                const destroyPromise = client.destroy();
                const timeoutPromise = new Promise((_, reject) =>
                    setTimeout(() => reject(new Error('Timeout distruzione client')), 5000)
                );

                await Promise.race([destroyPromise, timeoutPromise]);
                await new Promise(r => setTimeout(r, 1000)); // Attendi rilascio file lock
                client = null;
                logger.info('✅ Client distrutto.');
            } catch (err) {
                logger.info('❌ Errore o Timeout durante la distruzione del client:', err.message);
                // Force cleanup
                client = null;
            }

            if (pid) {
                try { execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
                await new Promise(r => setTimeout(r, 1000));
            }
        }

        // Rotazione Session ID per aggirare i file lock dei processi orfani di Chrome
        config.clientId = 'session_' + Date.now();
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        logger.info(`🔄 Generata nuova cartella sessione per scavalcare i file in uso: ${config.clientId}`);
        logger.info(`🔄 Generato nuovo clientId al logout: ${config.clientId}`);

        const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
        if (fs.existsSync(cachePath)) {
            try {
                fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 });
                logger.info('🗑️ Cache rimossa.');
            } catch (err) {
                logger.error('⚠️ Errore rimozione cache:', err.message);
            }
        }

        wpStatus = 'DISCONNECTED';
        latestQR = null;
        isInitializing = false;

        // Re-inizializza dopo un piccolo delay
        setTimeout(initializeClient, 2000); // Aumentato a 2 secondi

        res.json({ success: true, message: 'Disconnesso. Il client si sta riavviando.' });
    } catch (error) {
        logger.error('❌ Errore durante il logout:', error);
        fs.writeFileSync(path.join(DATA_DIR, 'logout_error.txt'), error.toString() + '\n' + (error.stack || ''));
        res.status(500).json({ error: 'Errore durante il logout: ' + error.message });
    }
});

app.post('/api/reset', async (req, res) => {
    logger.info('🔄 Richiesta RESET Sessione Ricevuta...');
    logger.info('🔄 Richiesta RESET Sessione Ricevuta...');
    try {
        if (client) {
            let pid = null;
            try {
                if (client.pupBrowser && client.pupBrowser.process()) {
                    pid = client.pupBrowser.process().pid;
                }
            } catch (e) { }

            try {
                // Timeout su destroy per evitare che rimanga appeso
                const destroyPromise = client.destroy();
                const timeoutPromise = new Promise((_, reject) =>
                    setTimeout(() => reject(new Error('Timeout distruzione client durante reset')), 5000)
                );
                await Promise.race([destroyPromise, timeoutPromise]);
                await new Promise(r => setTimeout(r, 1000)); // Attendi rilascio file lock
                logger.info('✅ Client distrutto durante reset.');
            } catch (err) {
                logger.info('ℹ️ Errore/Timeout distruzione client durante reset:', err.message);
                logger.info(`ℹ️ Errore/Timeout distruzione client: ${err.message}`);
            }
            client = null;

            if (pid) {
                logger.info(`🧹 Forzo sicurezza kill su PID noto del browser: ${pid}`);
                try { execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
                await new Promise(r => setTimeout(r, 1500)); // Attendi che Windows rilasci fisicamente i file
            }
        }

        // client.destroy() con timeout si occupa di chiudere il browser puppeteer
        // Rotazione Server ID per bypassare radicalmente i locks di Chrome fantasma
        config.clientId = 'session_' + Date.now();
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        logger.info(`🗑️ Nuova sessione assegnata: ${config.clientId}. Vecchia folder ignorata se bloccata.`);
        logger.info(`🗑️ Rotazione clientId per reset: ${config.clientId}.`);

        // Rimuovi anche la cache per un reset completo
        const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
        if (fs.existsSync(cachePath)) {
            try {
                fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 });
                logger.info('🗑️ Cache rimossa durante reset.');
            } catch (err) {
                logger.error('⚠️ Errore rimozione cache durante reset:', err.message);
            }
        }

        wpStatus = 'DISCONNECTED';
        latestQR = null;
        isInitializing = false;

        // Piccola attesa prima di reinizializzare
        setTimeout(initializeClient, 2000);

        res.json({ success: true, message: 'Sessione resettata. Nuovo QR in generazione...' });
    } catch (error) {
        logger.error('❌ Errore durante il reset:', error);
        logger.info(`❌ Errore durante il reset: ${error.message}`);
        res.status(500).json({ error: 'Errore durante il reset: ' + error.message });
    }
});

app.post('/api/system/close', async (req, res) => {
    logger.info('🔌 Richiesta chiusura servizio ricevuta...');
    res.json({ success: true, message: 'Servizio in chiusura...' });
    setTimeout(() => handleGracefulShutdown('API_CLOSE'), 1000);
});

app.get('/api/system/logs', (req, res) => {
    const logPath = path.join(DATA_DIR, 'app_debug.log');
    if (!fs.existsSync(logPath)) {
        return res.json({ logs: 'Nessun log di sistema trovato.' });
    }
    try {
        const content = fs.readFileSync(logPath, 'utf8');
        const lines = content.split('\n');
        const lastLines = lines.slice(-150).join('\n');
        res.json({ logs: lastLines });
    } catch (err) {
        res.status(500).json({ error: 'Impossibile leggere i log: ' + err.message });
    }
});

app.post('/api/system/shutdown', async (req, res) => {
    logger.info('🔌 Richiesta arresto PC ricevuta...');
    res.json({ success: true, message: 'Chiusura sicura di WhatsApp in corso... Il computer si spegnerà a breve.' });

    setTimeout(async () => {
        // 1. Chiusura pulita di WhatsApp
        if (client) {
            try {
                await Promise.race([
                    client.destroy(),
                    new Promise((_, r) => setTimeout(() => r(new Error('Timeout')), 4000))
                ]).catch(() => { });
            } catch (e) { }
        }

        // 2. Lancia arresto Windows
        exec('shutdown /s /t 0 /f', (err) => {
            if (err) logger.error('Errore esecuzione shutdown:', err);
            process.exit(0);
        });
    }, 1000);
});

app.get('/api/config', (req, res) => {
    res.json(config);
});

app.post('/api/config', (req, res) => {
    try {
        config = { ...config, ...req.body };
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        res.json({ success: true, config });
    } catch (error) {
        res.status(500).json({ error: 'Impossibile salvare la configurazione' });
    }
});

app.get('/api/update/check', async (req, res) => {
    // Controllo revoca licenza in background se configurato
    if (licenseInfo.activationKey && config.updatesUrl) {
        const baseUrl = config.updatesUrl.replace(/\/+$/, '');
        const licenseUrl = `${baseUrl}/licenses/${licenseInfo.activationKey}.json`;
        axios.get(licenseUrl, { timeout: 4000 }).then(async (response) => {
            if (response.status === 200 && response.data) {
                const remoteLicense = response.data;
                const LICENSE_SALT = 'PrintZapSecretSalt2026';
                const payload = `${remoteLicense.customer}|${remoteLicense.expiryDate || 'never'}|${LICENSE_SALT}`;
                const expectedKey = crypto.createHash('sha256').update(payload).digest('hex');

                // Se la licenza online ha una firma diversa o è stata disattivata, invalidala localmente
                if (remoteLicense.key !== expectedKey || remoteLicense.active === false) {
                    logger.info('⚠️ Rilevata licenza online non più valida o disattivata. Blocco del servizio.');
                    licenseInfo.active = false;
                    const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
                    fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
                    wpStatus = 'EXPIRED';
                    if (client) {
                        client.destroy().catch(() => { });
                        client = null;
                    }
                }
            }
        }).catch(async (err) => {
            // Se il server risponde con 404, significa che la licenza è stata eliminata (revocata)
            if (err.response && err.response.status === 404) {
                logger.info('⚠️ Licenza revocata dall\'amministratore (file non trovato online). Blocco del servizio.');
                licenseInfo.active = false;
                const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
                fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
                wpStatus = 'EXPIRED';
                if (client) {
                    client.destroy().catch(() => { });
                    client = null;
                }
            }
            // Per altri tipi di errore (es. rete non disponibile), non facciamo nulla: il cliente continua a usare il software offline
        });
    }

    if (!config.updatesUrl) {
        return res.json({ updateAvailable: false, message: 'URL aggiornamenti non configurato.' });
    }
    try {
        const baseUrl = config.updatesUrl.replace(/\/+$/, '');
        const resRemote = await axios.get(`${baseUrl}/version.json?t=${Date.now()}`, { timeout: 5000 });
        if (resRemote.status === 200 && resRemote.data) {
            const remoteInfo = resRemote.data;
            const remoteVersion = remoteInfo.version;

            const parseVersion = (v) => {
                if (typeof v !== 'string') return [0];
                return v.split('.').map(val => parseInt(val, 10) || 0);
            };
            const localParts = parseVersion(APP_VERSION);
            const remoteParts = parseVersion(remoteVersion);

            let updateAvailable = false;
            for (let i = 0; i < Math.max(localParts.length, remoteParts.length); i++) {
                const lp = localParts[i] || 0;
                const rp = remoteParts[i] || 0;
                if (rp > lp) {
                    updateAvailable = true;
                    break;
                } else if (lp > rp) {
                    break;
                }
            }
            res.json({
                updateAvailable,
                currentVersion: APP_VERSION,
                latestVersion: remoteVersion,
                zipUrl: remoteInfo.zipUrl,
                notes: remoteInfo.notes || 'Nessuna nota di rilascio fornita.'
            });
        } else {
            res.status(500).json({ error: 'Impossibile leggere le informazioni di versione dal server remoto.' });
        }
    } catch (error) {
        logger.error('Errore durante il controllo versione:', error);
        res.status(500).json({ error: 'Errore durante la connessione al server di aggiornamento.' });
    }
});

app.post('/api/update/download', async (req, res) => {
    const { zipUrl } = req.body;
    if (!zipUrl) {
        return res.status(400).json({ error: 'URL dello ZIP non fornito.' });
    }

    try {
        const tmpDir = path.join(DATA_DIR, 'tmp');
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }

        const zipPath = path.join(tmpDir, 'update.zip');
        logger.info(`📥 Avvio download aggiornamento da: ${zipUrl}`);

        const response = await axios({
            method: 'get',
            url: zipUrl,
            responseType: 'stream',
            timeout: 30000
        });

        const writer = fs.createWriteStream(zipPath);
        response.data.pipe(writer);

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        logger.info('✅ Download completato. Scrittura script di aggiornamento aggiorna.bat...');

        const currentPid = process.pid;
        const logFile = path.join(DATA_DIR, 'aggiornamento_log.txt');
        
        // Creazione dello script batch per sovrascrittura e riavvio
        const batchScript = `@echo off
echo ========================================================
echo   AGGIORNAMENTO DI PRINTZAP IN CORSO...
echo   Non chiudere questa finestra.
echo ========================================================

echo [LOG] Inizio aggiornamento: %date% %time% > "${logFile}"

echo [1/4] Spegnimento sicuro del servizio PrintZap...
echo [LOG] Spegnimento Node PID ${currentPid}... >> "${logFile}"
taskkill /F /PID ${currentPid} > nul 2>&1

echo [LOG] Spegnimento processi Chrome/Puppeteer orfani... >> "${logFile}"
taskkill /F /IM chrome.exe > nul 2>&1
taskkill /F /IM msedge.exe > nul 2>&1
echo [LOG] Attesa rilascio file lock (5 secondi)... >> "${logFile}"
timeout /t 5 /nobreak > nul

echo [2/4] Estrazione dei nuovi file in corso...
echo [LOG] Estrazione ZIP da: ${zipPath} >> "${logFile}"
echo [LOG] Destinazione: ${ROOT_DIR} >> "${logFile}"
powershell -NoProfile -Command "try { Expand-Archive -Path '${zipPath}' -DestinationPath '${ROOT_DIR}' -Force; Write-Output 'OK' } catch { Write-Output ('ERRORE: ' + $_.Exception.Message) }" > "${path.join(DATA_DIR, 'extract_result.txt')}" 2>&1

set /p EXTRACT_RESULT=<"${path.join(DATA_DIR, 'extract_result.txt')}"
echo [LOG] Risultato estrazione: %EXTRACT_RESULT% >> "${logFile}"

if /i not "%EXTRACT_RESULT%"=="OK" (
    echo.
    echo ========================================================
    echo   ERRORE DURANTE L'ESTRAZIONE DEI FILE!
    echo   Dettagli: %EXTRACT_RESULT%
    echo   Controlla il file di log: ${logFile}
    echo ========================================================
    echo [LOG] AGGIORNAMENTO FALLITO >> "${logFile}"
    del "${path.join(DATA_DIR, 'extract_result.txt')}" > nul 2>&1
    pause
    exit /b 1
)

del "${path.join(DATA_DIR, 'extract_result.txt')}" > nul 2>&1

echo [3/4] Pulizia dei file temporanei...
del "${zipPath}" > nul 2>&1

echo [4/4] Riavvio dell'applicazione...
echo [LOG] Riavvio tramite wscript PrintZap.vbs >> "${logFile}"
echo [LOG] AGGIORNAMENTO COMPLETATO CON SUCCESSO >> "${logFile}"

echo ========================================================
echo   AGGIORNAMENTO COMPLETATO CON SUCCESSO!
echo   Riavvio dell'applicazione in corso...
echo ========================================================
timeout /t 2 /nobreak > nul

cd /d "${ROOT_DIR}"
wscript.exe "${path.join(ROOT_DIR, 'PrintZap.vbs')}"
exit
`;

        const scriptPath = path.join(DATA_DIR, 'aggiorna.bat');
        fs.writeFileSync(scriptPath, batchScript, 'utf8');
        logger.info('🚀 Lancio script aggiorna.bat come Amministratore ed esco dal processo principale...');

        res.json({ success: true, message: 'Download completato. Avvio installazione...' });

        // Esegue il file batch come Amministratore per poter scrivere in Program Files (x86)
        const psCommand = `Start-Process cmd.exe -ArgumentList '/c "${scriptPath}"' -Verb RunAs`;
        const child = spawn('powershell.exe', ['-Command', psCommand], {
            detached: true,
            stdio: 'ignore'
        });
        child.unref();

        setTimeout(() => process.exit(0), 1000);

    } catch (error) {
        logger.error('Errore durante il download o la preparazione dell\'aggiornamento:', error);
        res.status(500).json({ error: 'Errore durante il download dell\'aggiornamento: ' + error.message });
    }
});

app.get('/api/orders', async (req, res) => {
    try {
        const orders = await db.getOrders(200);
        res.json(orders);
    } catch (error) {
        logger.error('Errore recupero ordini:', error);
        res.status(500).json({ error: 'Errore interno del database' });
    }
});

app.post('/api/orders/:id/print', async (req, res) => {
    const { id } = req.params;
    try {
        await db.markOrderPrinted(id);
        res.json({ success: true });
    } catch (error) {
        logger.error(`Errore print ordine ${id}:`, error);
        res.status(500).json({ error: 'Errore interno del database' });
    }
});

app.post('/api/orders/:id/open-folder', async (req, res) => {
    const { id } = req.params;
    try {
        const order = await db.getOrderById(id);
        if (order) {
            const folderPath = path.join(PRINT_FOLDER, path.dirname(order.file));
            if (fs.existsSync(folderPath)) {
                // Validate folderPath and use spawn
                const resolvedPath = path.resolve(folderPath);
                if (!resolvedPath.startsWith(path.resolve(PRINT_FOLDER))) {
                    throw new Error('Percorso non valido');
                }
                spawn('explorer.exe', [resolvedPath]);
                res.json({ success: true });
            } else {
                res.status(404).json({ error: 'Cartella non trovata' });
            }
        } else {
            res.status(404).json({ error: 'Ordine non trovato' });
        }
    } catch (error) {
        logger.error(`Errore open-folder ordine ${id}:`, error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.post('/api/orders/:id/open-file', async (req, res) => {
    const { id } = req.params;
    try {
        const order = await db.getOrderById(id);
        if (order) {
            const filePath = path.join(PRINT_FOLDER, order.file);
            if (fs.existsSync(filePath)) {
                // Validate filePath and use spawn
                const resolvedPath = path.resolve(filePath);
                if (!resolvedPath.startsWith(path.resolve(PRINT_FOLDER))) {
                    throw new Error('Percorso non valido');
                }
                spawn('explorer.exe', [resolvedPath]);
                res.json({ success: true });
            } else {
                res.status(404).json({ error: 'File non trovato' });
            }
        } else {
            res.status(404).json({ error: 'Ordine non trovato' });
        }
    } catch (error) {
        logger.error(`Errore open-file ordine ${id}:`, error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.post('/api/orders/:id/notify', async (req, res) => {
    const { id } = req.params;
    try {
        const order = await db.getOrderById(id);
        if (order) {
            try {
                // Invia il messaggio di "Stampa pronta"
                const message = config.notifyMessage || `✅ *Stampa Pronta!* 🖨️\nIl tuo documento è pronto per il ritiro.`;

                let recipientJid = null;
                if (order.msgId) {
                    const parts = order.msgId.split('_');
                    if (parts.length >= 2) {
                        recipientJid = parts[1];
                    }
                }
                if (!recipientJid) {
                    recipientJid = order.telefono.includes('@')
                        ? order.telefono
                        : (order.telefono.length >= 15 ? order.telefono + '@lid' : order.telefono + '@c.us');
                }

                logger.info(`Sending print ready notification to: ${recipientJid}`);
                await client.sendMessage(recipientJid, message);

                // Segna come stampato TUTTI gli ordini per questo contatto che non lo sono già
                await db.markContactOrdersPrinted(order.telefono);

                res.json({ success: true });
            } catch (error) {
                logger.error('Errore invio notifica:', error);
                res.status(500).json({ error: 'Impossibile inviare il messaggio WhatsApp' });
            }
        } else {
            res.status(404).json({ error: 'Ordine non trovato' });
        }
    } catch (error) {
        logger.error(`Errore notify ordine ${id}:`, error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.delete('/api/orders/bulk', async (req, res) => {
    const { ids } = req.body;
    if (!Array.isArray(ids)) return res.status(400).json({ error: 'IDs must be an array' });

    try {
        await db.archiveOrders(ids);
        res.json({ success: true, archived: ids.length });
    } catch (error) {
        logger.error('Errore archiviazione bulk:', error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.delete('/api/orders', async (req, res) => {
    try {
        const orders = await db.getOrders(999999);
        orders.forEach(order => {
            deleteFileWithCleanup(order.file);
        });

        await db.deleteAllOrders();
        res.json({ success: true, deleted: orders.length });
    } catch (error) {
        logger.error('Errore svuotamento ordini:', error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.delete('/api/orders/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const orderToDelete = await db.getOrderById(id);

        if (orderToDelete) {
            await db.archiveOrder(id);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'Ordine non trovato' });
        }
    } catch (error) {
        logger.error(`Errore archiviazione ordine ${id}:`, error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

// Helper per cancellare file e pulire cartelle vuote
function deleteFileWithCleanup(relativePath) {
    if (!relativePath) return; // Ignora se non c'è file (es. note)
    const filePath = path.join(PRINT_FOLDER, relativePath);
    if (fs.existsSync(filePath)) {
        try {
            fs.unlinkSync(filePath);

            // Tenta di rimuovere la cartella genitore se vuota
            const folderPath = path.dirname(filePath);
            // Verifica che siamo ancora dentro la PRINT_FOLDER per sicurezza
            if (folderPath.startsWith(PRINT_FOLDER) && folderPath !== PRINT_FOLDER) {
                const files = fs.readdirSync(folderPath);
                if (files.length === 0) {
                    fs.rmdirSync(folderPath);
                    logger.info(`🧹 Cartella vuota rimossa: ${folderPath}`);
                }
            }
        } catch (err) {
            logger.error(`Errore durante la pulizia del file ${relativePath}:`, err);
        }
    }
}

// Serve i file da stampare (per anteprima e audio)
app.use('/api/file', express.static(PRINT_FOLDER));

// Serve il frontend (dopo il build)
const dashboardPath = path.join(ROOT_DIR, 'dashboard', 'dist');
if (fs.existsSync(dashboardPath)) {
    app.use(express.static(dashboardPath));
}

app.get('/api/license', (req, res) => {
    const status = checkLicense();
    res.json({
        ...status,
        customer: licenseInfo.customer || null,
        expiryDate: licenseInfo.expiryDate || null,
        activationKey: licenseInfo.activationKey || null
    });
});

app.post('/api/license/activate', async (req, res) => {
    const { key } = req.body;
    if (!key || !key.trim()) {
        return res.status(400).json({ error: 'La chiave di licenza non può essere vuota.' });
    }

    if (!config.updatesUrl) {
        return res.status(400).json({ error: 'Impossibile scaricare la licenza: URL degli aggiornamenti (updatesUrl) non configurato nelle Impostazioni.' });
    }

    const baseUrl = config.updatesUrl.replace(/\/+$/, '');
    const cleanKey = key.trim().replace(/\.json$/i, '');
    const url = `${baseUrl}/licenses/${cleanKey}.json`;

    logger.info(`📥 Tentativo di attivazione online con chiave: ${cleanKey} da ${url}...`);

    try {
        const response = await axios.get(url, { timeout: 10000 });
        if (response.status !== 200 || typeof response.data !== 'object') {
            throw new Error('Risposta del server non valida.');
        }

        const remoteLicense = response.data;

        // Validazione crittografica locale
        const LICENSE_SALT = 'PrintZapSecretSalt2026';
        if (!remoteLicense.customer || !remoteLicense.key) {
            return res.status(400).json({ error: 'Il file di licenza scaricato è invalido o non firmato.' });
        }

        const payload = `${remoteLicense.customer}|${remoteLicense.expiryDate || 'never'}|${LICENSE_SALT}`;
        const expectedKey = crypto.createHash('sha256').update(payload).digest('hex');

        if (remoteLicense.key !== expectedKey) {
            return res.status(400).json({ error: 'Firma di licenza non valida. Possibile file corrotto o contraffatto.' });
        }

        // Aggiungi la chiave di attivazione utilizzata per controlli futuri
        remoteLicense.activationKey = cleanKey;

        // Salva localmente la licenza come license.json
        const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
        fs.writeFileSync(LICENSE_FILE, JSON.stringify(remoteLicense, null, 2));

        // Ricarica la licenza in memoria
        loadLicense();
        const status = checkLicense();

        logger.info(`✅ Licenza attivata con successo per: ${remoteLicense.customer}`);

        // Se il client era scaduto ed è spento, proviamo a riavviarlo
        if (wpStatus === 'EXPIRED') {
            wpStatus = 'DISCONNECTED';
            setTimeout(initializeClient, 1000);
        }

        res.json({
            success: true,
            message: 'Attivazione completata con successo!',
            license: remoteLicense,
            status: status.message
        });
    } catch (err) {
        logger.error(`❌ Errore durante l'attivazione della chiave ${cleanKey}:`, err.message);
        res.status(500).json({ error: `Impossibile scaricare o convalidare la chiave di licenza. Verifica che la chiave sia corretta e che il computer sia connesso a internet.` });
    }
});

async function saveOrderInfo(orderData) {
    try {
        await db.saveOrder(orderData);
    } catch (err) {
        logger.error('❌ Errore salvataggio ordine su SQLite:', err);
    }
}

function saveNote(cliente, nota) {
    const notesFile = path.join(DATA_DIR, 'note.txt');
    const line = `[${new Date().toLocaleString()}] ${cliente}: ${nota}\n`;
    fs.appendFileSync(notesFile, line);
}

if (fs.existsSync(dashboardPath)) {
    app.get('*', (req, res) => {
        res.sendFile(path.join(dashboardPath, 'index.html'));
    });
}

// Track active connections
const activeConnections = new Set();

const server = app.listen(PORT, async () => {
    logger.info(`🚀 Server in ascolto su http://localhost:${PORT}`);
    logger.info(`✅ Server avviato correttamente sulla porta ${PORT}`);

    try {
        const dbPath = path.join(DATA_DIR, 'ordini.db');
        logger.info(`📦 Inizializzazione database SQLite in ${dbPath}...`);
        await db.initDb(dbPath);
        logger.info('✅ Database SQLite pronto.');

        // Migrazione automatica da ordini.json se presente
        const ordersFile = path.join(DATA_DIR, 'ordini.json');
        if (fs.existsSync(ordersFile)) {
            try {
                logger.info("📦 Trovato file ordini.json. Avvio migrazione su SQLite...");
                const jsonOrders = JSON.parse(fs.readFileSync(ordersFile, 'utf8'));
                let count = 0;
                for (const order of jsonOrders) {
                    await db.saveOrder(order);
                    count++;
                }
                fs.renameSync(ordersFile, ordersFile + '.bak');
                logger.info(`✅ Migrazione completata con successo! Importati ${count} ordini. Creato backup ordini.json.bak`);
            } catch (err) {
                logger.error("❌ Errore durante la migrazione dei dati:", err);
            }
        }
    } catch (dbErr) {
        logger.error('❌ Errore critico inizializzazione database:', dbErr);
        setTimeout(() => process.exit(1), 5000);
        return;
    }

    // Avvia WhatsApp solo se il server è partito
    initializeClient();

    // Chiudi lo splash screen ed apri il browser sulla dashboard dinamicamente a server pronto
    if (process.platform === 'win32') {
        exec('taskkill /F /IM mshta.exe >nul 2>&1');
        exec(`start http://localhost:${PORT}`);
    }
}).on('connection', (socket) => {
    activeConnections.add(socket);
    socket.on('close', () => activeConnections.delete(socket));
}).on('error', (err) => {
    logger.info(`❌ ERRORE SERVER: ${err.message}`);
    if (err.code === 'EADDRINUSE') {
        logger.info(`⚠️ La porta ${PORT} è già occupata da un altro programma (forse hai già aperto il servizio?). Chiudi la versione precedente.`);
    }
    // Mostra errore all'utente prima di uscire
    logger.error('ERRORE CRITICO:', err.message);
    setTimeout(() => process.exit(1), 30000);
});

// initializeClient(); // Spostato dentro app.listen


async function handleGracefulShutdown(signal) {
    logger.info(`⏹️ Ricevuto segnale ${signal}. Chiusura pulita in corso...`);
    if (client) {
        try {
            // Distruzione client con timeout per evitare di rimanere appesi se WhatsApp risponde lentamente
            const destroyPromise = client.destroy();
            const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout destroy')), 4000));
            await Promise.race([destroyPromise, timeoutPromise]).catch(err => {
                logger.error('Errore durante client.destroy in shutdown:', err.message);
            });
        } catch (err) { }
    }

    // Chiudi tutte le connessioni attive
    activeConnections.forEach(socket => socket.destroy());

    // Chiudi il server ed esci
    server.close(() => {
        logger.info('Server chiuso correttamente');
        process.exit(0);
    });

    // Uscita forzata dopo 5 secondi
    setTimeout(() => {
        logger.error('Forzata chiusura dopo timeout di sicurezza');
        process.exit(1);
    }, 5000);
}

process.on('SIGINT', () => handleGracefulShutdown('SIGINT'));
process.on('SIGTERM', () => handleGracefulShutdown('SIGTERM'));
process.on('SIGHUP', () => handleGracefulShutdown('SIGHUP'));
