// whatsapp-print-service.js
let Client, LocalAuth;
const qrcode = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');
const express = require('express');
const cors = require('cors');
const { exec, execSync, spawn } = require('child_process');
const crypto = require('crypto');
const axios = require('axios');
const db = require('./db');
const nodemailer = require('nodemailer');
const imaps = require('imap-simple');
const { simpleParser } = require('mailparser');
const localtunnel = require('localtunnel');
let localtunnelInstance = null;
const multer = require('multer');

const APP_VERSION = '1.0.84';

const app = express();
const PORT = process.env.PORT || 3000;

// Determina la cartella radice e la cartella dati (standard Windows)
const isPkg = !!process.pkg;
const ROOT_DIR = isPkg ? path.dirname(process.execPath) : __dirname;

// Usa AppData\Roaming per dati utente se installato (in Program Files O in AppData\Local)
const isInstalled = isPkg || ROOT_DIR.toLowerCase().includes('program files') || ROOT_DIR.toLowerCase().includes('appdata\\local');
const appDataPath = process.env.APPDATA || path.join(process.env.USERPROFILE, 'AppData', 'Roaming');
const DATA_DIR = isInstalled
    ? path.join(appDataPath, 'PrintZap')
    : ROOT_DIR;

// Auto-migrazione dei dati utente da CartoleriaWhatsApp a PrintZap (preserva sessione e database)
if (isInstalled && !fs.existsSync(DATA_DIR)) {
    const oldDataDir = path.join(appDataPath, 'CartoleriaWhatsApp');
    if (fs.existsSync(oldDataDir)) {
        try {
            fs.renameSync(oldDataDir, DATA_DIR);
        } catch (migrateErr) {
            // Fallback se bloccato: procederà a ricrearla vuota
        }
    }
}

if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// --- STRUCTURED LOGGING (Scrive sia in Console che su File) ---
const pino = require('pino');
const streams = [
    { stream: process.stdout },
    { stream: fs.createWriteStream(path.join(DATA_DIR, 'app_debug.log'), { flags: 'a' }) }
];
const logger = pino({}, pino.multistream(streams));

logger.info('🚀 Avvio applicazione professionale...');
logger.info(`📂 DATA_DIR: ${DATA_DIR}`);

function notifyDashboard(data) {
    try {
        if (data && data.order) {
            logger.info(`📢 Notifica ordine dashboard (${data.channel || 'generico'}): ${data.order.id} per ${data.order.cliente}`);
        }
    } catch (e) {}
}

function sanitizeClientFolder(name, key) {
    const safeName = (name || 'Cliente').replace(/[^a-zA-Z0-9_]/g, '_');
    const safeKey = (key || 'key').replace(/[^a-zA-Z0-9_]/g, '_');
    return `Tg_${safeName}_${safeKey}`;
}

// --- PULIZIA PORTA ---
function killPort(port) {
    if (process.platform !== 'win32') return;
    try {
        const stdout = execSync(`netstat -ano | findstr :${port}`).toString();
        const lines = stdout.trim().split('\n');
        lines.forEach(line => {
            const parts = line.trim().split(/\s+/);
            const pid = parts[parts.length - 1];
            if (pid && pid !== '0' && pid !== process.pid.toString()) {
                logger.info(`🧹 Pulizia: Trovato processo ${pid} sulla porta ${port}. Terminazione...`);
                execSync(`taskkill /F /PID ${pid}`);
            }
        });
    } catch (e) {
        logger.info(`ℹ️ Info pulizia porta: ${e.message}`);
    }
}

killPort(PORT);

process.on('uncaughtException', (err) => {
    logger.info(`❌ CRASH (Uncaught Exception): ${err.message}\n${err.stack}`);
    logger.error('CRASH:', err);
    // Tieni aperto il processo per leggere l'errore se avviato da terminale
    setTimeout(() => process.exit(1), 30000);
});

process.on('unhandledRejection', (reason, promise) => {
    logger.info(`⚠️ UNHANDLED REJECTION: ${reason}`);
});

app.use(cors());
app.use(express.json());

// Add correlationId to all requests
app.use((req, res, next) => {
    req.correlationId = req.headers['x-correlation-id'] || crypto.randomUUID();
    logger.info({ correlationId: req.correlationId, path: req.path }, 'Request started');
    next();
});

// Cartelle
const PRINT_FOLDER = path.join(DATA_DIR, 'file_da_stampare');
if (!fs.existsSync(PRINT_FOLDER)) {
    fs.mkdirSync(PRINT_FOLDER, { recursive: true });
}

// Stato WhatsApp
let wpStatus = 'DISCONNECTED';
let latestQR = null;
let isSyncing = false;       // Flag: blocca eventi message durante la sync iniziale
let pendingMessages = [];    // Coda messaggi ricevuti durante la sync
let isInitializing = false;  // Flag: previene inizializzazioni parallele concorrenti

// Configurazione
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const LICENSE_FILE = path.join(DATA_DIR, 'license.json');

let config = {
    notifyMessage: "✅ *Stampa Pronta!* 🖨️\nIl tuo documento è pronto per il ritiro.",
    autoCleanupDays: 7,
    updatesUrl: "https://raw.githubusercontent.com/alfaomega-dev/cartoleria-whatsapp-updates/main",
    emailEnabled: false,
    emailHost: "",
    emailPort: 993,
    emailSecure: true,
    emailUser: "",
    emailPassword: "",
    smtpHost: "",
    smtpPort: 465,
    smtpSecure: true,
    emailCheckIntervalMinutes: 2,
    autoStartEnabled: true
};

let licenseInfo = {
    installDate: null,
    active: false,
    key: ""
};

function loadLicense() {
    if (fs.existsSync(LICENSE_FILE)) {
        try {
            licenseInfo = JSON.parse(fs.readFileSync(LICENSE_FILE, 'utf8'));
        } catch (err) {
            logger.info(`❌ Errore caricamento licenza.`);
        }
    } else {
        licenseInfo.installDate = new Date().toISOString();
        fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
    }
}

function checkLicense() {
    loadLicense();

    // Salt segreto per impedire la manomissione delle licenze
    const LICENSE_SALT = 'CartoleriaWhatsAppSecretSalt2026';

    // Se c'è una licenza firmata
    if (licenseInfo.customer && licenseInfo.key) {
        // Ricalcola il codice hash di verifica
        const payload = `${licenseInfo.customer}|${licenseInfo.expiryDate || 'never'}|${LICENSE_SALT}`;
        const expectedKey = crypto.createHash('sha256').update(payload).digest('hex');

        if (licenseInfo.key === expectedKey) {
            // Controlla data di scadenza
            if (licenseInfo.expiryDate && licenseInfo.expiryDate !== 'never') {
                const expiry = new Date(licenseInfo.expiryDate);
                const now = new Date();
                if (now > expiry) {
                    return { valid: false, message: `Licenza scaduta il ${expiry.toLocaleDateString()}` };
                }
                const diffDays = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));
                return { valid: true, isTrial: false, active: true, message: `Licenza valida per ${licenseInfo.customer}. Scadenza: ${expiry.toLocaleDateString()} (Rimangono ${diffDays} giorni).` };
            }
            return { valid: true, isTrial: false, active: true, message: `Licenza attiva a vita per: ${licenseInfo.customer}` };
        } else {
            logger.error('🛑 Tentativo di manomissione licenza rilevato!');
        }
    }

    // Se non c'è licenza attiva o è manomessa, controlla il periodo di prova (Trial)
    const installDate = new Date(licenseInfo.installDate || new Date());
    const now = new Date();
    const diffTime = Math.abs(now - installDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    const TRIAL_DAYS = 30; // 30 giorni di prova

    if (diffDays <= TRIAL_DAYS) {
        return {
            valid: true,
            isTrial: true,
            daysLeft: TRIAL_DAYS - diffDays,
            message: `Periodo di prova attivo: rimangono ${TRIAL_DAYS - diffDays} giorni.`
        };
    }

    return {
        valid: false,
        message: "Periodo di prova scaduto. Contatta l'amministratore per attivare la licenza."
    };
}

function sanitizeClientFolder(name, fallbackId) {
    const raw = (name || fallbackId || 'Cliente').toString().trim();
    let safe = raw.replace(/[/\\?%*:|"<>]/g, '_').replace(/\s+/g, ' ');
    if (!safe || safe.trim() === '_') {
        safe = (fallbackId || 'Cliente').toString().replace(/[/\\?%*:|"<>]/g, '_');
    }
    return safe;
}

function loadConfig() {
    // FIX: Se DATA_DIR==ROOT_DIR (modalità sviluppo/portatile), il CONFIG_FILE è lo stesso
    // del template. Per evitare di sovrascrivere le impostazioni dell'utente con i valori
    // di default del template, leggiamo prima il file e facciamo una merge sicura.
    let existingUserConfig = null;

    if (fs.existsSync(CONFIG_FILE)) {
        try {
            existingUserConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
            config = { ...config, ...existingUserConfig };
        } catch (err) {
            logger.error('❌ Errore caricamento config.json, uso default.');
        }
    } else {
        // Se non esiste in DATA_DIR, proviamo a caricarlo da ROOT_DIR (modello installato)
        // Solo se DATA_DIR != ROOT_DIR, altrimenti è già il file che stiamo leggendo
        const templateConfigPath = path.join(ROOT_DIR, 'config.json');
        if (DATA_DIR !== ROOT_DIR && fs.existsSync(templateConfigPath)) {
            try {
                const templateConfig = JSON.parse(fs.readFileSync(templateConfigPath, 'utf8'));
                // FIX: dal template prendiamo SOLO i campi non-sensibili (no token, no clientId)
                // per non sovrascrivere le impostazioni utente precedenti
                if (templateConfig.updatesUrl) config.updatesUrl = templateConfig.updatesUrl;
                if (templateConfig.notifyMessage) config.notifyMessage = templateConfig.notifyMessage;
                logger.info('📂 Caricato config.json predefinito da ROOT_DIR.');
            } catch (err) {
                logger.error('❌ Errore caricamento template config.json da ROOT_DIR.');
            }
        }
    }

    // Assicura che l'URL degli aggiornamenti sia impostato (auto-healing per file esistenti vuoti)
    if (!config.updatesUrl || !config.updatesUrl.trim()) {
        config.updatesUrl = "https://raw.githubusercontent.com/alfaomega-dev/cartoleria-whatsapp-updates/main";
    }

    // Assegna un clientId univoco alla prima esecuzione o se assente
    // FIX: NON sovrascrivere il clientId esistente - causerebbe la perdita della sessione WA e nuovo QR
    if (!config.clientId) {
        config.clientId = 'session_' + Date.now();
    }

    // Auto-healing e migrazione per parametri email multi-account
    if (config.emailEnabled === undefined) config.emailEnabled = false;
    if (config.emailCheckIntervalMinutes === undefined) config.emailCheckIntervalMinutes = 2;
    // FIX: NON sovrascrivere telegramEnabled/telegramBotToken se già configurati dall'utente
    if (config.telegramEnabled === undefined) config.telegramEnabled = false;
    if (config.telegramBotToken === undefined) config.telegramBotToken = "";
    if (config.telegramMode === undefined) config.telegramMode = "polling";
    if (config.telegramWebhookUrl === undefined) config.telegramWebhookUrl = "";
    if (config.language === undefined) config.language = 'it';
    if (config.autoStartEnabled === undefined) config.autoStartEnabled = true;
    
    if (!config.emailAccounts) {
        config.emailAccounts = [];
        
        // Se c'era già un account configurato con i vecchi parametri a livello radice, lo migriamo
        if (config.emailUser && config.emailUser.trim()) {
            config.emailAccounts.push({
                id: 'acc_' + Date.now(),
                emailUser: config.emailUser,
                emailPassword: config.emailPassword || '',
                emailHost: config.emailHost || '',
                emailPort: parseInt(config.emailPort) || 993,
                emailSecure: config.emailSecure !== undefined ? config.emailSecure : true,
                smtpHost: config.smtpHost || '',
                smtpPort: parseInt(config.smtpPort) || 465,
                smtpSecure: config.smtpSecure !== undefined ? config.smtpSecure : true
            });
        }
    }

    // Rimuoviamo i vecchi parametri obsoleti a livello radice per pulizia
    const oldFields = ['emailUser', 'emailPassword', 'emailHost', 'emailPort', 'emailSecure', 'smtpHost', 'smtpPort', 'smtpSecure'];
    let changed = false;
    oldFields.forEach(field => {
        if (config[field] !== undefined) {
            delete config[field];
            changed = true;
        }
    });

    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
    logger.info(`📋 Config caricato: telegramEnabled=${config.telegramEnabled}, clientId=${config.clientId}`);
}
loadConfig();

async function checkAndApplyHotPatch() {
    const patchDir = path.join(DATA_DIR, 'patch');
    const localPatchPath = path.join(patchDir, 'Utils.js');
    const originalPatchPath = path.join(ROOT_DIR, 'node_modules', 'whatsapp-web.js', 'src', 'util', 'Injected', 'Utils.js');

    if (!config.updatesUrl) {
        logger.info('ℹ️ Hot-Patch: updatesUrl non impostato, salto il controllo.');
        applyLocalHotPatchCache(localPatchPath);
        return;
    }

    const baseUrl = config.updatesUrl.replace(/\/+$/, '');
    const patchUrl = `${baseUrl}/patch/Utils.js`;

    logger.info(`🔍 Hot-Patch: Controllo aggiornamenti critici su: ${patchUrl}...`);

    try {
        const response = await axios.get(patchUrl, { timeout: 8000 });
        if (response.status === 200 && typeof response.data === 'string') {
            const remoteContent = response.data;

            let currentContent = '';
            if (fs.existsSync(localPatchPath)) {
                currentContent = fs.readFileSync(localPatchPath, 'utf8');
            } else if (fs.existsSync(originalPatchPath)) {
                currentContent = fs.readFileSync(originalPatchPath, 'utf8');
            }

            const remoteHash = crypto.createHash('md5').update(remoteContent).digest('hex');
            const currentHash = crypto.createHash('md5').update(currentContent).digest('hex');

            if (remoteHash !== currentHash) {
                logger.info('🔄 Hot-Patch: Trovata una nuova versione di Utils.js. Salvataggio in corso...');
                fs.mkdirSync(patchDir, { recursive: true });
                fs.writeFileSync(localPatchPath, remoteContent, 'utf8');
                logger.info('✅ Hot-Patch: Salvata patch di compatibilità WhatsApp Web con successo in DATA_DIR.');
            } else {
                logger.info('✅ Hot-Patch: Utils.js locale è già allineato alla versione remota.');
            }
        }
    } catch (err) {
        logger.error(`⚠️ Hot-Patch: Impossibile scaricare la patch remota (${err.message}). Verrà utilizzata la patch locale più recente.`);
    }

    applyLocalHotPatchCache(localPatchPath);
}

function applyLocalHotPatchCache(localPatchPath) {
    if (fs.existsSync(localPatchPath)) {
        try {
            logger.info(`🔄 Hot-Patch: Caricamento patch in memoria da: ${localPatchPath}`);
            const utilsModulePath = require.resolve('whatsapp-web.js/src/util/Injected/Utils');
            const patchedModule = require(localPatchPath);
            require.cache[utilsModulePath] = {
                id: utilsModulePath,
                filename: utilsModulePath,
                loaded: true,
                exports: patchedModule
            };
            logger.info('✅ Hot-Patch: Applicata con successo la patch in require.cache!');
        } catch (cacheErr) {
            logger.error(`⚠️ Hot-Patch: Errore nell'override di require.cache (${cacheErr.message})`);
        }
    } else {
        logger.info('ℹ️ Hot-Patch: Nessuna patch personalizzata da caricare. Verrà usata la versione predefinita.');
    }
}

function cleanupOldSessions() {
    if (process.platform !== 'win32') return;
    try {
        logger.info('🧹 Pulizia vecchie cartelle di sessione orfane...');
        logger.info('🧹 Pulizia vecchie cartelle di sessione orfane...');

        const authDir = path.join(DATA_DIR, '.wwebjs_auth');
        if (fs.existsSync(authDir)) {
            const dirs = fs.readdirSync(authDir);
            dirs.forEach(dir => {
                if (dir.startsWith('session-') && dir !== `session-${config.clientId}`) {
                    try {
                        fs.rmSync(path.join(authDir, dir), { recursive: true, force: true });
                        logger.info(`🗑️ Rimossa vecchia sessione: ${dir}`);
                    } catch (e) { }
                }
            });
        }

        const oldSessionDir = path.join(DATA_DIR, 'session');
        if (fs.existsSync(oldSessionDir)) {
            try { fs.rmSync(oldSessionDir, { recursive: true, force: true }); } catch (e) { }
        }
    } catch (e) {
        logger.info(`ℹ️ Output pulizia vecchie sessioni: ${e.message}`);
    }
}

function killOrphanedChrome() {
    if (process.platform !== 'win32') return;
    try {
        logger.info('🧹 Cerco e termino processi Chrome/Edge bloccati (Powershell+Taskkill)...');
        logger.info('🧹 Cerco processi Chrome/Edge bloccati...');

        // Estrai solo i PID numerici dei processi interessati
        const psCmd = `powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \\"Name='chrome.exe' OR Name='msedge.exe'\\" | Where-Object { $_.CommandLine -match 'PrintZap' -or $_.CommandLine -match 'wwebjs' -or $_.CommandLine -match 'cartoleria' } | Select-Object -ExpandProperty ProcessId"`;

        try {
            const pidsOutput = execSync(psCmd, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
            if (pidsOutput) {
                const pids = pidsOutput.split('\n');
                pids.forEach(pidStr => {
                    const pid = pidStr.trim();
                    if (pid && !isNaN(pid)) {
                        logger.info(`🔫 Trovato PID orfano: ${pid}. Termino albero processi...`);
                        try { execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
                    }
                });
            }
        } catch (e) {
            logger.info(`ℹ️ powershell non ha trovato processi o ha incontrato un errore`);
        }

        // Attesa bloccante puramente JS (senza comandi esterni che falliscono senza TTY)
        const start = Date.now();
        while (Date.now() - start < 1500) { }
    } catch (e) {
        logger.info(`ℹ️ Output pulizia Chrome fantasma: ${e.message}`);
        logger.info(`ℹ️ Output pulizia Chrome fantasma: ${e.message}`);
    }
}

let client;
let reconnectAttempts = 0;
const RECONNECT_BASE_DELAY = 5000;   // 5 secondi base
const RECONNECT_MAX_DELAY  = 300000; // massimo 5 minuti

async function initializeClient() {
    if (isInitializing) {
        logger.info('⚠️ initializeClient è già in corso. Ignoro chiamata parallela.');
        return;
    }
    isInitializing = true;
    logger.info('🎬 Avvio initializeClient...');
    await checkAndApplyHotPatch();

    // Caricamento differito di whatsapp-web.js per applicare l'Hot-Patch prima del require
    if (!Client || !LocalAuth) {
        try {
            logger.info('📦 Caricamento di whatsapp-web.js...');
            const wweb = require('whatsapp-web.js');
            Client = wweb.Client;
            LocalAuth = wweb.LocalAuth;
            logger.info('📦 Libreria whatsapp-web.js caricata correttamente.');
        } catch (wwebErr) {
            logger.error(`❌ Errore critico nel caricamento di whatsapp-web.js: ${wwebErr.message}`);
            isInitializing = false;
            return;
        }
    }
    cleanupOldSessions(); // Pulisce le cartelle vecchie non più in uso
    killOrphanedChrome(); // Forza sempre la pulizia prima dell'avvio o ravvio di un nuovo client

    // Pulisci la cache di WhatsApp Web per evitare versioni incompatibili
    const cachePathStartup = path.join(DATA_DIR, '.wwebjs_cache');
    if (fs.existsSync(cachePathStartup)) {
        try {
            fs.rmSync(cachePathStartup, { recursive: true, force: true });
            logger.info('🗑️ Cache WhatsApp Web rimossa per avvio pulito.');
        } catch (e) {
            logger.info('ℹ️ Impossibile rimuovere cache: ' + e.message);
        }
    }

    wpStatus = 'INITIALIZING';
    const lic = checkLicense();
    if (!lic.valid) {
        logger.error(`🛑 ${lic.message}`);
        logger.info(`🛑 LICENSE EXPIRED: ${lic.message}`);
        wpStatus = 'EXPIRED';
        isInitializing = false;
        return;
    }

    if (lic.isTrial) {
        logger.info(`💡 ${lic.message}`);
        logger.info(lic.message);
    }

    // --- RILEVAMENTO BROWSER ---
    let executablePath = undefined;

    // 1. Cerca Chrome locale (versione portabile in cartella app) - PRIORITÀ ALTA
    const localChrome = path.join(ROOT_DIR, 'chrome-win64', 'chrome.exe');

    // 2. Percorsi standard Windows per Chrome ed Edge (Chromium based) installati
    const systemChromePaths = [
        localChrome,
        // Google Chrome
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
        path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'),
        // Microsoft Edge (Perfettamente compatibile con Puppeteer)
        'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
        'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Microsoft\\Edge\\Application\\msedge.exe')
    ];

    for (const p of systemChromePaths) {
        if (p && fs.existsSync(p)) {
            executablePath = p;
            logger.info(`🌐 Browser trovato in: ${p}`);
            break;
        }
    }

    if (!executablePath) {
        logger.info("⚠️ ATTENZIONE: Chrome non trovato nel sistema. WhatsApp potrebbe non avviarsi.");
        logger.error("❌ Chrome non trovato! Installalo o aggiungi 'chrome-win64' nella cartella root.");
    }

    if (executablePath) logger.info('Chromium locale trovato:', executablePath);

    // Rimuovi eventuali file SingletonLock bloccati da precedenti chiusure brusche
    try {
        const sessionDir = path.join(DATA_DIR, '.wwebjs_auth', `session-${config.clientId}`);
        const lockFile = path.join(sessionDir, 'SingletonLock');
        if (fs.existsSync(lockFile)) {
            try {
                fs.unlinkSync(lockFile);
                logger.info('🔓 Rimosso file SingletonLock bloccato dalla sessione precedente.');
            } catch (lErr) {}
        }
    } catch (e) {}

    client = new Client({
        authStrategy: new LocalAuth({ clientId: config.clientId, dataPath: DATA_DIR }),
        puppeteer: {
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu'
            ],
            executablePath: executablePath
        },
        webVersionCache: {
            type: 'none'
        }
    });

    client.on('qr', (qr) => {
        isInitializing = false; // Il browser è avviato e aspetta lo scan
        logger.info('Scansiona questo QR con WhatsApp:');
        logger.info('📷 QR Code generato. In attesa di scansione...');
        qrcode.generate(qr, { small: true });
        wpStatus = 'WAITING_FOR_QR';
        latestQR = qr;
    });

    client.on('ready', async () => {
        isInitializing = false;
        logger.info('✅ WhatsApp connesso e pronto!');
        logger.info('✅ EVENTO READY: WhatsApp connesso e pronto!');
        wpStatus = 'CONNECTED';
        reconnectAttempts = 0; // reset backoff: connessione riuscita
        latestQR = null;

        // Attendi 3s per dare tempo a WhatsApp Web di stabilizzarsi
        // poi sincronizza messaggi non letti all'avvio
        await new Promise(r => setTimeout(r, 3000));
        isSyncing = true;
        pendingMessages = [];
        try {
            await syncUnreadMessages(client);
        } finally {
            isSyncing = false;
            // Processa i messaggi arrivati durante la sync (in ordine di arrivo)
            if (pendingMessages.length > 0) {
                logger.info(`📬 Processo ${pendingMessages.length} messaggi ricevuti durante la sync...`);
                const queue = [...pendingMessages];
                pendingMessages = [];
                for (const m of queue) {
                    await processMessageSafe(m);
                }
            }
            logger.info('✅ Sync completata. Ascolto nuovi messaggi attivo.');
        }
    });

    client.on('authenticated', () => {
        logger.info('🔑 Autenticato con successo!');
        logger.info('🔑 EVENTO AUTHENTICATED: Sessione ripristinata o nuova sessione creata.');
        wpStatus = 'AUTHENTICATING';
        latestQR = null; // Nascondi il QR dalla dashboard
    });

    client.on('auth_failure', msg => {
        isInitializing = false;
        logger.error('⛔ Errore di autenticazione:', msg);
        logger.info(`⛔ EVENTO AUTH_FAILURE: ${msg}`);
        wpStatus = 'DISCONNECTED';
    });

    client.on('message', async msg => {
        const msgId = getMessageId(msg);
        logger.info(`📥 Evento 'message' intercettato da: ${msg?.from || 'Mittente sconosciuto'} | ID: ${msgId || 'Nessuno'} | Tipo: ${msg?.type || 'Sconosciuto'}`);
        if (isSyncing) {
            // Metti in coda: verrà processato subito dopo la sync
            pendingMessages.push(msg);
            logger.info(`⏸ Messaggio in coda (sync in corso): ${msgId || 'ID sconosciuto'}`);
            return;
        }
        await processMessageSafe(msg);
    });

    client.on('message_create', async msg => {
        // Intercetta solo i messaggi inviati DA ME che contengono "stampa pronta"
        if (msg.fromMe && msg.body.toLowerCase().includes('stampa pronta')) {
            logger.info('⚡ Rilevato comando manuale "Stampa Pronta"');
            try {
                const targetId = msg.to;

                // Risolviamo il contatto per ottenere il numero reale (specialmente se è un @lid)
                const contact = await client.getContactById(targetId);
                const recipientNumber = contact.number;

                logger.info(`📩 Outgoing message to: ${targetId} | Real Phone: ${recipientNumber} | Body: ${msg.body}`);

                // Ignora gruppi
                if (!targetId || targetId.includes('@g.us')) return;

                const updated = await db.markContactOrdersPrinted(recipientNumber);
                if (updated) {
                    logger.info(`✅ Ordini per ${recipientNumber} segnati come STAMPATI (Manual Trigger SQLite)`);
                } else {
                    logger.info(`ℹ️ Nessun ordine 'nuovo' trovato per ${recipientNumber} in SQLite`);
                }
            } catch (error) {
                logger.error('❌ Errore processamento comando manuale:', error);
            }
        }
    });

    client.on('chat_removed', async chat => {
        if (chat.isGroup) return;
        const chatJid = chat.id._serialized;
        logger.info(`🗑️ Evento 'chat_removed' intercettato per la chat: ${chatJid}`);
        try {
            // Risolviamo il contatto per ottenere il numero reale (gestendo i @lid)
            const contact = await client.getContactById(chatJid);
            const phone = contact.number;

            if (phone) {
                // Recupera gli ordini associati a questo telefono per cancellare i file
                const orders = await db.getOrdersByPhone(phone);
                if (orders.length > 0) {
                    logger.info(`🗑️ Rimozione di ${orders.length} ordini associati al numero ${phone}`);

                    // Cancella i file fisici
                    orders.forEach(order => {
                        if (order.file) {
                            deleteFileWithCleanup(order.file);
                        }
                    });

                    // Rimuove gli ordini dal database
                    await db.deleteOrdersByPhone(phone);
                    logger.info(`✅ Eliminati con successo tutti gli ordini per ${phone} dal database.`);
                } else {
                    logger.info(`ℹ️ Nessun ordine presente nel database per il numero ${phone}.`);
                }
            }
        } catch (error) {
            logger.error('❌ Errore durante la rimozione automatica degli ordini per chat rimossa:', error);
        }
    });

    client.on('message_revoke_everyone', async (after, before) => {
        logger.info(`🗑️ Evento 'message_revoke_everyone' intercettato!`);
        try {
            let msgId = getMessageId(after) || getMessageId(before);
            if (!msgId && after) {
                if (after.id && after.id._serialized) msgId = after.id._serialized;
                else if (after.protocolMessageKey && after.protocolMessageKey.id) {
                    const remote = after.from || after.to || 'unknown';
                    msgId = `false_${remote}_${after.protocolMessageKey.id}`;
                }
            }
            if (!msgId && before) {
                if (before.id && before.id._serialized) msgId = before.id._serialized;
            }

            logger.info(`🔍 Revoke target msgId: ${msgId || 'Sconosciuto'}`);

            if (msgId) {
                const order = await db.getOrderByMsgId(msgId);
                if (order) {
                    logger.info(`🗑️ Trovato ordine da eliminare per messaggio revocato su WhatsApp: ID ${order.id} | File: ${order.file || 'Nessuno'}`);
                    if (order.file) {
                        deleteFileWithCleanup(order.file);
                    }
                    await db.deleteOrderById(order.id);
                    logger.info(`✅ Ordine ID ${order.id} e file associato eliminati con successo in seguito all'annullamento del cliente.`);
                } else {
                    logger.info(`ℹ️ Nessun ordine associato a msgId ${msgId} trovato nel database.`);
                }
            }
        } catch (error) {
            logger.error('❌ Errore durante il processamento del messaggio revocato:', error);
        }
    });

    client.on('disconnected', async (reason) => {
        logger.info('❌ WhatsApp disconnesso:', reason);
        logger.info(`❌ WhatsApp disconnesso: ${reason}. Inizializzo reset automatico sessione...`);
        wpStatus = 'DISCONNECTED';
        latestQR = null;
        isInitializing = false;

        if (client) {
            try {
                const destroyPromise = client.destroy();
                const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 5000));
                await Promise.race([destroyPromise, timeoutPromise]).catch(() => { });
                await new Promise(r => setTimeout(r, 1000)); // Attendi rilascio file lock
            } catch (err) { }
            client = null;
        }

        // Preserva sempre la sessione esistente (clientId) durante riavvii e disconnessioni impreviste
        // La rotazione della sessione avverrà solo se l'utente clicca esplicitamente "Disconnetti" nella Dashboard
        logger.info(`🔄 Riavvio con la sessione esistente (${config.clientId}) per preservare il login WhatsApp.`);

        const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
        if (fs.existsSync(cachePath)) {
            try { fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 }); } catch (e) { logger.info('Errore delete dir cache: ' + e.message); }
        }

        // Backoff esponenziale: ogni tentativo fallito raddoppia l'attesa fino al massimo
        reconnectAttempts++;
        const delay = Math.min(RECONNECT_BASE_DELAY * Math.pow(2, reconnectAttempts - 1), RECONNECT_MAX_DELAY);
        logger.info(`🔄 Tentativo di riconnessione #${reconnectAttempts} tra ${Math.round(delay / 1000)}s...`);
        setTimeout(initializeClient, delay);
    });

    try {
        logger.info(`🛠️ Inizializzazione client con browser: ${executablePath || 'Default'}`);
        client.initialize().catch(err => {
            logger.info(`❌ Errore in client.initialize(): ${err.message}`);
            logger.error('Errore inizializzazione:', err);
            wpStatus = 'DISCONNECTED';
            isInitializing = false;
        });
    } catch (err) {
        logger.info(`❌ Eccezione durante inizializzazione: ${err.message}`);
        wpStatus = 'DISCONNECTED';
        isInitializing = false;
    }
}

// Helper: rileva se l'errore è un errore transitorio di Puppeteer (pagina in reload)
function isPuppeteerContextError(err) {
    const msg = err && (err.message || err.toString());
    return (
        msg === 'r' ||
        (msg && msg.includes('Execution context was destroyed')) ||
        (msg && msg.includes('Cannot read properties of null')) ||
        (msg && msg.includes('Session closed'))
    );
}

// Helper: applica un timeout a una Promise
function promiseTimeout(promise, ms, name = 'Promise') {
    let timeout = new Promise((_, reject) => {
        let id = setTimeout(() => {
            clearTimeout(id);
            reject(new Error(`Timeout superato (${ms}ms) per: ${name}`));
        }, ms);
    });
    return Promise.race([promise, timeout]);
}

// Helper: estrae o genera un ID univoco per il messaggio in modo resiliente
function getMessageId(msg) {
    if (!msg) return null;
    if (msg.id) {
        if (typeof msg.id === 'string') return msg.id;
        if (msg.id._serialized) return msg.id._serialized;
        if (msg.id.id) {
            const remote = msg.id.remote || msg.from || 'unknown';
            const fromMe = msg.id.fromMe ? 'true' : 'false';
            return `${fromMe}_${remote}_${msg.id.id}`;
        }
    }
    // Fallback in caso di oggetti parziali per non scartare mai i messaggi reali
    if (msg.from && msg.timestamp) {
        return `fallback_${msg.from}_${msg.timestamp}_${msg.type || 'text'}`;
    }
    return null;
}

async function syncUnreadMessages(clientInstance = client, retryCount = 0) {
    logger.info('🔍 Sincronizzazione messaggi non letti (avvio)...');
    try {
        if (!clientInstance) {
            logger.error('❌ Errore sync: clientInstance è nullo.');
            return;
        }
        // Carica gli ID già processati per evitare duplicati
        const processedMsgIds = await db.getProcessedMessageIds();

        const chats = await promiseTimeout(clientInstance.getChats(), 15000, 'client.getChats()');

        // Filtra solo le chat private con messaggi non letti
        const unreadChats = chats.filter(chat => !chat.isGroup && chat.unreadCount > 0);

        if (unreadChats.length > 0) {
            logger.info(`📬 Trovate ${unreadChats.length} chat con messaggi non letti...`);

            for (const chat of unreadChats) {
                try {
                    const messages = await promiseTimeout(chat.fetchMessages({ limit: Math.max(chat.unreadCount, 30) }), 10000, `chat.fetchMessagesUnread(${chat.name})`);

                    const unprocessed = messages.filter(m =>
                        !m.fromMe &&
                        !processedMsgIds.has(m.id._serialized)
                    );

                    if (unprocessed.length > 0) {
                        logger.info(`📩 Chat "${chat.name}": processamento di ${unprocessed.length} nuovi messaggi...`);
                        for (const m of unprocessed) {
                            await processMessageSafe(m);
                            processedMsgIds.add(m.id._serialized);
                        }
                    }

                    // Segna come letta SOLO dopo aver processato tutto
                    await chat.sendSeen();
                } catch (chatErr) {
                    if (!isPuppeteerContextError(chatErr)) {
                        logger.error(`⚠️ Errore sincronizzazione chat "${chat.name}":`, chatErr.message);
                    }
                }
            }
        }

        logger.info('✅ Sincronizzazione all\'avvio completata.');

    } catch (error) {
        logger.info(`🔍 Dettaglio errore sync: ${error.message}\n${error.stack}`);
        if (isPuppeteerContextError(error)) {
            // Errore transitorio: WhatsApp Web stava ricaricando la pagina
            if (retryCount < 2) {
                const delay = (retryCount + 1) * 5000;
                logger.info(`⚠️ Sync interrotta (pagina in reload). Riprovo tra ${delay / 1000}s... (tentativo ${retryCount + 1}/2)`);
                await new Promise(r => setTimeout(r, delay));
                return syncUnreadMessages(clientInstance, retryCount + 1);
            } else {
                logger.info('⚠️ Sync annullata dopo 2 tentativi: pagina non ancora stabile. Riproverà al prossimo messaggio.');
            }
        } else {
            logger.error('❌ Errore durante la sincronizzazione:', error);
        }
    }
}

// Link Downloader
const linkDownloader = require('./link-downloader');

async function processMessage(msg, retryCount = 0) {

    const msgId = getMessageId(msg);
    if (!msgId) {
        logger.info('⏭ Messaggio di sistema senza ID valido ignorato.');
        return;
    }

    try {
        // Filtra storie/stati
        if (msg.isStatus) return;

        // Filtra solo chat private (esclude gruppi) con timeout di 8 secondi
        const chat = await promiseTimeout(msg.getChat(), 8000, 'msg.getChat()');
        if (chat.isGroup) return;

        // Evita di processare messaggi già salvati (controllo ID)
        const exists = await db.orderExists(msgId);
        if (exists) return;

        // Recupera contatto con timeout di 8 secondi
        const contact = await promiseTimeout(msg.getContact(), 8000, 'msg.getContact()');
        let contactName = (contact && (contact.name || contact.pushname)) ? (contact.name || contact.pushname) : null;
        if (!contactName || /^[\d\s+\-()]+$/.test(contactName.trim())) {
            try {
                if (chat && chat.name && !/^[\d\s+\-()]+$/.test(chat.name.trim())) {
                    contactName = chat.name;
                }
            } catch (e) {}
        }
        if (!contactName) {
            contactName = contact ? contact.number : 'Cliente';
        }

        // Sanitize contact name with allowlist
        const safeContactName = contactName.replace(/[^a-z0-9]/gi, '_');
        if (!/^[a-z0-9_]+$/i.test(safeContactName)) {
            throw new Error('Nome contatto non valido');
        }
        const contactFolder = path.join(PRINT_FOLDER, safeContactName);

        // --- LOGICA DI SINCRONIZZAZIONE CARTELLE ---
        const existingOrders = await db.getOrdersByPhoneAndHasFile(contact.number);

        if (existingOrders.length > 0) {
            const oldRelativeFolder = path.dirname(existingOrders[0].file);

            if (oldRelativeFolder !== safeContactName) {
                const oldFullPath = path.join(PRINT_FOLDER, oldRelativeFolder);
                if (fs.existsSync(oldFullPath)) {
                    logger.info(`🔄 Sincronizzazione: Rinomino/Sposto cartella da ${oldRelativeFolder} a ${safeContactName}`);
                    try {
                        if (!fs.existsSync(contactFolder)) {
                            fs.renameSync(oldFullPath, contactFolder);
                        } else {
                            const files = fs.readdirSync(oldFullPath);
                            for (const f of files) {
                                const src = path.join(oldFullPath, f);
                                const dest = path.join(contactFolder, f);
                                if (!fs.existsSync(dest)) fs.renameSync(src, dest);
                            }
                            try { if (fs.readdirSync(oldFullPath).length === 0) fs.rmdirSync(oldFullPath); } catch(e){}
                        }

                        await db.updateContactOrdersFolder(contact.number, contactName, safeContactName);
                    } catch (err) {
                        logger.error('❌ Errore sincronizzazione nomi:', err);
                    }
                }
            }
        }

        // --- GESTIONE LINK ---
        // Verifica se il messaggio contiene un link supportato
        const body = msg.body || "";
        const detectedService = linkDownloader.detectService(body);

        if (detectedService) {
            logger.info(`🔗 Rilevato link ${detectedService} da: ${contactName}`);

            if (!fs.existsSync(contactFolder)) {
                fs.mkdirSync(contactFolder, { recursive: true });
            }

            const timestamp = Date.now();
            // Aggiungi tag "_link" al prefisso per identificare i file scaricati da link
            const prefix = `${timestamp}_link`;
            const result = await linkDownloader.download(body, contactFolder, prefix);

            if (result.success) {
                const relativePath = `${safeContactName}/${path.basename(result.filepath)}`;
                logger.info(`✅ Link scaricato: ${relativePath}`);

                // Mappa estensione a tipo ordine
                const ext = path.extname(result.filename).toLowerCase().replace('.', '');
                let orderType = 'documento';
                if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) orderType = 'immagine';
                if (['pdf'].includes(ext)) orderType = 'pdf';

                await saveOrderInfo({
                    id: timestamp,
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: relativePath,
                    tipo: orderType,
                    messaggio: `Link ${detectedService}: ${body}`,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: 'nuovo'
                });

                // Opzionale: Rispondi al cliente
                // await msg.reply(`✅ Ho scaricato il tuo file ${detectedService}!`);
                return; // Esci per non salvare anche come nota
            } else {
                logger.error(`❌ Errore download link: ${result.error}`);
                // Se fallisce, lo salviamo comunque come nota con il link
            }
        }


        if (msg.hasMedia) {
            logger.info(`📩 Messaggio con media da: ${contactName}`);
            const media = await msg.downloadMedia();

            if (media) {
                if (!fs.existsSync(contactFolder)) {
                    fs.mkdirSync(contactFolder, { recursive: true });
                }

                const mimeMap = {
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
                    'application/msword': 'doc',
                    'application/pdf': 'pdf',
                    'application/vnd.ms-excel': 'xls',
                    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
                    'application/vnd.ms-powerpoint': 'ppt',
                    'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
                    'text/plain': 'txt',
                    'text/csv': 'csv',
                    'image/jpeg': 'jpg',
                    'image/png': 'png',
                    'image/gif': 'gif',
                    'image/webp': 'webp',
                    'image/bmp': 'bmp',
                    'image/tiff': 'tiff',
                    'video/mp4': 'mp4',
                    'application/zip': 'zip',
                    'audio/ogg; codecs=opus': 'ogg',
                    'audio/ogg': 'ogg',
                    'audio/mpeg': 'mp3',
                    'audio/mp4': 'm4a'
                };

                let ext = mimeMap[media.mimetype] || media.mimetype.split('/')[1]?.split(';')[0] || 'bin';
                if (ext.includes('wordprocessingml')) ext = 'docx';
                if (ext.includes('spreadsheetml')) ext = 'xlsx';
                if (ext.includes('presentationml')) ext = 'pptx';

                // Gestione specifica per audio/vocali
                let orderType = media.mimetype;
                if (msg.type === 'ptt' || msg.type === 'audio') {
                    orderType = 'audio';
                    if (!ext || ext === 'bin') ext = 'ogg'; // Default extension for voice notes
                }

                const timestamp = Date.now();
                let fileName;

                if (media.filename) {
                    // Se c'è un nome file originale, usalo (sanitizzato)
                    const originalName = media.filename;
                    // Ottieni l'estensione originale se disponibile
                    const originalExt = path.extname(originalName).replace('.', '');
                    
                    // Rimuovi caratteri non validi
                    const safeOriginalName = originalName.replace(/[^a-z0-9\.\-_]/gi, '_');
                    
                    if (originalExt) {
                        ext = originalExt;
                        fileName = `${timestamp}_${safeOriginalName}`;
                    } else {
                        // Se il nome file originale non ha estensione, aggiungiamo quella dedotta dal mimetype
                        fileName = `${timestamp}_${safeOriginalName}.${ext}`;
                    }
                } else {
                    // Fallback: usa timestamp + estensione dedotta
                    fileName = `${timestamp}.${ext}`;
                }

                const filePath = path.join(contactFolder, fileName);

                const buffer = Buffer.from(media.data, 'base64');
                fs.writeFileSync(filePath, buffer);

                const relativePath = `${safeContactName}/${fileName}`;
                logger.info(`✅ File salvato: ${relativePath} (Tipo: ${orderType})`);

                await saveOrderInfo({
                    id: timestamp,
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: relativePath,
                    tipo: orderType, // 'audio' se è un vocale
                    messaggio: msg.body, // Di solito vuoto per audio
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: 'nuovo'
                });
            } else {
                logger.warn(`⚠️ Impossibile scaricare i media per il messaggio ${msgId}. Salvo come nota.`);
                const warningMessage = msg.body
                    ? `${msg.body}\n\n⚠️ (Errore: Impossibile scaricare l'allegato)`
                    : `⚠️ (Errore: Impossibile scaricare l'allegato)`;

                await saveOrderInfo({
                    id: Date.now(),
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: null,
                    tipo: 'nota',
                    messaggio: warningMessage,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: 'nuovo'
                });
            }

        } else if (msg.body && !msg.fromMe) {
            logger.info(`💬 Testo da ${contactName}: ${msg.body}`);
            saveNote(contactName, msg.body);

            // Nuovo: Salva anche come "ordine" di tipo nota per la Dashboard
            await saveOrderInfo({
                id: Date.now(),
                msgId: msgId,
                cliente: contactName,
                telefono: contact.number,
                file: null, // Nessun file
                tipo: 'nota',
                messaggio: msg.body,
                data: new Date(msg.timestamp * 1000).toISOString(),
                stato: 'nuovo'
            });
        }

    } catch (error) {
        logger.info(`🔍 Dettaglio errore per msg ${msgId || '?'}: ${error.message}\n${error.stack}`);
        if (isPuppeteerContextError(error)) {
            // Errore transitorio: WhatsApp Web stava ricaricando la pagina
            if (retryCount < 3) {
                const delay = (retryCount + 1) * 3000; // 3s, 6s, 9s
                logger.info(`⚠️ Retry msg ${msgId || '?'} tra ${delay / 1000}s (tentativo ${retryCount + 1}/3)...`);
                await new Promise(r => setTimeout(r, delay));
                return processMessage(msg, retryCount + 1);
            } else {
                logger.info(`⚠️ Messaggio ${msgId || 'ID sconosciuto'} non processabile dopo 3 tentativi (pagina instabile).`);
            }
        } else {
            logger.error('❌ Errore processamento messaggio:', error);
        }
    }
}

async function processMessageSafe(msg) {
    const msgId = getMessageId(msg);
    if (!msgId) {
        logger.info('⏭ Messaggio di sistema senza ID valido ignorato.');
        return;
    }
    return processMessage(msg, 0);
}

// API Endpoints
app.get('/api/status', (req, res) => {
    res.json({ status: wpStatus, qr: latestQR });
});

app.post('/api/logout', async (req, res) => {
    logger.info('🔄 Richiesta Logout Ricevuta...');
    try {
        if (client) {
            let pid = null;
            try {
                if (client.pupBrowser && client.pupBrowser.process()) {
                    pid = client.pupBrowser.process().pid;
                }
            } catch (e) { }

            try {
                await client.logout();
                logger.info('✅ Logout effettuato.');
            } catch (err) {
                logger.info('ℹ️ Client già disconnesso o logout non necessario.');
            }
            try {
                // Wrap destroy in a race with timeout
                const destroyPromise = client.destroy();
                const timeoutPromise = new Promise((_, reject) =>
                    setTimeout(() => reject(new Error('Timeout distruzione client')), 5000)
                );

                await Promise.race([destroyPromise, timeoutPromise]);
                await new Promise(r => setTimeout(r, 1000)); // Attendi rilascio file lock
                client = null;
                logger.info('✅ Client distrutto.');
            } catch (err) {
                logger.info('❌ Errore o Timeout durante la distruzione del client:', err.message);
                // Force cleanup
                client = null;
            }

            if (pid) {
                try { execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
                await new Promise(r => setTimeout(r, 1000));
            }
        }

        // Rotazione Session ID per aggirare i file lock dei processi orfani di Chrome
        config.clientId = 'session_' + Date.now();
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        logger.info(`🔄 Generata nuova cartella sessione per scavalcare i file in uso: ${config.clientId}`);
        logger.info(`🔄 Generato nuovo clientId al logout: ${config.clientId}`);

        const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
        if (fs.existsSync(cachePath)) {
            try {
                fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 });
                logger.info('🗑️ Cache rimossa.');
            } catch (err) {
                logger.error('⚠️ Errore rimozione cache:', err.message);
            }
        }

        wpStatus = 'DISCONNECTED';
        latestQR = null;
        isInitializing = false;

        // Re-inizializza dopo un piccolo delay
        setTimeout(initializeClient, 2000); // Aumentato a 2 secondi

        res.json({ success: true, message: 'Disconnesso. Il client si sta riavviando.' });
    } catch (error) {
        logger.error('❌ Errore durante il logout:', error);
        fs.writeFileSync(path.join(DATA_DIR, 'logout_error.txt'), error.toString() + '\n' + (error.stack || ''));
        res.status(500).json({ error: 'Errore durante il logout: ' + error.message });
    }
});

app.post('/api/reset', async (req, res) => {
    logger.info('🔄 Richiesta RESET Sessione Ricevuta...');
    logger.info('🔄 Richiesta RESET Sessione Ricevuta...');
    try {
        if (client) {
            let pid = null;
            try {
                if (client.pupBrowser && client.pupBrowser.process()) {
                    pid = client.pupBrowser.process().pid;
                }
            } catch (e) { }

            try {
                // Timeout su destroy per evitare che rimanga appeso
                const destroyPromise = client.destroy();
                const timeoutPromise = new Promise((_, reject) =>
                    setTimeout(() => reject(new Error('Timeout distruzione client durante reset')), 5000)
                );
                await Promise.race([destroyPromise, timeoutPromise]);
                await new Promise(r => setTimeout(r, 1000)); // Attendi rilascio file lock
                logger.info('✅ Client distrutto durante reset.');
            } catch (err) {
                logger.info('ℹ️ Errore/Timeout distruzione client durante reset:', err.message);
                logger.info(`ℹ️ Errore/Timeout distruzione client: ${err.message}`);
            }
            client = null;

            if (pid) {
                logger.info(`🧹 Forzo sicurezza kill su PID noto del browser: ${pid}`);
                try { execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
                await new Promise(r => setTimeout(r, 1500)); // Attendi che Windows rilasci fisicamente i file
            }
        }

        // client.destroy() con timeout si occupa di chiudere il browser puppeteer
        // Rotazione Server ID per bypassare radicalmente i locks di Chrome fantasma
        config.clientId = 'session_' + Date.now();
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        logger.info(`🗑️ Nuova sessione assegnata: ${config.clientId}. Vecchia folder ignorata se bloccata.`);
        logger.info(`🗑️ Rotazione clientId per reset: ${config.clientId}.`);

        // Rimuovi anche la cache per un reset completo
        const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
        if (fs.existsSync(cachePath)) {
            try {
                fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 });
                logger.info('🗑️ Cache rimossa durante reset.');
            } catch (err) {
                logger.error('⚠️ Errore rimozione cache durante reset:', err.message);
            }
        }

        wpStatus = 'DISCONNECTED';
        latestQR = null;
        isInitializing = false;

        // Piccola attesa prima di reinizializzare
        setTimeout(initializeClient, 2000);

        res.json({ success: true, message: 'Sessione resettata. Nuovo QR in generazione...' });
    } catch (error) {
        logger.error('❌ Errore durante il reset:', error);
        logger.info(`❌ Errore durante il reset: ${error.message}`);
        res.status(500).json({ error: 'Errore durante il reset: ' + error.message });
    }
});

app.post('/api/system/close', async (req, res) => {
    logger.info('🔌 Richiesta chiusura servizio ricevuta...');
    res.json({ success: true, message: 'Servizio in chiusura...' });
    setTimeout(() => handleGracefulShutdown('API_CLOSE'), 1000);
});

app.get('/api/system/logs', (req, res) => {
    const logPath = path.join(DATA_DIR, 'app_debug.log');
    if (!fs.existsSync(logPath)) {
        return res.json({ logs: 'Nessun log di sistema trovato.' });
    }
    try {
        const content = fs.readFileSync(logPath, 'utf8');
        const lines = content.split('\n');
        const lastLines = lines.slice(-150).join('\n');
        res.json({ logs: lastLines });
    } catch (err) {
        res.status(500).json({ error: 'Impossibile leggere i log: ' + err.message });
    }
});

app.post('/api/system/shutdown', async (req, res) => {
    logger.info('🔌 Richiesta arresto PC ricevuta...');
    res.json({ success: true, message: 'Chiusura sicura di WhatsApp in corso... Il computer si spegnerà a breve.' });

    setTimeout(async () => {
        // 1. Chiusura pulita di WhatsApp
        if (client) {
            try {
                await Promise.race([
                    client.destroy(),
                    new Promise((_, r) => setTimeout(() => r(new Error('Timeout')), 4000))
                ]).catch(() => { });
            } catch (e) { }
        }

        // 2. Lancia arresto Windows
        exec('shutdown /s /t 0 /f', (err) => {
            if (err) logger.error('Errore esecuzione shutdown:', err);
            process.exit(0);
        });
    }, 1000);
});

// ===== AVVIO AUTOMATICO CON WINDOWS =====
// Aggiunge o rimuove la voce nel Registro di Windows per l'avvio automatico con il sistema
function updateAutoStart(enabled) {
    const REG_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
    const REG_NAME = 'PrintZap';

    // Determina il percorso del launcher VBS (o fallback a exe diretto)
    const vbsPath = path.join(ROOT_DIR, 'PrintZap.vbs');
    const exePath = path.join(ROOT_DIR, 'PrintZap.exe');
    let launchCmd;
    if (fs.existsSync(vbsPath)) {
        // wscript.exe avvia il VBS senza finestra terminale
        launchCmd = `wscript.exe "${vbsPath}"`;
    } else if (fs.existsSync(exePath)) {
        launchCmd = `"${exePath}" "${path.join(ROOT_DIR, 'whatsapp.js')}"`;
    } else {
        logger.info('⚠️ Avvio automatico: nessun launcher trovato (PrintZap.vbs / PrintZap.exe).');
        return;
    }

    if (enabled) {
        const regCmd = `reg add "${REG_KEY}" /v "${REG_NAME}" /t REG_SZ /d "${launchCmd}" /f`;
        exec(regCmd, (err) => {
            if (err) {
                logger.error(`❌ Errore aggiunta avvio automatico: ${err.message}`);
            } else {
                logger.info('✅ Avvio automatico con Windows: ATTIVATO.');
            }
        });
    } else {
        const regCmd = `reg delete "${REG_KEY}" /v "${REG_NAME}" /f`;
        exec(regCmd, (err) => {
            if (err && !err.message.includes('Impossibile trovare')) {
                logger.error(`❌ Errore rimozione avvio automatico: ${err.message}`);
            } else {
                logger.info('🔕 Avvio automatico con Windows: DISATTIVATO.');
            }
        });
    }
}

app.get('/api/config', (req, res) => {
    res.json(config);
});

app.post('/api/config', (req, res) => {
    try {
        const prevAutoStart = config.autoStartEnabled;
        config = { ...config, ...req.body };
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        // Aggiorna il Registro di Windows se il flag avvio automatico è cambiato
        if (config.autoStartEnabled !== prevAutoStart || req.body.autoStartEnabled !== undefined) {
            updateAutoStart(config.autoStartEnabled);
        }
        startEmailPoller();
        initTelegramService();
        res.json({ success: true, config });
    } catch (error) {
        res.status(500).json({ error: 'Impossibile salvare la configurazione' });
    }
});

app.get('/api/update/check', async (req, res) => {
    // Controllo revoca licenza in background se configurato
    if (licenseInfo.activationKey && config.updatesUrl) {
        const baseUrl = config.updatesUrl.replace(/\/+$/, '');
        const licenseUrl = `${baseUrl}/licenses/${licenseInfo.activationKey}.json`;
        axios.get(licenseUrl, { timeout: 4000 }).then(async (response) => {
            if (response.status === 200 && response.data) {
                const remoteLicense = response.data;
                const LICENSE_SALT = 'CartoleriaWhatsAppSecretSalt2026';
                const payload = `${remoteLicense.customer}|${remoteLicense.expiryDate || 'never'}|${LICENSE_SALT}`;
                const expectedKey = crypto.createHash('sha256').update(payload).digest('hex');

                // Se la licenza online ha una firma diversa o è stata disattivata, invalidala localmente
                if (remoteLicense.key !== expectedKey || remoteLicense.active === false) {
                    logger.info('⚠️ Rilevata licenza online non più valida o disattivata. Blocco del servizio.');
                    licenseInfo.active = false;
                    const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
                    fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
                    wpStatus = 'EXPIRED';
                    if (client) {
                        client.destroy().catch(() => { });
                        client = null;
                    }
                }
            }
        }).catch(async (err) => {
            // Se il server risponde con 404, significa che la licenza è stata eliminata (revocata)
            if (err.response && err.response.status === 404) {
                logger.info('⚠️ Licenza revocata dall\'amministratore (file non trovato online). Blocco del servizio.');
                licenseInfo.active = false;
                const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
                fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenseInfo, null, 2));
                wpStatus = 'EXPIRED';
                if (client) {
                    client.destroy().catch(() => { });
                    client = null;
                }
            }
            // Per altri tipi di errore (es. rete non disponibile), non facciamo nulla: il cliente continua a usare il software offline
        });
    }

    if (!config.updatesUrl) {
        return res.json({ updateAvailable: false, message: 'URL aggiornamenti non configurato.' });
    }
    try {
        const baseUrl = config.updatesUrl.replace(/\/+$/, '');
        const resRemote = await axios.get(`${baseUrl}/version.json?t=${Date.now()}`, { timeout: 5000 });
        if (resRemote.status === 200 && resRemote.data) {
            const remoteInfo = resRemote.data;
            const remoteVersion = remoteInfo.version;

            const parseVersion = (v) => {
                if (typeof v !== 'string') return [0];
                return v.split('.').map(val => parseInt(val, 10) || 0);
            };
            const localParts = parseVersion(APP_VERSION);
            const remoteParts = parseVersion(remoteVersion);

            let updateAvailable = false;
            for (let i = 0; i < Math.max(localParts.length, remoteParts.length); i++) {
                const lp = localParts[i] || 0;
                const rp = remoteParts[i] || 0;
                if (rp > lp) {
                    updateAvailable = true;
                    break;
                } else if (lp > rp) {
                    break;
                }
            }
            res.json({
                updateAvailable,
                currentVersion: APP_VERSION,
                latestVersion: remoteVersion,
                zipUrl: remoteInfo.zipUrl,
                notes: remoteInfo.notes || 'Nessuna nota di rilascio fornita.'
            });
        } else {
            res.status(500).json({ error: 'Impossibile leggere le informazioni di versione dal server remoto.' });
        }
    } catch (error) {
        logger.error('Errore durante il controllo versione:', error);
        res.status(500).json({ error: 'Errore durante la connessione al server di aggiornamento.' });
    }
});

app.post('/api/update/download', async (req, res) => {
    const { zipUrl } = req.body;
    if (!zipUrl) {
        return res.status(400).json({ error: 'URL dello ZIP non fornito.' });
    }

    try {
        const tmpDir = path.join(DATA_DIR, 'tmp');
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }

        const zipPath = path.join(tmpDir, 'update.zip');
        logger.info(`📥 Avvio download aggiornamento da: ${zipUrl}`);

        const response = await axios({
            method: 'get',
            url: zipUrl,
            responseType: 'stream',
            timeout: 30000
        });

        const writer = fs.createWriteStream(zipPath);
        response.data.pipe(writer);

        await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        logger.info('✅ Download completato. Avvio aggiornamento diretto (senza UAC)...');

        res.json({ success: true, message: 'Download completato. Avvio installazione...' });

        // Scriviamo il flag di avvenuto aggiornamento per evitare l'apertura di un secondo tab su Chrome al riavvio
        const updatedFlagPath = path.join(DATA_DIR, 'updated.flag');
        try { fs.writeFileSync(updatedFlagPath, '1'); } catch (e) {}

        // --- AGGIORNAMENTO TRAMITE SCRIPT BATCH DINAMICO ---
        // Scriviamo un file .bat che attende la chiusura di Node, pulisce i processi, estrae i file e riavvia wscript.exe
        const batPath = path.join(ROOT_DIR, 'aggiorna.bat');
        const vbsPath = path.join(ROOT_DIR, 'PrintZap.vbs');

        // FIX: Protezione config utente durante aggiornamento
        // Prima di estrarre lo ZIP, salviamo il config utente e lo ripristiniamo dopo,
        // così non viene sovrascritto da un config.json di default nello ZIP.
        const configBackupPath = path.join(DATA_DIR, 'tmp', 'config_user_backup.json');
        const configSourcePath = CONFIG_FILE; // es: AppData\Roaming\PrintZap\config.json
        // Se DATA_DIR==ROOT_DIR (modalità portatile), il config è nella stessa cartella dello ZIP
        // → dobbiamo proteggerlo esplicitamente
        const configIsInsideRootDir = configSourcePath.startsWith(ROOT_DIR);

        const batContent = `@echo off
echo Preparazione dell'aggiornamento in corso...
timeout /t 3 /nobreak > nul

echo Chiusura dei servizi attivi...
taskkill /F /IM mshta.exe > nul 2>&1
taskkill /F /IM PrintZap.exe > nul 2>&1
taskkill /F /IM node.exe > nul 2>&1
timeout /t 3 /nobreak > nul

echo Terminazione residui browser per sblocco sessione...
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe' OR Name='msedge.exe'\" | Where-Object { $_.CommandLine -match 'PrintZap' } | Stop-Process -Force" > nul 2>&1

echo Backup impostazioni utente...
if exist "${configSourcePath.replace(/\\/g, '\\\\')}" copy /Y "${configSourcePath.replace(/\\/g, '\\\\')}" "${configBackupPath.replace(/\\/g, '\\\\')}"

echo Estrazione dei nuovi file di aggiornamento...
powershell -NoProfile -Command "try { Expand-Archive -Path '${zipPath.replace(/\\/g, '\\\\')}' -DestinationPath '${ROOT_DIR.replace(/\\/g, '\\\\')}' -Force } catch { Write-Host $_.Exception.Message }"

echo Ripristino impostazioni utente (protezione sovrascrittura config)...
if exist "${configBackupPath.replace(/\\/g, '\\\\')}" copy /Y "${configBackupPath.replace(/\\/g, '\\\\')}" "${configSourcePath.replace(/\\/g, '\\\\')}"
if exist "${configBackupPath.replace(/\\/g, '\\\\')}" del /f /q "${configBackupPath.replace(/\\/g, '\\\\')}"

echo Pulizia file temporanei...
if exist "${zipPath}" del /f /q "${zipPath}"

echo Riavvio di PrintZap...
start "" "wscript.exe" "${vbsPath}"

echo Aggiornamento completato con successo!
del "%~f0"
`;

        try {
            fs.writeFileSync(batPath, batContent, 'utf8');
        } catch (writeErr) {
            logger.error('❌ Impossibile scrivere il file aggiorna.bat:', writeErr);
        }

        setTimeout(async () => {
            try {
                // 1. Chiudi il client WhatsApp/Puppeteer
                if (client) {
                    try {
                        await Promise.race([
                            client.destroy(),
                            new Promise(r => setTimeout(r, 4000))
                        ]);
                        logger.info('✅ Client WhatsApp chiuso.');
                    } catch (e) {
                        logger.warn('⚠️ Errore chiusura client:', e.message);
                    }
                }

                // 2. Chiudi il server HTTP
                for (const socket of activeConnections) {
                    socket.destroy();
                }
                server.close();

                // 3. Esegui il file batch staccato in background
                spawn('cmd.exe', ['/c', batPath], {
                    detached: true,
                    stdio: 'ignore',
                    cwd: ROOT_DIR
                }).unref();

                setTimeout(() => process.exit(0), 500);

            } catch (updateErr) {
                logger.error('❌ Errore durante l\'esecuzione del file batch:', updateErr);
                process.exit(1);
            }
        }, 1500);

    } catch (error) {
        logger.error('Errore durante il download o la preparazione dell\'aggiornamento:', error);
        res.status(500).json({ error: 'Errore durante il download dell\'aggiornamento: ' + error.message });
    }
});

function moveContactFolderOnDisk(phone, newFolder) {
    try {
        if (!phone || !newFolder) return;
        const targetDir = path.join(PRINT_FOLDER, newFolder);
        
        const possibleOldFolders = [
            path.join(PRINT_FOLDER, phone.trim()),
            path.join(PRINT_FOLDER, phone.replace(/[^a-z0-9]/gi, '_'))
        ];

        for (const oldDir of possibleOldFolders) {
            if (fs.existsSync(oldDir) && oldDir !== targetDir) {
                if (!fs.existsSync(targetDir)) {
                    fs.mkdirSync(targetDir, { recursive: true });
                }
                const files = fs.readdirSync(oldDir);
                for (const file of files) {
                    const src = path.join(oldDir, file);
                    const dest = path.join(targetDir, file);
                    try {
                        if (!fs.existsSync(dest)) {
                            fs.renameSync(src, dest);
                        }
                    } catch (e) {
                        logger.warn(`⚠️ Errore spostamento file ${file}:`, e.message);
                    }
                }
                try {
                    if (fs.readdirSync(oldDir).length === 0) {
                        fs.rmdirSync(oldDir);
                    }
                } catch (e) {}
            }
        }
    } catch (err) {
        logger.warn(`⚠️ Errore moveContactFolderOnDisk per ${phone}:`, err.message);
    }
}

async function repairMismatchedFolders() {
    try {
        const orders = await db.getOrders(9999);
        let repairedCount = 0;

        for (const order of orders) {
            if (!order.file) continue;
            const expectedPath = path.join(PRINT_FOLDER, order.file);
            
            if (!fs.existsSync(expectedPath)) {
                const fileName = path.basename(order.file);
                const targetDir = path.join(PRINT_FOLDER, path.dirname(order.file));
                
                // 1. Controlla cartella numerica basata su telefono
                if (order.telefono) {
                    const numDir = path.join(PRINT_FOLDER, order.telefono.trim());
                    const numFilePath = path.join(numDir, fileName);

                    if (fs.existsSync(numFilePath)) {
                        if (!fs.existsSync(targetDir)) {
                            fs.mkdirSync(targetDir, { recursive: true });
                        }
                        const targetFilePath = path.join(targetDir, fileName);
                        fs.renameSync(numFilePath, targetFilePath);
                        repairedCount++;
                        logger.info(`🛠 Riparazione cartella: ${numFilePath} -> ${targetFilePath}`);
                        
                        try {
                            if (fs.readdirSync(numDir).length === 0) {
                                fs.rmdirSync(numDir);
                            }
                        } catch(e){}
                        continue;
                    }
                }

                // 2. Se non ancora trovato, cerca il file in qualsiasi cartella di PRINT_FOLDER
                if (fs.existsSync(PRINT_FOLDER)) {
                    const subdirs = fs.readdirSync(PRINT_FOLDER);
                    for (const subdir of subdirs) {
                        const subdirPath = path.join(PRINT_FOLDER, subdir);
                        if (fs.statSync(subdirPath).isDirectory()) {
                            const candidateFile = path.join(subdirPath, fileName);
                            if (fs.existsSync(candidateFile)) {
                                if (!fs.existsSync(targetDir)) {
                                    fs.mkdirSync(targetDir, { recursive: true });
                                }
                                const targetFilePath = path.join(targetDir, fileName);
                                fs.renameSync(candidateFile, targetFilePath);
                                repairedCount++;
                                logger.info(`🛠 Riparazione cartella (cerca globale): ${candidateFile} -> ${targetFilePath}`);
                                try {
                                    if (fs.readdirSync(subdirPath).length === 0) {
                                        fs.rmdirSync(subdirPath);
                                    }
                                } catch(e){}
                                break;
                            }
                        }
                    }
                }
            }
        }
        if (repairedCount > 0) {
            logger.info(`✅ Riparazione completata: ${repairedCount} file riallineati nelle cartelle con nome contatto.`);
        }
    } catch (err) {
        logger.error('❌ Errore durante repairMismatchedFolders:', err);
    }
}

async function syncContactNames() {
    if (!client || wpStatus !== 'CONNECTED') return;
    try {
        await repairMismatchedFolders();

        const orders = await db.getOrders(9999);
        const numericContacts = new Map();
        orders.forEach(o => {
            if (!o.telefono || o.telefono.startsWith('tg_') || o.telefono.includes('@')) return;
            const clientTrimmed = o.cliente ? o.cliente.trim() : '';
            // Riconosce numeri puri, numeri formattati (+39...), ID interni LID o quando cliente == telefono
            if (o.telefono && clientTrimmed && (clientTrimmed === o.telefono.trim() || /^[\d\s+\-()]+$/.test(clientTrimmed))) {
                numericContacts.set(o.telefono, clientTrimmed);
            }
        });

        if (numericContacts.size === 0) return;

        logger.info(`🔄 syncContactNames: trovati ${numericContacts.size} contatti con nome numerico da risolvere...`);

        let chatNameMap = new Map();
        try {
            const allChats = await promiseTimeout(client.getChats(), 10000, 'getChats() for syncContactNames');
            allChats.forEach(chat => {
                if (!chat.isGroup && chat.id && chat.id.user && chat.name && !/^[\d\s+\-()]+$/.test(chat.name.trim())) {
                    chatNameMap.set(chat.id.user, chat.name);
                }
            });
            logger.info(`📋 syncContactNames: ${chatNameMap.size} chat caricate come mappa di fallback.`);
        } catch (chatErr) {
            logger.warn('⚠️ syncContactNames: impossibile caricare le chat per fallback:', chatErr.message);
        }

        for (const [phone, currentName] of numericContacts.entries()) {
            try {
                let resolvedName = null;

                if (chatNameMap.has(phone)) {
                    resolvedName = chatNameMap.get(phone);
                    logger.info(`✅ Nome risolto via chatMap: ${phone} -> ${resolvedName}`);
                }

                if (!resolvedName) {
                    const candidateJids = phone.includes('@')
                        ? [phone]
                        : [`${phone}@c.us`, `${phone}@lid`];

                    for (const jid of candidateJids) {
                        try {
                            const contact = await promiseTimeout(client.getContactById(jid), 4000, `getContactById(${jid})`);
                            if (contact && (contact.name || contact.pushname)) {
                                const nameCandidate = contact.name || contact.pushname;
                                if (nameCandidate && !/^[\d\s+\-()]+$/.test(nameCandidate.trim())) {
                                    resolvedName = nameCandidate;
                                    break;
                                }
                            }
                        } catch (e) {
                            logger.info(`ℹ️ getContactById(${jid}) fallito: ${e.message}`);
                        }

                        if (resolvedName) break;

                        try {
                            const chat = await promiseTimeout(client.getChatById(jid), 4000, `getChatById(${jid})`);
                            if (chat && chat.name && !/^[\d\s+\-()]+$/.test(chat.name.trim())) {
                                resolvedName = chat.name;
                                break;
                            }
                        } catch (e) {
                            logger.info(`ℹ️ getChatById(${jid}) fallito: ${e.message}`);
                        }
                    }
                }

                if (resolvedName && !/^[\d\s+\-()]+$/.test(resolvedName.trim())) {
                    const safeName = resolvedName.replace(/[^a-z0-9]/gi, '_');
                    moveContactFolderOnDisk(phone, safeName);
                    await db.updateContactOrdersFolder(phone, resolvedName, safeName);
                    logger.info(`✅ Nome contatto aggiornato: ${phone} (${currentName}) -> ${resolvedName}`);
                } else {
                    logger.info(`ℹ️ Nome NON risolto per: ${phone} (${currentName}) — contatto non trovato in rubrica.`);
                }
            } catch (err) {
                logger.warn(`⚠️ Errore risoluzione nome per ${phone}:`, err.message);
            }
        }
    } catch (err) {
        logger.error('Errore durante la risoluzione dei nomi contatti:', err);
    }
}

app.get('/api/orders', async (req, res) => {
    try {
        if (req.query.sync === 'true') {
            await syncContactNames();
        } else {
            syncContactNames().catch(() => {});
        }
        const orders = await db.getOrders(200);
        res.json(orders);
    } catch (error) {
        logger.error('Errore recupero ordini:', error);
        res.status(500).json({ error: 'Errore interno del database' });
    }
});

// ===== ESPORTAZIONE RUBRICA (CSV & VCF) =====
async function getExportableContacts() {
    const orders = await db.getOrders(999999);
    const contactsMap = new Map();

    // 1. Contatti registrati nel database SQLite
    orders.forEach(o => {
        const phone = o.telefono || '';
        if (!phone) return;
        if (!contactsMap.has(phone)) {
            contactsMap.set(phone, {
                name: o.cliente || phone,
                phone: phone,
                orderCount: 1,
                lastOrder: o.data || ''
            });
        } else {
            const existing = contactsMap.get(phone);
            existing.orderCount += 1;
            if (o.data && (!existing.lastOrder || new Date(o.data) > new Date(existing.lastOrder))) {
                existing.lastOrder = o.data;
            }
            if (o.cliente && !/^\d+$/.test(o.cliente) && /^\d+$/.test(existing.name)) {
                existing.name = o.cliente;
            }
        }
    });

    // 2. Contatti addizionali dalla rubrica WhatsApp
    if (client && wpStatus === 'CONNECTED') {
        try {
            const waContacts = await promiseTimeout(client.getContacts(), 8000, 'client.getContacts()');
            if (waContacts && Array.isArray(waContacts)) {
                waContacts.forEach(c => {
                    const number = c.number || (c.id ? c.id.user : null);
                    if (!number || c.isGroup) return;
                    const name = c.name || c.pushname || number;
                    if (!contactsMap.has(number)) {
                        contactsMap.set(number, {
                            name: name,
                            phone: number,
                            orderCount: 0,
                            lastOrder: ''
                        });
                    } else {
                        const existing = contactsMap.get(number);
                        if (name && !/^\d+$/.test(name) && /^\d+$/.test(existing.name)) {
                            existing.name = name;
                        }
                    }
                });
            }
        } catch (err) {
            logger.warn('⚠️ Impossibile recuperare contatti extra da WhatsApp per export:', err.message);
        }
    }

    return Array.from(contactsMap.values());
}

app.get('/api/contacts/export/csv', async (req, res) => {
    try {
        const contacts = await getExportableContacts();
        let csvContent = '\uFEFF'; // UTF-8 BOM per Excel
        csvContent += 'Nome;Telefono;Totale Ordini;Ultimo Ordine\n';

        contacts.forEach(c => {
            const safeName = (c.name || '').replace(/;/g, ',');
            const phone = (c.phone || '').replace(/;/g, '');
            const count = c.orderCount || 0;
            const lastDate = c.lastOrder ? new Date(c.lastOrder).toLocaleString('it-IT') : 'N/D';
            csvContent += `"${safeName}";"${phone}";${count};"${lastDate}"\n`;
        });

        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename="rubrica_printzap.csv"');
        res.status(200).send(csvContent);
    } catch (err) {
        logger.error('Errore export CSV:', err);
        res.status(500).json({ error: 'Errore durante la generazione del file CSV' });
    }
});

app.get('/api/contacts/export/vcf', async (req, res) => {
    try {
        const contacts = await getExportableContacts();
        let vcfContent = '';

        contacts.forEach(c => {
            let phone = (c.phone || '').replace(/[^0-9+]/g, '');
            if (!phone) return;
            if (!phone.startsWith('+') && !phone.startsWith('00')) {
                if (phone.startsWith('39') && phone.length >= 10) {
                    phone = '+' + phone;
                } else if (phone.length === 10) {
                    phone = '+39' + phone;
                }
            }

            const name = c.name || phone;

            vcfContent += 'BEGIN:VCARD\r\n';
            vcfContent += 'VERSION:3.0\r\n';
            vcfContent += `FN:${name}\r\n`;
            vcfContent += `TEL;TYPE=CELL:${phone}\r\n`;
            vcfContent += 'END:VCARD\r\n';
        });

        res.setHeader('Content-Type', 'text/vcard; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename="rubrica_printzap.vcf"');
        res.status(200).send(vcfContent);
    } catch (err) {
        logger.error('Errore export VCF:', err);
        res.status(500).json({ error: 'Errore durante la generazione del file VCF' });
    }
});

app.get('/api/stats', async (req, res) => {
    try {
        const stats = await db.getStatistics();
        res.json(stats);
    } catch (err) {
        logger.error('Errore recupero statistiche:', err);
        res.status(500).json({ error: 'Impossibile caricare le statistiche.' });
    }
});

app.post('/api/stats/reset-today', async (req, res) => {
    try {
        const result = await db.resetTodayStatistics();
        logger.info(`🧹 Statistiche della giornata azzerate: ${result.updatedRows} ordini spostati in archivio.`);
        res.json({ success: true, message: 'Statistiche della giornata azzerate con successo.', updatedOrders: result.updatedRows });
    } catch (err) {
        logger.error('Errore azzeramento statistiche giornata:', err);
        res.status(500).json({ error: 'Impossibile azzerare le statistiche di oggi.' });
    }
});

app.get('/api/stats/export/excel', async (req, res) => {
    try {
        const stats = await db.getStatistics();
        const now = new Date();
        const dateStr = now.toLocaleDateString('it-IT');
        const timeStr = now.toLocaleTimeString('it-IT');

        let csvContent = '\uFEFF'; // BOM UTF-8 per apertura diretta in Excel
        csvContent += `REPORT STATISTICHE PRINTZAP;Data: ${dateStr} ${timeStr}\n\n`;
        csvContent += `INDICATORE;VALORE;NOTE\n`;
        csvContent += `Totale Ordini Storici;${stats.totalOrders};Tutti gli ordini registrati\n`;
        csvContent += `Ordini di Oggi;${stats.todayOrders};Ordini ricevuti nella giornata odierna\n`;
        csvContent += `Ordini Mese Corrente;${stats.thisMonthOrders};Ordini ricevuti nel mese corrente\n`;
        csvContent += `Ordini Stampati;${stats.printedOrders};${stats.totalOrders > 0 ? Math.round((stats.printedOrders / stats.totalOrders) * 100) : 0}% del totale\n`;
        csvContent += `Ordini In Coda;${stats.pendingOrders};In attesa di stampa\n`;
        csvContent += `Ordini Archiviati;${stats.archivedOrders};Ordini completati e archiviati\n`;
        csvContent += `Clienti Unici;${stats.uniqueContacts};Numero contatti/telefoni distinti\n`;
        csvContent += `File / Documenti;${stats.filesCount};Allegati ricevuti\n`;
        csvContent += `Note di Testo;${stats.notesCount};Messaggi scritti\n`;
        csvContent += `Messaggi Vocali;${stats.audioCount};File audio ricevuti\n`;
        csvContent += `Ora di Punta;"${stats.peakHour}";Fascia oraria max affluenza\n`;
        csvContent += `Giorno di Maggior Affluenza;"${stats.peakDay}";Giorno settimana max ordini\n\n`;

        csvContent += `CANALE DI RICEZIONE;CONTEGGIO;PERCENTUALE\n`;
        csvContent += `WhatsApp Web;${stats.whatsappOrders};${stats.totalOrders > 0 ? Math.round((stats.whatsappOrders / stats.totalOrders) * 100) : 0}%\n`;
        csvContent += `Telegram Bot;${stats.telegramOrders};${stats.totalOrders > 0 ? Math.round((stats.telegramOrders / stats.totalOrders) * 100) : 0}%\n`;
        csvContent += `E-mail (IMAP);${stats.emailOrders};${stats.totalOrders > 0 ? Math.round((stats.emailOrders / stats.totalOrders) * 100) : 0}%\n\n`;

        csvContent += `TENDENZA ULTIME 7 GIORNATE;ORDINI TOTALI;ORDINI STAMPATI\n`;
        if (stats.recentDailyTrend) {
            stats.recentDailyTrend.forEach(d => {
                csvContent += `${d.label};${d.total};${d.printed}\n`;
            });
        }

        const fileName = `statistiche_printzap_${now.toISOString().split('T')[0]}.csv`;
        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
        res.status(200).send(csvContent);
    } catch (err) {
        logger.error('Errore export Excel statistiche:', err);
        res.status(500).json({ error: 'Errore durante la generazione del file Excel.' });
    }
});

app.get('/api/stats/export/pdf', async (req, res) => {
    try {
        const stats = await db.getStatistics();
        const now = new Date();
        const dateStr = now.toLocaleDateString('it-IT', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

        const html = `<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Report Statistiche Stampa - PrintZap (${dateStr})</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; color: #1e293b; margin: 30px; background-color: #ffffff; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0284c7; padding-bottom: 15px; margin-bottom: 25px; }
        .title { font-size: 22px; font-weight: bold; color: #0f172a; }
        .subtitle { font-size: 13px; color: #64748b; margin-top: 4px; }
        .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px; }
        .card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; background: #f8fafc; text-align: center; }
        .card-val { font-size: 24px; font-weight: bold; color: #0284c7; }
        .card-lbl { font-size: 12px; color: #64748b; margin-top: 4px; text-transform: uppercase; }
        .section-title { font-size: 16px; font-weight: bold; border-bottom: 1px solid #cbd5e1; padding-bottom: 6px; margin-top: 25px; margin-bottom: 12px; color: #334155; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13px; }
        th, td { border: 1px solid #e2e8f0; padding: 8px 12px; text-align: left; }
        th { background-color: #f1f5f9; color: #334155; }
        tr:nth-child(even) { background-color: #f8fafc; }
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 20px; text-align: right;">
        <button onclick="window.print()" style="padding: 8px 16px; background-color: #0284c7; color: white; border: none; border-radius: 4px; font-size: 14px; cursor: pointer;">🖨️ Stampa / Salva come PDF</button>
    </div>

    <div class="header">
        <div>
            <div class="title">📊 Report Statistiche Stampa</div>
            <div class="subtitle">Generato da PrintZap Cartoleria il ${dateStr}</div>
        </div>
        <div style="text-align: right; font-size: 12px; color: #64748b;">
            PrintZap Service
        </div>
    </div>

    <div class="grid">
        <div class="card"><div class="card-val">${stats.totalOrders}</div><div class="card-lbl">Totale Ordini Storici</div></div>
        <div class="card"><div class="card-val" style="color: #eab308;">${stats.todayOrders}</div><div class="card-lbl">Ordini Oggi</div></div>
        <div class="card"><div class="card-val" style="color: #25d366;">${stats.printedOrders}</div><div class="card-lbl">Stampati (${stats.totalOrders > 0 ? Math.round((stats.printedOrders/stats.totalOrders)*100) : 0}%)</div></div>
        <div class="card"><div class="card-val" style="color: #f97316;">${stats.pendingOrders}</div><div class="card-lbl">In Coda</div></div>
        <div class="card"><div class="card-val" style="color: #a855f7;">${stats.thisMonthOrders || 0}</div><div class="card-lbl">Questo Mese</div></div>
        <div class="card"><div class="card-val" style="color: #ec4899;">${stats.uniqueContacts}</div><div class="card-lbl">Clienti Unici</div></div>
    </div>

    <div class="section-title">⏱️ Affluenza e Orari di Punta</div>
    <table>
        <tr><th>Indicatore</th><th>Valore / Dettaglio</th></tr>
        <tr><td><strong>Ora di Punta (Peak Hour)</strong></td><td>${stats.peakHour}</td></tr>
        <tr><td><strong>Giorno di Maggior Affluenza (Peak Day)</strong></td><td>${stats.peakDay}</td></tr>
    </table>

    <div class="section-title">💬 Canali di Ricezione e Tipologie Contenuti</div>
    <table>
        <thead>
            <tr><th>Canale / Tipologia</th><th>Quantità Ordini</th><th>Percentuale</th></tr>
        </thead>
        <tbody>
            <tr><td>WhatsApp Web</td><td>${stats.whatsappOrders}</td><td>${stats.totalOrders > 0 ? Math.round((stats.whatsappOrders/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>Telegram Bot</td><td>${stats.telegramOrders}</td><td>${stats.totalOrders > 0 ? Math.round((stats.telegramOrders/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>E-mail (IMAP)</td><td>${stats.emailOrders}</td><td>${stats.totalOrders > 0 ? Math.round((stats.emailOrders/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>Documenti / File Allegati</td><td>${stats.filesCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.filesCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>Note di Testo</td><td>${stats.notesCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.notesCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>Messaggi Vocali</td><td>${stats.audioCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.audioCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
        </tbody>
    </table>

    <div class="section-title">📈 Tendenza degli Ultime 7 Giorni</div>
    <table>
        <thead>
            <tr><th>Data</th><th>Ordini Ricevuti</th><th>Ordini Stampati</th></tr>
        </thead>
        <tbody>
            ${(stats.recentDailyTrend || []).map(d => `<tr><td>${d.label}</td><td>${d.total}</td><td>${d.printed}</td></tr>`).join('')}
        </tbody>
    </table>

    <script>
        window.onload = function() {
            setTimeout(function() { window.print(); }, 500);
        };
    </script>
</body>
</html>`;
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.status(200).send(html);
    } catch (err) {
        logger.error('Errore export PDF statistiche:', err);
        res.status(500).send('Errore durante la generazione del report PDF.');
    }
});

app.post('/api/orders/:id/print', async (req, res) => {
    const { id } = req.params;
    try {
        await db.markOrderPrinted(id);
        res.json({ success: true });
    } catch (error) {
        logger.error(`Errore print ordine ${id}:`, error);
        res.status(500).json({ error: 'Errore interno del database' });
    }
});

app.post('/api/orders/bulk/print', async (req, res) => {
    const { ids } = req.body;
    if (!Array.isArray(ids)) return res.status(400).json({ error: 'IDs must be an array' });
    try {
        for (const id of ids) {
            await db.markOrderPrinted(id);
        }
        res.json({ success: true });
    } catch (error) {
        logger.error('Errore print bulk:', error);
        res.status(500).json({ error: 'Errore interno del database' });
    }
});

app.post('/api/notes', async (req, res) => {
    const { cliente, telefono, messaggio } = req.body;
    if (!cliente || !messaggio) return res.status(400).json({ error: 'Missing client or message' });
    try {
        const orderData = {
            id: 'note_' + Date.now(),
            cliente: cliente.trim(),
            telefono: telefono || '',
            file: '',
            data: new Date().toISOString(),
            stato: 'ricevuto',
            tipo: 'nota',
            messaggio: messaggio.trim()
        };
        await db.saveOrder(orderData);
        res.json({ success: true, order: orderData });
    } catch (error) {
        logger.error('Errore creazione nota manuale:', error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.post('/api/orders/:id/open-folder', async (req, res) => {
    const { id } = req.params;
    const { telefono, cliente } = req.body || {};
    try {
        let targetFolder = PRINT_FOLDER;
        if (id && id !== 'contact') {
            const order = await db.getOrderById(id);
            if (order && order.file) {
                const possibleFolder = path.join(PRINT_FOLDER, path.dirname(order.file));
                if (fs.existsSync(possibleFolder)) {
                    targetFolder = possibleFolder;
                } else if (order.telefono && fs.existsSync(path.join(PRINT_FOLDER, order.telefono))) {
                    targetFolder = path.join(PRINT_FOLDER, order.telefono);
                }
            }
        }
        
        if (targetFolder === PRINT_FOLDER && (cliente || telefono)) {
            const clientFolder = sanitizeClientFolder(cliente || telefono, telefono || cliente);
            const possibleClientFolder = path.join(PRINT_FOLDER, clientFolder);
            if (fs.existsSync(possibleClientFolder)) {
                targetFolder = possibleClientFolder;
            } else if (telefono && fs.existsSync(path.join(PRINT_FOLDER, telefono))) {
                targetFolder = path.join(PRINT_FOLDER, telefono);
            }
        }

        const resolvedPath = path.resolve(targetFolder);
        logger.info(`📂 Apertura cartella Explorer: ${resolvedPath} (ID: ${id})`);
        
        exec(`explorer "${resolvedPath}"`, (err) => {
            if (err) {
                exec(`start "" "${resolvedPath}"`);
            }
        });
        res.json({ success: true });
    } catch (error) {
        logger.error(`Errore open-folder ID ${id}:`, error);
        res.status(500).json({ error: 'Errore durante l\'apertura della cartella' });
    }
});

app.post('/api/orders/:id/open-file', async (req, res) => {
    const { id } = req.params;
    try {
        const order = await db.getOrderById(id);
        if (order && order.file) {
            let filePath = path.join(PRINT_FOLDER, order.file);
            
            if (!fs.existsSync(filePath)) {
                await repairMismatchedFolders();
                filePath = path.join(PRINT_FOLDER, order.file);
            }

            if (!fs.existsSync(filePath) && order.telefono) {
                const altPath = path.join(PRINT_FOLDER, order.telefono, path.basename(order.file));
                if (fs.existsSync(altPath)) {
                    filePath = altPath;
                }
            }

            if (fs.existsSync(filePath)) {
                const resolvedPath = path.resolve(filePath);
                logger.info(`📄 Apertura file: ${resolvedPath} (Ordine ID: ${id})`);
                
                exec(`start "" "${resolvedPath}"`, (err) => {
                    if (err) {
                        exec(`explorer /select,"${resolvedPath}"`);
                    }
                });
                return res.json({ success: true });
            } else {
                logger.warn(`⚠️ File non trovato sul disco per ordine ${id}: ${filePath}`);
                return res.status(404).json({ error: 'File non trovato sul disco' });
            }
        } else {
            logger.warn(`⚠️ Ordine non trovato o privo di file per ID ${id}`);
            return res.status(404).json({ error: 'Ordine non trovato' });
        }
    } catch (error) {
        logger.error(`Errore open-file ordine ${id}:`, error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.post('/api/orders/:id/notify', async (req, res) => {
    const { id } = req.params;
    const { message: customMessage } = req.body;
    try {
        const order = await db.getOrderById(id);
        if (order) {
            const message = customMessage || config.notifyMessage || `✅ *Stampa Pronta!* 🖨️\nIl tuo documento è pronto per il ritiro.`;

            // Se è un ordine Telegram
            if (order.telefono && order.telefono.startsWith('tg_')) {
                const token = config.telegramBotToken ? config.telegramBotToken.trim() : '';
                if (!token) {
                    return res.status(400).json({ error: 'Token Bot Telegram non configurato nelle Impostazioni.' });
                }
                try {
                    const chatId = order.telefono.replace('tg_', '');
                    logger.info(`✈️ Invio risposta Telegram a Chat ID: ${chatId}`);
                    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
                        chat_id: chatId,
                        text: message
                    });
                    logger.info(`✈️ Messaggio Telegram inviato con successo a: ${order.telefono}`);
                    await db.markContactOrdersPrinted(order.telefono);
                    return res.json({ success: true });
                } catch (tgError) {
                    logger.error('❌ Errore durante l\'invio del messaggio Telegram:', tgError);
                    return res.status(500).json({ error: 'Impossibile inviare la notifica Telegram: ' + (tgError.response?.data?.description || tgError.message) });
                }
            }

            // Se è un ordine Email
            if (order.telefono && order.telefono.includes('@')) {
                if (!config.emailEnabled) {
                    return res.status(400).json({ error: 'Configurazione E-mail non abilitata.' });
                }

                // Trova l'account e-mail corretto che ha ricevuto l'ordine
                let activeAccount = null;
                if (order.msgId && order.msgId.startsWith('email_')) {
                    const parts = order.msgId.split('_');
                    if (parts.length >= 3) {
                        const accountUser = parts[1];
                        activeAccount = config.emailAccounts.find(acc => acc.emailUser === accountUser);
                    }
                }

                // Fallback al primo account e-mail disponibile
                if (!activeAccount && config.emailAccounts && config.emailAccounts.length > 0) {
                    activeAccount = config.emailAccounts[0];
                }

                if (!activeAccount || !activeAccount.smtpHost || !activeAccount.emailUser || !activeAccount.emailPassword) {
                    return res.status(400).json({ error: 'Configurazione SMTP non abilitata o incompleta per questo account.' });
                }

                logger.info(`📧 Invio risposta email a: ${order.telefono} tramite account ${activeAccount.emailUser}`);
                try {
                    const transporter = nodemailer.createTransport({
                        host: activeAccount.smtpHost,
                        port: activeAccount.smtpPort,
                        secure: activeAccount.smtpSecure,
                        auth: {
                            user: activeAccount.emailUser,
                            pass: activeAccount.emailPassword
                        },
                        tls: {
                            rejectUnauthorized: false
                        }
                    });

                    await transporter.sendMail({
                        from: `"${activeAccount.emailUser.split('@')[0]}" <${activeAccount.emailUser}>`,
                        to: order.telefono,
                        subject: 'STAMPA PRONTA',
                        text: message
                    });

                    logger.info(`📧 E-mail inviata con successo a: ${order.telefono}`);
                    await db.markContactOrdersPrinted(order.telefono);
                    return res.json({ success: true });
                } catch (emailError) {
                    logger.error('❌ Errore durante l\'invio dell\'email:', emailError);
                    return res.status(500).json({ error: 'Impossibile inviare la notifica e-mail: ' + emailError.message });
                }
            }

            // Invio classico via WhatsApp
            try {
                let recipientJid = null;
                if (order.msgId) {
                    const parts = order.msgId.split('_');
                    if (parts.length >= 2) {
                        recipientJid = parts[1];
                    }
                }
                if (!recipientJid) {
                    recipientJid = order.telefono.length >= 15 ? order.telefono + '@lid' : order.telefono + '@c.us';
                }

                logger.info(`Sending print ready notification to: ${recipientJid}`);
                await client.sendMessage(recipientJid, message);

                // Segna come stampato TUTTI gli ordini per questo contatto che non lo sono già
                await db.markContactOrdersPrinted(order.telefono);

                res.json({ success: true });
            } catch (error) {
                logger.error('Errore invio notifica:', error);
                res.status(500).json({ error: 'Impossibile inviare il messaggio WhatsApp' });
            }
        } else {
            res.status(404).json({ error: 'Ordine non trovato' });
        }
    } catch (error) {
        logger.error(`Errore notify ordine ${id}:`, error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.delete('/api/orders/bulk', async (req, res) => {
    const { ids } = req.body;
    if (!Array.isArray(ids)) return res.status(400).json({ error: 'IDs must be an array' });

    try {
        const orders = await db.getOrdersByIds(ids);
        orders.forEach(order => {
            if (order.file) {
                deleteFileWithCleanup(order.file);
            }
        });
        await db.archiveOrders(ids);
        res.json({ success: true, archived: ids.length });
    } catch (error) {
        logger.error('Errore archiviazione bulk:', error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.delete('/api/orders', async (req, res) => {
    try {
        const channel = req.query.channel;
        let orders = await db.getOrders(999999);

        if (channel === 'email') {
            orders = orders.filter(o => o.telefono && o.telefono.includes('@'));
        } else if (channel === 'telegram') {
            orders = orders.filter(o => o.telefono && o.telefono.startsWith('tg_'));
        } else if (channel === 'whatsapp') {
            orders = orders.filter(o => o.telefono && !o.telefono.includes('@') && !o.telefono.startsWith('tg_'));
        }

        orders.forEach(order => {
            if (order.file) {
                deleteFileWithCleanup(order.file);
            }
        });

        if (channel) {
            const ids = orders.map(o => o.id);
            await db.archiveOrders(ids);
        } else {
            await db.deleteAllOrders();
        }

        res.json({ success: true, deleted: orders.length });
    } catch (error) {
        logger.error('Errore svuotamento ordini:', error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

app.delete('/api/orders/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const orderToDelete = await db.getOrderById(id);

        if (orderToDelete) {
            if (orderToDelete.file) {
                deleteFileWithCleanup(orderToDelete.file);
            }
            await db.archiveOrder(id);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'Ordine non trovato' });
        }
    } catch (error) {
        logger.error(`Errore archiviazione ordine ${id}:`, error);
        res.status(500).json({ error: 'Errore interno' });
    }
});

// Helper per cancellare file e pulire cartelle vuote
function deleteFileWithCleanup(relativePath) {
    if (!relativePath) return; // Ignora se non c'è file (es. note)
    const filePath = path.join(PRINT_FOLDER, relativePath);
    if (fs.existsSync(filePath)) {
        try {
            fs.unlinkSync(filePath);

            // Tenta di rimuovere la cartella genitore se vuota
            const folderPath = path.dirname(filePath);
            // Verifica che siamo ancora dentro la PRINT_FOLDER per sicurezza
            if (folderPath.startsWith(PRINT_FOLDER) && folderPath !== PRINT_FOLDER) {
                const files = fs.readdirSync(folderPath);
                if (files.length === 0) {
                    fs.rmdirSync(folderPath);
                    logger.info(`🧹 Cartella vuota rimossa: ${folderPath}`);
                }
            }
        } catch (err) {
            logger.error(`Errore durante la pulizia del file ${relativePath}:`, err);
        }
    }
}

// Serve i file da stampare (per anteprima e audio)
app.use('/api/file', express.static(PRINT_FOLDER));

// Serve il frontend (dopo il build)
const dashboardPath = path.join(ROOT_DIR, 'dashboard', 'dist');
if (fs.existsSync(dashboardPath)) {
    app.use(express.static(dashboardPath, {
        setHeaders: (res, filePath) => {
            res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        }
    }));
}

app.get('/api/license', (req, res) => {
    const status = checkLicense();
    res.json({
        ...status,
        customer: licenseInfo.customer || null,
        expiryDate: licenseInfo.expiryDate || null,
        activationKey: licenseInfo.activationKey || null
    });
});

app.post('/api/license/activate', async (req, res) => {
    const { key } = req.body;
    if (!key || !key.trim()) {
        return res.status(400).json({ error: 'La chiave di licenza non può essere vuota.' });
    }

    if (!config.updatesUrl) {
        return res.status(400).json({ error: 'Impossibile scaricare la licenza: URL degli aggiornamenti (updatesUrl) non configurato nelle Impostazioni.' });
    }

    const baseUrl = config.updatesUrl.replace(/\/+$/, '');
    const cleanKey = key.trim().replace(/\.json$/i, '');
    const url = `${baseUrl}/licenses/${cleanKey}.json`;

    logger.info(`📥 Tentativo di attivazione online con chiave: ${cleanKey} da ${url}...`);

    try {
        const response = await axios.get(url, { timeout: 10000 });
        if (response.status !== 200 || typeof response.data !== 'object') {
            throw new Error('Risposta del server non valida.');
        }

        const remoteLicense = response.data;

        // Validazione crittografica locale
        const LICENSE_SALT = 'CartoleriaWhatsAppSecretSalt2026';
        if (!remoteLicense.customer || !remoteLicense.key) {
            return res.status(400).json({ error: 'Il file di licenza scaricato è invalido o non firmato.' });
        }

        const payload = `${remoteLicense.customer}|${remoteLicense.expiryDate || 'never'}|${LICENSE_SALT}`;
        const expectedKey = crypto.createHash('sha256').update(payload).digest('hex');

        if (remoteLicense.key !== expectedKey) {
            return res.status(400).json({ error: 'Firma di licenza non valida. Possibile file corrotto o contraffatto.' });
        }

        // Aggiungi la chiave di attivazione utilizzata per controlli futuri
        remoteLicense.activationKey = cleanKey;

        // Salva localmente la licenza come license.json
        const LICENSE_FILE = path.join(DATA_DIR, 'license.json');
        fs.writeFileSync(LICENSE_FILE, JSON.stringify(remoteLicense, null, 2));

        // Ricarica la licenza in memoria
        loadLicense();
        const status = checkLicense();

        logger.info(`✅ Licenza attivata con successo per: ${remoteLicense.customer}`);

        // Se il client era scaduto ed è spento, proviamo a riavviarlo
        if (wpStatus === 'EXPIRED') {
            wpStatus = 'DISCONNECTED';
            setTimeout(initializeClient, 1000);
        }

        res.json({
            success: true,
            message: 'Attivazione completata con successo!',
            license: remoteLicense,
            status: status.message
        });
    } catch (err) {
        logger.error(`❌ Errore durante l'attivazione della chiave ${cleanKey}:`, err.message);
        res.status(500).json({ error: `Impossibile scaricare o convalidare la chiave di licenza. Verifica che la chiave sia corretta e che il computer sia connesso a internet.` });
    }
});

async function saveOrderInfo(orderData) {
    try {
        await db.saveOrder(orderData);
    } catch (err) {
        logger.error('❌ Errore salvataggio ordine su SQLite:', err);
    }
}

function saveNote(cliente, nota) {
    const notesFile = path.join(DATA_DIR, 'note.txt');
    const line = `[${new Date().toLocaleString()}] ${cliente}: ${nota}\n`;
    fs.appendFileSync(notesFile, line);
}

// ================= RICEZIONE ED INVIO E-MAIL (IMAP / SMTP) =================
let emailIntervalId = null;

function parseThunderbirdFilters(fileContent) {
    const rules = [];
    const lines = fileContent.split(/\r?\n/);
    let currentRule = null;

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('name=')) {
            if (currentRule && currentRule.conditions && currentRule.conditions.length > 0) {
                rules.push(currentRule);
            }
            const nameMatch = trimmed.match(/name="([^"]+)"/);
            currentRule = {
                id: 'tb_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
                name: nameMatch ? nameMatch[1] : 'Filtro Thunderbird',
                enabled: true,
                conditions: []
            };
        } else if (currentRule && trimmed.startsWith('enabled=')) {
            const val = trimmed.match(/enabled="([^"]+)"/);
            if (val && val[1] === 'no') {
                currentRule.enabled = false;
            }
        } else if (currentRule && trimmed.startsWith('condition=')) {
            const valMatch = trimmed.match(/condition="([^"]+)"/);
            if (valMatch) {
                const condString = valMatch[1];
                // Thunderbird condition format: "OR (subject,contains,Value) OR (from,contains,Other)"
                const regex = /\((subject|from|body|to|message),(contains|is|begins w|ends w),([^)]+)\)/gi;
                let match;
                while ((match = regex.exec(condString)) !== null) {
                    let field = match[1].toLowerCase();
                    if (field === 'message' || field === 'body') field = 'body';
                    let op = match[2].toLowerCase();
                    let operator = 'contains';
                    if (op === 'is') operator = 'is';
                    if (op === 'begins w') operator = 'startsWith';
                    if (op === 'ends w') operator = 'endsWith';

                    currentRule.conditions.push({
                        field,
                        operator,
                        value: match[3].trim()
                    });
                }
            }
        }
    }
    if (currentRule && currentRule.conditions && currentRule.conditions.length > 0) {
        rules.push(currentRule);
    }

    const flatRules = [];
    for (const r of rules) {
        for (const cond of r.conditions) {
            flatRules.push({
                id: 'tb_' + Date.now() + '_' + Math.random().toString(36).substr(2, 7),
                name: r.name,
                field: cond.field,
                operator: cond.operator,
                value: cond.value,
                action: 'skip',
                enabled: r.enabled
            });
        }
    }
    return flatRules;
}

function shouldFilterEmail(emailData, rules) {
    if (!rules || rules.length === 0) return false;

    for (const rule of rules) {
        if (!rule.enabled) continue;

        let textToTest = '';
        if (rule.field === 'from') {
            textToTest = emailData.from || '';
        } else if (rule.field === 'subject') {
            textToTest = emailData.subject || '';
        } else if (rule.field === 'body') {
            textToTest = emailData.body || '';
        }

        textToTest = textToTest.toLowerCase();
        const val = (rule.value || '').toLowerCase();

        let match = false;
        if (rule.operator === 'contains') {
            match = textToTest.includes(val);
        } else if (rule.operator === 'is') {
            match = textToTest === val;
        } else if (rule.operator === 'startsWith') {
            match = textToTest.startsWith(val);
        } else if (rule.operator === 'endsWith') {
            match = textToTest.endsWith(val);
        }

        if (match && rule.action === 'skip') {
            return true;
        }
    }
    return false;
}

async function checkNewEmails() {
    if (!config.emailEnabled) {
        logger.info('📧 Servizio e-mail disabilitato.');
        return { success: true, processed: 0, checkedAccounts: 0 };
    }

    if (!config.emailAccounts || config.emailAccounts.length === 0) {
        logger.warn('📧 Nessun account e-mail configurato nelle impostazioni.');
        return { success: true, processed: 0, checkedAccounts: 0 };
    }

    let totalProcessed = 0;
    let checkedAccounts = 0;

    for (const account of config.emailAccounts) {
        if (!account.emailHost || !account.emailUser || !account.emailPassword) {
            logger.warn(`📧 Credenziali incomplete per l'account: ${account.emailUser || 'sconosciuto'}, salto.`);
            continue;
        }

        checkedAccounts++;
        logger.info(`📧 Avvio controllo e-mail per: ${account.emailUser}...`);

        const imapConfig = {
            imap: {
                user: account.emailUser,
                password: account.emailPassword,
                host: account.emailHost,
                port: parseInt(account.emailPort) || 993,
                tls: account.emailSecure,
                tlsOptions: { rejectUnauthorized: false },
                authTimeout: 10000
            }
        };

        let connection;
        try {
            connection = await imaps.connect(imapConfig);
            await connection.openBox('INBOX');

            const today = new Date();
            today.setHours(0, 0, 0, 0);

            // Cerca e-mail NON LETTE del giorno corrente (ricerca leggera solo degli UIDs)
            const searchCriteria = [
                'UNSEEN',
                ['SINCE', today]
            ];
            const searchResults = await connection.search(searchCriteria);
            
            if (searchResults.length === 0) {
                logger.info(`📧 [${account.emailUser}] Nessuna nuova e-mail da elaborare per oggi.`);
                continue;
            }

            // Ordina in ordine crescente di UID e prendi le ultime 20 più recenti per evitare blocchi/hang
            searchResults.sort((a, b) => a.attributes.uid - b.attributes.uid);
            const latestUids = searchResults.slice(-20).map(msg => msg.attributes.uid);
            
            logger.info(`📧 [${account.emailUser}] Trovate ${searchResults.length} e-mail non lette per oggi. Recupero dettagli per le ultime ${latestUids.length}...`);

            const fetchOptions = {
                bodies: ['HEADER', 'TEXT', ''],
                struct: true
            };

            const messages = await connection.search([['UID', latestUids.join(',')]], fetchOptions);

            for (const message of messages) {
                try {
                    const uid = message.attributes.uid;
                    const emailOrderId = `email_${account.emailUser}_${uid}`;

                    // Verifica se questa e-mail è già stata elaborata
                    const existsNew = await db.orderExists(emailOrderId);
                    const existsOld = await db.orderExists(`email_${uid}`);
                    if (existsNew || existsOld) {
                        logger.info(`📧 [${account.emailUser}] E-mail UID ${uid} già processata. La segno come letta per risparmio banda.`);
                        await connection.addFlags(uid, '\\Seen');
                        continue;
                    }

                    // Trova la sorgente completa per il parser
                    const all = message.parts.find(part => part.which === '');
                    if (!all) {
                        await connection.addFlags(uid, '\\Seen');
                        continue;
                    }

                    const parsed = await simpleParser(all.body);
                    const senderEmail = parsed.from && parsed.from.value && parsed.from.value[0] ? parsed.from.value[0].address : 'sconosciuto@esempio.com';
                    const senderName = parsed.from && parsed.from.value && parsed.from.value[0] ? (parsed.from.value[0].name || senderEmail.split('@')[0]) : 'Cliente E-mail';
                    const subject = parsed.subject || 'Nessun Oggetto';
                    const bodyText = parsed.text || '';

                    // Applica i filtri antispam
                    const emailDataToTest = {
                        from: senderEmail,
                        subject: subject,
                        body: bodyText
                    };

                    if (shouldFilterEmail(emailDataToTest, config.emailFilters)) {
                        logger.info(`📧 [${account.emailUser}] Email UID ${uid} saltata per filtri anti-spam.`);
                        await connection.addFlags(uid, '\\Seen');
                        continue;
                    }

                    logger.info(`📧 [${account.emailUser}] Elaborazione e-mail da: ${senderEmail} - Oggetto: ${subject}`);

                    // Elabora gli allegati
                    const attachments = parsed.attachments || [];
                    if (attachments.length === 0) {
                        logger.info(`📧 [${account.emailUser}] L'e-mail da ${senderEmail} non ha allegati. La salvo come nota.`);
                        
                        const orderData = {
                            id: `email_${account.emailUser.replace(/[^a-zA-Z0-9]/g, '_')}_${uid}_text`,
                            cliente: `${senderName} (Email)`,
                            telefono: senderEmail,
                            file: "",
                            data: parsed.date ? parsed.date.toISOString() : new Date().toISOString(),
                            stato: 'ricevuto',
                            tipo: 'nota',
                            messaggio: `Oggetto: ${subject}\n\n${parsed.text || ''}`,
                            msgId: emailOrderId
                        };
                        
                        await db.saveOrder(orderData);
                        await connection.addFlags(uid, '\\Seen');
                        totalProcessed++;
                        continue;
                    }

                    const safeSenderName = senderEmail.replace(/[^a-zA-Z0-9]/g, '_');
                    const userFolder = path.join(PRINT_FOLDER, `Email_${safeSenderName}`);
                    if (!fs.existsSync(userFolder)) {
                        fs.mkdirSync(userFolder, { recursive: true });
                    }

                    let hasValidPrintFile = false;
                    let attIndex = 0;
                    for (const att of attachments) {
                        attIndex++;
                        const filename = att.filename || `allegato_${Date.now()}_${attIndex}`;
                        const extension = path.extname(filename).toLowerCase();

                        const isPrintable = ['.pdf', '.jpg', '.jpeg', '.png', '.tiff', '.bmp', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.docm'].includes(extension);
                        if (!isPrintable) {
                            logger.info(`📧 [${account.emailUser}] Allegato ${filename} non stampabile, salto.`);
                            continue;
                        }

                        let targetFilename = filename;
                        let localPath = path.join(userFolder, targetFilename);
                        if (fs.existsSync(localPath)) {
                            const ext = path.extname(filename);
                            const nameWithoutExt = path.basename(filename, ext);
                            targetFilename = `${nameWithoutExt}_${attIndex}${ext}`;
                            localPath = path.join(userFolder, targetFilename);
                        }

                        fs.writeFileSync(localPath, att.content);
                        hasValidPrintFile = true;

                        const relativePath = path.join(`Email_${safeSenderName}`, targetFilename);
                        const cleanFilename = targetFilename.replace(/[^a-zA-Z0-9]/g, '_');
                        const attMsgId = `${emailOrderId}_att${attIndex}_${cleanFilename}`;

                        const orderData = {
                            id: attMsgId,
                            cliente: `${senderName} (Email)`,
                            telefono: senderEmail,
                            file: relativePath.replace(/\\/g, '/'),
                            data: parsed.date ? parsed.date.toISOString() : new Date().toISOString(),
                            stato: 'ricevuto',
                            tipo: extension === '.pdf' ? 'pdf' : (['.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx'].includes(extension) ? 'documento' : 'immagine'),
                            messaggio: `Oggetto: ${subject}`,
                            msgId: attMsgId
                        };

                        await db.saveOrder(orderData);
                        logger.info(`📧 [${account.emailUser}] Allegato ${targetFilename} salvato come ordine SQLite.`);
                        totalProcessed++;
                    }

                    // Segna come letta
                    await connection.addFlags(uid, '\\Seen');

                } catch (msgErr) {
                    logger.error(`❌ Errore processamento e-mail singola su ${account.emailUser}: ${msgErr.message}`);
                }
            }

        } catch (imapErr) {
            logger.error(`❌ Errore durante il poller IMAP per ${account.emailUser}: ${imapErr.message}`);
        } finally {
            if (connection) {
                try { await connection.end(); } catch (e) {}
            }
        }
    }

    return { success: true, processed: totalProcessed, checkedAccounts };
}

function startEmailPoller() {
    if (emailIntervalId) {
        clearInterval(emailIntervalId);
        emailIntervalId = null;
    }

    if (config.emailEnabled) {
        // Avvia primo controllo immediato in background per non bloccare lo startup
        setTimeout(checkNewEmails, 2000);
        const intervalMs = (config.emailCheckIntervalMinutes || 2) * 60 * 1000;
        emailIntervalId = setInterval(checkNewEmails, intervalMs);
        logger.info(`📧 Poller E-mail impostato ogni ${config.emailCheckIntervalMinutes} minuti.`);
    } else {
        logger.info('📧 Poller E-mail disattivato.');
    }
}

// Endpoint per testare connessione IMAP / SMTP
app.post('/api/email/test', async (req, res) => {
    const { emailHost, emailPort, emailSecure, emailUser, emailPassword, smtpHost, smtpPort, smtpSecure } = req.body;

    if (!emailHost || !emailUser || !emailPassword || !smtpHost) {
        return res.status(400).json({ error: 'Dati incompleti per eseguire il test.' });
    }

    const testResults = { imap: 'Da testare', smtp: 'Da testare' };

    // 1. Test IMAP
    try {
        const connection = await imaps.connect({
            imap: {
                user: emailUser,
                password: emailPassword,
                host: emailHost,
                port: parseInt(emailPort) || 993,
                tls: emailSecure,
                tlsOptions: { rejectUnauthorized: false },
                authTimeout: 6000
            }
        });
        await connection.end();
        testResults.imap = 'OK';
    } catch (imapErr) {
        testResults.imap = 'ERRORE: ' + imapErr.message;
    }

    // 2. Test SMTP
    try {
        const transporter = nodemailer.createTransport({
            host: smtpHost,
            port: parseInt(smtpPort) || 465,
            secure: smtpSecure,
            auth: {
                user: emailUser,
                pass: emailPassword
            },
            tls: {
                rejectUnauthorized: false
            }
        });
        await transporter.verify();
        testResults.smtp = 'OK';
    } catch (smtpErr) {
        testResults.smtp = 'ERRORE: ' + smtpErr.message;
    }

    res.json(testResults);
});

// Endpoint per ottenere tutti i filtri e-mail
app.get('/api/email/filters', (req, res) => {
    res.json(config.emailFilters || []);
});

// Endpoint per aggiungere un nuovo filtro e-mail manualmente
app.post('/api/email/filters', (req, res) => {
    const { name, field, operator, value, action } = req.body;
    if (!field || !operator || !value) {
        return res.status(400).json({ error: 'Campi obbligatori mancanti.' });
    }

    const newRule = {
        id: 'rule_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        name: name || 'Nuova Regola',
        field: field,
        operator: operator,
        value: value,
        action: action || 'skip',
        enabled: true
    };

    if (!config.emailFilters) config.emailFilters = [];
    config.emailFilters.push(newRule);
    
    try {
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        res.json({ success: true, filters: config.emailFilters });
    } catch (err) {
        res.status(500).json({ error: 'Impossibile salvare la configurazione.' });
    }
});

// Endpoint per eliminare un filtro e-mail
app.delete('/api/email/filters/:id', (req, res) => {
    const { id } = req.params;
    if (!config.emailFilters) config.emailFilters = [];
    
    config.emailFilters = config.emailFilters.filter(rule => rule.id !== id);
    
    try {
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        res.json({ success: true, filters: config.emailFilters });
    } catch (err) {
        res.status(500).json({ error: 'Impossibile salvare la configurazione.' });
    }
});

// Endpoint per importare filtri da file msgFilterRules.dat di Thunderbird
app.post('/api/email/filters/import', (req, res) => {
    const { fileContent } = req.body;
    if (!fileContent) {
        return res.status(400).json({ error: 'Nessun contenuto del file ricevuto.' });
    }

    try {
        const importedRules = parseThunderbirdFilters(fileContent);
        if (!config.emailFilters) config.emailFilters = [];

        // Filtra ed evita i duplicati
        let addedCount = 0;
        for (const imp of importedRules) {
            const exists = config.emailFilters.some(
                existing => existing.field === imp.field && 
                            existing.operator === imp.operator && 
                            existing.value.toLowerCase() === imp.value.toLowerCase()
            );
            if (!exists) {
                config.emailFilters.push(imp);
                addedCount++;
            }
        }

        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
        res.json({ success: true, importedCount: addedCount, totalCount: config.emailFilters.length, filters: config.emailFilters });
    } catch (err) {
        logger.error('Errore importazione filtri Thunderbird:', err);
        res.status(500).json({ error: 'Errore durante la lettura del file dei filtri.' });
    }
});

// Endpoint per verificare il Token di un Bot Telegram
app.post('/api/telegram/test', async (req, res) => {
    const { token } = req.body;
    if (!token || !token.trim()) {
        return res.status(400).json({ error: 'Token non inserito' });
    }
    try {
        const cleanToken = token.trim();
        const response = await axios.get(`https://api.telegram.org/bot${cleanToken}/getMe`, { timeout: 8000 });
        if (response.data && response.data.ok) {
            const botInfo = response.data.result;
            return res.json({
                success: true,
                botName: botInfo.first_name,
                username: botInfo.username
            });
        }
        res.status(400).json({ error: 'Token non valido' });
    } catch (err) {
        const detail = err.response?.data?.description || err.message;
        logger.error(`❌ Errore test Telegram Token: ${detail}`);
        res.status(400).json({ error: `Errore Telegram: ${detail}` });
    }
});

let currentTunnelUrl = '';

// Endpoint per ottenere lo stato attuale del Servizio Telegram
app.get('/api/telegram/status', (req, res) => {
    const currentMode = config.telegramMode || 'cloudflare';
    const isOnline = telegramStatus === 'ONLINE';
    res.json({
        polling: isOnline,
        enabled: config.telegramEnabled !== false && currentMode !== 'off',
        hasToken: !!(config.telegramBotToken && config.telegramBotToken.trim()),
        lastUpdateId: lastTelegramUpdateId,
        status: telegramStatus,          // 'DISABLED' | 'CONNECTING' | 'ONLINE' | 'ERROR_TOKEN' | 'ERROR_NET'
        botName: telegramBotName,
        botUsername: telegramBotUsername,
        mode: currentMode,
        webhookUrl: config.telegramWebhookUrl || '',
        currentTunnelUrl: currentTunnelUrl,
        qrCodeUrl: telegramBotUsername ? `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent('https://t.me/' + telegramBotUsername)}` : null,
        botLink: telegramBotUsername ? `https://t.me/${telegramBotUsername}` : null
    });
});

// Endpoint per avviare / configurare il Servizio Telegram dalla dashboard
app.post('/api/telegram/start', async (req, res) => {
    if (req.body.mode) config.telegramMode = req.body.mode;
    if (req.body.telegramBotToken !== undefined) config.telegramBotToken = req.body.telegramBotToken;
    if (req.body.telegramWebhookUrl !== undefined) config.telegramWebhookUrl = req.body.telegramWebhookUrl;
    config.telegramEnabled = config.telegramMode !== 'off';
    
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));

    await initTelegramService();
    logger.info(`▶️ Servizio Telegram aggiornato dalla dashboard (Modalità: ${config.telegramMode}).`);
    res.json({
        success: true,
        message: telegramStatus === 'ERROR_TOKEN' ? 'Token non valido.' : 'Servizio Telegram avviato.',
        status: telegramStatus,
        mode: config.telegramMode,
        currentTunnelUrl,
        botName: telegramBotName,
        botUsername: telegramBotUsername
    });
});

// Endpoint per fermare il Servizio Telegram dalla dashboard
app.post('/api/telegram/stop', async (req, res) => {
    config.telegramMode = 'off';
    config.telegramEnabled = false;
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
    await stopTelegramBot();
    telegramStatus = 'DISABLED';
    logger.info('⏹️ Servizio Telegram fermato dalla dashboard.');
    res.json({ success: true, message: 'Servizio Telegram fermato.', status: telegramStatus, mode: 'off' });
});

// ===== TELEGRAM SERVICE ENGINE =====
let telegramPollingTimer = null;
let lastTelegramUpdateId = 0;
let isTelegramPolling = false;
let telegramStatus = 'DISCONNECTED'; // 'DISCONNECTED'|'CONNECTING'|'ONLINE'|'ERROR_TOKEN'|'ERROR_NET'|'DISABLED'
let telegramBotName = '';
let telegramBotUsername = '';
let telegramReconnectDelay = 1000;
let cloudflaredProcess = null;
let cloudflareTimeoutTimer = null;

function findCloudflaredBinary() {
    const candidates = [
        path.join(ROOT_DIR, 'cloudflared.exe'),
        path.join(DATA_DIR, 'cloudflared.exe'),
        path.join(process.cwd(), 'cloudflared.exe'),
        'cloudflared.exe'
    ];
    for (const c of candidates) {
        if (c && fs.existsSync(c)) {
            return c;
        }
    }
    return null;
}

function stopCloudflareProcess() {
    if (cloudflareTimeoutTimer) {
        clearTimeout(cloudflareTimeoutTimer);
        cloudflareTimeoutTimer = null;
    }
    if (cloudflaredProcess) {
        try { cloudflaredProcess.kill('SIGKILL'); } catch (e) {}
        cloudflaredProcess = null;
    }
    if (process.platform === 'win32') {
        try { execSync('taskkill /F /IM cloudflared.exe', { stdio: 'ignore' }); } catch (e) {}
    }
}

async function startCloudflareTunnel(token) {
    stopCloudflareProcess();

    const binPath = findCloudflaredBinary();
    if (!binPath) {
        logger.error('❌ Executable cloudflared.exe non trovato nelle cartelle di gioco o di installazione.');
        telegramStatus = 'ERROR_NET';
        return false;
    }

    logger.info(`🚀 [CLOUDFLARE] Avvio Cloudflare Tunnel con: ${binPath}...`);

    return new Promise((resolve) => {
        let isResolved = false;
        if (cloudflareTimeoutTimer) clearTimeout(cloudflareTimeoutTimer);
        cloudflareTimeoutTimer = setTimeout(() => {
            if (!isResolved) {
                isResolved = true;
                cloudflareTimeoutTimer = null;
                logger.error('❌ [CLOUDFLARE] Timeout avvio tunnel (35s).');
                telegramStatus = 'ERROR_NET';
                resolve(false);
            }
        }, 35000);

        try {
            cloudflaredProcess = spawn(binPath, ['tunnel', '--url', `http://localhost:${PORT}`], {
                windowsHide: true
            });

            const onData = async (data) => {
                const text = data.toString();
                const match = text.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/i);
                if (match && !isResolved) {
                    isResolved = true;
                    if (cloudflareTimeoutTimer) {
                        clearTimeout(cloudflareTimeoutTimer);
                        cloudflareTimeoutTimer = null;
                    }
                    currentTunnelUrl = match[0];
                    logger.info(`✅ [CLOUDFLARE] Tunnel generato con successo: ${currentTunnelUrl}`);
                    logger.info('⏳ [CLOUDFLARE] Attesa propagazione DNS (3.5s)...');

                    // Attendi 3.5s per consentire a Cloudflare di propagare il record DNS globale a Telegram
                    await new Promise(r => setTimeout(r, 3500));

                    const webhookEndpoint = `${currentTunnelUrl}/api/telegram/webhook`;
                    let success = false;

                    for (let attempt = 1; attempt <= 3; attempt++) {
                        try {
                            const setRes = await axios.get(`https://api.telegram.org/bot${token}/setWebhook`, {
                                params: {
                                    url: webhookEndpoint,
                                    allowed_updates: JSON.stringify(["message", "edited_message"])
                                },
                                timeout: 10000
                            });
                            if (setRes.data && setRes.data.ok) {
                                telegramStatus = 'ONLINE';
                                logger.info(`✅ Webhook Telegram registrato su Cloudflare Tunnel: ${webhookEndpoint}`);
                                success = true;
                                break;
                            } else {
                                logger.error(`❌ Errore registrazione Webhook (tentativo ${attempt}): ${JSON.stringify(setRes.data)}`);
                            }
                        } catch (err) {
                            const errDesc = err.response?.data?.description || err.message;
                            logger.warn(`⚠️ Tentativo ${attempt}/3 setWebhook fallito (${errDesc}). Riprovo tra 2s...`);
                            await new Promise(r => setTimeout(r, 2000));
                        }
                    }

                    if (success) {
                        resolve(true);
                    } else {
                        telegramStatus = 'ERROR_NET';
                        logger.error('❌ Impossibile registrare Webhook su Telegram dopo 3 tentativi.');
                        resolve(false);
                    }
                }
            };

            if (cloudflaredProcess.stdout) cloudflaredProcess.stdout.on('data', onData);
            if (cloudflaredProcess.stderr) cloudflaredProcess.stderr.on('data', onData);

            cloudflaredProcess.on('error', (err) => {
                logger.error(`❌ [CLOUDFLARE] Errore processo: ${err.message}`);
                if (!isResolved) {
                    isResolved = true;
                    clearTimeout(timeoutTimer);
                    telegramStatus = 'ERROR_NET';
                    resolve(false);
                }
            });

            cloudflaredProcess.on('close', (code) => {
                logger.info(`🚀 [CLOUDFLARE] Processo terminato (code ${code}).`);
                cloudflaredProcess = null;
            });
        } catch (e) {
            clearTimeout(timeoutTimer);
            logger.error(`❌ Errore spawn cloudflared: ${e.message}`);
            telegramStatus = 'ERROR_NET';
            resolve(false);
        }
    });
}

app.post('/api/telegram/webhook', async (req, res) => {
    res.status(200).send('OK');
    try {
        const update = req.body;
        if (!update) return;
        const msg = update.message || update.edited_message;
        if (msg) {
            await handleIncomingTelegramMessage(msg);
        }
    } catch (err) {
        logger.error('⚠️ Errore durante elaborazione Webhook Telegram:', err.message);
    }
});

async function initTelegramService() {
    await stopTelegramBot();

    const mode = config.telegramMode || (config.telegramEnabled !== false ? 'cloudflare' : 'off');
    const token = config.telegramBotToken ? config.telegramBotToken.trim() : '';

    if (mode === 'off') {
        telegramStatus = 'DISABLED';
        logger.info('ℹ️ Servizio Telegram: Disabilitato dall\'utente.');
        return;
    }

    if (!token) {
        telegramStatus = 'DISABLED';
        logger.info('ℹ️ Servizio Telegram: Nessun token configurato.');
        return;
    }

    telegramStatus = 'CONNECTING';
    logger.info(`✈️ Servizio Telegram: avvio in modalità '${mode}'...`);

    try {
        const meRes = await axios.get(`https://api.telegram.org/bot${token}/getMe`, { timeout: 8000 });
        if (meRes.data && meRes.data.ok && meRes.data.result) {
            telegramBotName = meRes.data.result.first_name || '';
            telegramBotUsername = meRes.data.result.username || '';
            logger.info(`✅ Token Telegram valido. Bot: ${telegramBotName} (@${telegramBotUsername})`);
        } else {
            telegramStatus = 'ERROR_TOKEN';
            logger.error('❌ Token Telegram non valido (getMe fallito).');
            return;
        }
    } catch (err) {
        if (err.response && err.response.status === 401) {
            telegramStatus = 'ERROR_TOKEN';
            logger.error('❌ Token Telegram non valido (401).');
        } else {
            telegramStatus = 'ERROR_NET';
            logger.error(`⚠️ Impossibile verificare token Telegram (errore rete): ${err.message}`);
        }
        return;
    }

    if (mode === 'cloudflare' || (mode === 'tunnel' && findCloudflaredBinary() !== null)) {
        logger.info('🚀 Modalità Cloudflare Tunnel attivata.');
        await startCloudflareTunnel(token);
    } else if (mode === 'tunnel') {
        try {
            if (localtunnelInstance) {
                try { localtunnelInstance.close(); } catch(e){}
                localtunnelInstance = null;
            }
            localtunnelInstance = await localtunnel({ port: PORT });
            currentTunnelUrl = localtunnelInstance.url;
            logger.info(`🚀 Tunnel HTTPS localtunnel avviato: ${currentTunnelUrl}`);

            const webhookEndpoint = `${currentTunnelUrl}/api/telegram/webhook`;
            const setRes = await axios.get(`https://api.telegram.org/bot${token}/setWebhook`, {
                params: {
                    url: webhookEndpoint,
                    allowed_updates: JSON.stringify(["message", "edited_message"])
                },
                timeout: 10000
            });
            if (setRes.data && setRes.data.ok) {
                telegramStatus = 'ONLINE';
                logger.info(`✅ Webhook Telegram registrato con successo su: ${webhookEndpoint}`);
            } else {
                telegramStatus = 'ERROR_NET';
                logger.error(`❌ Errore registrazione Webhook Telegram: ${JSON.stringify(setRes.data)}`);
            }

            localtunnelInstance.on('close', () => {
                logger.info('🚀 Tunnel HTTPS localtunnel chiuso.');
            });
        } catch (tErr) {
            telegramStatus = 'ERROR_NET';
            logger.error(`❌ Errore avvio Tunnel HTTPS Telegram: ${tErr.message}`);
        }
    } else if (mode === 'webhook_custom') {
        const customUrl = (config.telegramWebhookUrl || '').trim();
        if (!customUrl) {
            telegramStatus = 'ERROR_NET';
            logger.error('❌ URL Webhook personalizzato non specificato nelle Impostazioni.');
            return;
        }
        try {
            const webhookEndpoint = customUrl.endsWith('/') ? `${customUrl}api/telegram/webhook` : `${customUrl}/api/telegram/webhook`;
            const setRes = await axios.get(`https://api.telegram.org/bot${token}/setWebhook`, {
                params: {
                    url: webhookEndpoint,
                    allowed_updates: JSON.stringify(["message", "edited_message"])
                },
                timeout: 10000
            });
            if (setRes.data && setRes.data.ok) {
                telegramStatus = 'ONLINE';
                logger.info(`✅ Webhook Telegram Personalizzato registrato su: ${webhookEndpoint}`);
            } else {
                telegramStatus = 'ERROR_NET';
                logger.error(`❌ Errore registrazione Webhook Personalizzato: ${JSON.stringify(setRes.data)}`);
            }
        } catch (wErr) {
            telegramStatus = 'ERROR_NET';
            logger.error(`❌ Errore impostazione Webhook Personalizzato: ${wErr.message}`);
        }
    } else if (mode === 'qr_account' || mode === 'polling') {
        try {
            await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=true`, { timeout: 8000 });
            logger.info('✅ Webhook Telegram rimosso per modalità polling/QR.');
        } catch (delErr) {
            logger.warn(`⚠️ Warning rimozione webhook: ${delErr.message}`);
        }

        isTelegramPolling = true;
        telegramReconnectDelay = 1000;
        telegramStatus = 'ONLINE';
        pollTelegramUpdates();
    }
}

async function stopTelegramBot() {
    isTelegramPolling = false;
    stopCloudflareProcess();
    if (telegramPollingTimer) {
        clearTimeout(telegramPollingTimer);
        telegramPollingTimer = null;
    }
    if (localtunnelInstance) {
        try { localtunnelInstance.close(); } catch(e){}
        localtunnelInstance = null;
    }
    currentTunnelUrl = '';
    const token = config.telegramBotToken ? config.telegramBotToken.trim() : '';
    if (token) {
        try {
            await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=true`, { timeout: 8000 });
            logger.info('✅ Webhook Telegram rimosso con successo.');
        } catch (e) {
            logger.warn(`⚠️ Rimozione webhook Telegram: ${e.message}`);
        }
    }
    lastTelegramUpdateId = 0;
    telegramReconnectDelay = 1000;
    if (telegramStatus !== 'ERROR_TOKEN') {
        telegramStatus = 'DISCONNECTED';
    }
}

async function pollTelegramUpdates() {
    if (!isTelegramPolling || !config.telegramBotToken) return;

    // Cancella sempre i timer pendenti per evitare chiamate concurrenti sovrapposte
    if (telegramPollingTimer) {
        clearTimeout(telegramPollingTimer);
        telegramPollingTimer = null;
    }

    let nextDelay = 500;

    try {
        const token = config.telegramBotToken.trim();
        if (!token) {
            isTelegramPolling = false;
            telegramStatus = 'DISABLED';
            return;
        }

        const url = `https://api.telegram.org/bot${token}/getUpdates?offset=${lastTelegramUpdateId + 1}&timeout=20`;
        const res = await axios.get(url, { timeout: 35000 });

        if (res.data && res.data.ok && Array.isArray(res.data.result)) {
            telegramStatus = 'ONLINE';
            telegramReconnectDelay = 1000;
            if (res.data.result.length > 0) {
                logger.info(`📩 Telegram: ricevuti ${res.data.result.length} aggiornamento/i`);
            }
            for (const update of res.data.result) {
                lastTelegramUpdateId = Math.max(lastTelegramUpdateId, update.update_id);
                if (update.message) {
                    await handleIncomingTelegramMessage(update.message);
                }
            }
            nextDelay = res.data.result.length > 0 ? 100 : 500;
        } else if (res.data && !res.data.ok) {
            logger.error(`❌ Telegram API error: ${res.data.description || JSON.stringify(res.data)}`);
            if (res.data.error_code === 401) {
                telegramStatus = 'ERROR_TOKEN';
                isTelegramPolling = false;
                logger.error('❌ Token Telegram non valido (401). Polling interrotto.');
                return;
            } else if (res.data.error_code === 409) {
                telegramStatus = 'ERROR_NET';
                logger.info('⚠️ Telegram: conflitto (409) — riprovo tra 5s...');
                nextDelay = 5000;
            }
        }
    } catch (err) {
        if (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT') {
            // Timeout normale del long-polling: riprova subito
            nextDelay = 100;
        } else if (err.response && err.response.status === 409) {
            // Conflitto 409 da axios (Webhook ancora attivo su Telegram): forziamo la rimozione del webhook
            logger.info('⚠️ Telegram: conflitto HTTP 409 (Webhook residuo). Forzo la rimozione del Webhook...');
            try {
                await axios.get(`https://api.telegram.org/bot${token}/deleteWebhook?drop_pending_updates=false`, { timeout: 6000 });
                logger.info('✅ Webhook residuo rimosso con successo dopo 409.');
            } catch (del409Err) {}
            nextDelay = 1000;
        } else {
            telegramStatus = 'ERROR_NET';
            telegramReconnectDelay = Math.min(telegramReconnectDelay * 2, 30000);
            logger.info(`⚠️ Polling Telegram: ${err.message}. Riprovo tra ${telegramReconnectDelay / 1000}s...`);
            nextDelay = telegramReconnectDelay;
        }
    }

    // Programma la prossima iterazione SOLO se il polling è ancora attivo e SENZA sovrapposizioni da finally
    if (isTelegramPolling) {
        telegramPollingTimer = setTimeout(pollTelegramUpdates, nextDelay);
    }
}

async function handleIncomingTelegramMessage(msg) {
    if (!msg || !msg.chat) return;
    const chatId = msg.chat.id;
    const phoneKey = `tg_${chatId}`;

    let clientName = [msg.from?.first_name, msg.from?.last_name].filter(Boolean).join(' ');
    if (msg.from?.username) {
        clientName = clientName ? `${clientName} (@${msg.from.username})` : `@${msg.from.username}`;
    }
    if (!clientName) clientName = `Telegram User ${chatId}`;

    const token = config.telegramBotToken ? config.telegramBotToken.trim() : '';

    // 1. Gestione del comando /start: Risposta automatica di benvenuto senza creare note vuote
    if (msg.text && msg.text.trim().startsWith('/start')) {
        logger.info(`✈️ Ricevuto /start da Telegram: ${clientName} (${phoneKey})`);
        if (token) {
            try {
                await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
                    chat_id: chatId,
                    text: `👋 Benvenuto su PrintZap!\n\nInviami pure i documenti o le foto che desideri stampare (PDF, Word, Excel, Foto, ecc.) e li riceveremo subito in cartoleria.`
                });
            } catch (replyErr) {
                logger.error('⚠️ Errore invio riscontro /start Telegram:', replyErr.message);
            }
        }
        return; // NON creare un ordine vuoto per /start
    }

    // 2. Rilevamento qualsiasi formato di file (Documenti, Foto, Audio, Vocali, Video)
    let fileObj = msg.document || (msg.photo ? msg.photo[msg.photo.length - 1] : null) || msg.audio || msg.voice || msg.video;

    if (fileObj) {
        try {
            if (!token) return;
            const fileId = fileObj.file_id;

            const fileRes = await axios.get(`https://api.telegram.org/bot${token}/getFile?file_id=${fileId}`);
            if (fileRes.data && fileRes.data.ok && fileRes.data.result.file_path) {
                const filePathOnTelegram = fileRes.data.result.file_path;
                const fileDownloadUrl = `https://api.telegram.org/file/bot${token}/${filePathOnTelegram}`;

                let originalFileName = msg.document?.file_name || msg.audio?.file_name || msg.video?.file_name;
                if (!originalFileName) {
                    if (msg.photo) {
                        originalFileName = `foto_${Date.now()}.jpg`;
                    } else if (msg.voice) {
                        originalFileName = `vocale_${Date.now()}.ogg`;
                    } else {
                        originalFileName = path.basename(filePathOnTelegram) || `file_${Date.now()}`;
                    }
                }

                const safeName = originalFileName.replace(/[^a-zA-Z0-9_.-]/g, '_');
                const localFileName = `tg_${Date.now()}_${safeName}`;

                const clientFolder = sanitizeClientFolder(clientName, phoneKey);
                const absoluteClientFolder = path.join(PRINT_FOLDER, clientFolder);

                if (!fs.existsSync(absoluteClientFolder)) {
                    fs.mkdirSync(absoluteClientFolder, { recursive: true });
                }

                const relativeFilePath = path.join(clientFolder, localFileName);
                const savePath = path.join(PRINT_FOLDER, relativeFilePath);

                const fileStreamRes = await axios.get(fileDownloadUrl, { responseType: 'stream' });
                const writer = fs.createWriteStream(savePath);
                fileStreamRes.data.pipe(writer);

                await new Promise((resolve, reject) => {
                    writer.on('finish', resolve);
                    writer.on('error', reject);
                });

                logger.info(`📥 File Telegram scaricato (${originalFileName}): ${relativeFilePath} per ${clientName}`);

                const isAudio = !!(msg.voice || msg.audio);
                const newOrder = {
                    id: 'tg_ord_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
                    cliente: clientName,
                    telefono: phoneKey,
                    file: relativeFilePath,
                    tipo: isAudio ? 'audio' : 'file',
                    messaggio: msg.caption || `File Telegram: ${originalFileName}`,
                    stato: 'nuovo',
                    data: new Date().toISOString(),
                    orarioStampa: null,
                    msgId: `tg_msg_${msg.message_id}`
                };

                await db.saveOrder(newOrder);

                // Invia conferma automatica di ricezione al cliente su Telegram
                try {
                    await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
                        chat_id: chatId,
                        text: `📥 File "${originalFileName}" ricevuto con successo! È pronto per la stampa in cartoleria.`
                    });
                } catch (confErr) {
                    logger.error('⚠️ Errore invio conferma ricezione file Telegram:', confErr.message);
                }
            }
        } catch (err) {
            logger.error('❌ Errore durante il download del file Telegram:', err);
        }
    } else if (msg.text) {
        const newOrder = {
            id: 'tg_note_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
            cliente: clientName,
            telefono: phoneKey,
            file: '',
            tipo: 'nota',
            messaggio: msg.text,
            stato: 'nuovo',
            data: new Date().toISOString(),
            orarioStampa: null,
            msgId: `tg_msg_${msg.message_id}`
        };

        await db.saveOrder(newOrder);
    }
}

// ===== MOTORE MODULO WEB BANCONE (SELF-SERVICE VIA QR CODE) =====
const webUploadStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const rawName = req.body.nome || 'Cliente_Web';
        const safeName = rawName.replace(/[^a-zA-Z0-9_]/g, '_');
        const userFolder = path.join(PRINT_FOLDER, `WebBancone_${safeName}`);
        if (!fs.existsSync(userFolder)) {
            fs.mkdirSync(userFolder, { recursive: true });
        }
        cb(null, userFolder);
    },
    filename: function (req, file, cb) {
        const ext = path.extname(file.originalname);
        const baseName = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_]/g, '_');
        cb(null, `web_${Date.now()}_${baseName}${ext}`);
    }
});

const uploadWebMulter = multer({
    storage: webUploadStorage,
    limits: { fileSize: 100 * 1024 * 1024 } // 100MB per file
});

// Rotta per servire la pagina Web Mobile di Caricamento Bancone
app.get('/upload', (req, res) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    const htmlPage = `<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>PrintZap — Caricamento Rapido Bancone</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', system-ui, sans-serif; }
        body { background: #0f172a; color: #f8fafc; padding: 16px; min-height: 100vh; display: flex; justify-content: center; }
        .card { background: #1e293b; border: 1px solid #334155; border-radius: 16px; width: 100%; max-width: 480px; padding: 20px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5); }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 1px solid #334155; padding-bottom: 16px; }
        .header h1 { font-size: 1.3rem; color: #38bdf8; display: flex; align-items: center; justify-content: center; gap: 8px; }
        .badge-live { background: rgba(37,211,102,0.15); color: #25d366; border: 1px solid #25d366; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; margin-top: 8px; display: inline-block; }
        .form-group { margin-bottom: 16px; }
        label { display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 6px; color: #cbd5e1; }
        input[type="text"], input[type="tel"], textarea { width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #475569; background: #0f172a; color: #f8fafc; font-size: 0.95rem; }
        input:focus, textarea:focus { outline: none; border-color: #38bdf8; }
        
        .upload-area { border: 2px dashed #38bdf8; border-radius: 12px; padding: 24px 16px; text-align: center; background: rgba(56,189,248,0.05); cursor: pointer; transition: all 0.2s; }
        .upload-area:active { background: rgba(56,189,248,0.15); }
        .upload-icon { font-size: 2.2rem; margin-bottom: 8px; }
        
        .grid-options { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 6px; }
        .option-card { background: #0f172a; border: 1px solid #334155; padding: 10px; border-radius: 8px; cursor: pointer; text-align: center; font-size: 0.85rem; font-weight: 500; transition: all 0.2s; }
        .option-card.selected { border-color: #38bdf8; background: rgba(56,189,248,0.15); color: #38bdf8; font-weight: 700; }
        
        .checkbox-group { display: flex; flex-direction: column; gap: 8px; margin-top: 6px; }
        .checkbox-label { display: flex; align-items: center; gap: 10px; background: #0f172a; border: 1px solid #334155; padding: 10px 12px; border-radius: 8px; cursor: pointer; font-size: 0.85rem; }
        .checkbox-label input { width: 18px; height: 18px; accent-color: #38bdf8; }
        
        .stepper { display: flex; align-items: center; justify-content: center; gap: 16px; background: #0f172a; border: 1px solid #334155; border-radius: 8px; padding: 8px; }
        .btn-step { width: 36px; height: 36px; border-radius: 50%; border: 1px solid #38bdf8; background: rgba(56,189,248,0.1); color: #38bdf8; font-size: 1.2rem; font-weight: bold; cursor: pointer; }
        
        .btn-submit { width: 100%; padding: 14px; background: #38bdf8; color: #0f172a; font-weight: 700; font-size: 1rem; border: none; border-radius: 10px; cursor: pointer; margin-top: 20px; transition: opacity 0.2s; }
        .btn-submit:disabled { opacity: 0.5; }
        
        .file-list { margin-top: 10px; font-size: 0.8rem; color: #94a3b8; text-align: left; max-height: 100px; overflow-y: auto; }
        .file-item { padding: 4px 8px; background: #0f172a; border-radius: 4px; margin-top: 4px; word-break: break-all; }
        
        #successScreen { display: none; text-align: center; padding: 30px 10px; }
        .success-icon { font-size: 4rem; color: #25d366; margin-bottom: 16px; }
        .ticket-box { background: rgba(37,211,102,0.1); border: 2px dashed #25d366; border-radius: 12px; padding: 16px; margin: 20px 0; font-size: 1.4rem; font-weight: 800; color: #25d366; }
    </style>
</head>
<body>
    <div class="card">
        <div id="uploadFormScreen">
            <div class="header">
                <h1>🖨️ PrintZap Bancone</h1>
                <span class="badge-live">🟢 Bancone Attivo — Invia per la Stampa</span>
            </div>

            <form id="mainUploadForm">
                <div class="form-group">
                    <label>Nome e Cognome *</label>
                    <input type="text" id="nome" required placeholder="es. Mario Rossi">
                </div>

                <div class="form-group">
                    <label>Cellulare (Opzionale per avviso)</label>
                    <input type="tel" id="telefono" placeholder="es. 3331234567">
                </div>

                <div class="form-group">
                    <label>Seleziona File da Stampare *</label>
                    <div class="upload-area" onclick="document.getElementById('fileInput').click()">
                        <div class="upload-icon">📁</div>
                        <div style="font-weight: 600; font-size: 0.9rem;">Tocca per caricare documenti o foto</div>
                        <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 4px;">PDF, Word, Excel, Foto</div>
                        <input type="file" id="fileInput" multiple style="display:none;" onchange="handleFilesSelected(this)">
                    </div>
                    <div class="file-list" id="fileListDisplay"></div>
                </div>

                <div class="form-group">
                    <label>Formato Carta</label>
                    <div class="grid-options" id="formatoCartaGroup">
                        <div class="option-card selected" onclick="selectCard('formatoCartaGroup', this, 'A4')">📄 A4 Standard (80g)</div>
                        <div class="option-card" onclick="selectCard('formatoCartaGroup', this, 'A3')">📐 A3 Grande</div>
                        <div class="option-card" onclick="selectCard('formatoCartaGroup', this, 'Foto')">🖼️ Carta Fotografica</div>
                        <div class="option-card" onclick="selectCard('formatoCartaGroup', this, 'Cartoncino')">🎴 Cartoncino</div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Colore Stampa</label>
                    <div class="grid-options" id="coloreGroup">
                        <div class="option-card selected" onclick="selectCard('coloreGroup', this, 'B/N')">⚫ Bianco e Nero</div>
                        <div class="option-card" onclick="selectCard('coloreGroup', this, 'Colore')">🎨 A Colori</div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Finitura & Opzioni</label>
                    <div class="checkbox-group">
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkFronteRetro"> 📑 Stampa Fronte e Retro
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkNonSpillate" checked> 📄 Non Spillate (Fogli Sciolti)
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkSpillatura"> 📌 Spillatura nell'angolo (Pinzatura)
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkRilegatura"> 🌀 Rilegatura a Spirale
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkBusta"> ✉️ Busta Protettiva Trasparente
                        </label>
                    </div>
                </div>

                <div class="form-group">
                    <label>Numero Copie</label>
                    <div class="stepper">
                        <button type="button" class="btn-step" onclick="changeCopie(-1)">-</button>
                        <span id="copieVal" style="font-size: 1.2rem; font-weight: bold; width: 30px; text-align: center;">1</span>
                        <button type="button" class="btn-step" onclick="changeCopie(1)">+</button>
                    </div>
                </div>

                <div class="form-group">
                    <label>Note per l'operatore (Opzionale)</label>
                    <textarea id="note" rows="2" placeholder="es. Stampa solo da pagina 3 a 10..."></textarea>
                </div>

                <button type="submit" class="btn-submit" id="submitBtn">🚀 INVIA PER LA STAMPA</button>
            </form>
        </div>

        <div id="successScreen">
            <div class="success-icon">✅</div>
            <h2>Inviato alla Cassa!</h2>
            <p style="font-size: 0.9rem; color: #cbd5e1; margin-top: 8px;">Il tuo documento è stato ricevuto dalla cartoleria.</p>
            <div class="ticket-box" id="ticketNumberDisplay">CODICE #W-101</div>
            <p style="font-size: 0.8rem; color: #94a3b8;">Mostra questo codice o comunica il tuo nome al bancone per il ritiro.</p>
            <button type="button" class="btn-submit" onclick="location.reload()" style="margin-top: 24px;">🔄 Invia un altro file</button>
        </div>
    </div>

    <script>
        let selectedFormato = 'A4';
        let selectedColore = 'B/N';
        let copieCount = 1;

        function selectCard(groupId, element, val) {
            document.querySelectorAll('#' + groupId + ' .option-card').forEach(el => el.classList.remove('selected'));
            element.classList.add('selected');
            if (groupId === 'formatoCartaGroup') selectedFormato = val;
            if (groupId === 'coloreGroup') selectedColore = val;
        }

        function changeCopie(delta) {
            copieCount = Math.max(1, copieCount + delta);
            document.getElementById('copieVal').textContent = copieCount;
        }

        function handleFilesSelected(input) {
            const display = document.getElementById('fileListDisplay');
            display.innerHTML = '';
            if (input.files && input.files.length > 0) {
                for (let i = 0; i < input.files.length; i++) {
                    const item = document.createElement('div');
                    item.className = 'file-item';
                    item.textContent = '📄 ' + input.files[i].name + ' (' + (input.files[i].size / 1024 / 1024).toFixed(2) + ' MB)';
                    display.appendChild(item);
                }
            }
        }

        document.getElementById('mainUploadForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const fileInput = document.getElementById('fileInput');
            if (!fileInput.files || fileInput.files.length === 0) {
                alert('Seleziona almeno un file prima di inviare!');
                return;
            }

            const btn = document.getElementById('submitBtn');
            btn.disabled = true;
            btn.textContent = '⏳ Invio in corso...';

            const formData = new FormData();
            formData.append('nome', document.getElementById('nome').value.trim());
            formData.append('telefono', document.getElementById('telefono').value.trim());
            formData.append('formato', selectedFormato);
            formData.append('colore', selectedColore);
            formData.append('copie', copieCount);
            formData.append('fronteRetro', document.getElementById('chkFronteRetro').checked ? 'Sì' : 'No');
            formData.append('nonSpillate', document.getElementById('chkNonSpillate').checked ? 'Sì' : 'No');
            formData.append('spillatura', document.getElementById('chkSpillatura').checked ? 'Sì' : 'No');
            formData.append('rilegatura', document.getElementById('chkRilegatura').checked ? 'Sì' : 'No');
            formData.append('busta', document.getElementById('chkBusta').checked ? 'Sì' : 'No');
            formData.append('note', document.getElementById('note').value.trim());

            for (let i = 0; i < fileInput.files.length; i++) {
                formData.append('files', fileInput.files[i]);
            }

            try {
                const res = await fetch('/api/web/upload', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.success) {
                    document.getElementById('uploadFormScreen').style.display = 'none';
                    document.getElementById('successScreen').style.display = 'block';
                    document.getElementById('ticketNumberDisplay').textContent = 'CODICE ' + (data.ticketCode || '#W-BANCONE');
                } else {
                    alert('Errore durante l\'invio: ' + (data.error || 'Impossibile completare'));
                    btn.disabled = false;
                    btn.textContent = '🚀 INVIA PER LA STAMPA';
                }
            } catch (err) {
                alert('Errore di connessione: ' + err.message);
                btn.disabled = false;
                btn.textContent = '🚀 INVIA PER LA STAMPA';
            }
        });
    </script>
</body>
</html>`;
    res.send(htmlPage);
});

// Endpoint per ricevere gli upload del modulo web bancone
app.post('/api/web/upload', uploadWebMulter.array('files', 10), async (req, res) => {
    try {
        const { nome, telefono, formato, colore, copie, fronteRetro, nonSpillate, spillatura, rilegatura, busta, note } = req.body;
        const files = req.files || [];

        if (files.length === 0) {
            return res.status(400).json({ error: 'Nessun file ricevuto.' });
        }

        const safeSenderName = (nome || 'Cliente_Web').replace(/[^a-zA-Z0-9]/g, '_');
        let totalProcessed = 0;
        let lastTicketCode = '';

        const finitureList = [];
        if (fronteRetro === 'Sì') finitureList.push('Fronte/Retro');
        if (nonSpillate === 'Sì') finitureList.push('Fogli Sciolti');
        if (spillatura === 'Sì') finitureList.push('Spillato');
        if (rilegatura === 'Sì') finitureList.push('Rilegatura');
        if (busta === 'Sì') finitureList.push('Busta Protettiva');
        const finituraStr = finitureList.length > 0 ? finitureList.join(', ') : 'Standard';

        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const relativePath = path.join(`WebBancone_${safeSenderName}`, file.filename);
            const ticketIndex = Math.floor(100 + Math.random() * 900);
            lastTicketCode = `#W-${ticketIndex}`;

            const formattedMsg = `📋 Modulo Web Bancone | Formato: ${formato || 'A4'} | Colore: ${colore || 'B/N'} | Copie: ${copie || 1} | Finitura: ${finituraStr}${note ? ' | Note: ' + note : ''}`;

            const orderData = {
                id: `web_ord_${Date.now()}_${i}_${Math.random().toString(36).substr(2, 4)}`,
                cliente: `${nome || 'Cliente Web'} (Web Bancone)`,
                telefono: telefono ? `web_${telefono}` : 'web_bancone',
                file: relativePath.replace(/\\/g, '/'),
                data: new Date().toISOString(),
                stato: 'ricevuto',
                tipo: 'web',
                messaggio: formattedMsg,
                msgId: `web_msg_${Date.now()}_${i}`
            };

            await db.saveOrder(orderData);
            notifyDashboard({
                type: 'NEW_ORDER',
                order: orderData,
                channel: 'web'
            });
            totalProcessed++;
        }

        logger.info(`🌐 Ricevuti ${totalProcessed} file dal Modulo Web Bancone per ${nome}`);
        res.json({ success: true, processed: totalProcessed, ticketCode: lastTicketCode });
    } catch (err) {
        logger.error('❌ Errore durante elaborazione upload web:', err);
        res.status(500).json({ error: 'Errore durante il salvataggio dei file: ' + err.message });
    }
});

// Endpoint per la generazione del Report CSV/Excel degli ordini
app.get('/api/reports/export', async (req, res) => {
    try {
        const orders = await db.getOrders();
        let csv = '\uFEFF'; // UTF-8 BOM per Excel
        csv += 'ID Ordine;Data;Ora;Cliente;Canale / Telefono;Tipo Documento;File;Stato;Dettagli / Messaggio\n';

        for (const ord of orders) {
            const dateObj = new Date(ord.data);
            const dataFormatted = !isNaN(dateObj) ? dateObj.toLocaleDateString('it-IT') : '';
            const oraFormatted = !isNaN(dateObj) ? dateObj.toLocaleTimeString('it-IT') : '';
            const channel = (ord.telefono || '').startsWith('tg_') ? 'Telegram' :
                            (ord.telefono || '').startsWith('web_') ? 'Web Bancone' :
                            (ord.id || '').startsWith('email_') ? 'Email' : 'WhatsApp';

            const cleanMessage = (ord.messaggio || '').replace(/[\r\n]+/g, ' | ').replace(/;/g, ',');
            csv += `"${ord.id}";"${dataFormatted}";"${oraFormatted}";"${ord.cliente}";"${channel} (${ord.telefono})";"${ord.tipo}";"${ord.file}";"${ord.stato}";"${cleanMessage}"\n`;
        }

        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', `attachment; filename="report_ordini_printzap_${Date.now()}.csv"`);
        res.send(csv);
    } catch (err) {
        logger.error('❌ Errore durante esportazione report CSV:', err);
        res.status(500).json({ error: 'Impossibile esportare il report: ' + err.message });
    }
});

// Endpoint per forzare il controllo manuale delle e-mail
app.post('/api/email/check', async (req, res) => {
    try {
        const result = await checkNewEmails();
        res.json(result);
    } catch (err) {
        logger.error('❌ Errore durante il controllo e-mail manuale:', err);
        res.status(500).json({ error: 'Errore durante il controllo e-mail: ' + err.message });
    }
});

// SPA Fallback: deve rimanere in fondo a tutte le rotte API per non intercettare le chiamate /api/*
if (fs.existsSync(dashboardPath)) {
    app.get('*', (req, res) => {
        res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        res.sendFile(path.join(dashboardPath, 'index.html'));
    });
}

// Track active connections
const activeConnections = new Set();

const server = app.listen(PORT, async () => {
    logger.info(`🚀 Server in ascolto su http://localhost:${PORT}`);
    logger.info(`✅ Server avviato correttamente sulla porta ${PORT}`);

    try {
        const dbPath = path.join(DATA_DIR, 'ordini.db');
        logger.info(`📦 Inizializzazione database SQLite in ${dbPath}...`);
        await db.initDb(dbPath);
        logger.info('✅ Database SQLite pronto.');

        // Sincronizzazione / Riparazione cartelle numeriche con nomi contatto
        await repairMismatchedFolders();

        // Migrazione automatica da ordini.json se presente
        const ordersFile = path.join(DATA_DIR, 'ordini.json');
        if (fs.existsSync(ordersFile)) {
            try {
                logger.info("📦 Trovato file ordini.json. Avvio migrazione su SQLite...");
                const jsonOrders = JSON.parse(fs.readFileSync(ordersFile, 'utf8'));
                let count = 0;
                for (const order of jsonOrders) {
                    await db.saveOrder(order);
                    count++;
                }
                fs.renameSync(ordersFile, ordersFile + '.bak');
                logger.info(`✅ Migrazione completata con successo! Importati ${count} ordini. Creato backup ordini.json.bak`);
            } catch (err) {
                logger.error("❌ Errore durante la migrazione dei dati:", err);
            }
        }
    } catch (dbErr) {
        logger.error('❌ Errore critico inizializzazione database:', dbErr);
        setTimeout(() => process.exit(1), 5000);
        return;
    }

    // Avvia WhatsApp solo se il server è partito
    initializeClient();

    // Avvia il poller e-mail all'avvio
    startEmailPoller();

    // Avvia il servizio Telegram all'avvio (gestisce la modalità configurata)
    initTelegramService();

    // Chiudi lo splash screen ed apri il browser sulla dashboard dinamicamente a server pronto
    if (process.platform === 'win32') {
        exec('taskkill /F /IM mshta.exe >nul 2>&1');
        const flagPath = path.join(DATA_DIR, 'updated.flag');
        if (fs.existsSync(flagPath)) {
            try { fs.unlinkSync(flagPath); } catch (e) {}
        }
        // Apri sempre il browser sulla Dashboard ad ogni avvio del server
        exec(`start http://localhost:${PORT}`);
    }
}).on('connection', (socket) => {
    activeConnections.add(socket);
    socket.on('close', () => activeConnections.delete(socket));
}).on('error', (err) => {
    logger.info(`❌ ERRORE SERVER: ${err.message}`);
    if (err.code === 'EADDRINUSE') {
        logger.info(`⚠️ La porta ${PORT} è già occupata da un altro programma (forse hai già aperto il servizio?). Chiudi la versione precedente.`);
    }
    // Mostra errore all'utente prima di uscire
    logger.error('ERRORE CRITICO:', err.message);
    setTimeout(() => process.exit(1), 30000);
});

// initializeClient(); // Spostato dentro app.listen


async function handleGracefulShutdown(signal) {
    logger.info(`⏹️ Ricevuto segnale ${signal}. Chiusura pulita in corso...`);
    if (client) {
        try {
            // Distruzione client con timeout per evitare di rimanere appesi se WhatsApp risponde lentamente
            const destroyPromise = client.destroy();
            const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout destroy')), 4000));
            await Promise.race([destroyPromise, timeoutPromise]).catch(err => {
                logger.error('Errore durante client.destroy in shutdown:', err.message);
            });
        } catch (err) { }
    }

    // Chiudi tutte le connessioni attive
    activeConnections.forEach(socket => socket.destroy());

    // Chiudi il server ed esci
    server.close(() => {
        logger.info('Server chiuso correttamente');
        process.exit(0);
    });

    // Uscita forzata dopo 5 secondi
    setTimeout(() => {
        logger.error('Forzata chiusura dopo timeout di sicurezza');
        process.exit(1);
    }, 5000);
}

process.on('SIGINT', () => handleGracefulShutdown('SIGINT'));
process.on('SIGTERM', () => handleGracefulShutdown('SIGTERM'));
process.on('SIGHUP', () => handleGracefulShutdown('SIGHUP'));
