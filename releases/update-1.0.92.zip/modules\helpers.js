const fs = require('fs');
const path = require('path');
const db = require('../db');
const { DATA_DIR, PRINT_FOLDER } = require('./paths');

let _logger = console;

function init({ logger } = {}) {
    if (logger) _logger = logger;
}

async function saveOrderInfo(orderData) {
    try {
        await db.saveOrder(orderData);
    } catch (err) {
        _logger.error('❌ Errore salvataggio ordine su SQLite:', err);
    }
}

function saveNote(cliente, nota) {
    const notesFile = path.join(DATA_DIR, 'note.txt');
    const line = `[${new Date().toLocaleString()}] ${cliente}: ${nota}\n`;
    fs.appendFileSync(notesFile, line);
}

function deleteFileWithCleanup(relativePath) {
    if (!relativePath) return; // Ignora se non c'è file (es. note)
    const filePath = path.join(PRINT_FOLDER, relativePath);
    if (fs.existsSync(filePath)) {
        try {
            fs.unlinkSync(filePath);

            // Tenta di rimuovere la cartella genitore se vuota
            const folderPath = path.dirname(filePath);
            // Verifica che siamo ancora dentro la PRINT_FOLDER per sicurezza
            if (folderPath.startsWith(PRINT_FOLDER) && folderPath !== PRINT_FOLDER) {
                const files = fs.readdirSync(folderPath);
                if (files.length === 0) {
                    fs.rmdirSync(folderPath);
                    _logger.info(`🗑️ Cartella vuota rimossa: ${folderPath}`);
                }
            }
        } catch (err) {
            _logger.error(`Errore durante la pulizia del file ${relativePath}:`, err);
        }
    }
}

async function repairMismatchedFolders() {
    try {
        const orders = await db.getOrders(9999);
        let repairedCount = 0;

        for (const order of orders) {
            if (!order.file) continue;
            const expectedPath = path.join(PRINT_FOLDER, order.file);
            
            if (!fs.existsSync(expectedPath)) {
                const fileName = path.basename(order.file);
                const targetDir = path.join(PRINT_FOLDER, path.dirname(order.file));
                
                // 1. Controlla cartella numerica basata su telefono
                if (order.telefono) {
                    const numDir = path.join(PRINT_FOLDER, order.telefono.trim());
                    const numFilePath = path.join(numDir, fileName);

                    if (fs.existsSync(numFilePath)) {
                        if (!fs.existsSync(targetDir)) {
                            fs.mkdirSync(targetDir, { recursive: true });
                        }
                        const targetFilePath = path.join(targetDir, fileName);
                        fs.renameSync(numFilePath, targetFilePath);
                        repairedCount++;
                        _logger.info(`🛠 Riparazione cartella: ${numFilePath} -> ${targetFilePath}`);
                        
                        try {
                            if (fs.readdirSync(numDir).length === 0) {
                                fs.rmdirSync(numDir);
                            }
                        } catch(e){}
                        continue;
                    }
                }

                // 2. Se non ancora trovato, cerca il file in qualsiasi cartella di PRINT_FOLDER
                if (fs.existsSync(PRINT_FOLDER)) {
                    const subdirs = fs.readdirSync(PRINT_FOLDER);
                    for (const subdir of subdirs) {
                        const subdirPath = path.join(PRINT_FOLDER, subdir);
                        if (fs.statSync(subdirPath).isDirectory()) {
                            const candidateFile = path.join(subdirPath, fileName);
                            if (fs.existsSync(candidateFile)) {
                                if (!fs.existsSync(targetDir)) {
                                    fs.mkdirSync(targetDir, { recursive: true });
                                }
                                const targetFilePath = path.join(targetDir, fileName);
                                fs.renameSync(candidateFile, targetFilePath);
                                repairedCount++;
                                _logger.info(`🛠 Riparazione cartella (cerca globale): ${candidateFile} -> ${targetFilePath}`);
                                try {
                                    if (fs.readdirSync(subdirPath).length === 0) {
                                        fs.rmdirSync(subdirPath);
                                    }
                                } catch(e){}
                                break;
                            }
                        }
                    }
                }
            }
        }
        if (repairedCount > 0) {
            _logger.info(`✅ Riparazione completata: ${repairedCount} file riallineati nelle cartelle con nome contatto.`);
        }
    } catch (err) {
        _logger.error('❌ Errore durante la riparazione delle cartelle:', err);
    }
}

module.exports = {
    init,
    saveOrderInfo,
    saveNote,
    deleteFileWithCleanup,
    repairMismatchedFolders
};
