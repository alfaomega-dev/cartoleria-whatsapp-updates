const fs = require('fs');
const path = require('path');
const multer = require('multer');
const db = require('../db');
const { PRINT_FOLDER } = require('./paths');
const { getConfig } = require('./config');

let _logger = console;
let _notifyDashboard = () => {};

function init({ logger, notifyDashboard } = {}) {
    if (logger) _logger = logger;
    if (notifyDashboard) _notifyDashboard = notifyDashboard;
}

const webUploadStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const rawName = (req.body && req.body.nome) ? req.body.nome : 'Cliente_Web';
        const safeName = rawName.replace(/[^a-zA-Z0-9_-]/g, '_').trim() || 'Cliente_Web';
        const userFolder = path.join(PRINT_FOLDER, `WebBancone_${safeName}`);
        if (!fs.existsSync(userFolder)) {
            fs.mkdirSync(userFolder, { recursive: true });
        }
        cb(null, userFolder);
    },
    filename: function (req, file, cb) {
        const ext = path.extname(file.originalname).toLowerCase();
        const baseName = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 40) || 'doc';
        cb(null, `web_${Date.now()}_${baseName}${ext}`);
    }
});

const uploadWebMulter = multer({
    storage: webUploadStorage,
    limits: { fileSize: 100 * 1024 * 1024 } // 100MB per file
});

function generateUploadPage(currentConfig) {
    const config = currentConfig || getConfig();
    if (config.webBanconeEnabled === false) {
        return `<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servizio Non Attivo — PrintZap</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', sans-serif; }
        body { background: #0b0f19; color: #f8fafc; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .card { background: #161f30; border: 1px solid #283548; border-radius: 20px; padding: 36px 24px; max-width: 440px; text-align: center; box-shadow: 0 20px 40px rgba(0,0,0,0.5); }
        .icon { font-size: 3rem; margin-bottom: 16px; }
        h1 { font-size: 1.3rem; margin-bottom: 12px; color: #f87171; }
        p { color: #94a3b8; font-size: 0.95rem; line-height: 1.5; }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">🛑</div>
        <h1>Servizio Web Bancone Non Attivo</h1>
        <p>Il caricamento self-service da bancone è momentaneamente disattivato dal gestore della cartoleria. Rivolgiti al personale per stampare i tuoi documenti.</p>
    </div>
</body>
</html>`;
    }

    return `<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>PrintZap — Caricamento Rapido Bancone</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', system-ui, -apple-system, sans-serif; -webkit-tap-highlight-color: transparent; }
        body { background: #0b0f19; color: #f8fafc; padding: 12px; min-height: 100vh; display: flex; justify-content: center; align-items: flex-start; }
        .card { background: #161f30; border: 1px solid #283548; border-radius: 20px; width: 100%; max-width: 480px; padding: 20px 16px; box-shadow: 0 25px 35px -10px rgba(0,0,0,0.7); }
        
        .header { text-align: center; margin-bottom: 20px; border-bottom: 1px solid #283548; padding-bottom: 16px; }
        .header h1 { font-size: 1.35rem; font-weight: 800; color: #38bdf8; display: flex; align-items: center; justify-content: center; gap: 8px; letter-spacing: -0.5px; }
        .badge-live { background: rgba(37,211,102,0.15); color: #25d366; border: 1px solid rgba(37,211,102,0.4); padding: 5px 12px; border-radius: 20px; font-size: 0.78rem; font-weight: 600; margin-top: 8px; display: inline-block; }
        
        .form-group { margin-bottom: 16px; }
        label.input-title { display: block; font-size: 0.85rem; font-weight: 700; margin-bottom: 6px; color: #cbd5e1; }
        input[type="text"], input[type="tel"], textarea { width: 100%; padding: 13px 14px; border-radius: 10px; border: 1px solid #334155; background: #0b0f19; color: #f8fafc; font-size: 0.95rem; }
        input:focus, textarea:focus { outline: none; border-color: #38bdf8; box-shadow: 0 0 0 2px rgba(56,189,248,0.2); }
        
        /* Area Upload ottimizzata per touch e drag&drop */
        .upload-area { display: block; border: 2px dashed #38bdf8; border-radius: 14px; padding: 22px 14px; text-align: center; background: rgba(56,189,248,0.06); cursor: pointer; transition: all 0.2s; user-select: none; }
        .upload-area:active, .upload-area.dragover { background: rgba(56,189,248,0.18); border-color: #25d366; }
        .upload-icon { font-size: 2.4rem; margin-bottom: 6px; }
        .upload-title { font-weight: 700; font-size: 0.95rem; color: #38bdf8; }
        .upload-subtitle { font-size: 0.75rem; color: #94a3b8; margin-top: 4px; }
        
        .grid-options { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 6px; }
        .option-card { background: #0b0f19; border: 1px solid #283548; padding: 11px 8px; border-radius: 10px; cursor: pointer; text-align: center; font-size: 0.85rem; font-weight: 600; color: #94a3b8; transition: all 0.15s; }
        .option-card.selected { border-color: #38bdf8; background: rgba(56,189,248,0.18); color: #38bdf8; font-weight: 700; }
        
        .checkbox-group { display: flex; flex-direction: column; gap: 8px; margin-top: 6px; }
        .checkbox-label { display: flex; align-items: center; gap: 10px; background: #0b0f19; border: 1px solid #283548; padding: 10px 12px; border-radius: 10px; cursor: pointer; font-size: 0.85rem; font-weight: 500; }
        .checkbox-label input { width: 18px; height: 18px; accent-color: #38bdf8; }
        
        .stepper { display: flex; align-items: center; justify-content: center; gap: 16px; background: #0b0f19; border: 1px solid #283548; border-radius: 10px; padding: 8px; }
        .btn-step { width: 38px; height: 38px; border-radius: 50%; border: 1px solid #38bdf8; background: rgba(56,189,248,0.12); color: #38bdf8; font-size: 1.3rem; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; }
        
        .btn-submit { width: 100%; padding: 15px; background: linear-gradient(135deg, #38bdf8 0%, #0284c7 100%); color: #08101e; font-weight: 800; font-size: 1.05rem; border: none; border-radius: 12px; cursor: pointer; margin-top: 22px; transition: transform 0.1s, opacity 0.2s; box-shadow: 0 10px 20px -5px rgba(56,189,248,0.4); }
        .btn-submit:active { transform: scale(0.98); }
        .btn-submit:disabled { opacity: 0.5; box-shadow: none; cursor: not-allowed; }
        
        /* Lista Anteprime File */
        .file-list { margin-top: 12px; display: flex; flex-direction: column; gap: 8px; }
        .file-card { display: flex; align-items: center; justify-content: space-between; padding: 10px 12px; background: #0b0f19; border-radius: 10px; border: 1px solid #334155; }
        .file-thumb { width: 48px; height: 48px; border-radius: 8px; object-fit: cover; background: #1e293b; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; flex-shrink: 0; border: 1px solid #475569; overflow: hidden; }
        .file-details { margin-left: 10px; flex: 1; min-width: 0; }
        .file-name { font-size: 0.85rem; font-weight: 700; color: #f8fafc; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .file-size { font-size: 0.75rem; color: #94a3b8; margin-top: 2px; }
        .btn-remove-file { background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.4); border-radius: 8px; padding: 6px 10px; cursor: pointer; font-size: 0.8rem; font-weight: bold; }
        .files-count-badge { display: block; background: rgba(37,211,102,0.15); color: #25d366; border: 1px solid rgba(37,211,102,0.4); padding: 8px 12px; border-radius: 8px; font-size: 0.82rem; font-weight: 700; margin-top: 10px; text-align: center; }
        
        /* Barra di avanzamento */
        .progress-container { display: none; margin-top: 14px; background: #0b0f19; border-radius: 10px; border: 1px solid #334155; overflow: hidden; padding: 3px; }
        .progress-bar { height: 12px; background: linear-gradient(90deg, #38bdf8, #25d366); width: 0%; border-radius: 7px; transition: width 0.2s; }
        .progress-text { text-align: center; font-size: 0.75rem; color: #94a3b8; margin-top: 6px; font-weight: 600; }
        
        #successScreen { display: none; text-align: center; padding: 30px 10px; }
        .success-icon { font-size: 4.2rem; color: #25d366; margin-bottom: 14px; }
        .ticket-box { background: rgba(37,211,102,0.12); border: 2px dashed #25d366; border-radius: 14px; padding: 18px; margin: 20px 0; font-size: 1.6rem; font-weight: 800; color: #25d366; letter-spacing: 1px; }
    </style>
</head>
<body>
    <div class="card">
        <div id="uploadFormScreen">
            <div class="header">
                <h1>🖨️ PrintZap Bancone</h1>
                <span class="badge-live">🟢 Bancone Attivo — Invia per la Stampa</span>
            </div>

            <form id="mainUploadForm">
                <div class="form-group">
                    <label class="input-title">Nome e Cognome *</label>
                    <input type="text" id="nome" required placeholder="es. Mario Rossi" autocomplete="name">
                </div>

                <div class="form-group">
                    <label class="input-title">Cellulare (Opzionale per avviso)</label>
                    <input type="tel" id="telefono" placeholder="es. 3331234567" autocomplete="tel">
                </div>

                <div class="form-group">
                    <label class="input-title">Seleziona File da Stampare</label>
                    
                    <!-- Input file nascosto separato -->
                    <input type="file" id="fileInput" multiple style="display:none;">

                    <!-- Area cliccabile con supporto drag & drop -->
                    <div class="upload-area" id="dropArea">
                        <div class="upload-icon">📁</div>
                        <div class="upload-title">Tocca qui per scegliere Foto o Documenti</div>
                        <div class="upload-subtitle">PDF, Word, Excel, JPG, PNG (anche più file insieme)</div>
                    </div>

                    <div id="filesCountDisplay" style="display:none;"></div>
                    <div class="file-list" id="fileListDisplay"></div>
                </div>

                <div class="form-group">
                    <label class="input-title">Formato Carta</label>
                    <div class="grid-options" id="formatoCartaGroup">
                        <div class="option-card selected" onclick="selectCard('formatoCartaGroup', this, 'A4')">📄 A4 Standard (80g)</div>
                        <div class="option-card" onclick="selectCard('formatoCartaGroup', this, 'A3')">📐 A3 Grande</div>
                        <div class="option-card" onclick="selectCard('formatoCartaGroup', this, 'Foto')">🖼️ Carta Fotografica</div>
                        <div class="option-card" onclick="selectCard('formatoCartaGroup', this, 'Cartoncino')">🎴 Cartoncino</div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="input-title">Colore Stampa</label>
                    <div class="grid-options" id="coloreGroup">
                        <div class="option-card selected" onclick="selectCard('coloreGroup', this, 'B/N')">⚫ Bianco e Nero</div>
                        <div class="option-card" onclick="selectCard('coloreGroup', this, 'Colore')">🎨 A Colori</div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="input-title">Finitura & Opzioni</label>
                    <div class="checkbox-group">
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkFronteRetro"> 📑 Stampa Fronte e Retro
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkNonSpillate" checked> 📄 Non Spillate (Fogli Sciolti)
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkSpillatura"> 📌 Spillatura nell'angolo (Pinzatura)
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkRilegatura"> 🌀 Rilegatura a Spirale
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" id="chkBusta"> ✉️ Busta Protettiva Trasparente
                        </label>
                    </div>
                </div>

                <div class="form-group">
                    <label class="input-title">Numero Copie</label>
                    <div class="stepper">
                        <button type="button" class="btn-step" onclick="changeCopie(-1)">-</button>
                        <span id="copieVal" style="font-size: 1.25rem; font-weight: 800; width: 36px; text-align: center; color: #f8fafc;">1</span>
                        <button type="button" class="btn-step" onclick="changeCopie(1)">+</button>
                    </div>
                </div>

                <div class="form-group">
                    <label class="input-title">Note / Richiesta per l'operatore (Opzionale)</label>
                    <textarea id="note" rows="2" placeholder="es. Stampa solo le prime 3 pagine, oppure chiedi informazioni..."></textarea>
                </div>

                <div class="progress-container" id="progressContainer">
                    <div class="progress-bar" id="progressBar"></div>
                </div>
                <div class="progress-text" id="progressText" style="display:none;">Caricamento: 0%</div>

                <button type="submit" class="btn-submit" id="submitBtn">🚀 INVIA AL BANCONE</button>
            </form>
        </div>

        <div id="successScreen">
            <div class="success-icon">✅</div>
            <h2 style="font-size: 1.4rem; font-weight: 800; color: #f8fafc;">Inviato alla Cassa!</h2>
            <p style="font-size: 0.9rem; color: #cbd5e1; margin-top: 8px;">I tuoi dati e documenti sono stati ricevuti con successo dalla cartoleria.</p>
            <div class="ticket-box" id="ticketNumberDisplay">CODICE #W-101</div>
            <p style="font-size: 0.85rem; color: #94a3b8;">Mostra questo codice o comunica il tuo nome al bancone per il ritiro rapido.</p>
            <button type="button" class="btn-submit" onclick="location.reload()" style="margin-top: 24px;">🔄 Invia un'altra richiesta</button>
        </div>
    </div>

    <script>
        let selectedFormato = 'A4';
        let selectedColore = 'B/N';
        let copieCount = 1;
        let selectedFiles = [];

        function selectCard(groupId, element, val) {
            document.querySelectorAll('#' + groupId + ' .option-card').forEach(el => el.classList.remove('selected'));
            element.classList.add('selected');
            if (groupId === 'formatoCartaGroup') selectedFormato = val;
            if (groupId === 'coloreGroup') selectedColore = val;
        }

        function changeCopie(delta) {
            copieCount = Math.max(1, copieCount + delta);
            document.getElementById('copieVal').textContent = copieCount;
        }

        const fileInputEl = document.getElementById('fileInput');
        const dropAreaEl = document.getElementById('dropArea');

        // Click sull'area apre il selettore nativo in modo pulito
        dropAreaEl.addEventListener('click', function() {
            fileInputEl.click();
        });

        // Evento cambio file
        fileInputEl.addEventListener('change', function(e) {
            if (this.files && this.files.length > 0) {
                addFiles(this.files);
                this.value = ''; // Reset per consentire nuove selezioni
            }
        });

        // Supporto Drag & Drop completo
        dropAreaEl.addEventListener('dragover', function(e) {
            e.preventDefault();
            dropAreaEl.classList.add('dragover');
        });
        dropAreaEl.addEventListener('dragleave', function(e) {
            e.preventDefault();
            dropAreaEl.classList.remove('dragover');
        });
        dropAreaEl.addEventListener('drop', function(e) {
            e.preventDefault();
            dropAreaEl.classList.remove('dragover');
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                addFiles(e.dataTransfer.files);
            }
        });

        function addFiles(files) {
            for (let i = 0; i < files.length; i++) {
                const f = files[i];
                const exists = selectedFiles.some(item => item.name === f.name && item.size === f.size);
                if (!exists) {
                    selectedFiles.push(f);
                }
            }
            renderFileList();
        }

        function removeFile(index) {
            selectedFiles.splice(index, 1);
            renderFileList();
        }

        function renderFileList() {
            const display = document.getElementById('fileListDisplay');
            const countDisplay = document.getElementById('filesCountDisplay');
            display.innerHTML = '';

            if (selectedFiles.length === 0) {
                countDisplay.style.display = 'none';
                return;
            }

            countDisplay.style.display = 'block';
            countDisplay.innerHTML = '<span class="files-count-badge">✅ ' + selectedFiles.length + ' ' + (selectedFiles.length === 1 ? 'file pronto per la stampa' : 'file pronti per la stampa') + '</span>';

            selectedFiles.forEach((file, idx) => {
                const card = document.createElement('div');
                card.className = 'file-card';

                const ext = (file.name.split('.').pop() || '').toLowerCase();
                const isImage = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'heic'].includes(ext);
                const isPdf = ext === 'pdf';
                const isOffice = ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(ext);

                const thumbContainer = document.createElement('div');
                thumbContainer.className = 'file-thumb';

                if (isImage) {
                    const img = document.createElement('img');
                    try {
                        img.src = URL.createObjectURL(file);
                    } catch(e) {}
                    img.style.width = '100%';
                    img.style.height = '100%';
                    img.style.objectFit = 'cover';
                    thumbContainer.appendChild(img);
                } else {
                    thumbContainer.textContent = isPdf ? '📕' : isOffice ? '📘' : '📄';
                }

                const details = document.createElement('div');
                details.className = 'file-details';

                const nameEl = document.createElement('div');
                nameEl.className = 'file-name';
                nameEl.textContent = file.name;
                nameEl.title = file.name;

                const sizeMb = (file.size / 1024 / 1024).toFixed(2);
                const sizeText = file.size > 1024 * 1024 ? sizeMb + ' MB' : Math.round(file.size / 1024) + ' KB';
                
                const sizeEl = document.createElement('div');
                sizeEl.className = 'file-size';
                sizeEl.textContent = sizeText + ' • ' + ext.toUpperCase();

                details.appendChild(nameEl);
                details.appendChild(sizeEl);

                const removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.className = 'btn-remove-file';
                removeBtn.textContent = '❌ Rimuovi';
                removeBtn.onclick = function() { removeFile(idx); };

                card.appendChild(thumbContainer);
                card.appendChild(details);
                card.appendChild(removeBtn);
                display.appendChild(card);
            });
        }

        document.getElementById('mainUploadForm').addEventListener('submit', function(e) {
            e.preventDefault();

            const nomeVal = document.getElementById('nome').value.trim();
            if (!nomeVal) {
                alert('⚠️ Inserisci il tuo Nome e Cognome prima di procedere.');
                return;
            }

            const noteVal = document.getElementById('note').value.trim();

            if (selectedFiles.length === 0 && !noteVal) {
                alert('⚠️ Seleziona almeno un documento da stampare oppure scrivi un messaggio/richiesta nelle note!');
                return;
            }

            const btn = document.getElementById('submitBtn');
            const progContainer = document.getElementById('progressContainer');
            const progBar = document.getElementById('progressBar');
            const progText = document.getElementById('progressText');

            btn.disabled = true;
            btn.textContent = selectedFiles.length > 0 ? '⏳ Caricamento file in corso...' : '⏳ Invio richiesta in corso...';
            
            if (selectedFiles.length > 0) {
                progContainer.style.display = 'block';
                progText.style.display = 'block';
                progBar.style.width = '0%';
            }

            const formData = new FormData();
            formData.append('nome', nomeVal);
            formData.append('telefono', document.getElementById('telefono').value.trim());
            formData.append('formato', selectedFormato);
            formData.append('colore', selectedColore);
            formData.append('copie', copieCount);
            formData.append('fronteRetro', document.getElementById('chkFronteRetro').checked ? 'Sì' : 'No');
            formData.append('nonSpillate', document.getElementById('chkNonSpillate').checked ? 'Sì' : 'No');
            formData.append('spillatura', document.getElementById('chkSpillatura').checked ? 'Sì' : 'No');
            formData.append('rilegatura', document.getElementById('chkRilegatura').checked ? 'Sì' : 'No');
            formData.append('busta', document.getElementById('chkBusta').checked ? 'Sì' : 'No');
            formData.append('note', noteVal);

            selectedFiles.forEach(file => {
                formData.append('files', file);
            });

            const xhr = new XMLHttpRequest();
            xhr.open('POST', '/api/web/upload', true);

            xhr.upload.onprogress = function(event) {
                if (event.lengthComputable && selectedFiles.length > 0) {
                    const percent = Math.round((event.loaded / event.total) * 100);
                    progBar.style.width = percent + '%';
                    progText.textContent = 'Invio in corso: ' + percent + '%';
                }
            };

            xhr.onload = function() {
                if (xhr.status >= 200 && xhr.status < 300) {
                    try {
                        const data = JSON.parse(xhr.responseText);
                        if (data.success) {
                            document.getElementById('uploadFormScreen').style.display = 'none';
                            document.getElementById('successScreen').style.display = 'block';
                            document.getElementById('ticketNumberDisplay').textContent = 'CODICE ' + (data.ticketCode || '#W-BANCONE');
                        } else {
                            alert('Errore dal server: ' + (data.error || 'Impossibile completare'));
                            resetBtn();
                        }
                    } catch (e) {
                        alert('Errore di elaborazione risposta server.');
                        resetBtn();
                    }
                } else {
                    alert('Errore HTTP ' + xhr.status + ' durante il caricamento.');
                    resetBtn();
                }
            };

            xhr.onerror = function() {
                alert('Errore di connessione di rete durante l\'invio.');
                resetBtn();
            };

            function resetBtn() {
                btn.disabled = false;
                btn.textContent = '🚀 INVIA AL BANCONE';
                progContainer.style.display = 'none';
                progText.style.display = 'none';
            }

            xhr.send(formData);
        });
    </script>
</body>
</html>`;
}

async function handleWebUpload({ body, files } = {}) {
    const { nome, telefono, formato, colore, copie, fronteRetro, nonSpillate, spillatura, rilegatura, busta, note } = body || {};
    const uploadFiles = files || [];

    let totalProcessed = 0;
    const ticketIndex = Math.floor(100 + Math.random() * 900);
    const lastTicketCode = `#W-${ticketIndex}`;

    const finitureList = [];
    if (fronteRetro === 'Sì') finitureList.push('Fronte/Retro');
    if (nonSpillate === 'Sì') finitureList.push('Fogli Sciolti');
    if (spillatura === 'Sì') finitureList.push('Spillato');
    if (rilegatura === 'Sì') finitureList.push('Rilegatura');
    if (busta === 'Sì') finitureList.push('Busta Protettiva');
    const finituraStr = finitureList.length > 0 ? finitureList.join(', ') : 'Standard';

    // Caso 1: File allegati
    if (uploadFiles.length > 0) {
        for (let i = 0; i < uploadFiles.length; i++) {
            const file = uploadFiles[i];
            const relativePath = path.relative(PRINT_FOLDER, file.path).replace(/\\/g, '/');
            const formattedMsg = `📋 Modulo Web Bancone | Formato: ${formato || 'A4'} | Colore: ${colore || 'B/N'} | Copie: ${copie || 1} | Finitura: ${finituraStr}${note ? ' | Note: ' + note : ''}`;

            const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
            const isImg = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'heic'].includes(ext);
            const docType = isImg ? 'immagine' : 'documento';

            const orderData = {
                id: `web_ord_${Date.now()}_${i}_${Math.random().toString(36).substr(2, 4)}`,
                cliente: `${nome || 'Cliente Web'} (Web Bancone)`,
                telefono: telefono ? `web_${telefono}` : 'web_bancone',
                file: relativePath,
                data: new Date().toISOString(),
                stato: 'ricevuto',
                tipo: docType,
                messaggio: formattedMsg,
                msgId: `web_msg_${Date.now()}_${i}`
            };

            await db.saveOrder(orderData);
            _notifyDashboard({
                type: 'NEW_ORDER',
                order: orderData,
                channel: 'web'
            });
            totalProcessed++;
        }
        _logger.info(`🌐 Ricevuti e salvati ${totalProcessed} file dal Modulo Web Bancone per ${nome}`);
    } else {
        // Caso 2: Solo richiesta / messaggio testuale senza file
        const orderData = {
            id: `web_note_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
            cliente: `${nome || 'Cliente Web'} (Web Bancone)`,
            telefono: telefono ? `web_${telefono}` : 'web_bancone',
            file: '',
            data: new Date().toISOString(),
            stato: 'ricevuto',
            tipo: 'nota',
            messaggio: `📋 Modulo Web Bancone | Richiesta/Note: ${note || 'Richiesta info al bancone'} (Formato: ${formato || 'A4'}, Copie: ${copie || 1})`,
            msgId: `web_note_${Date.now()}`
        };

        await db.saveOrder(orderData);
        _notifyDashboard({
            type: 'NEW_ORDER',
            order: orderData,
            channel: 'web'
        });
        totalProcessed = 1;
        _logger.info(`📝 Ricevuta richiesta testuale dal Modulo Web Bancone per ${nome}`);
    }

    return { success: true, processed: totalProcessed, ticketCode: lastTicketCode };
}

module.exports = {
    init,
    generateUploadPage,
    uploadWebMulter,
    handleWebUpload
};
