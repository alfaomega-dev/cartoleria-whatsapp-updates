const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const qrcode = require('qrcode-terminal');
const db = require('../db');
const linkDownloader = require('../link-downloader');

const { ROOT_DIR, DATA_DIR, AUTH_DIR, PRINT_FOLDER } = require('./paths');
const { getConfig, saveConfig, checkLicense } = require('./config');
const { cleanupOldSessions, clearSessionLocks, killOrphanedChrome } = require('./startup');
const { waitForNetwork, checkAndApplyHotPatch, isPuppeteerContextError, promiseTimeout } = require('./session');
const { saveOrderInfo, saveNote, deleteFileWithCleanup, repairMismatchedFolders } = require('./helpers');

let Client, LocalAuth;
let _logger = console;
let _notifyDashboard = () => {};

// WhatsApp State
let client = null;
let wpStatus = 'DISCONNECTED'; // 'DISCONNECTED'|'INITIALIZING'|'WAITING_FOR_QR'|'AUTHENTICATING'|'CONNECTED'|'EXPIRED'
let latestQR = null;
let isSyncing = false;       // Flag: blocca eventi message durante la sync iniziale
let pendingMessages = [];    // Coda messaggi ricevuti durante la sync
let isInitializing = false;  // Flag: previene inizializzazioni parallele concorrenti
let reconnectAttempts = 0;
const RECONNECT_BASE_DELAY = 5000;   // 5 secondi base
const RECONNECT_MAX_DELAY  = 300000; // massimo 5 minuti

let messageQueueChain = Promise.resolve();
let lastUniqueOrderTimestamp = 0;

function init({ logger, notifyDashboard } = {}) {
    if (logger) _logger = logger;
    if (notifyDashboard) _notifyDashboard = notifyDashboard;
}

function getStatus() {
    return {
        status: wpStatus,
        qr: latestQR,
        isSyncing,
        pendingMessages: pendingMessages.length
    };
}

function getWpStatus() {
    return wpStatus;
}

function setWpStatus(status) {
    wpStatus = status;
}

function getLatestQR() {
    return latestQR;
}

function getClient() {
    return client;
}

function isReady() {
    return wpStatus === 'CONNECTED' && !!client;
}

function generateUniqueOrderId() {
    let now = Date.now();
    if (now <= lastUniqueOrderTimestamp) {
        now = lastUniqueOrderTimestamp + 1;
    }
    lastUniqueOrderTimestamp = now;
    return now;
}

function getMessageId(msg) {
    if (!msg) return null;
    if (msg.id) {
        if (typeof msg.id === 'string' && msg.id !== '[object Object]') return msg.id;
        if (msg.id._serialized && msg.id._serialized !== '[object Object]' && typeof msg.id._serialized === 'string' && !msg.id._serialized.includes('[object Object]')) {
            return msg.id._serialized;
        }
        if (msg.id.$1 && msg.id.$1 !== '[object Object]' && typeof msg.id.$1 === 'string' && !msg.id.$1.includes('[object Object]')) {
            return msg.id.$1;
        }
        if (msg.id.id) {
            const remote = msg.id.remote || msg.from || 'unknown';
            const remoteStr = typeof remote === 'object' && remote !== null
                ? ((remote._serialized && remote._serialized !== '[object Object]') ? remote._serialized : (remote.$1 || (remote.user && remote.server ? `${remote.user}@${remote.server}` : 'unknown')))
                : remote;
            const fromMe = msg.id.fromMe ? 'true' : 'false';
            if (remoteStr && remoteStr !== 'unknown') {
                return `${fromMe}_${remoteStr}_${msg.id.id}`;
            }
            return `${fromMe}_${msg.from || 'unknown'}_${msg.id.id}`;
        }
    }
    if (msg.from && msg.timestamp) {
        const extraKey = msg.mediaKey || (msg.mediaData && msg.mediaData.filehash) || (msg._data && (msg._data.filehash || msg._data.id)) || Math.random().toString(36).substring(2, 6);
        return `fallback_${msg.from}_${msg.timestamp}_${msg.type || 'text'}_${extraKey}`;
    }
    return null;
}

function enqueueIncomingMessage(msg) {
    const task = async () => {
        try {
            await processMessageSafe(msg);
            await new Promise(r => setTimeout(r, 200));
        } catch (err) {
            _logger.error('❌ Errore in coda elaborazione messaggio:', err);
        }
    };
    messageQueueChain = messageQueueChain.then(task, task);
    return messageQueueChain;
}

async function handleRevokedMessage(after, before) {
    _logger.info(`🗑️ Evento revoca messaggio avviato...`);
    try {
        const candidates = new Set();

        if (after?.protocolMessageKey) {
            if (after.protocolMessageKey.id) candidates.add(after.protocolMessageKey.id);
            if (after.protocolMessageKey._serialized) candidates.add(after.protocolMessageKey._serialized);
            const remote = after.protocolMessageKey.remoteJid || after.protocolMessageKey.remote || after.from || after.to;
            if (remote && after.protocolMessageKey.id) {
                candidates.add(`false_${remote}_${after.protocolMessageKey.id}`);
                candidates.add(`true_${remote}_${after.protocolMessageKey.id}`);
            }
        }

        if (before) {
            const bId = getMessageId(before);
            if (bId) candidates.add(bId);
            if (before.id?._serialized) candidates.add(before.id._serialized);
            if (before.id?.id) candidates.add(before.id.id);
            if (before.id?.$1) candidates.add(before.id.$1);
            if (before.protocolMessageKey?.id) candidates.add(before.protocolMessageKey.id);
        }

        if (after) {
            const aId = getMessageId(after);
            if (aId) candidates.add(aId);
            if (after.id?._serialized) candidates.add(after.id._serialized);
            if (after.id?.id) candidates.add(after.id.id);
            if (after.id?.$1) candidates.add(after.id.$1);
        }

        const candidateList = Array.from(candidates).filter(Boolean);
        _logger.info(`🔍 Candidati ID revoca (${candidateList.length}): ${candidateList.join(', ')}`);

        if (candidateList.length > 0) {
            const order = await db.getOrderByMsgId(candidateList);
            if (order) {
                _logger.info(`🗑️ Trovato ordine da eliminare per messaggio revocato su WhatsApp: ID ${order.id} | File: ${order.file || 'Nessuno'}`);
                if (order.file) {
                    deleteFileWithCleanup(order.file);
                }
                await db.deleteOrderById(order.id);
                _logger.info(`✅ Ordine ID ${order.id} e file associato eliminati con successo in seguito all'annullamento del cliente.`);
            } else {
                _logger.info(`ℹ️ Nessun ordine associato ai candidati di revoca trovato nel database.`);
            }
        }
    } catch (error) {
        _logger.error('❌ Errore durante il processamento del messaggio revocato:', error);
    }
}

async function initializeClient() {
    if (isInitializing) {
        _logger.info('⚠️ initializeClient è già in corso. Ignoro chiamata parallela.');
        return;
    }
    isInitializing = true;
    _logger.info('🎬 Avvio initializeClient...');
    await checkAndApplyHotPatch();

    await waitForNetwork(15);

    if (!Client || !LocalAuth) {
        try {
            _logger.info('📦 Caricamento di whatsapp-web.js...');
            const wweb = require('whatsapp-web.js');
            Client = wweb.Client;
            LocalAuth = wweb.LocalAuth;
            _logger.info('📦 Libreria whatsapp-web.js caricata correttamente.');
        } catch (wwebErr) {
            _logger.error(`❌ Errore critico nel caricamento di whatsapp-web.js: ${wwebErr.message}`);
            isInitializing = false;
            return;
        }
    }
    cleanupOldSessions();
    killOrphanedChrome();

    const cachePathStartup = path.join(DATA_DIR, '.wwebjs_cache');
    if (fs.existsSync(cachePathStartup)) {
        try {
            fs.rmSync(cachePathStartup, { recursive: true, force: true });
            _logger.info('🗑️ Cache WhatsApp Web rimossa per avvio pulito.');
        } catch (e) {
            _logger.info('ℹ️ Impossibile rimuovere cache: ' + e.message);
        }
    }

    wpStatus = 'INITIALIZING';
    const lic = checkLicense();
    if (!lic.valid) {
        _logger.error(`🛑 ${lic.message}`);
        _logger.info(`🛑 LICENSE EXPIRED: ${lic.message}`);
        wpStatus = 'EXPIRED';
        isInitializing = false;
        return;
    }

    if (lic.isTrial) {
        _logger.info(`💡 ${lic.message}`);
    }

    let executablePath = undefined;
    const localChrome = path.join(ROOT_DIR, 'chrome-win64', 'chrome.exe');
    const systemChromePaths = [
        localChrome,
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
        path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'),
        'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
        'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Microsoft\\Edge\\Application\\msedge.exe')
    ];

    for (const p of systemChromePaths) {
        if (p && fs.existsSync(p)) {
            executablePath = p;
            _logger.info(`🌐 Browser trovato in: ${p}`);
            break;
        }
    }

    if (!executablePath) {
        _logger.info("⚠️ ATTENZIONE: Chrome non trovato nel sistema. WhatsApp potrebbe non avviarsi.");
        _logger.error("❌ Chrome non trovato! Installalo o aggiungi 'chrome-win64' nella cartella root.");
    }

    if (executablePath) _logger.info('Chromium locale trovato:', executablePath);

    const config = getConfig();
    const activeSessionDir = path.join(AUTH_DIR, `session-${config.clientId}`);
    clearSessionLocks(activeSessionDir);

    client = new Client({
        authStrategy: new LocalAuth({ clientId: config.clientId, dataPath: AUTH_DIR }),
        authTimeoutMs: 60000,
        qrMaxRetries: 5,
        puppeteer: {
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--disable-gpu',
                '--disable-session-crashed-bubble',
                '--disable-features=Translate,OptimizationHints',
                '--disable-blink-features=AutomationControlled',
                '--disable-infobars'
            ],
            executablePath: executablePath
        },
        webVersionCache: {
            type: 'none'
        }
    });

    client.on('qr', (qr) => {
        isInitializing = false;
        _logger.info('Scansiona questo QR con WhatsApp:');
        _logger.info('📷 QR Code generato. In attesa di scansione...');
        qrcode.generate(qr, { small: true });
        wpStatus = 'WAITING_FOR_QR';
        latestQR = qr;
    });

    client.on('ready', async () => {
        isInitializing = false;
        _logger.info('✅ WhatsApp connesso e pronto!');
        _logger.info('✅ EVENTO READY: WhatsApp connesso e pronto!');
        wpStatus = 'CONNECTED';
        reconnectAttempts = 0;
        latestQR = null;

        if (client.pupPage) {
            await applyBrowserCompatibilityPatches(client.pupPage);
        }

        await new Promise(r => setTimeout(r, 3000));
        isSyncing = true;
        pendingMessages = [];
        try {
            await syncUnreadMessages(client);
        } finally {
            isSyncing = false;
            if (pendingMessages.length > 0) {
                _logger.info(`📬 Processo ${pendingMessages.length} messaggi ricevuti durante la sync...`);
                const queue = [...pendingMessages];
                pendingMessages = [];
                for (const m of queue) {
                    await enqueueIncomingMessage(m);
                }
            }
            _logger.info('✅ Sync completata. Ascolto nuovi messaggi attivo.');
        }
    });

    client.on('authenticated', () => {
        _logger.info('🔑 Autenticato con successo!');
        _logger.info('🔑 EVENTO AUTHENTICATED: Sessione ripristinata o nuova sessione creata.');
        wpStatus = 'AUTHENTICATING';
        latestQR = null;

        // Watchdog per sessioni ripristinate da disco: se Socket.hasSynced è già true, sblocca la transizione a READY
        setTimeout(async () => {
            if (wpStatus !== 'CONNECTED' && client && client.pupPage && !client.pupPage.isClosed()) {
                try {
                    await client.pupPage.evaluate(() => {
                        const Socket = window.require && window.require('WAWebSocketModel')?.Socket;
                        if (Socket && Socket.hasSynced && typeof window.onAppStateHasSyncedEvent === 'function') {
                            window.onAppStateHasSyncedEvent();
                        }
                    });
                } catch (e) {}
            }
        }, 3000);
    });

    client.on('auth_failure', msg => {
        isInitializing = false;
        _logger.error('⛔ Errore di autenticazione:', msg);
        _logger.info(`⛔ EVENTO AUTH_FAILURE: ${msg}`);
        wpStatus = 'DISCONNECTED';
    });

    client.on('message', async msg => {
        const msgId = getMessageId(msg);
        _logger.info(`📥 Evento 'message' intercettato da: ${msg?.from || 'Mittente sconosciuto'} | ID: ${msgId || 'Nessuno'} | Tipo: ${msg?.type || 'Sconosciuto'}`);
        
        if (msg?.type === 'revoked') {
            await handleRevokedMessage(msg, null);
            return;
        }

        if (isSyncing) {
            pendingMessages.push(msg);
            _logger.info(`⏸ Messaggio in coda (sync in corso): ${msgId || 'ID sconosciuto'}`);
            return;
        }
        enqueueIncomingMessage(msg);
    });

    client.on('message_create', async msg => {
        if (msg.fromMe) {
            try {
                const targetId = msg.to;
                if (!targetId || targetId.includes('@g.us') || targetId.includes('@broadcast') || targetId.includes('@newsletter')) return;

                const bodyLower = (msg.body || '').toLowerCase();
                // Rileva risposte del negoziante come "stampa pronta", "documenti pronti", "puoi passare a ritirare"
                const isReadyResponse = bodyLower.includes('stampa pronta') ||
                                        bodyLower.includes('pronto') ||
                                        bodyLower.includes('pronte') ||
                                        bodyLower.includes('pronti') ||
                                        bodyLower.includes('ritirare');

                if (isReadyResponse) {
                    _logger.info(`⚡ Rilevato messaggio notifica/risposta negoziante per ${targetId}: "${msg.body}"`);
                    const candidates = [targetId, targetId.replace(/@c\.us|@lid/g, '')];
                    try {
                        const contact = await client.getContactById(targetId);
                        if (contact && contact.number) candidates.push(contact.number);
                    } catch (e) {}

                    const updated = await db.markContactOrdersPrinted(candidates);
                    if (updated) {
                        _logger.info(`✅ Ordini per ${candidates.join(', ')} contrassegnati come STAMPATI in seguito a risposta da cellulare.`);
                        if (typeof _notifyDashboard === 'function') {
                            _notifyDashboard({ type: 'ORDERS_UPDATED' });
                        }
                    }
                }
            } catch (error) {
                _logger.error('❌ Errore processamento messaggio in uscita negoziante:', error);
            }
        }
    });

    client.on('chat_removed', async chat => {
        if (chat.isGroup) return;
        const chatJid = chat.id._serialized;
        _logger.info(`🗑️ Evento 'chat_removed' intercettato per la chat: ${chatJid}`);
        try {
            const contact = await client.getContactById(chatJid);
            const phone = contact.number;

            if (phone) {
                const orders = await db.getOrdersByPhone(phone);
                if (orders.length > 0) {
                    _logger.info(`🗑️ Rimozione di ${orders.length} ordini associati al numero ${phone}`);

                    orders.forEach(order => {
                        if (order.file) {
                            deleteFileWithCleanup(order.file);
                        }
                    });

                    await db.deleteOrdersByPhone(phone);
                    _logger.info(`✅ Eliminati con successo tutti gli ordini per ${phone} dal database.`);
                } else {
                    _logger.info(`ℹ️ Nessun ordine presente nel database per il numero ${phone}.`);
                }
            }
        } catch (error) {
            _logger.error('❌ Errore durante la rimozione automatica degli ordini per chat rimossa:', error);
        }
    });

    client.on('message_revoke_everyone', async (after, before) => {
        _logger.info(`🗑️ Evento 'message_revoke_everyone' intercettato!`);
        await handleRevokedMessage(after, before);
    });

    client.on('disconnected', async (reason) => {
        _logger.info('❌ WhatsApp disconnesso:', reason);
        _logger.info(`❌ WhatsApp disconnesso: ${reason}. Inizializzo reset automatico sessione...`);
        wpStatus = 'DISCONNECTED';
        latestQR = null;
        isInitializing = false;

        if (client) {
            try {
                const destroyPromise = client.destroy();
                const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 5000));
                await Promise.race([destroyPromise, timeoutPromise]).catch(() => { });
                await new Promise(r => setTimeout(r, 1000));
            } catch (err) { }
            client = null;
        }

        const currentConfig = getConfig();
        _logger.info(`🔄 Riavvio con la sessione esistente (${currentConfig.clientId}) per preservare il login WhatsApp.`);

        const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
        if (fs.existsSync(cachePath)) {
            try { fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 }); } catch (e) { _logger.info('Errore delete dir cache: ' + e.message); }
        }

        reconnectAttempts++;
        const delay = Math.min(RECONNECT_BASE_DELAY * Math.pow(2, reconnectAttempts - 1), RECONNECT_MAX_DELAY);
        _logger.info(`🔄 Tentativo di riconnessione #${reconnectAttempts} tra ${Math.round(delay / 1000)}s...`);
        setTimeout(initializeClient, delay);
    });

    try {
        _logger.info(`🛠️ Inizializzazione client con browser: ${executablePath || 'Default'}`);
        client.initialize().catch(err => {
            _logger.info(`❌ Errore in client.initialize(): ${err.message}`);
            _logger.error('Errore inizializzazione:', err);
            wpStatus = 'DISCONNECTED';
            isInitializing = false;
        });
    } catch (err) {
        _logger.info(`❌ Eccezione durante inizializzazione: ${err.message}`);
        wpStatus = 'DISCONNECTED';
        isInitializing = false;
    }
}

async function syncUnreadMessages(clientInstance = client, retryCount = 0) {
    _logger.info('🔍 Sincronizzazione messaggi non letti (avvio)...');
    try {
        if (!clientInstance) {
            _logger.error('❌ Errore sync: clientInstance è nullo.');
            return;
        }
        const processedMsgIds = await db.getProcessedMessageIds();
        const chats = await promiseTimeout(clientInstance.getChats(), 15000, 'client.getChats()');
        const unreadChats = chats.filter(chat => !chat.isGroup && chat.unreadCount > 0);

        if (unreadChats.length > 0) {
            _logger.info(`📬 Trovate ${unreadChats.length} chat con messaggi non letti...`);

            for (const chat of unreadChats) {
                try {
                    const messages = await promiseTimeout(chat.fetchMessages({ limit: Math.max(chat.unreadCount, 30) }), 10000, `chat.fetchMessagesUnread(${chat.name})`);

                    const unprocessed = messages.filter(m =>
                        !m.fromMe &&
                        !processedMsgIds.has(m.id._serialized)
                    );

                    if (unprocessed.length > 0) {
                        _logger.info(`📩 Chat "${chat.name}": processamento di ${unprocessed.length} nuovi messaggi...`);
                        for (const m of unprocessed) {
                            await enqueueIncomingMessage(m);
                            processedMsgIds.add(m.id._serialized);
                        }
                    }

                    await chat.sendSeen();
                } catch (chatErr) {
                    if (!isPuppeteerContextError(chatErr)) {
                        _logger.error(`⚠️ Errore sincronizzazione chat "${chat.name}":`, chatErr.message);
                    }
                }
            }
        }

        _logger.info('✅ Sincronizzazione all\'avvio completata.');

    } catch (error) {
        _logger.info(`🔍 Dettaglio errore sync: ${error.message}\n${error.stack}`);
        if (isPuppeteerContextError(error)) {
            if (retryCount < 2) {
                const delay = (retryCount + 1) * 5000;
                _logger.info(`⚠️ Sync interrotta (pagina in reload). Riprovo tra ${delay / 1000}s... (tentativo ${retryCount + 1}/2)`);
                await new Promise(r => setTimeout(r, delay));
                return syncUnreadMessages(clientInstance, retryCount + 1);
            } else {
                _logger.info('⚠️ Sync annullata dopo 2 tentativi: pagina non ancora stabile. Riproverà al prossimo messaggio.');
            }
        } else {
            _logger.error('❌ Errore durante la sincronizzazione:', error);
        }
    }
}

async function downloadMediaResilient(msg, clientInstance) {
    if (!msg) return null;
    const msgId = getMessageId(msg);

    try {
        if (typeof msg.downloadMedia === 'function') {
            const media = await promiseTimeout(msg.downloadMedia(), 8000, `msg.downloadMedia(${msgId})`);
            if (media && media.data) {
                return media;
            }
        }
    } catch (err) {
        _logger.info(`ℹ️ Download nativo non immediato per ${msgId} (${err.message}), avvio fallback resiliente...`);
    }

    if (!clientInstance || !clientInstance.pupPage) {
        return null;
    }

    try {
        const rawId = msg.id;
        const targetId = msgId;
        const remoteStr = msg.from || (msg.id && typeof msg.id.remote === 'string' ? msg.id.remote : (msg.id?.remote?._serialized || msg.id?.remote?.$1));

        const result = await clientInstance.pupPage.evaluate(async (targetId, rawId, remoteStr) => {
            const sleep = ms => new Promise(r => setTimeout(r, ms));
            const { Msg, Chat } = window.require('WAWebCollections') || {};
            const { Cmd } = window.require('WAWebCmd') || {};
            const widFactory = window.require('WAWebWidFactory');

            const rawPart = (rawId && rawId.id) || (targetId && targetId.split('_').pop());

            async function findMsg() {
                try {
                    if (!Msg) return null;

                    if (targetId) {
                        let m = Msg.get(targetId);
                        if (m) return m;
                    }

                    if (rawId) {
                        const s = rawId._serialized || rawId.$1;
                        if (s) {
                            let m = Msg.get(s);
                            if (m) return m;
                        }
                    }

                    if (targetId && typeof Msg.getMessagesById === 'function') {
                        try {
                            const res = await Msg.getMessagesById([targetId]);
                            const m = res?.messages?.[0] || (Array.isArray(res) ? res[0] : null);
                            if (m) return m;
                        } catch (e) {}
                    }
                    if (rawId && typeof Msg.getMessagesById === 'function') {
                        const s = rawId._serialized || rawId.$1;
                        if (s) {
                            try {
                                const res = await Msg.getMessagesById([s]);
                                const m = res?.messages?.[0] || (Array.isArray(res) ? res[0] : null);
                                if (m) return m;
                            } catch (e) {}
                        }
                    }

                    if (Msg.models && Msg.models.length > 0) {
                        const targetIdStr = targetId || (rawId && (rawId._serialized || rawId.$1));
                        for (let i = Msg.models.length - 1; i >= 0; i--) {
                            const mod = Msg.models[i];
                            if (!mod || !mod.id) continue;
                            const modSerialized = mod.id._serialized || mod.id.$1 || (typeof mod.id.toString === 'function' ? mod.id.toString() : '');
                            if (targetIdStr && (modSerialized === targetIdStr || modSerialized.includes(targetIdStr))) return mod;
                            if (rawPart && mod.id.id === rawPart) return mod;
                        }
                    }

                    if (Chat && remoteStr) {
                        let chat = Chat.get(remoteStr);
                        if (!chat && widFactory) {
                            try { chat = Chat.get(widFactory.createWid(remoteStr)); } catch (e) {}
                        }
                        if (chat) {
                            if (chat.msgs) {
                                const m = (targetId && chat.msgs.get(targetId)) ||
                                    (rawPart && chat.msgs.models && chat.msgs.models.find(mod => mod?.id?.id === rawPart));
                                if (m) return m;
                            }
                            if (typeof chat.fetchMessages === 'function') {
                                try {
                                    const msgs = await chat.fetchMessages({ limit: 30 });
                                    if (msgs && Array.isArray(msgs)) {
                                        const m = msgs.find(mod => {
                                            if (!mod || !mod.id) return false;
                                            const s = mod.id._serialized || mod.id.$1;
                                            if (s === targetId) return true;
                                            if (rawPart && mod.id.id === rawPart) return true;
                                            return false;
                                        });
                                        if (m) return m;
                                    }
                                } catch (e) {}
                            }
                        }
                    }
                } catch (e) {}
                return null;
            }

            let m = await findMsg();

            for (let i = 0; !m && i < 8; i++) {
                await sleep(250);
                m = await findMsg();
            }

            if (!m) return { error: 'Messaggio non trovato nel database interno di WhatsApp' };

            if (m.mediaData || typeof m.downloadMedia === 'function') {
                try {
                    if (typeof m.downloadMedia === 'function') {
                        m.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
                    } else if (m.mediaData && typeof m.mediaData.downloadMedia === 'function') {
                        m.mediaData.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
                    }
                } catch (e) {}

                for (let i = 0; i < 32; i++) {
                    if (m.mediaData?.mediaStage === 'RESOLVED') break;
                    if (m.mediaObject?.mediaBlob || m.mediaData?.renderableUrl) break;
                    if (m.mediaData?.mediaStage && m.mediaData?.mediaStage.includes('ERROR')) break;
                    await sleep(250);
                }
            }

            let blob = null;

            try {
                const cache = window.require('WAWebMediaInMemoryBlobCache')?.InMemoryMediaBlobCache;
                if (cache) {
                    const hash = m.mediaObject?.filehash || m.filehash || m.mediaData?.filehash || m._data?.filehash;
                    if (hash) blob = cache.get(hash);
                }
            } catch (e) {}

            if (!blob && m.mediaObject?.mediaBlob) {
                try {
                    blob = typeof m.mediaObject.mediaBlob.forceToBlob === 'function'
                        ? m.mediaObject.mediaBlob.forceToBlob()
                        : m.mediaObject.mediaBlob;
                } catch (e) {}
            }

            if (!blob && m.mediaData?.renderableUrl) {
                try {
                    const resp = await window.fetch(m.mediaData.renderableUrl);
                    if (resp.ok) blob = await resp.blob();
                } catch (e) {}
            }

            if (!blob) {
                try {
                    const downloadManager = window.require('WAWebDownloadManager')?.downloadManager;
                    if (downloadManager && typeof downloadManager.downloadAndMaybeDecrypt === 'function') {
                        const mockQpl = { addAnnotations: () => mockQpl, addPoint: () => mockQpl };
                        const rawType = m.type || m.mediaData?.type || m._data?.type || 'image';
                        const safeType = rawType === 'album' ? 'image' : rawType;
                        const decrypted = await downloadManager.downloadAndMaybeDecrypt({
                            directPath: m.directPath || m.mediaData?.directPath || m._data?.directPath,
                            encFilehash: m.encFilehash || m.mediaData?.encFilehash || m._data?.encFilehash,
                            filehash: m.filehash || m.mediaData?.filehash || m._data?.filehash,
                            mediaKey: m.mediaKey || m.mediaData?.mediaKey || m._data?.mediaKey,
                            mediaKeyTimestamp: m.mediaKeyTimestamp || m.mediaData?.mediaKeyTimestamp || m._data?.mediaKeyTimestamp,
                            type: safeType,
                            signal: new AbortController().signal,
                            downloadQpl: mockQpl
                        });
                        if (decrypted) {
                            blob = new Blob([decrypted], { type: m.mimetype || m.mediaData?.mimetype || m._data?.mimetype || 'application/octet-stream' });
                        }
                    }
                } catch (e) {}
            }

            if (!blob) {
                try {
                    let img = null;
                    if (rawPart) {
                        img = document.querySelector(`div[data-id*="${rawPart}"] img[src^="blob:"]`) ||
                              document.querySelector(`div[data-id*="${rawPart}"] img`) ||
                              document.querySelector(`img[src*="${rawPart}"]`);
                    }
                    if (!img) {
                        const allImgs = Array.from(document.querySelectorAll('#main img[src^="blob:"]'));
                        if (allImgs.length > 0) {
                            img = allImgs[allImgs.length - 1];
                        }
                    }
                    if (img && img.src && img.src.startsWith('blob:')) {
                        const resp = await window.fetch(img.src);
                        if (resp.ok) blob = await resp.blob();
                    }
                } catch (e) {}
            }

            if (!blob) {
                return { error: `Impossibile estrarre blob multimediale (mediaStage: ${m.mediaData?.mediaStage || 'sconosciuto'})` };
            }

            const base64 = await new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onloadend = () => {
                    if (typeof reader.result === 'string') {
                        const commaIdx = reader.result.indexOf(',');
                        resolve(commaIdx !== -1 ? reader.result.substring(commaIdx + 1) : reader.result);
                    } else {
                        resolve('');
                    }
                };
                reader.onerror = () => reject(new Error('Errore FileReader durante lettura Blob'));
                reader.readAsDataURL(blob);
            });

            return {
                data: base64,
                mimetype: m.mimetype || (m.mediaData && m.mediaData.mimetype) || (m._data && m._data.mimetype) || blob.type || 'application/octet-stream',
                filename: m.filename || (m.mediaData && m.mediaData.filename) || (m._data && m._data.filename) || null,
                filesize: blob.size
            };
        }, targetId, rawId, remoteStr);

        if (result && result.data) {
            _logger.info(`✨ Recupero multimediale resiliente riuscito per ${targetId} (${result.mimetype}, ${Math.round((result.filesize || 0) / 1024)} KB)`);
            return result;
        } else if (result && result.error) {
            _logger.warn(`⚠️ Dettaglio tentativo recupero resiliente per ${targetId}: ${result.error}`);
        }
    } catch (evalErr) {
        _logger.error(`❌ Errore in downloadMediaResilient per ${msgId}: ${evalErr.message}`);
    }

    return null;
}

async function processMessage(msg, retryCount = 0) {
    const msgId = getMessageId(msg);
    if (!msgId) {
        _logger.info('⏭ Messaggio di sistema senza ID valido ignorato.');
        return;
    }

    try {
        if (msg.isStatus) return;

        const chat = await promiseTimeout(msg.getChat(), 8000, 'msg.getChat()');
        if (chat.isGroup) return;

        const exists = await db.orderExists(msgId);
        if (exists) return;

        const contact = await promiseTimeout(msg.getContact(), 8000, 'msg.getContact()');
        let contactName = (contact && (contact.name || contact.pushname)) ? (contact.name || contact.pushname) : null;
        if (!contactName || /^[\d\s+\-()]+$/.test(contactName.trim())) {
            try {
                if (chat && chat.name && !/^[\d\s+\-()]+$/.test(chat.name.trim())) {
                    contactName = chat.name;
                }
            } catch (e) {}
        }
        if (!contactName) {
            contactName = contact ? contact.number : 'Cliente';
        }

        const safeContactName = contactName.replace(/[^a-z0-9]/gi, '_');
        if (!/^[a-z0-9_]+$/i.test(safeContactName)) {
            throw new Error('Nome contatto non valido');
        }
        const contactFolder = path.join(PRINT_FOLDER, safeContactName);

        const existingOrders = await db.getOrdersByPhoneAndHasFile(contact.number);

        if (existingOrders.length > 0) {
            const oldRelativeFolder = path.dirname(existingOrders[0].file);

            if (oldRelativeFolder !== safeContactName) {
                const oldFullPath = path.join(PRINT_FOLDER, oldRelativeFolder);
                if (fs.existsSync(oldFullPath)) {
                    _logger.info(`🔄 Sincronizzazione: Rinomino/Sposto cartella da ${oldRelativeFolder} a ${safeContactName}`);
                    try {
                        if (!fs.existsSync(contactFolder)) {
                            fs.renameSync(oldFullPath, contactFolder);
                        } else {
                            const files = fs.readdirSync(oldFullPath);
                            for (const f of files) {
                                const src = path.join(oldFullPath, f);
                                const dest = path.join(contactFolder, f);
                                if (!fs.existsSync(dest)) fs.renameSync(src, dest);
                            }
                            try { if (fs.readdirSync(oldFullPath).length === 0) fs.rmdirSync(oldFullPath); } catch(e){}
                        }

                        await db.updateContactOrdersFolder(contact.number, contactName, safeContactName);
                    } catch (err) {
                        _logger.error('❌ Errore sincronizzazione nomi:', err);
                    }
                }
            }
        }

        const body = msg.body || "";
        const detectedService = linkDownloader.detectService(body);

        if (detectedService) {
            _logger.info(`🔗 Rilevato link ${detectedService} da: ${contactName}`);

            if (!fs.existsSync(contactFolder)) {
                fs.mkdirSync(contactFolder, { recursive: true });
            }

            const timestamp = generateUniqueOrderId();
            const prefix = `${timestamp}_link`;
            const result = await linkDownloader.download(body, contactFolder, prefix);

            if (result.success) {
                const relativePath = `${safeContactName}/${path.basename(result.filepath)}`;
                _logger.info(`✅ Link scaricato: ${relativePath}`);

                const ext = path.extname(result.filename).toLowerCase().replace('.', '');
                let orderType = 'documento';
                if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) orderType = 'immagine';
                if (['pdf'].includes(ext)) orderType = 'pdf';

                await saveOrderInfo({
                    id: timestamp,
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: relativePath,
                    tipo: orderType,
                    messaggio: `Link ${detectedService}: ${body}`,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: 'nuovo'
                });

                return;
            } else {
                _logger.error(`❌ Errore download link: ${result.error}`);
            }
        }

        if (msg.hasMedia) {
            _logger.info(`📩 Messaggio con media da: ${contactName} | Tipo: ${msg.type || 'sconosciuto'}`);
            let media = null;

            try {
                media = await msg.downloadMedia();
            } catch (mediaErr) {
                _logger.warn(`⚠️ msg.downloadMedia() per ${msgId} non immediato: ${mediaErr.message}`);
            }

            if (!media || !media.data) {
                try {
                    media = await downloadMediaResilient(msg, client);
                } catch (resilientErr) {
                    _logger.warn(`⚠️ downloadMediaResilient per ${msgId} fallito: ${resilientErr.message}`);
                }
            }

            if (media) {
                if (!fs.existsSync(contactFolder)) {
                    fs.mkdirSync(contactFolder, { recursive: true });
                }

                const mimeMap = {
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
                    'application/msword': 'doc',
                    'application/pdf': 'pdf',
                    'application/vnd.ms-excel': 'xls',
                    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
                    'application/vnd.ms-powerpoint': 'ppt',
                    'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
                    'text/plain': 'txt',
                    'text/csv': 'csv',
                    'image/jpeg': 'jpg',
                    'image/png': 'png',
                    'image/gif': 'gif',
                    'image/webp': 'webp',
                    'image/bmp': 'bmp',
                    'image/tiff': 'tiff',
                    'video/mp4': 'mp4',
                    'application/zip': 'zip',
                    'audio/ogg; codecs=opus': 'ogg',
                    'audio/ogg': 'ogg',
                    'audio/mpeg': 'mp3',
                    'audio/mp4': 'm4a'
                };

                let ext = mimeMap[media.mimetype] || media.mimetype?.split('/')[1]?.split(';')[0] || 'bin';
                if (ext.includes('wordprocessingml')) ext = 'docx';
                if (ext.includes('spreadsheetml')) ext = 'xlsx';
                if (ext.includes('presentationml')) ext = 'pptx';

                let orderType = media.mimetype;
                if (msg.type === 'ptt' || msg.type === 'audio') {
                    orderType = 'audio';
                    if (!ext || ext === 'bin') ext = 'ogg';
                } else if (media.mimetype && media.mimetype.startsWith('image/')) {
                    orderType = 'immagine';
                } else if (media.mimetype === 'application/pdf') {
                    orderType = 'pdf';
                }

                const timestamp = generateUniqueOrderId();
                let fileName;

                if (media.filename) {
                    const originalName = media.filename;
                    const originalExt = path.extname(originalName).replace('.', '');
                    const safeOriginalName = originalName.replace(/[^a-z0-9\.\-_]/gi, '_');
                    
                    if (originalExt) {
                        ext = originalExt;
                        fileName = `${timestamp}_${safeOriginalName}`;
                    } else {
                        fileName = `${timestamp}_${safeOriginalName}.${ext}`;
                    }
                } else {
                    const randomSuffix = Math.random().toString(36).substring(2, 6);
                    fileName = `${timestamp}_${randomSuffix}.${ext}`;
                }

                const filePath = path.join(contactFolder, fileName);
                const buffer = Buffer.from(media.data, 'base64');
                fs.writeFileSync(filePath, buffer);

                const relativePath = `${safeContactName}/${fileName}`;
                _logger.info(`✅ File salvato: ${relativePath} (Tipo: ${orderType})`);

                await saveOrderInfo({
                    id: timestamp,
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: relativePath,
                    tipo: orderType,
                    messaggio: msg.body,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: 'nuovo'
                });
            } else {
                _logger.warn(`⚠️ Impossibile scaricare i media per il messaggio ${msgId}. Salvo come nota.`);
                const warningMessage = msg.body
                    ? `${msg.body}\n\n⚠️ (Errore: Impossibile scaricare l'allegato)`
                    : `⚠️ (Errore: Impossibile scaricare l'allegato)`;

                await saveOrderInfo({
                    id: generateUniqueOrderId(),
                    msgId: msgId,
                    cliente: contactName,
                    telefono: contact.number,
                    file: null,
                    tipo: 'nota',
                    messaggio: warningMessage,
                    data: new Date(msg.timestamp * 1000).toISOString(),
                    stato: 'nuovo'
                });
            }

        } else if (msg.body && !msg.fromMe) {
            _logger.info(`💬 Testo da ${contactName}: ${msg.body}`);
            saveNote(contactName, msg.body);

            await saveOrderInfo({
                id: generateUniqueOrderId(),
                msgId: msgId,
                cliente: contactName,
                telefono: contact.number,
                file: null,
                tipo: 'nota',
                messaggio: msg.body,
                data: new Date(msg.timestamp * 1000).toISOString(),
                stato: 'nuovo'
            });
        }

    } catch (error) {
        _logger.info(`🔍 Dettaglio errore per msg ${msgId || '?'}: ${error.message}\n${error.stack}`);
        if (isPuppeteerContextError(error)) {
            if (retryCount < 3) {
                const delay = (retryCount + 1) * 3000;
                _logger.info(`⚠️ Retry msg ${msgId || '?'} tra ${delay / 1000}s (tentativo ${retryCount + 1}/3)...`);
                await new Promise(r => setTimeout(r, delay));
                return processMessage(msg, retryCount + 1);
            } else {
                _logger.info(`⚠️ Messaggio ${msgId || 'ID sconosciuto'} non processabile dopo 3 tentativi (pagina instabile).`);
            }
        } else {
            _logger.error('❌ Errore processamento messaggio:', error);
        }
    }
}

async function processMessageSafe(msg) {
    const msgId = getMessageId(msg);
    if (!msgId) {
        _logger.info('⏭ Messaggio di sistema senza ID valido ignorato.');
        return;
    }
    return processMessage(msg, 0);
}

function moveContactFolderOnDisk(phone, newFolder) {
    try {
        if (!phone || !newFolder) return;
        const targetDir = path.join(PRINT_FOLDER, newFolder);
        
        const possibleOldFolders = [
            path.join(PRINT_FOLDER, phone.trim()),
            path.join(PRINT_FOLDER, phone.replace(/[^a-z0-9]/gi, '_'))
        ];

        for (const oldDir of possibleOldFolders) {
            if (fs.existsSync(oldDir) && oldDir !== targetDir) {
                if (!fs.existsSync(targetDir)) {
                    fs.mkdirSync(targetDir, { recursive: true });
                }
                const files = fs.readdirSync(oldDir);
                for (const file of files) {
                    const src = path.join(oldDir, file);
                    const dest = path.join(targetDir, file);
                    try {
                        if (!fs.existsSync(dest)) {
                            fs.renameSync(src, dest);
                        }
                    } catch (e) {
                        _logger.warn(`⚠️ Errore spostamento file ${file}:`, e.message);
                    }
                }
                try {
                    if (fs.readdirSync(oldDir).length === 0) {
                        fs.rmdirSync(oldDir);
                    }
                } catch (e) {}
            }
        }
    } catch (err) {
        _logger.warn(`⚠️ Errore moveContactFolderOnDisk per ${phone}:`, err.message);
    }
}

async function syncContactNames() {
    if (!client || wpStatus !== 'CONNECTED') return;
    try {
        await repairMismatchedFolders();

        const orders = await db.getOrders(9999);
        const numericContacts = new Map();
        orders.forEach(o => {
            if (!o.telefono || o.telefono.startsWith('tg_') || o.telefono.includes('@')) return;
            const clientTrimmed = o.cliente ? o.cliente.trim() : '';
            if (o.telefono && clientTrimmed && (clientTrimmed === o.telefono.trim() || /^[\d\s+\-()]+$/.test(clientTrimmed))) {
                numericContacts.set(o.telefono, clientTrimmed);
            }
        });

        if (numericContacts.size === 0) return;

        _logger.info(`🔄 syncContactNames: trovati ${numericContacts.size} contatti con nome numerico da risolvere...`);

        let chatNameMap = new Map();
        try {
            const allChats = await promiseTimeout(client.getChats(), 10000, 'getChats() for syncContactNames');
            allChats.forEach(chat => {
                if (!chat.isGroup && chat.id && chat.id.user && chat.name && !/^[\d\s+\-()]+$/.test(chat.name.trim())) {
                    chatNameMap.set(chat.id.user, chat.name);
                }
            });
            _logger.info(`📋 syncContactNames: ${chatNameMap.size} chat caricate come mappa di fallback.`);
        } catch (chatErr) {
            _logger.warn('⚠️ syncContactNames: impossibile caricare le chat per fallback:', chatErr.message);
        }

        for (const [phone, currentName] of numericContacts.entries()) {
            try {
                let resolvedName = null;

                if (chatNameMap.has(phone)) {
                    resolvedName = chatNameMap.get(phone);
                    _logger.info(`✅ Nome risolto via chatMap: ${phone} -> ${resolvedName}`);
                }

                if (!resolvedName) {
                    const candidateJids = phone.includes('@')
                        ? [phone]
                        : [`${phone}@c.us`, `${phone}@lid`];

                    for (const jid of candidateJids) {
                        try {
                            const contact = await promiseTimeout(client.getContactById(jid), 4000, `getContactById(${jid})`);
                            if (contact && (contact.name || contact.pushname)) {
                                const nameCandidate = contact.name || contact.pushname;
                                if (nameCandidate && !/^[\d\s+\-()]+$/.test(nameCandidate.trim())) {
                                    resolvedName = nameCandidate;
                                    break;
                                }
                            }
                        } catch (e) {
                            _logger.info(`ℹ️ getContactById(${jid}) fallito: ${e.message}`);
                        }

                        if (resolvedName) break;

                        try {
                            const chat = await promiseTimeout(client.getChatById(jid), 4000, `getChatById(${jid})`);
                            if (chat && chat.name && !/^[\d\s+\-()]+$/.test(chat.name.trim())) {
                                resolvedName = chat.name;
                                break;
                            }
                        } catch (e) {
                            _logger.info(`ℹ️ getChatById(${jid}) fallito: ${e.message}`);
                        }
                    }
                }

                if (resolvedName && !/^[\d\s+\-()]+$/.test(resolvedName.trim())) {
                    const safeName = resolvedName.replace(/[^a-z0-9]/gi, '_');
                    moveContactFolderOnDisk(phone, safeName);
                    await db.updateContactOrdersFolder(phone, resolvedName, safeName);
                    _logger.info(`✅ Nome contatto aggiornato: ${phone} (${currentName}) -> ${resolvedName}`);
                } else {
                    _logger.info(`ℹ️ Nome NON risolto per: ${phone} (${currentName}) — contatto non trovato in rubrica.`);
                }
            } catch (err) {
                _logger.warn(`⚠️ Errore risoluzione nome per ${phone}:`, err.message);
            }
        }
    } catch (err) {
        _logger.error('Errore durante la risoluzione dei nomi contatti:', err);
    }
}

async function getExportableContacts() {
    const orders = await db.getOrders(999999);
    const contactsMap = new Map();

    orders.forEach(o => {
        const phone = o.telefono || '';
        if (!phone) return;
        if (!contactsMap.has(phone)) {
            contactsMap.set(phone, {
                name: o.cliente || phone,
                phone: phone,
                orderCount: 1,
                lastOrder: o.data || ''
            });
        } else {
            const existing = contactsMap.get(phone);
            existing.orderCount += 1;
            if (o.data && (!existing.lastOrder || new Date(o.data) > new Date(existing.lastOrder))) {
                existing.lastOrder = o.data;
            }
            if (o.cliente && !/^\d+$/.test(o.cliente) && /^\d+$/.test(existing.name)) {
                existing.name = o.cliente;
            }
        }
    });

    if (client && wpStatus === 'CONNECTED') {
        try {
            const waContacts = await promiseTimeout(client.getContacts(), 8000, 'client.getContacts()');
            if (waContacts && Array.isArray(waContacts)) {
                waContacts.forEach(c => {
                    const number = c.number || (c.id ? c.id.user : null);
                    if (!number || c.isGroup) return;
                    const name = c.name || c.pushname || number;
                    if (!contactsMap.has(number)) {
                        contactsMap.set(number, {
                            name: name,
                            phone: number,
                            orderCount: 0,
                            lastOrder: ''
                        });
                    } else {
                        const existing = contactsMap.get(number);
                        if (name && !/^\d+$/.test(name) && /^\d+$/.test(existing.name)) {
                            existing.name = name;
                        }
                    }
                });
            }
        } catch (err) {
            _logger.warn('⚠️ Impossibile recuperare contatti extra da WhatsApp per export:', err.message);
        }
    }

    return Array.from(contactsMap.values());
}

async function redownloadOrderMedia(order) {
    if (!order) throw new Error('Ordine non specificato');
    if (!client || !client.pupPage) {
        throw new Error('WhatsApp Web non è connesso o non pronto.');
    }

    _logger.info(`🔄 Tentativo recupero download allegato per ordine ${order.id} (msgId: ${order.msgId}, contatto: ${order.cliente || order.telefono})...`);

    const result = await client.pupPage.evaluate(async (targetMsgId, phone, contactName) => {
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        const { Msg, Chat } = window.require('WAWebCollections') || {};
        const { Cmd } = window.require('WAWebCmd') || {};
        const widFactory = window.require('WAWebWidFactory');

        let chat = null;
        const remotesToTry = [];
        if (phone) {
            const cleanPhone = String(phone).trim();
            if (cleanPhone.includes('@')) {
                remotesToTry.push(cleanPhone);
            } else {
                remotesToTry.push(`${cleanPhone}@lid`);
                remotesToTry.push(`${cleanPhone}@c.us`);
            }
        }
        if (targetMsgId && targetMsgId.includes('_')) {
            const parts = targetMsgId.split('_');
            if (parts.length >= 3) {
                remotesToTry.unshift(parts[1]);
            }
        }

        if (Chat) {
            for (const r of remotesToTry) {
                try {
                    chat = Chat.get(r);
                    if (!chat && widFactory) chat = Chat.get(widFactory.createWid(r));
                    if (chat) break;
                } catch (e) {}
            }
            if (!chat && contactName && Chat.models) {
                chat = Chat.models.find(c => {
                    const title = c.name || c.formattedTitle || (c.contact && (c.contact.name || c.contact.pushname));
                    return title && title.toLowerCase() === String(contactName).toLowerCase();
                });
            }
        }

        if (chat && Cmd && typeof Cmd.openChatBottom === 'function') {
            try {
                await Cmd.openChatBottom({ chat });
                await sleep(800);
            } catch (e) {}
        }

        let m = null;
        const rawPart = targetMsgId && targetMsgId.includes('_') ? targetMsgId.split('_').pop() : targetMsgId;

        if (targetMsgId && Msg) {
            try { m = Msg.get(targetMsgId); } catch (e) {}
        }

        if (!m && targetMsgId && Msg && typeof Msg.getMessagesById === 'function') {
            try {
                const res = await Msg.getMessagesById([targetMsgId]);
                m = res?.messages?.[0] || (Array.isArray(res) ? res[0] : null);
            } catch (e) {}
        }

        if (!m && chat && typeof chat.fetchMessages === 'function') {
            try {
                const msgs = await chat.fetchMessages({ limit: 30 });
                if (msgs && Array.isArray(msgs)) {
                    m = msgs.find(mod => {
                        if (!mod || !mod.id) return false;
                        const s = mod.id._serialized || mod.id.$1;
                        if (s === targetMsgId) return true;
                        if (rawPart && mod.id.id === rawPart) return true;
                        return false;
                    });
                }
            } catch (e) {}
        }

        if (!m && Msg && Msg.models) {
            m = Msg.models.find(mod => {
                if (!mod || !mod.id) return false;
                const s = mod.id._serialized || mod.id.$1;
                if (s === targetMsgId) return true;
                if (rawPart && mod.id.id === rawPart) return true;
                return false;
            });
        }

        if (!m && chat && chat.msgs && chat.msgs.models) {
            for (let i = chat.msgs.models.length - 1; i >= 0; i--) {
                const candidate = chat.msgs.models[i];
                if (candidate && !candidate.id?.fromMe && (candidate.hasMedia || candidate.mediaData || candidate.type === 'image' || candidate.type === 'document')) {
                    m = candidate;
                    break;
                }
            }
        }

        if (m && (m.mediaData || typeof m.downloadMedia === 'function')) {
            try {
                if (typeof m.downloadMedia === 'function') {
                    m.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
                } else if (m.mediaData && typeof m.mediaData.downloadMedia === 'function') {
                    m.mediaData.downloadMedia({ downloadEvenIfExpensive: true, rmrReason: 1, isUserInitiated: true });
                }
            } catch (e) {}

            for (let i = 0; i < 20; i++) {
                if (m.mediaData?.mediaStage === 'RESOLVED') break;
                if (m.mediaObject?.mediaBlob || m.mediaData?.renderableUrl) break;
                if (m.mediaData?.mediaStage && m.mediaData?.mediaStage.includes('ERROR')) break;
                await sleep(200);
            }
        }

        let blob = null;

        try {
            const cache = window.require('WAWebMediaInMemoryBlobCache')?.InMemoryMediaBlobCache;
            if (cache) {
                const hash = m?.mediaObject?.filehash || m?.filehash || m?.mediaData?.filehash || m?._data?.filehash;
                if (hash) blob = cache.get(hash);
            }
        } catch (e) {}

        if (!blob && m?.mediaObject?.mediaBlob) {
            try {
                blob = typeof m.mediaObject.mediaBlob.forceToBlob === 'function'
                    ? m.mediaObject.mediaBlob.forceToBlob()
                    : m.mediaObject.mediaBlob;
            } catch (e) {}
        }

        if (!blob && m?.mediaData?.renderableUrl) {
            try {
                const resp = await window.fetch(m.mediaData.renderableUrl);
                if (resp.ok) blob = await resp.blob();
            } catch (e) {}
        }

        if (!blob && m) {
            try {
                const downloadManager = window.require('WAWebDownloadManager')?.downloadManager;
                if (downloadManager && typeof downloadManager.downloadAndMaybeDecrypt === 'function') {
                    const mockQpl = { addAnnotations: () => mockQpl, addPoint: () => mockQpl };
                    const rawType = m.type || m.mediaData?.type || m._data?.type || 'image';
                    const safeType = rawType === 'album' ? 'image' : rawType;
                    const decrypted = await downloadManager.downloadAndMaybeDecrypt({
                        directPath: m.directPath || m.mediaData?.directPath || m._data?.directPath,
                        encFilehash: m.encFilehash || m.mediaData?.encFilehash || m._data?.encFilehash,
                        filehash: m.filehash || m.mediaData?.filehash || m._data?.filehash,
                        mediaKey: m.mediaKey || m.mediaData?.mediaKey || m._data?.mediaKey,
                        mediaKeyTimestamp: m.mediaKeyTimestamp || m.mediaData?.mediaKeyTimestamp || m._data?.mediaKeyTimestamp,
                        type: safeType,
                        signal: new AbortController().signal,
                        downloadQpl: mockQpl
                    });
                    if (decrypted) {
                        blob = new Blob([decrypted], { type: m.mimetype || m.mediaData?.mimetype || m._data?.mimetype || 'image/jpeg' });
                    }
                }
            } catch (e) {}
        }

        if (!blob) {
            try {
                let img = null;
                if (rawPart) {
                    img = document.querySelector(`div[data-id*="${rawPart}"] img[src^="blob:"]`) ||
                          document.querySelector(`div[data-id*="${rawPart}"] img`);
                }
                if (!img) {
                    const allImgs = Array.from(document.querySelectorAll('#main img[src^="blob:"]'));
                    if (allImgs.length > 0) {
                        img = allImgs[allImgs.length - 1];
                    }
                }
                if (img && img.src && img.src.startsWith('blob:')) {
                    const resp = await window.fetch(img.src);
                    if (resp.ok) blob = await resp.blob();
                }
            } catch (e) {}
        }

        if (!blob) {
            return { error: 'Impossibile estrarre il file multimediale da WhatsApp Web.' };
        }

        const base64 = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                if (typeof reader.result === 'string') {
                    const commaIdx = reader.result.indexOf(',');
                    resolve(commaIdx !== -1 ? reader.result.substring(commaIdx + 1) : reader.result);
                } else {
                    resolve('');
                }
            };
            reader.onerror = () => reject(new Error('Errore FileReader durante lettura Blob'));
            reader.readAsDataURL(blob);
        });

        return {
            data: base64,
            mimetype: (m && (m.mimetype || m.mediaData?.mimetype || m._data?.mimetype)) || blob.type || 'image/jpeg',
            filename: (m && (m.filename || m.mediaData?.filename || m._data?.filename)) || null
        };
    }, order.msgId, order.telefono, order.cliente);

    if (!result || !result.data) {
        throw new Error((result && result.error) || 'Download non riuscito da WhatsApp Web');
    }

    const extMap = {
        'image/jpeg': 'jpg',
        'image/png': 'png',
        'image/webp': 'webp',
        'application/pdf': 'pdf'
    };
    const ext = extMap[result.mimetype] || result.mimetype?.split('/')[1]?.split(';')[0] || 'jpg';
    const contactName = order.cliente || order.telefono || 'Cliente';
    const safeContactName = contactName.replace(/[^a-z0-9]/gi, '_');
    const contactFolder = path.join(PRINT_FOLDER, safeContactName);
    if (!fs.existsSync(contactFolder)) {
        fs.mkdirSync(contactFolder, { recursive: true });
    }

    const timestamp = Date.now();
    const fileName = `${timestamp}_recuperato.${ext}`;
    const filePath = path.join(contactFolder, fileName);
    fs.writeFileSync(filePath, Buffer.from(result.data, 'base64'));

    const relativePath = `${safeContactName}/${fileName}`;
    const cleanMsg = (order.messaggio || '')
        .replace(/\n\n⚠️ \(Errore: Impossibile scaricare l'allegato\)/g, '')
        .replace(/⚠️ \(Errore: Impossibile scaricare l'allegato\)/g, '')
        .trim();

    order.file = relativePath;
    order.tipo = (result.mimetype && result.mimetype.startsWith('image/')) ? 'immagine' : (result.mimetype === 'application/pdf' ? 'pdf' : 'documento');
    order.messaggio = cleanMsg;
    order.stato = 'nuovo';

    await db.saveOrder(order);
    _logger.info(`🎉 Recupero download completato con successo per ordine ${order.id}: salvato in ${relativePath}`);
    return { success: true, order };
}

async function applyBrowserCompatibilityPatches(page) {
    if (!page || page.isClosed()) return;
    try {
        await page.evaluate(() => {
            // 1. String.prototype.isBot - fondamentale quando remote è una stringa serializzata
            if (typeof String.prototype.isBot !== 'function') {
                String.prototype.isBot = function () {
                    return (this.includes && (this.includes('@bot') || this.includes('bot@'))) ? true : false;
                };
            }

            // 2. Wid.prototype.isBot
            try {
                const Wid = window.require && window.require('WAWebWid');
                if (Wid && Wid.prototype && typeof Wid.prototype.isBot !== 'function') {
                    Wid.prototype.isBot = function () {
                        return (this && this.server && this.server.includes('bot')) ? true : false;
                    };
                }
                const WidFactory = window.require && window.require('WAWebWidFactory');
                if (WidFactory) {
                    const sample = WidFactory.createWid('393330000000@c.us');
                    if (sample && sample.constructor && sample.constructor.prototype && typeof sample.constructor.prototype.isBot !== 'function') {
                        sample.constructor.prototype.isBot = function () {
                            return (this && this.server && this.server.includes('bot')) ? true : false;
                        };
                    }
                }
            } catch (e) {}

            // 3. WAWebWamMsgUtils.getWamAgentEngagementType wrapper protetto
            try {
                const WamUtils = window.require && window.require('WAWebWamMsgUtils');
                if (WamUtils && WamUtils.getWamAgentEngagementType && !WamUtils.getWamAgentEngagementType._patched) {
                    const orig = WamUtils.getWamAgentEngagementType;
                    WamUtils.getWamAgentEngagementType = function (e) {
                        try {
                            if (e && e.id && e.id.remote && typeof e.id.remote.isBot !== 'function') {
                                e.id.remote.isBot = () => false;
                            }
                            return orig.apply(this, arguments);
                        } catch (err) {
                            return null;
                        }
                    };
                    WamUtils.getWamAgentEngagementType._patched = true;
                }
            } catch (e) {}
        });
    } catch (err) {
        // Silenzioso se la pagina non è ancora pronta
    }
}

async function sendWhatsAppNotification({ order, message }) {
    if (!client) throw new Error('Client WhatsApp non connesso');

    const remotesToTry = [];

    // 1. Estrai JID dal msgId originale dell'ordine se presente
    if (order.msgId && typeof order.msgId === 'string') {
        const parts = order.msgId.split('_');
        if (parts.length >= 2 && (parts[1].includes('@c.us') || parts[1].includes('@lid') || parts[1].includes('@g.us'))) {
            remotesToTry.push(parts[1]);
        }
    }

    // 2. Aggiungi formati basati sul telefono
    if (order.telefono) {
        const clean = String(order.telefono).trim();
        if (clean.includes('@')) {
            if (!remotesToTry.includes(clean)) remotesToTry.push(clean);
        } else {
            const jidLid = clean.length >= 15 ? clean + '@lid' : null;
            const jidCus = clean + '@c.us';
            if (jidLid && !remotesToTry.includes(jidLid)) remotesToTry.push(jidLid);
            if (!remotesToTry.includes(jidCus)) remotesToTry.push(jidCus);
        }
    }

    // 3. Se tra i candidati c'è un @lid, prova a risolvere il numero telefonico reale (@c.us) via getContactLidAndPhone
    const lidCandidate = remotesToTry.find(r => r.includes('@lid'));
    if (lidCandidate && typeof client.getContactLidAndPhone === 'function') {
        try {
            const lidData = await client.getContactLidAndPhone(lidCandidate);
            const pn = lidData?.[0]?.pn;
            if (pn && !remotesToTry.includes(pn)) {
                remotesToTry.unshift(pn);
                _logger.info(`🔍 Risolto numero reale per LID ${lidCandidate} -> ${pn}`);
            }
        } catch (e) {
            _logger.info(`ℹ️ getContactLidAndPhone non disponibile per ${lidCandidate}: ${e.message}`);
        }
    }

    if (remotesToTry.length === 0) {
        throw new Error('Nessun destinatario valido per la notifica WhatsApp');
    }

    _logger.info(`🚀 Tentativo invio notifica per ${order.cliente || order.telefono} su: ${remotesToTry.join(', ')}`);

    // 4. Prova l'invio via client.sendMessage sui JID candidati
    for (const jid of remotesToTry) {
        try {
            _logger.info(`Tentativo sendMessage verso: ${jid}`);
            const res = await client.sendMessage(jid, message);
            if (res) {
                _logger.info(`✅ Messaggio WhatsApp inviato con successo a: ${jid}`);
                return res;
            } else {
                _logger.warn(`⚠️ sendMessage su ${jid} ha restituito null/undefined (chat non indicizzata per JID diretto)`);
            }
        } catch (sendErr) {
            _logger.warn(`⚠️ Errore sendMessage verso ${jid}: ${sendErr.message}`);
        }
    }

    // 5. Fallback in-page resiliente: cerca il modello Chat attivo (per JID o nome contatto) e invia direttamente
    if (client.pupPage && !client.pupPage.isClosed()) {
        _logger.info(`🔄 Tentativo fallback in-page per: ${order.cliente || order.telefono}...`);
        try {
            const pageResult = await client.pupPage.evaluate(async (candidates, contactName, text) => {
                const { Chat } = window.require('WAWebCollections') || {};
                const widFactory = window.require('WAWebWidFactory');
                if (!Chat) return { success: false, error: 'Chat collection non disponibile' };

                let targetChat = null;

                for (const cand of candidates) {
                    try {
                        if (widFactory) targetChat = Chat.get(widFactory.createWid(cand));
                        if (!targetChat) targetChat = Chat.get(cand);
                        if (targetChat) break;
                    } catch (e) {}
                }

                if (!targetChat && contactName && Chat.models) {
                    targetChat = Chat.models.find(c => {
                        const title = c.name || c.formattedTitle || (c.contact && (c.contact.name || c.contact.pushname));
                        return title && title.toLowerCase() === String(contactName).toLowerCase();
                    });
                }

                if (!targetChat) {
                    return { success: false, error: 'Chat non trovata né per JID né per nome contatto' };
                }

                const sent = await window.WWebJS.sendMessage(targetChat, text, {});
                return { success: !!sent, msgId: sent?.id?._serialized };
            }, remotesToTry, order.cliente, message);

            if (pageResult && pageResult.success) {
                _logger.info(`✅ Notifica WhatsApp inviata con successo tramite fallback in-page (msgId: ${pageResult.msgId})`);
                return pageResult;
            } else {
                _logger.warn(`⚠️ Fallback in-page non riuscito: ${pageResult?.error}`);
            }
        } catch (pageErr) {
            _logger.error(`❌ Errore durante il fallback in-page: ${pageErr.message}`);
        }
    }

    throw new Error(`Impossibile inviare la notifica WhatsApp a ${order.cliente || order.telefono}. La chat WhatsApp non è stata trovata.`);
}

async function logout() {
    _logger.info('🔄 Richiesta Logout Ricevuta...');
    if (client) {
        let pid = null;
        try {
            if (client.pupBrowser && client.pupBrowser.process()) {
                pid = client.pupBrowser.process().pid;
            }
        } catch (e) { }

        try {
            await client.logout();
            _logger.info('✅ Logout effettuato.');
        } catch (err) {
            _logger.info('ℹ️ Client già disconnesso o logout non necessario.');
        }
        try {
            const destroyPromise = client.destroy();
            const timeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Timeout distruzione client')), 5000)
            );
            await Promise.race([destroyPromise, timeoutPromise]);
            await new Promise(r => setTimeout(r, 1000));
            client = null;
            _logger.info('✅ Client distrutto.');
        } catch (err) {
            _logger.info('❌ Errore o Timeout durante la distruzione del client:', err.message);
            client = null;
        }

        if (pid) {
            try { execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
            await new Promise(r => setTimeout(r, 1000));
        }
    }

    const config = getConfig();
    config.clientId = 'session_' + Date.now();
    saveConfig(config);
    _logger.info(`🔄 Generata nuova cartella sessione per scavalcare i file in uso: ${config.clientId}`);

    const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
    if (fs.existsSync(cachePath)) {
        try {
            fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 });
            _logger.info('🗑️ Cache rimossa.');
        } catch (err) {
            _logger.error('⚠️ Errore rimozione cache:', err.message);
        }
    }

    wpStatus = 'DISCONNECTED';
    latestQR = null;
    isInitializing = false;

    setTimeout(initializeClient, 2000);
    return { success: true, message: 'Disconnesso. Il client si sta riavviando.' };
}

async function reset() {
    _logger.info('🔄 Richiesta RESET Sessione Ricevuta...');
    if (client) {
        let pid = null;
        try {
            if (client.pupBrowser && client.pupBrowser.process()) {
                pid = client.pupBrowser.process().pid;
            }
        } catch (e) { }

        try {
            const destroyPromise = client.destroy();
            const timeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Timeout distruzione client durante reset')), 5000)
            );
            await Promise.race([destroyPromise, timeoutPromise]);
            await new Promise(r => setTimeout(r, 1000));
            _logger.info('✅ Client distrutto durante reset.');
        } catch (err) {
            _logger.info('ℹ️ Errore/Timeout distruzione client durante reset:', err.message);
        }
        client = null;

        if (pid) {
            _logger.info(`🧹 Forzo sicurezza kill su PID noto del browser: ${pid}`);
            try { execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
            await new Promise(r => setTimeout(r, 1500));
        }
    }

    const config = getConfig();
    config.clientId = 'session_' + Date.now();
    saveConfig(config);
    _logger.info(`🗑️ Nuova sessione assegnata: ${config.clientId}. Vecchia folder ignorata se bloccata.`);

    const cachePath = path.join(DATA_DIR, '.wwebjs_cache');
    if (fs.existsSync(cachePath)) {
        try {
            fs.rmSync(cachePath, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 });
            _logger.info('🗑️ Cache rimossa durante reset.');
        } catch (err) {
            _logger.error('⚠️ Errore rimozione cache durante reset:', err.message);
        }
    }

    wpStatus = 'DISCONNECTED';
    latestQR = null;
    isInitializing = false;

    setTimeout(initializeClient, 2000);
    return { success: true, message: 'Reset completato. Il client si sta riavviando.' };
}

async function shutdown() {
    if (client) {
        try {
            const destroyPromise = client.destroy();
            const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout destroy')), 4000));
            await Promise.race([destroyPromise, timeoutPromise]).catch(err => {
                _logger.error('Errore durante client.destroy in shutdown:', err.message);
            });
        } catch (err) { }
        client = null;
    }
}

module.exports = {
    init,
    initializeClient,
    getStatus,
    getWpStatus,
    setWpStatus,
    getLatestQR,
    getClient,
    isReady,
    generateUniqueOrderId,
    enqueueIncomingMessage,
    getMessageId,
    syncUnreadMessages,
    downloadMediaResilient,
    processMessage,
    processMessageSafe,
    handleRevokedMessage,
    moveContactFolderOnDisk,
    syncContactNames,
    getExportableContacts,
    redownloadOrderMedia,
    sendWhatsAppNotification,
    logout,
    reset,
    shutdown
};
