const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const db = require('../db');
const { ROOT_DIR, DATA_DIR, PRINT_FOLDER } = require('../modules/paths');
const { getConfig, sanitizeClientFolder } = require('../modules/config');
const { deleteFileWithCleanup, repairMismatchedFolders } = require('../modules/helpers');
const { sendEmailNotification } = require('../modules/email');
const { sendTelegramNotification } = require('../modules/telegram');
const {
    syncContactNames,
    getExportableContacts,
    redownloadOrderMedia,
    sendWhatsAppNotification
} = require('../modules/whatsappClient');

function init({ logger } = {}) {
    const _logger = logger || console;

    // GET /api/orders - Recupero lista ordini
    router.get('/api/orders', async (req, res) => {
        try {
            if (req.query.sync === 'true') {
                await syncContactNames();
            } else {
                syncContactNames().catch(() => {});
            }
            const orders = await db.getOrders(200);
            res.json(orders);
        } catch (error) {
            _logger.error('Errore recupero ordini:', error);
            res.status(500).json({ error: 'Errore interno del database' });
        }
    });

    // GET /api/contacts/export/csv - Esportazione contatti in formato CSV
    router.get('/api/contacts/export/csv', async (req, res) => {
        try {
            const contacts = await getExportableContacts();
            let csvContent = '\uFEFF'; // UTF-8 BOM per Excel
            csvContent += 'Nome;Telefono;Totale Ordini;Ultimo Ordine\n';

            contacts.forEach(c => {
                const safeName = (c.name || '').replace(/;/g, ',');
                const phone = (c.phone || '').replace(/;/g, '');
                const count = c.orderCount || 0;
                const lastDate = c.lastOrder ? new Date(c.lastOrder).toLocaleString('it-IT') : 'N/D';
                csvContent += `"${safeName}";"${phone}";${count};"${lastDate}"\n`;
            });

            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', 'attachment; filename="rubrica_printzap.csv"');
            res.status(200).send(csvContent);
        } catch (err) {
            _logger.error('Errore export CSV:', err);
            res.status(500).json({ error: 'Errore durante la generazione del file CSV' });
        }
    });

    // GET /api/contacts/export/vcf - Esportazione contatti in formato VCF (vCard)
    router.get('/api/contacts/export/vcf', async (req, res) => {
        try {
            const contacts = await getExportableContacts();
            let vcfContent = '';

            contacts.forEach(c => {
                let phone = (c.phone || '').replace(/[^0-9+]/g, '');
                if (!phone) return;
                if (!phone.startsWith('+') && !phone.startsWith('00')) {
                    if (phone.startsWith('39') && phone.length >= 10) {
                        phone = '+' + phone;
                    } else if (phone.length === 10) {
                        phone = '+39' + phone;
                    }
                }

                const name = c.name || phone;

                vcfContent += 'BEGIN:VCARD\r\n';
                vcfContent += 'VERSION:3.0\r\n';
                vcfContent += `FN:${name}\r\n`;
                vcfContent += `TEL;TYPE=CELL:${phone}\r\n`;
                vcfContent += 'END:VCARD\r\n';
            });

            res.setHeader('Content-Type', 'text/vcard; charset=utf-8');
            res.setHeader('Content-Disposition', 'attachment; filename="rubrica_printzap.vcf"');
            res.status(200).send(vcfContent);
        } catch (err) {
            _logger.error('Errore export VCF:', err);
            res.status(500).json({ error: 'Errore durante la generazione del file VCF' });
        }
    });

    // GET /api/stats - Statistiche complessive (con supporto filtri periodo)
    router.get('/api/stats', async (req, res) => {
        try {
            const { period, from, to } = req.query;
            const stats = await db.getStatistics({ period, from, to });
            res.json(stats);
        } catch (err) {
            _logger.error('Errore recupero statistiche:', err);
            res.status(500).json({ error: 'Impossibile caricare le statistiche.' });
        }
    });

    // POST /api/stats/reset-today - Reset statistiche della giornata odierna
    router.post('/api/stats/reset-today', async (req, res) => {
        try {
            const result = await db.resetTodayStatistics();
            _logger.info(`🧹 Statistiche della giornata azzerate: ${result.updatedRows} ordini spostati in archivio.`);
            res.json({ success: true, message: 'Statistiche della giornata azzerate con successo.', updatedOrders: result.updatedRows });
        } catch (err) {
            _logger.error('Errore azzeramento statistiche giornata:', err);
            res.status(500).json({ error: 'Impossibile azzerare le statistiche di oggi.' });
        }
    });

    // POST /api/stats/reset-all - Reset totale dell'archivio ordini
    router.post('/api/stats/reset-all', async (req, res) => {
        try {
            const result = await db.resetAllStatistics();
            _logger.info(`🧹 Reset totale statistiche completato: ${result.updatedRows} ordini spostati in archivio.`);
            res.json({ success: true, message: 'Tutti gli ordini sono stati archiviati con successo.', updatedOrders: result.updatedRows });
        } catch (err) {
            _logger.error('Errore azzeramento totale statistiche:', err);
            res.status(500).json({ error: 'Impossibile azzerare lo storico ordini.' });
        }
    });

    // GET /api/stats/export/excel - Esportazione statistiche in formato Excel (CSV)
    router.get('/api/stats/export/excel', async (req, res) => {
        try {
            const { period, from, to } = req.query;
            const stats = await db.getStatistics({ period, from, to });
            const now = new Date();
            const dateStr = now.toLocaleDateString('it-IT');
            const timeStr = now.toLocaleTimeString('it-IT');

            const periodLabels = {
                all: 'Tutto lo Storico',
                today: 'Oggi',
                yesterday: 'Ieri',
                week: 'Ultimi 7 Giorni',
                month: 'Questo Mese',
                custom: `Personalizzato (${from || ''} - ${to || ''})`
            };
            const currentPeriodLabel = periodLabels[period] || periodLabels.all;

            let csvContent = '\uFEFF'; // BOM UTF-8 per apertura diretta in Excel
            csvContent += `REPORT STATISTICHE PRINTZAP;Data: ${dateStr} ${timeStr};Periodo: ${currentPeriodLabel}\n\n`;
            csvContent += `INDICATORE;VALORE;NOTE\n`;
            csvContent += `Totale Ordini Periodo;${stats.totalOrders};Ordini nel periodo selezionato\n`;
            csvContent += `Totale Storico Assoluto;${stats.allTimeOrders || stats.totalOrders};Tutti gli ordini registrati nel DB\n`;
            csvContent += `Ordini di Oggi;${stats.todayOrders};Ordini ricevuti nella giornata odierna\n`;
            csvContent += `Ordini Mese Corrente;${stats.thisMonthOrders};Ordini ricevuti nel mese corrente\n`;
            csvContent += `Ordini Stampati;${stats.printedOrders};${stats.totalOrders > 0 ? Math.round((stats.printedOrders / stats.totalOrders) * 100) : 0}% del periodo\n`;
            csvContent += `Ordini In Coda;${stats.pendingOrders};In attesa di stampa\n`;
            csvContent += `Ordini Archiviati;${stats.archivedOrders};Completati e archiviati\n`;
            csvContent += `Clienti Unici;${stats.uniqueContacts};Contatti distinti nel periodo\n`;
            csvContent += `Volume Dati Ricevuto;${stats.totalSizeFormatted || '0 B'};Peso totale allegati su disco\n`;
            csvContent += `File / Allegati;${stats.filesCount};Totale file ricevuti\n`;
            csvContent += `Documenti PDF;${stats.pdfCount || 0};File PDF\n`;
            csvContent += `Immagini / Foto;${stats.imagesCount || 0};JPG, PNG, WebP\n`;
            csvContent += `Documenti Office / Altro;${stats.docsCount || 0};Word, Excel, PPT, Zip\n`;
            csvContent += `Note di Testo;${stats.notesCount};Messaggi scritti\n`;
            csvContent += `Messaggi Vocali;${stats.audioCount};File audio ricevuti\n`;
            csvContent += `Ora di Punta;"${stats.peakHour}";Fascia oraria max affluenza\n`;
            csvContent += `Giorno di Maggior Affluenza;"${stats.peakDay}";Giorno settimana max ordini\n\n`;

            csvContent += `CANALE DI RICEZIONE;CONTEGGIO;PERCENTUALE\n`;
            csvContent += `WhatsApp Web;${stats.whatsappOrders};${stats.totalOrders > 0 ? Math.round((stats.whatsappOrders / stats.totalOrders) * 100) : 0}%\n`;
            csvContent += `Telegram Bot;${stats.telegramOrders};${stats.totalOrders > 0 ? Math.round((stats.telegramOrders / stats.totalOrders) * 100) : 0}%\n`;
            csvContent += `E-mail (IMAP);${stats.emailOrders};${stats.totalOrders > 0 ? Math.round((stats.emailOrders / stats.totalOrders) * 100) : 0}%\n`;
            csvContent += `Web Bancone (Self-Service);${stats.webOrders || 0};${stats.totalOrders > 0 ? Math.round(((stats.webOrders || 0) / stats.totalOrders) * 100) : 0}%\n\n`;

            if (stats.topClients && stats.topClients.length > 0) {
                csvContent += `TOP 5 CLIENTI PIU' ATTIVI;ORDINI TOTALI;STAMPATI;FILE;CANALE PRINCIPALE\n`;
                stats.topClients.forEach((c, idx) => {
                    csvContent += `#${idx + 1} ${c.cliente} (${c.telefono});${c.count};${c.printed};${c.files};${c.channel}\n`;
                });
                csvContent += `\n`;
            }

            csvContent += `TENDENZA ULTIME 7 GIORNATE;ORDINI TOTALI;ORDINI STAMPATI\n`;
            if (stats.recentDailyTrend) {
                stats.recentDailyTrend.forEach(d => {
                    csvContent += `${d.label};${d.total};${d.printed}\n`;
                });
            }

            const fileName = `statistiche_printzap_${now.toISOString().split('T')[0]}.csv`;
            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
            res.status(200).send(csvContent);
        } catch (err) {
            _logger.error('Errore export Excel statistiche:', err);
            res.status(500).json({ error: 'Errore durante la generazione del file Excel.' });
        }
    });

    // GET /api/stats/export/pdf - Anteprima stampabile PDF delle statistiche
    router.get('/api/stats/export/pdf', async (req, res) => {
        try {
            const { period, from, to } = req.query;
            const stats = await db.getStatistics({ period, from, to });
            const now = new Date();
            const dateStr = now.toLocaleDateString('it-IT', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

            const periodLabels = {
                all: 'Tutto lo Storico',
                today: 'Oggi',
                yesterday: 'Ieri',
                week: 'Ultimi 7 Giorni',
                month: 'Questo Mese',
                custom: `Personalizzato (${from || ''} - ${to || ''})`
            };
            const currentPeriodLabel = periodLabels[period] || periodLabels.all;

            const html = `<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Report Statistiche Stampa - PrintZap (${dateStr})</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; color: #1e293b; margin: 30px; background-color: #ffffff; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0284c7; padding-bottom: 15px; margin-bottom: 25px; }
        .title { font-size: 22px; font-weight: bold; color: #0f172a; }
        .subtitle { font-size: 13px; color: #64748b; margin-top: 4px; }
        .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 25px; }
        .card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; background: #f8fafc; text-align: center; }
        .card-val { font-size: 24px; font-weight: bold; color: #0284c7; }
        .card-lbl { font-size: 12px; color: #64748b; margin-top: 4px; text-transform: uppercase; }
        .section-title { font-size: 16px; font-weight: bold; border-bottom: 1px solid #cbd5e1; padding-bottom: 6px; margin-top: 25px; margin-bottom: 12px; color: #334155; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13px; }
        th, td { border: 1px solid #e2e8f0; padding: 8px 12px; text-align: left; }
        th { background-color: #f1f5f9; color: #334155; }
        tr:nth-child(even) { background-color: #f8fafc; }
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 20px; text-align: right;">
        <button onclick="window.print()" style="padding: 8px 16px; background-color: #0284c7; color: white; border: none; border-radius: 4px; font-size: 14px; cursor: pointer;">🖨️ Stampa / Salva come PDF</button>
    </div>

    <div class="header">
        <div>
            <div class="title">📊 Report Statistiche Stampa & Affluenza</div>
            <div class="subtitle">Generato da PrintZap Cartoleria il ${dateStr} | <strong>Filtro: ${currentPeriodLabel}</strong></div>
        </div>
        <div style="text-align: right; font-size: 12px; color: #64748b;">
            PrintZap Service
        </div>
    </div>

    <div class="grid">
        <div class="card"><div class="card-val">${stats.totalOrders}</div><div class="card-lbl">Ordini Periodo</div></div>
        <div class="card"><div class="card-val" style="color: #25d366;">${stats.printedOrders}</div><div class="card-lbl">Stampati (${stats.totalOrders > 0 ? Math.round((stats.printedOrders/stats.totalOrders)*100) : 0}%)</div></div>
        <div class="card"><div class="card-val" style="color: #f97316;">${stats.pendingOrders}</div><div class="card-lbl">In Coda</div></div>
        <div class="card"><div class="card-val" style="color: #0284c7;">${stats.totalSizeFormatted || '0 B'}</div><div class="card-lbl">Volume Dati Ricevuto</div></div>
        <div class="card"><div class="card-val" style="color: #ec4899;">${stats.uniqueContacts}</div><div class="card-lbl">Clienti Unici</div></div>
        <div class="card"><div class="card-val" style="color: #a855f7;">${stats.allTimeOrders || stats.totalOrders}</div><div class="card-lbl">Totale Storico Assoluto</div></div>
    </div>

    <div class="section-title">⏱️ Affluenza e Orari di Punta</div>
    <table>
        <tr><th>Indicatore</th><th>Valore / Dettaglio</th></tr>
        <tr><td><strong>Ora di Punta (Peak Hour)</strong></td><td>${stats.peakHour}</td></tr>
        <tr><td><strong>Giorno di Maggior Affluenza (Peak Day)</strong></td><td>${stats.peakDay}</td></tr>
    </table>

    <div class="section-title">💬 Canali di Ricezione e Tipologie Contenuti</div>
    <table>
        <thead>
            <tr><th>Canale / Tipologia</th><th>Quantità Ordini</th><th>Percentuale</th></tr>
        </thead>
        <tbody>
            <tr><td>💬 WhatsApp Web</td><td>${stats.whatsappOrders}</td><td>${stats.totalOrders > 0 ? Math.round((stats.whatsappOrders/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>✈️ Telegram Bot</td><td>${stats.telegramOrders}</td><td>${stats.totalOrders > 0 ? Math.round((stats.telegramOrders/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>✉️ E-mail (IMAP)</td><td>${stats.emailOrders}</td><td>${stats.totalOrders > 0 ? Math.round((stats.emailOrders/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>🌐 Web Bancone (Self-Service)</td><td>${stats.webOrders || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.webOrders || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>📕 Documenti PDF</td><td>${stats.pdfCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.pdfCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>🖼️ Immagini / Foto (JPG, PNG)</td><td>${stats.imagesCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.imagesCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>📘 Office / Word / Excel / Altro</td><td>${stats.docsCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.docsCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>🎙️ Messaggi Vocali</td><td>${stats.audioCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.audioCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
            <tr><td>💬 Note di Testo</td><td>${stats.notesCount || 0}</td><td>${stats.totalOrders > 0 ? Math.round(((stats.notesCount || 0)/stats.totalOrders)*100) : 0}%</td></tr>
        </tbody>
    </table>

    ${stats.topClients && stats.topClients.length > 0 ? `
    <div class="section-title">🏆 Top 5 Clienti del Periodo</div>
    <table>
        <thead>
            <tr><th>#</th><th>Cliente</th><th>Telefono</th><th>Ordini</th><th>Stampati</th><th>File</th><th>Canale</th></tr>
        </thead>
        <tbody>
            ${stats.topClients.map((c, i) => `
                <tr>
                    <td><strong>#${i + 1}</strong></td>
                    <td>${c.cliente}</td>
                    <td>${c.telefono}</td>
                    <td><strong>${c.count}</strong></td>
                    <td>${c.printed}</td>
                    <td>${c.files}</td>
                    <td>${c.channel}</td>
                </tr>
            `).join('')}
        </tbody>
    </table>
    ` : ''}

    <div class="section-title">📈 Tendenza degli Ultime 7 Giorni</div>
    <table>
        <thead>
            <tr><th>Data</th><th>Ordini Ricevuti</th><th>Ordini Stampati</th></tr>
        </thead>
        <tbody>
            ${(stats.recentDailyTrend || []).map(d => `<tr><td>${d.label}</td><td>${d.total}</td><td>${d.printed}</td></tr>`).join('')}
        </tbody>
    </table>

    <script>
        window.onload = function() {
            setTimeout(function() { window.print(); }, 500);
        };
    </script>
</body>
</html>`;
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            res.status(200).send(html);
        } catch (err) {
            _logger.error('Errore export PDF statistiche:', err);
            res.status(500).send('Errore durante la generazione del report PDF.');
        }
    });

    // POST /api/orders/:id/print - Contrassegna singolo ordine come stampato
    router.post('/api/orders/:id/print', async (req, res) => {
        const { id } = req.params;
        try {
            await db.markOrderPrinted(id);
            res.json({ success: true });
        } catch (error) {
            _logger.error(`Errore print ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno del database' });
        }
    });

    // POST /api/orders/bulk/print - Contrassegna più ordini come stampati
    router.post('/api/orders/bulk/print', async (req, res) => {
        const { ids } = req.body;
        if (!Array.isArray(ids)) return res.status(400).json({ error: 'IDs must be an array' });
        try {
            for (const id of ids) {
                await db.markOrderPrinted(id);
            }
            res.json({ success: true });
        } catch (error) {
            _logger.error('Errore print bulk:', error);
            res.status(500).json({ error: 'Errore interno del database' });
        }
    });

    // POST /api/notes - Creazione rapida nota manuale
    router.post('/api/notes', async (req, res) => {
        const { cliente, telefono, messaggio } = req.body;
        if (!cliente || !messaggio) return res.status(400).json({ error: 'Missing client or message' });
        try {
            const orderData = {
                id: 'note_' + Date.now(),
                cliente: cliente.trim(),
                telefono: telefono || '',
                file: '',
                data: new Date().toISOString(),
                stato: 'ricevuto',
                tipo: 'nota',
                messaggio: messaggio.trim()
            };
            await db.saveOrder(orderData);
            res.json({ success: true, order: orderData });
        } catch (error) {
            _logger.error('Errore creazione nota manuale:', error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // POST /api/orders/:id/retry-download - Nuovo tentativo di download allegato
    router.post('/api/orders/:id/retry-download', async (req, res) => {
        const { id } = req.params;
        try {
            const order = await db.getOrderById(id);
            if (!order) {
                return res.status(404).json({ error: 'Ordine non trovato' });
            }

            if (order.file && fs.existsSync(path.join(PRINT_FOLDER, order.file))) {
                return res.json({ success: true, order, message: 'File già presente' });
            }

            const result = await redownloadOrderMedia(order);
            return res.json(result);
        } catch (error) {
            _logger.error(`❌ Errore in retry-download per ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno durante il recupero: ' + error.message });
        }
    });

    // POST /api/orders/:id/open-folder - Apertura cartella ordine in Esplora Risorse
    router.post('/api/orders/:id/open-folder', async (req, res) => {
        const { id } = req.params;
        const { telefono, cliente } = req.body || {};
        try {
            let targetFolder = PRINT_FOLDER;
            if (id && id !== 'contact') {
                const order = await db.getOrderById(id);
                if (order && order.file) {
                    const possibleFolder = path.join(PRINT_FOLDER, path.dirname(order.file));
                    if (fs.existsSync(possibleFolder)) {
                        targetFolder = possibleFolder;
                    } else if (order.telefono && fs.existsSync(path.join(PRINT_FOLDER, order.telefono))) {
                        targetFolder = path.join(PRINT_FOLDER, order.telefono);
                    }
                }
            }

            if (targetFolder === PRINT_FOLDER && (cliente || telefono)) {
                const clientFolder = sanitizeClientFolder(cliente || telefono, telefono || cliente);
                const possibleClientFolder = path.join(PRINT_FOLDER, clientFolder);
                if (fs.existsSync(possibleClientFolder)) {
                    targetFolder = possibleClientFolder;
                } else if (telefono && fs.existsSync(path.join(PRINT_FOLDER, telefono))) {
                    targetFolder = path.join(PRINT_FOLDER, telefono);
                }
            }

            const resolvedPath = path.resolve(targetFolder);
            _logger.info(`📂 Apertura cartella Explorer: ${resolvedPath} (ID: ${id})`);

            exec(`explorer "${resolvedPath}"`, (err) => {
                if (err) {
                    exec(`start "" "${resolvedPath}"`);
                }
            });
            res.json({ success: true });
        } catch (error) {
            _logger.error(`Errore open-folder ID ${id}:`, error);
            res.status(500).json({ error: 'Errore durante l\'apertura della cartella' });
        }
    });

    // POST /api/orders/:id/open-file - Apertura file associato all'ordine
    router.post('/api/orders/:id/open-file', async (req, res) => {
        const { id } = req.params;
        try {
            const order = await db.getOrderById(id);
            if (order && order.file) {
                let filePath = path.join(PRINT_FOLDER, order.file);

                if (!fs.existsSync(filePath)) {
                    await repairMismatchedFolders();
                    filePath = path.join(PRINT_FOLDER, order.file);
                }

                if (!fs.existsSync(filePath) && order.telefono) {
                    const altPath = path.join(PRINT_FOLDER, order.telefono, path.basename(order.file));
                    if (fs.existsSync(altPath)) {
                        filePath = altPath;
                    }
                }

                if (fs.existsSync(filePath)) {
                    const resolvedPath = path.resolve(filePath);
                    _logger.info(`📄 Apertura file: ${resolvedPath} (Ordine ID: ${id})`);

                    exec(`start "" "${resolvedPath}"`, (err) => {
                        if (err) {
                            exec(`explorer /select,"${resolvedPath}"`);
                        }
                    });
                    return res.json({ success: true });
                } else {
                    _logger.warn(`⚠️ File non trovato sul disco per ordine ${id}: ${filePath}`);
                    return res.status(404).json({ error: 'File non trovato sul disco' });
                }
            } else {
                _logger.warn(`⚠️ Ordine non trovato o privo di file per ID ${id}`);
                return res.status(404).json({ error: 'Ordine non trovato' });
            }
        } catch (error) {
            _logger.error(`Errore open-file ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // POST /api/orders/:id/notify - Invia notifica di pronto al cliente (WhatsApp, Telegram o Email)
    router.post('/api/orders/:id/notify', async (req, res) => {
        const { id } = req.params;
        const { message: customMessage } = req.body;
        const config = getConfig();

        try {
            const order = await db.getOrderById(id);
            if (order) {
                const message = customMessage || config.notifyMessage || `✅ *Stampa Pronta!* 🖨️\nIl tuo documento è pronto per il ritiro.`;

                // Se è un ordine Telegram
                if (order.telefono && order.telefono.startsWith('tg_')) {
                    try {
                        const chatId = order.telefono.replace('tg_', '');
                        await sendTelegramNotification({ chatId, message });
                        await db.markContactOrdersPrinted(order.telefono);
                        return res.json({ success: true });
                    } catch (tgError) {
                        _logger.error('❌ Errore durante l\'invio del messaggio Telegram:', tgError);
                        return res.status(500).json({ error: 'Impossibile inviare la notifica Telegram: ' + (tgError.response?.data?.description || tgError.message) });
                    }
                }

                // Se è un ordine Email
                if (order.telefono && order.telefono.includes('@')) {
                    if (!config.emailEnabled) {
                        return res.status(400).json({ error: 'Configurazione E-mail non abilitata.' });
                    }

                    // Trova l'account e-mail corretto che ha ricevuto l'ordine
                    let activeAccount = null;
                    if (order.msgId && order.msgId.startsWith('email_')) {
                        const parts = order.msgId.split('_');
                        if (parts.length >= 3) {
                            const accountUser = parts[1];
                            activeAccount = config.emailAccounts.find(acc => acc.emailUser === accountUser);
                        }
                    }

                    // Fallback al primo account e-mail disponibile
                    if (!activeAccount && config.emailAccounts && config.emailAccounts.length > 0) {
                        activeAccount = config.emailAccounts[0];
                    }

                    try {
                        await sendEmailNotification({ to: order.telefono, message, activeAccount });
                        await db.markContactOrdersPrinted(order.telefono);
                        return res.json({ success: true });
                    } catch (emailError) {
                        _logger.error('❌ Errore durante l\'invio dell\'email:', emailError);
                        return res.status(500).json({ error: 'Impossibile inviare la notifica e-mail: ' + emailError.message });
                    }
                }

                // Se è un ordine Web Bancone
                if ((order.telefono && order.telefono.startsWith('web_')) || order.tipo === 'web') {
                    await db.markContactOrdersPrinted(order.telefono);
                    return res.json({ success: true, message: 'Notifica completata: ordine Web Bancone segnato come stampato' });
                }

                // Invio classico via WhatsApp
                try {
                    await sendWhatsAppNotification({ order, message });
                    // Segna come stampato TUTTI gli ordini per questo contatto che non lo sono già
                    await db.markContactOrdersPrinted(order.telefono);
                    res.json({ success: true });
                } catch (error) {
                    _logger.error('Errore invio notifica WhatsApp:', error);
                    res.status(500).json({ error: 'Impossibile inviare il messaggio WhatsApp: ' + error.message });
                }
            } else {
                res.status(404).json({ error: 'Ordine non trovato' });
            }
        } catch (error) {
            _logger.error(`Errore notify ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // DELETE /api/orders/bulk - Archiviazione ordini multipli
    router.delete('/api/orders/bulk', async (req, res) => {
        const { ids } = req.body;
        if (!Array.isArray(ids)) return res.status(400).json({ error: 'IDs must be an array' });

        try {
            const orders = await db.getOrdersByIds(ids);
            orders.forEach(order => {
                if (order.file) {
                    deleteFileWithCleanup(order.file);
                }
            });
            await db.archiveOrders(ids);
            res.json({ success: true, archived: ids.length });
        } catch (error) {
            _logger.error('Errore archiviazione bulk:', error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // DELETE /api/orders - Svuotamento ordini (con filtro opzionale canale)
    router.delete('/api/orders', async (req, res) => {
        try {
            const channel = req.query.channel;
            let orders = await db.getOrders(999999);

            if (channel === 'email') {
                orders = orders.filter(o => o.telefono && o.telefono.includes('@'));
            } else if (channel === 'telegram') {
                orders = orders.filter(o => o.telefono && o.telefono.startsWith('tg_'));
            } else if (channel === 'whatsapp') {
                orders = orders.filter(o => o.telefono && !o.telefono.includes('@') && !o.telefono.startsWith('tg_'));
            }

            orders.forEach(order => {
                if (order.file) {
                    deleteFileWithCleanup(order.file);
                }
            });

            if (channel) {
                const ids = orders.map(o => o.id);
                await db.archiveOrders(ids);
            } else {
                await db.deleteAllOrders();
            }

            res.json({ success: true, deleted: orders.length });
        } catch (error) {
            _logger.error('Errore svuotamento ordini:', error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // DELETE /api/orders/:id - Archiviazione singolo ordine
    router.delete('/api/orders/:id', async (req, res) => {
        const { id } = req.params;
        try {
            const orderToDelete = await db.getOrderById(id);

            if (orderToDelete) {
                if (orderToDelete.file) {
                    deleteFileWithCleanup(orderToDelete.file);
                }
                await db.archiveOrder(id);
                res.json({ success: true });
            } else {
                res.status(404).json({ error: 'Ordine non trovato' });
            }
        } catch (error) {
            _logger.error(`Errore archiviazione ordine ${id}:`, error);
            res.status(500).json({ error: 'Errore interno' });
        }
    });

    // GET /api/reports/export - Generazione Report CSV degli ordini
    router.get('/api/reports/export', async (req, res) => {
        try {
            const orders = await db.getOrders();
            let csv = '\uFEFF'; // UTF-8 BOM per Excel
            csv += 'ID Ordine;Data;Ora;Cliente;Canale / Telefono;Tipo Documento;File;Stato;Dettagli / Messaggio\n';

            for (const ord of orders) {
                const dateObj = new Date(ord.data);
                const dataFormatted = !isNaN(dateObj) ? dateObj.toLocaleDateString('it-IT') : '';
                const oraFormatted = !isNaN(dateObj) ? dateObj.toLocaleTimeString('it-IT') : '';
                const channel = (ord.telefono || '').startsWith('tg_') ? 'Telegram' :
                                (ord.telefono || '').startsWith('web_') ? 'Web Bancone' :
                                (ord.id || '').startsWith('email_') ? 'Email' : 'WhatsApp';

                const cleanMessage = (ord.messaggio || '').replace(/[\r\n]+/g, ' | ').replace(/;/g, ',');
                csv += `"${ord.id}";"${dataFormatted}";"${oraFormatted}";"${ord.cliente}";"${channel} (${ord.telefono})";"${ord.tipo}";"${ord.file}";"${ord.stato}";"${cleanMessage}"\n`;
            }

            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="report_ordini_printzap_${Date.now()}.csv"`);
            res.send(csv);
        } catch (err) {
            _logger.error('❌ Errore durante esportazione report CSV:', err);
            res.status(500).json({ error: 'Impossibile esportare il report: ' + err.message });
        }
    });

    // Static files handler per /api/file
    router.use('/api/file', express.static(PRINT_FOLDER));

    return router;
}

module.exports = { init };
