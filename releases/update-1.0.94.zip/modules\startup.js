const fs = require('fs');
const path = require('path');
const { exec, execSync } = require('child_process');
const { ROOT_DIR, DATA_DIR, AUTH_DIR, isPkg } = require('./paths');
const { getConfig } = require('./config');

let _logger = console;

function init({ logger } = {}) {
    if (logger) _logger = logger;
}

// Sincronizza lo stato di avvio automatico gestendo sia la chiave nel Registro (HKCU\...\Run)
// sia i collegamenti nella cartella Startup (Esecuzione automatica)
function updateAutoStart(enabled) {
    if (process.platform !== 'win32') return;

    const REG_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
    const REG_NAME = 'PrintZap';

    // Individua la cartella Startup dell'utente e quella globale
    const appData = process.env.APPDATA || (process.env.USERPROFILE ? path.join(process.env.USERPROFILE, 'AppData', 'Roaming') : '');
    const userStartupLnk = appData ? path.join(appData, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'PrintZap.lnk') : null;
    const commonStartupLnk = process.env.ProgramData ? path.join(process.env.ProgramData, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'PrintZap.lnk') : null;

    // Determina il percorso del launcher VBS (o fallback a exe diretto)
    const vbsPath = path.join(ROOT_DIR, 'PrintZap.vbs');
    const exePath = path.join(ROOT_DIR, 'PrintZap.exe');
    let launchCmd = null;
    if (fs.existsSync(vbsPath)) {
        // wscript.exe avvia il VBS senza finestra terminale
        launchCmd = `wscript.exe "${vbsPath}"`;
    } else if (fs.existsSync(exePath)) {
        launchCmd = `"${exePath}" "${path.join(ROOT_DIR, 'whatsapp.js')}"`;
    }

    if (enabled) {
        if (launchCmd) {
            const regCmd = `reg add "${REG_KEY}" /v "${REG_NAME}" /t REG_SZ /d "${launchCmd}" /f`;
            exec(regCmd, (err) => {
                if (err) {
                    _logger.error(`❌ Errore aggiunta avvio automatico (Registro): ${err.message}`);
                } else {
                    _logger.info('✅ Avvio automatico con Windows: ATTIVATO (Registro).');
                }
            });
        }
        // Rimuovi eventuali collegamenti duplicati residui dalla cartella Startup (l'avvio è delegato pulitamente al Registro Run)
        [userStartupLnk, commonStartupLnk].forEach(lnkPath => {
            if (lnkPath && fs.existsSync(lnkPath)) {
                try {
                    fs.unlinkSync(lnkPath);
                    _logger.info(`🧹 Rimosso collegamento duplicato da Startup: ${lnkPath}`);
                } catch (e) { }
            }
        });
    } else {
        // 1. Rimuovi la chiave dal Registro di Windows
        const regCmd = `reg delete "${REG_KEY}" /v "${REG_NAME}" /f`;
        exec(regCmd, (err) => {
            if (err && !err.message.includes('Impossibile trovare') && !err.message.includes('The system was unable to find')) {
                _logger.error(`❌ Errore rimozione avvio automatico (Registro): ${err.message}`);
            } else {
                _logger.info('🔕 Avvio automatico con Windows (Registro): DISATTIVATO.');
            }
        });

        // 2. Rimuovi categoricamente il file .lnk dalla cartella Startup di Windows (se presente)
        [userStartupLnk, commonStartupLnk].forEach(lnkPath => {
            if (lnkPath && fs.existsSync(lnkPath)) {
                try {
                    fs.unlinkSync(lnkPath);
                    _logger.info(`🔕 Avvio automatico con Windows: Rimosso collegamento fisico da ${lnkPath}`);
                } catch (e) {
                    _logger.error(`⚠️ Impossibile rimuovere collegamento Startup (${lnkPath}): ${e.message}`);
                }
            }
        });
    }
}

function migrateLegacySessionFolder(clientId) {
    try {
        const activeClientId = clientId || getConfig().clientId;
        if (!activeClientId) return;
        const legacyPath = path.join(DATA_DIR, `session-${activeClientId}`);
        const targetPath = path.join(AUTH_DIR, `session-${activeClientId}`);
        if (fs.existsSync(legacyPath) && !fs.existsSync(targetPath)) {
            _logger.info(`📦 Migrazione cartella sessione attiva in AUTH_DIR (.wwebjs_auth): ${activeClientId}`);
            fs.renameSync(legacyPath, targetPath);
        }
    } catch (e) {
        _logger.info(`ℹ️ Info migrazione sessione: ${e.message}`);
    }
}

function cleanupOldSessions(currentClientId) {
    if (process.platform !== 'win32') return;
    try {
        _logger.info('🧹 Pulizia vecchie cartelle di sessione orfane...');

        const activeClientId = currentClientId || getConfig().clientId;
        const authDir = AUTH_DIR;
        if (fs.existsSync(authDir)) {
            const dirs = fs.readdirSync(authDir);
            dirs.forEach(dir => {
                if (dir.startsWith('session-') && dir !== `session-${activeClientId}`) {
                    try {
                        fs.rmSync(path.join(authDir, dir), { recursive: true, force: true });
                        _logger.info(`🗑️ Rimossa vecchia sessione da AUTH_DIR: ${dir}`);
                    } catch (e) { }
                }
            });
        }

        // Pulisce anche eventuali vecchie cartelle di sessione rimaste accidentalmente nella root DATA_DIR
        if (fs.existsSync(DATA_DIR)) {
            const rootItems = fs.readdirSync(DATA_DIR);
            rootItems.forEach(item => {
                if (item.startsWith('session-') && item !== `session-${activeClientId}`) {
                    try {
                        fs.rmSync(path.join(DATA_DIR, item), { recursive: true, force: true });
                        _logger.info(`🗑️ Rimossa vecchia sessione residua da DATA_DIR: ${item}`);
                    } catch (e) { }
                }
            });
        }

        const oldSessionDir = path.join(DATA_DIR, 'session');
        if (fs.existsSync(oldSessionDir)) {
            try { fs.rmSync(oldSessionDir, { recursive: true, force: true }); } catch (e) { }
        }
    } catch (e) {
        _logger.info(`ℹ️ Output pulizia vecchie sessioni: ${e.message}`);
    }
}

// Rimuove in modo sicuro e approfondito i file di lock orfani lasciati da spegnimenti improvvisi di Windows
function clearSessionLocks(sessionDir) {
    if (!fs.existsSync(sessionDir)) return;
    try {
        const lockFiles = [
            path.join(sessionDir, 'SingletonLock'),
            path.join(sessionDir, 'SingletonCookie'),
            path.join(sessionDir, 'SingletonSocket'),
            path.join(sessionDir, 'DevToolsActivePort'),
            path.join(sessionDir, 'Default', 'SingletonLock'),
            path.join(sessionDir, 'Default', 'SingletonCookie'),
            path.join(sessionDir, 'Default', 'SingletonSocket'),
            path.join(sessionDir, 'Default', 'DevToolsActivePort'),
            path.join(sessionDir, 'Default', 'LOCK'),
            path.join(sessionDir, 'Default', 'IndexedDB', 'https_web.whatsapp.com_0.indexeddb.leveldb', 'LOCK'),
            path.join(sessionDir, 'Default', 'Local Storage', 'leveldb', 'LOCK')
        ];

        lockFiles.forEach(lf => {
            if (fs.existsSync(lf)) {
                try {
                    fs.unlinkSync(lf);
                    _logger.info(`🔓 Rimosso file lock orfano: ${path.basename(lf)} (${path.dirname(lf)})`);
                } catch (err) {
                    _logger.info(`ℹ️ Impossibile rimuovere lockfile ${path.basename(lf)}: ${err.message}`);
                }
            }
        });
    } catch (e) {
        _logger.info(`ℹ️ Info rimozione lock sessione: ${e.message}`);
    }
}

function killOrphanedChrome() {
    if (process.platform !== 'win32') return;
    try {
        _logger.info('🧹 Cerco e termino processi Chrome/Edge bloccati (Powershell+Taskkill)...');

        // Estrai solo i PID numerici dei processi interessati
        const psCmd = `powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \\"Name='chrome.exe' OR Name='msedge.exe'\\" | Where-Object { $_.CommandLine -match 'PrintZap' -or $_.CommandLine -match 'wwebjs' -or $_.CommandLine -match 'cartoleria' } | Select-Object -ExpandProperty ProcessId"`;

        try {
            const pidsOutput = execSync(psCmd, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
            if (pidsOutput) {
                const pids = pidsOutput.split('\n');
                pids.forEach(pidStr => {
                    const pid = pidStr.trim();
                    if (pid && !isNaN(pid)) {
                        _logger.info(`🔫 Trovato PID orfano: ${pid}. Termino albero processi...`);
                        try { execSync(`taskkill /F /T /PID ${pid}`, { stdio: 'ignore' }); } catch (err) { }
                    }
                });
            }
        } catch (e) {
            _logger.info(`ℹ️ powershell non ha trovato processi o ha incontrato un errore`);
        }

        // Breve pausa sincrona pulita per permettere all'OS di rilasciare i lock sui file
        try {
            Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 500);
        } catch (e) { }
    } catch (e) {
        _logger.info(`ℹ️ Output pulizia Chrome fantasma: ${e.message}`);
    }
}

module.exports = {
    init,
    updateAutoStart,
    migrateLegacySessionFolder,
    cleanupOldSessions,
    clearSessionLocks,
    killOrphanedChrome
};
