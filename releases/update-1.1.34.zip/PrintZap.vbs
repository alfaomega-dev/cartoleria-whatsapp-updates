Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appPath = fso.GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = appPath
If fso.FileExists(appPath & "\PrintZap.exe") Then
    ' Delega interamente al launcher nativo PrintZap.exe (gestisce splash solo al 1° avvio e focus/riapertura se già attivo)
    WshShell.Run """" & appPath & "\PrintZap.exe""", 0, False
Else
    WshShell.Run "taskkill /F /IM mshta.exe", 0, True
    WshShell.Run "mshta.exe """ & appPath & "\splash.hta""", 1, False
    WshShell.Run """" & appPath & "\node.exe"" """ & appPath & "\whatsapp.js""", 0, False
End If
