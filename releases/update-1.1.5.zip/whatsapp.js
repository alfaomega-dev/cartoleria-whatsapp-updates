// PrintZap Bytecode Loader - Proprietary & Confidential
const fs = require('fs');
const path = require('path');
require('bytenode');

// Auto-bonifica dei vecchi file .js in chiaro da precedenti installazioni
try {
    const cleanJs = (dir) => {
        if (!fs.existsSync(dir)) return;
        fs.readdirSync(dir).forEach(f => {
            if (f.endsWith('.js')) {
                try { fs.unlinkSync(path.join(dir, f)); } catch(e){}
            }
        });
    };
    cleanJs(path.join(__dirname, 'modules'));
    cleanJs(path.join(__dirname, 'routes'));
    ['db.js', 'link-downloader.js'].forEach(f => {
        const p = path.join(__dirname, f);
        if (fs.existsSync(p)) {
            try { fs.unlinkSync(p); } catch(e){}
        }
    });
} catch (e) {}

// Avvia il core PrintZap da Bytecode V8 nativo
require('./whatsapp.jsc');
